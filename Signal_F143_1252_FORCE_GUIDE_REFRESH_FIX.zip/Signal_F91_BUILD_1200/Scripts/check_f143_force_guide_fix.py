#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'Sources/DebridChannelsTVOSApp.swift'
s=p.read_text()
manual=s.split('    private func runQuickPanelForceRefresh() {',1)[1].split('    private var quickPanelRefreshLabel:',1)[0]
assert 'guard acceptSingleSelect()' not in manual, 'Guide action can be dropped after focus handoff'
assert 'await liveModel.forceRefreshGuide()' in manual
assert 'Requesting fresh guide directly from IPTV provider' in manual
assert 'supersedePending: true' in s.split('    func forceRefreshGuide() async {',1)[1].split('    func suspendForVODPlayback()',1)[0]
assert 'if !userInitiatedForce, index == 0, xmltvURL == xmltvURLs.first' in s
assert 'if providerRefreshIsForced { request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData }' in s
print('F143 manual force-guide refresh regression PASS')
