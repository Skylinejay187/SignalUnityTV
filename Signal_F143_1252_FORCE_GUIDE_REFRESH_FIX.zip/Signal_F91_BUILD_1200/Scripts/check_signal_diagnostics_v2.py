#!/usr/bin/env python3
"""Static telemetry contracts; no credentials or runtime media needed."""
from pathlib import Path
r = Path(__file__).resolve().parents[1]
s = (r/'Sources/SignalDiagnosticCenter.swift').read_text()
b = (r/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
v = (r/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
assert b == v, 'Aether bridge copies diverged'
for term in ('forward_segment_target','buffer_frontier_seconds','ahead_seconds',
             'coverage_percent','buffer_stall_seconds','free_disk_bytes',
             'thermal_level','memory_warning_count','low_power_mode',
             'diagnostics_summary.json','aether_cache_bytes_available',
             'SignalCacheFrontierStall','resourceSampler?.cancel()',
             'guard metrics.contains(key)','maxEvents = 2400'):
    assert term in s, f'Missing instrumentation {term}'
for term in ('Signal.Aether.ForwardCacheTarget','userInfo: ["segments": options.forwardBufferSegments]'):
    assert term in b, f'Missing engine published cache policy {term}'
assert 'No viewing titles, URLs, or credentials' in s
assert 'NOT a byte quota' in s or 'NOT the number of bytes on disk' in s
print('Signal diagnostics v2 instrumentation and privacy static checks PASS')
