#!/usr/bin/env python3
"""Static contract: F143 added user preferences survive protected profile backup/restore."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
app=(r/'Sources/DebridChannelsTVOSApp.swift').read_text()
portable=(r/'Sources/SignalPortableSettings.swift').read_text()
keys={
 'signalOpenLiveChannelInPlaybackFullGuideV1':('openChannelInPlaybackGuide','false'),
 'signalFullGuideVideoLayoutV1':('fullGuideVideoLayout','Preview Left'),
 'signalVODDiscPeekV1':('vodDiscPeekEnabled','false'),
 'signalVODDiscEjectAnimationV1':('vodDiscEjectAnimationEnabled','false'),
 'signalVODSeasonPassStyleV1':('vodSeasonPassStyle','portraitLeft'),
 'signalVODTechnicalBadgePackV1':('vodTechnicalBadgePack','Off'),
 'signalSettingsLayoutV1':('signalSettingsLayout','standard'),
}
for key,(var,default) in keys.items():
  assert f'"{key}": {var}' in app, f'Backup export missing: {key}'
  assert f'settings["{key}"]' in app, f'Backup restore missing: {key}'
  assert f'"{key}": ' in portable, f'Portable backup whitelist missing: {key}'
  assert f'"{key}": "{default}"' in portable if default not in ('false','true') else f'"{key}": {default}' in portable
# Critical UI state restoration should reject unknown layout variants and keep old backups valid.
assert 'restoredSettingsLayout == "vertical" ? "vertical" : "standard"' in app
assert 'savedGuideLayout == "Live Background" ? "Live Background" : "Preview Left"' in app
assert '["portraitLeft", "horizontalRight", "off"].contains(restoredSeasonPass)' in app
assert '["Off", "Signal Neon", "Cinema Silver"].contains(savedBadgePack)' in app
print('F143 backup presentation coverage PASS: 7 keys export/restore/portable whitelist')
