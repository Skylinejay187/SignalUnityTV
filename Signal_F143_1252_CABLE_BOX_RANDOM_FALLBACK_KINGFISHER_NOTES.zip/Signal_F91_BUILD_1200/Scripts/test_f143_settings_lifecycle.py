#!/usr/bin/env python3
"""Structural regression for AppleTV14,1 settings screen isolation."""
from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'Sources/DebridChannelsTVOSApp.swift').read_text()
assert 'private func categoryContent(_ category: SettingsCategory) -> AnyView' in s
slice_=s.split('private func categoryContent(_ category: SettingsCategory) -> AnyView',1)[1].split('private func firstFocus(',1)[0]
for case in ['general','appearance','liveTV','streamingCatalogs','mediaFlowProxy','backupStreaming','catalogHealth','vodPlayer','sourceIntelligence','newEpisodeAlerts','sports','diagnostics','backupRestore']:
    assert f'case .{case}:' in slice_
assert slice_.count('return AnyView(')==13
assert '.id(category) // dispose the previous category tree on switch' in s
chunk=s.split('private var liveTVSourcesSection: some View',1)[1].split('private var liveTVSourcesChunk1',1)[0]
assert 'LazyVStack(alignment: .leading' in chunk
assert all(f'liveTVSourcesChunk{i}' in chunk for i in range(1,6))
assert all(f'private var liveTVSourcesChunk{i}: AnyView' in s for i in range(1,6))
assert 'settingsLayoutButton(title: "Standard"' in s and 'settingsLayoutButton(title: "Vertical List"' in s
assert 'await Task.yield()' in s
print('Settings lifecycle regression PASS: 13 isolated categories, 5 lazy Live TV groups, dual layouts')
