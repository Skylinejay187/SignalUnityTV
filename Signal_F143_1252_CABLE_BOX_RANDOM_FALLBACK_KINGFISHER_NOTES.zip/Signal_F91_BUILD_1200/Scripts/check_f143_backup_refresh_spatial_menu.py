from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'Sources/DebridChannelsTVOSApp.swift').read_text()
c=(Path(__file__).resolve().parents[1]/'Sources/CatalogStore.swift').read_text()
checks={
 'refresh confirmation state':'@State private var confirmBackendBackupRefresh: Bool = false' in s,
 'refresh confirm alert':'"Refresh Existing Signal Backup?"' in s,
 'refresh requires explicit confirmation':'confirmBackendBackupRefresh = true' in s,
 'refresh guard has existing code':'!cleanBackupCode(backendProfileBackupCode).isEmpty else { return }' in s,
 'restore confirmation preserved':'"Restore Signal Settings?"' in s,
 'clear confirmation preserved':'"Clear Restore Code Backup?"' in s,
 'selected surface remains highlighted':'isSelected: store.selectedTab == tab,' in s,
 'position based focus helper':'private func nearestTopMenuTab(for normalizedX: CGFloat)' in s,
 'grid column captured before tile focus cleared':'store.topMenuEntryHorizontalFraction = (CGFloat(column) + 0.5)' in s,
 'position hint consumed':'store.topMenuEntryHorizontalFraction = nil // consume on focus entry' in s,
 'legacy forced Home removed':'requestedOrigin == .live ? .home' not in s,
 'shared focus hint':'var topMenuEntryHorizontalFraction: CGFloat? = nil' in c,
 'same settings controls':'SettingsButton(title: "Restore Code"' in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),k)
assert all(checks.values())
