# Signal F143 – Cable Box Mode (opt-in Unity experience)

Based on F143 backup/restore coverage baseline. This feature does not change masking, Usenet, movie disc, AppleTV14,1 Settings lifecycle, or other playback engine source files.

## Controls and behavior
- Settings → Live TV Sources → Startup Experience: Standard / Cable Box (default Standard).
- Cable Box launch uses the last **actually tuned** channel ID, optionally restores its prior ID on a compatible lineup. It refuses demo channels and sources without stream URLs. When the remembered channel is missing, Cable Box chooses a different available provider channel at random. If no provider channels have loaded yet, it keeps Cable Box selected and waits for the lineup; demo channels are never automatically tuned.
- Starts an existing AetherEngine Live TV playback session, not a second player or a separate screen.
- Press Up in cable fullscreen to reveal Unity menu: Home, Movies, TV Shows, Sports Center, Favorites, Channels, Settings; Full Guide is in the same menu.
- Press Down on video for existing Quick Guide; the video and program information reuse the current player.
- The Unity menu uses the player’s ordered playback-dismissal handoff to re-enter the same persistent Unity root. Channels exposes the full original grid.
- Top menu options: Auto-hide (default, 12 seconds), Always visible, On demand; timeout: 5/12/20 seconds. The menu is transparent when hidden and does not obscure video.
- User preferences and last tuned channel ID are included in protected backup/restore and portable settings, with normalization for older backups.

## Release caveats
- Static Swift parsing, source identity and source regression checks completed. Requires full Xcode/tvOS build and Apple TV test before any claim of operational success.
- The last channel only autoplays when the same channel ID remains in the loaded provider lineup; it does not tune demo channels. If the provider is offline or channel IDs changed, the existing grid remains usable.
- This does not reconfigure tvOS to tune live streams while Signal is suspended or guarantee instantaneous startup on a slow provider.
