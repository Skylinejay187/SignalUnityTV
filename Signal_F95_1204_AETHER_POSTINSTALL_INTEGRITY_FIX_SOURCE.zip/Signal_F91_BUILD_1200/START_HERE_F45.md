# Signal F45 — build 1154

Narrow build correction based on F44 / build 1153. Use the same universal source-ZIP workflow.

## Reported failure and correction

The supplied `Signal_tvOS_build_logs (12).zip` contains one fatal compiler diagnostic:

`DebridChannelsTVOSApp.swift:46983:43: error: implicit use of 'self' in closure; use 'self.' to make capture semantics explicit`

The Quick Guide's `keys.lazy.compactMap` closure called `normalizeGuideKey(key)` without explicit instance capture syntax. Changed that single call to `self.normalizeGuideKey(key)`. The lookup order, exact alias matching, 48-channel window, retained indexes, and cache behavior are unchanged.

This compiler reference originated in the F43 performance work and remained in F44. Swift syntax parsing could not detect the semantic capture requirement. The F45 preflight now extracts this exact production method into a minimal interface harness and typechecks it with the real production resource policy. Its negative control removes `self.` and must reproduce the reported diagnostic. This check runs before the full app build.

All other 126 prior Swift files are byte-identical to F44. Up Next's visible Dismiss controls, autoplay retry repair, Guide appearance/time alignment, prior performance changes, and app-wide settings backup remain intact. App/Top Shelf/project identities are aligned at Signal-F45 / 1.0.1154 / build 1154.

## Validation

Local: one-line scope/hash audit, F44/F43/F40 regression checks, six build-identity tests, remote-thumbnail gate, changed Swift/compile-fixture grammar, YAML, Python, and shell syntax passed. The exact historical fixtures remain intact through reviewed delta projection.

Supplied Actions evidence for F44: preflight passed, including native F43 resource tests and F44 Up Next policy/EPG alignment tests. This is evidence for those tests on F44, not a successful F45 rebuild or device test.

Not run locally: the new F45 Swift semantic compiler gate, full Xcode/tvOS rebuild, and Apple TV runtime tests. No Swift compiler or Apple SDK is installed in this environment. The next macOS Actions run will perform the semantic check and full compilation.
