# Signal F63 — build 1172

Source release based on F62/build1171. Use the existing Universal ZIP build workflow on macOS; this archive is not an installed or signed Apple TV binary.

## Paused playback information

During movie or episode playback, pausing for three uninterrupted seconds reveals a passive information block in the top left (64-point top/left inset). It shows PAUSED, the title, available season/episode and episode name, synopsis, and estimated local end time. Missing fields are omitted. End time means "if resumed now" and uses the existing remaining duration; unknown/invalid duration omits the estimate.

Text fades in over 0.4 seconds and fades out over 0.3 seconds when resumed. The overlay never takes remote focus or handles input. The reveal delay belongs to the current playback presentation, URL, surface generation and eligibility state. Resume, source changes, loading, backgrounding, errors, protected-route checks, browsing panels, seeking, scrubbing, Up Next and dismissal cancel/invalidate the pending reveal. Returning to an eligible pause starts a fresh three-second wait.

There are no additional metadata requests, artwork loads, video surfaces, blur layers, settings or persistent timers. While visible, a local 30-second TimelineView refreshes the end-time estimate; it is removed with the information. The existing title metadata and authoritative playback clock supply all fields. Episode text formatting is deferred until the information is rendered, so ordinary playing clock updates do not repeat it. Episode text formatting is deferred until the information is rendered, so ordinary playing clock updates do not repeat it. Existing episode notifications remain above the information layer.

## Scope and checks

The only changes to the existing app Swift code are the new presentation property and its passive VOD paint layer. All 113 other prior Swift files, including the playback bridge, host, network protection, Search, guide, cache, audio and notification policies are byte-for-byte unchanged from F62. The two new Swift source files are explicitly included in project.yml. Dependencies remain AetherEngine 7.44.0 and Kingfisher 8.11.0.

See F63_VALIDATION.json for checks actually run. Supplied native tests exercise the production policy (delay, cancellation, request/lease ownership, metadata, finite timeline handling) and SDK-check the actual SwiftUI view plus the extracted VOD mapping. They are wired into Scripts/check_f28_source_preflight.sh. This environment has no Swift compiler, Apple SDK or Apple TV, so those native/device checks have NOT been run here. Tree-sitter grammar checks are not compiler validation.

## Required Apple TV verification

1. Pause a movie and an episode. At less than three seconds, no information; after three seconds, title/details fade in at the top left. Resume: fade out without a seek, reload or focus change.
2. Pause/resume rapidly several times, including before the delay completes. No stale reveal; the final pause gets its own full three-second delay.
3. Pause for several minutes. "Ends at" advances with the current local clock. Verify an unknown-duration item shows the remaining available metadata without an invented end time.
4. While paused, open/close player panels, Search, TV and episode browsing; seek; background/foreground; switch episodes and dismiss. No information over a loading/error/browse screen and no delayed reappearance from the previous source.
5. Verify Up Next auto-advance and always-visible Dismiss, show notification delivery, at-home protection continuity, audio boost, foreground recovery and explicit EPG refresh remain functional.
