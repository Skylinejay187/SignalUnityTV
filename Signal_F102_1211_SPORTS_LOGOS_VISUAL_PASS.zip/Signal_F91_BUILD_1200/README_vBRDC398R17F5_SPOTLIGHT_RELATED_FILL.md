# vBRDC398R17F5 — Spotlight Related on Trakt poster fill

- Preserve genuine Trakt related results in their original order.
- Fill short responses up to four portrait posters using real existing catalog items with valid poster URLs.
- Prioritize matching media type and overlapping genres, avoid the current title and duplicate IDs.
- Make the Related on Trakt panel available when catalog fallback items exist even if Trakt returns zero results.
- No synthetic movies, no unrelated random network searches, and no changes to Media Information logo or Cover Flow geometry.

Validation: Swift frontend parse passed on Linux. Full Xcode/tvOS build and device testing not available in this environment. If the user's loaded catalog has fewer than four distinct poster-bearing titles of the same media type, fewer than four will display; no false guarantee of four.
