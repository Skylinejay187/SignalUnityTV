# vBRDC398R17F19 — Performance stabilization checkpoint

Authoritative base: vBRDC398R17F18. Incremental, source-level performance fix only.

## Changed
- Two rotating dashboard ticker `.task(id:)` dependencies previously included every `UnityAnimationCoordinator.revision`. Runtime revisions also change for unrelated navigation recovery and surface events. Their task identity now uses `unityAnimations.allows(.tickerMotion)` instead. SwiftUI still observes the coordinator so permission changes restart/suspend rotation, but unrelated revisions with unchanged ticker permission do not cancel and restart the asynchronous ticker task.
- Version synchronized to 1.0.1124 / build 1124 / vBRDC398R17F19.

## Preserved
- MediaFlow ATS/proxy, F17 Up Next/EOF work, F18 resume-removal and Cover Flow layout, all player and UI paths unchanged.

## Scope and validation
- Swift frontend syntax parsing passed for modified file and animation runtime files.
- Info.plist parsed successfully. ZIP integrity checked.
- No Apple TV runtime, Xcode build, Instruments trace, or measured frame-time improvement in this environment.
- This is NOT a completed app-wide performance audit or release candidate. Do not represent the main lag as resolved.

## Mandatory remaining release work
1. Physical Apple TV Instruments: SwiftUI update groups, Hangs/Hitches, Time Profiler, Core Animation, Metal GPU; 30s idle vs rapid navigation in dashboard, Classic catalog, 3D Cover Flow, Guide, Media Information, playback return.
2. Capture main-thread call stacks on hitches; compare warm/cold image cache and ambient on/off. Inspect image decode/publish costs and catalog store invalidation fan-out.
3. Verify stable catalog row/card identity and focus restoration on dismiss; make scoped patches with before/after traces.
4. Verify retained previews, ambient timers, ticker and background fetches are suspended on covered surfaces.
5. On device regressions: MediaFlow, Up Next at EOF, Resume removal, Cover Flow alignment, Live TV, top-menu focus and backup/restore.
