# Signal F61 — build 1170

Forward from F60 / build 1169. Addresses show episode notifications disappearing during full-screen VOD/Live TV handoff, expiring behind the opening cover and being covered by in-player browsing panels.

## Findings and changes

The previous passive notification timer used `try? await Task.sleep(...)`, followed only by an alert-ID check. Re-preparing an active alert cancels the old timer and starts a replacement for that same alert ID. Cancellation throws out of sleep, but `try?` ignored it, so the old task immediately dismissed the active notification and cancelled its replacement. Entering playback invokes this preparation from both URL and exclusive-playback transitions. The old dismissal also marked an unconfirmed notification as presented, which could suppress it on later scans.

The new production policy returns false on cancelled sleep and checks cancellation again after a completed sleep. Each displayed duration has a unique revocable lease tied to its alert and surface. Cancelling/replacing a timer clears that lease before cancelling the task. A stale timer cannot dismiss a renewed notification with the same alert ID, a different player presentation, an inactive/covered surface or a different alert.

`onAppear` now records which main/player surface actually mounted the notification. The timer and duplicate-progress acknowledgement start only after that receipt is eligible on the foreground visible surface. Player callbacks capture their specific playback presentation ID, so an old surface cannot acknowledge a newer one. Main banner/popup identities include the alert ID. The VOD banner is withheld while the existing matching playback startup cover is displayed, then appears when the cover clears. This changes only the notification input; it does not remount the player or change its URL/session/token.

Foreground return renews an already-mounted notification's display period or drains the retained queue. Backgrounding and a playback-disabled notification scope revoke the timer without consuming the pending alert. Changing surfaces waits for the new surface receipt. The passive in-player banner is drawn above Search/catalog/detail panels, remains non-focusable and cannot pause playback or intercept remote commands.

Previously recorded notification progress is preserved. The app cannot reliably distinguish an old unseen notification incorrectly recorded by the previous bug from one the viewer actually saw. This revision does not erase notification history or replay all past releases. The existing Test New Episode Alert control can be used to check the handoff immediately; real alerts still require followed shows, enabled Follow Center/New Episode Alerts, eligible verified episode metadata and the Main + VOD presentation scope for full-screen playback.

## Preserved scope

The actual metadata scanner, its one low-frequency heartbeat, follow list/snapshots, recent-release eligibility, queue persistence, duplicate suppression, popup actions and user preferences are preserved. No extra polling loop, notification sound, playback operation or global ambient work is added.

Existing production App changes are confined to Root alert delivery/runtime state plus the passive notification's paint order inside VODPlayerScreen. The entire remainder of the VOD implementation is byte-identical, including F57 no-restart continuity, setup/teardown, seek/cache, Up Next/autoplay and engine ownership. All 147 other prior Swift files are byte-identical. Search, Guide, Settings/phone setup, Media Information, CatalogStore/episode metadata, network/proxy safety and the Aether bridge remain unchanged. AetherEngine 7.44.0 and Kingfisher 8.11.0 remain pinned.

## Validation

Executed locally: all 22 available Python preflight checks, including a negative control using the actual F60 timer; six build-identity tests; retained actual phone-page JS flow tests with simulated DOM/transport; exact source-delta/unchanged-file checks; script/shell syntax; Swift grammar comparison plus clean policy/native-test/current Root fixture grammar; ZIP CRC and every-entry/source byte comparison.

Native tests are supplied for cancellation of actual production waits, zero-duration completed/cancelled waits, same-ID timer replacement, stale main/player presentations, inactive/covered surfaces and replaced alert IDs. The macOS preflight also extracts and type-checks the actual Root receipt/timer functions and surface properties against the tvOS SDK.

Native executables, tvOS SDK type-check, full Xcode compilation and physical Apple TV rendering/remote testing have not run here: this environment has no Swift compiler or Apple SDK. Source checks do not prove the reported installed-device behavior is resolved.

Device checks: select Main + VOD scope and a long banner duration; use Test New Episode Alert, then enter VOD before it expires; confirm it survives the handoff and receives its full duration after the opening cover. Repeat Live TV, channel/player presentation changes, Search/Media Information panels, background/resume and Main Only/Main + VOD scope changes. Verify a real newly eligible followed-show episode arrives while playing and duplicate history is respected. Confirm ordinary playback, Up Next and phone setup are stable.
