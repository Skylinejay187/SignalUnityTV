# Signal F51 — build 1160

Forward from F50/build 1159. AetherEngine stays 7.44.0; Kingfisher stays 8.11.0. Source release: full Xcode and physical Apple TV validation are still required.

## Aligned mode is a distinct renderer again

F42 removed the fitted geometry to correct stretched cards; that also removed the visual alignment transform. The aligned flag subsequently fixed the pose/offsets but still used the same ordinary rotation chain as Original.

Aligned now invokes the real GeometryEffect backed by `SignalLiveTVCardProjection.uniformlyFitted`. This centers each projected quad inside its existing slot, using ONE scale for both axes. It preserves the chosen contour/perspective without the old independent X/Y stretching. Matching columns repeat the same quad in all three rows. Original retains its ordinary rotations. The live decoder plane remains flat. The same host is used in the dashboard and full-screen customization, so every preview card displays the selected layout/theme.

F50 Standard/Pop Out values and transition timing remain: Standard 1.025/three-point rise; ready Pop Out 1.09/eight-point rise; 140 ms focus/180 ms preview transition. Reveal timing, 12-card layout, channel focus targets, preview cancellation and native video lifecycle are unchanged. No new rendering loop, shadow/blur or decoder is introduced by alignment.

## Protected-source routing no longer depends on a shared Off switch

The old disableable safety switch is retired. Its legacy backup value is canonicalized to true and a restored false value cannot disable enforcement.

The Full/Light master switches and preferred local profile remain device choices. `applyBackendProfilePayload` filters them before BOTH the generic UserDefaults restore and explicit AppStorage assignments. Their values remain represented in portable backups, but restoring another device's profile does not overwrite local activation decisions. Saved Full/Light server fields, protected passwords, ordinary app/VOD/appearance preferences and the home-anchor identity still restore.

For a protected source:

1. This device verifies its current public egress with small credential-free HTTPS checks of the IPv4 and preferred IPv4/IPv6 routes. A direct route requires consistent results matching the home anchor. No Wi-Fi name or private subnet is treated as proof.
2. The home anchor is learned only from a successful authenticated check of the configured MediaFlow server; a manually typed expected IP is an additional verification pin, not permission to enroll an arbitrary network as home. An imported anchor never counts as a live check of this device.
3. With a verified home match and the master switch Off, direct playback is permitted. After initial verification, the saved anchor can permit direct home playback even if the proxy itself is unavailable.
4. Away, mismatched, failed or uncertain checks never permit direct protected playback. The selected saved Full/Light profile is enforced in memory even when both master switches are Off. A usable authenticated proxy permits playback; missing configuration, failed authentication, unavailability or a pinned-IP mismatch blocks it with an error. The guard does not silently change a shared switch or fall back directly.
5. Network path changes revoke the in-memory home proof. A current protected direct VOD session is stopped with a retry message; Retry rechecks routing before preparing a decoder. No live proof is backed up.

Checks are coalesced and briefly cached (successful public-IP diagnostics 15 seconds, uncertain diagnostics five seconds, recent proxy verification 20 seconds), with invalidation on network-path changes. They are not a frame loop or continuous polling task. Diagnostic requests carry no debrid token, stream URL, cookie or proxy password. A mixed IPv4/IPv6 observation is treated as uncertain and uses the proxy rather than assuming the two addresses represent the same permitted route.

Playback launch is now cancellable while verifying. A generation/ownership check prevents a late result from starting playback after Back or a newer selection. The source opening state clears on a failed route. Verification covers native RD resolving APIs, availability checks, selected source startup, external-player launch and player Retry/initialization. Existing router checks remain at final transport boundaries, including fallback URLs. Older Up Next discovery/countdown/dismissal/commit and engine code remain unchanged.

### Scope and limits

This is no longer a blanket requirement for every identified VOD source. Recognized `torbox.app` hosts are exempt from automatic enforcement, consistent with TorBox's published multi-IP policy: https://support.torbox.app/en/articles/9836406-can-i-use-my-account-with-many-different-ip-s . False host suffixes do not qualify. Known protected debrid domains and unidentified addon/CDN VOD links remain protected. The app does not blindly exempt an opaque URL based on a guessed sharing policy. This means an unidentified legitimate source can still require a home proof/proxy. No other provider's sharing permission is assumed.

Manually enabling global MediaFlow retains the earlier app-wide routing behavior, including Live TV; the exemption concerns the automatic guard when the master switches are Off. Protecting routes does not grant permission to share an account, monitor other applications/devices, or guarantee against provider restrictions. Server misconfiguration, third-party clients and upstream addon proxies are outside this client's enforcement. Do not interpret the guard as an account-wide concurrency detector or an absolute guarantee.

The diagnostic endpoints are documented by ipify: https://www.ipify.org/ . The app checks egress addresses, not geolocation.

## Validation

Executed locally: current F51 ownership/safety/source guards, historical F50/F49/F48/F47/F46/F43/F42 regressions, changed/new Swift grammar, 714 independent uniform-projection bounds/centering cases, build-identity tests, remote-thumbnail gate, shell/Python/YAML validation. See F51_VALIDATION.json.

The macOS preflight retains the existing actual-router and full-health-client checks, updated to the automatic-routing semantics. It adds native cases for verified home direct with proxy Off, away forced proxy without changing master switches, unavailable/uncertain/pinned routes, a powerless shared legacy Off value, mixed address-family observations, learned home identity, restore filtering, TorBox exemption, and all-column uniform projection. It also type-checks the actual GeometryEffect/ViewModifier against the real tvOS SDK. Fake HTTP transports are used; tests do not contact real accounts.

Not run here: those native executables/SDK type-check, a full Xcode build, actual proxy/public-IP integration, physical Apple TV focus/playback/visual behavior or CPU/GPU profiling. The environment has no Swift compiler or Apple SDK. Accept the build only after its macOS workflow and device checks pass. Native tests from the supplied F48 log do not establish that this new F51 implementation has compiled or run.

Device checks should cover same-home direct with masters Off, remote client after importing a home-Off backup, Full/Light saved profiles, unavailable proxy, expected-IP mismatch, canceled source launch, external launch, network change/Retry, TorBox and opaque links, and each original/aligned card theme/size in the real customization preview. Verify the retained Pop Out effect separately.
