# vBRDC390 Unified Performance Profile checkpoint — NOT FINAL

Changes: a single shared VisualPerformanceProfile.Policy defines Normal, Performance, Turbo budgets for procedural wallpaper, animated image decoding FPS, eligible UI timelines, focus response, navigation rendering, and future image concurrency integration. Existing consumers use central policy for navigation detail and frame limits. Setting relabeled App Performance. Existing v390 fixes retained.

IMPORTANT: This is a partial integration, not proof that every subsystem reads the profile. `imageDecodeConcurrency` is a policy target and is NOT yet wired into Kingfisher. Other SwiftUI animation paths and catalog transitions still require a full audit. Frame rates are targets, not measured hardware FPS. Swift frontend parse succeeded; Xcode compilation and device profiling NOT performed.

Outstanding v390: comprehensive UI animation and artwork request integration; random themed logos/first-presentation; Spotlight and VOD resume; public-facing build history cleanup; device regression tests. Future: Up Next, Aether-only migration after stability, release validation.
