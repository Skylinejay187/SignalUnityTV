# Signal F89 / Build 1198 — F88 source follow-up

Source base: F88 Build 1197, derived from user-approved F87 Build 1196. Existing app and GitHub workflow preserved.

## Code applied
- VOD 3D catalog rail shifts left automatically whenever Media Information is presented, without an enable/disable preference. Existing shift animation and return-to-position are preserved. Removed obsolete Settings button, SettingsFocus case, and old @AppStorage reads. Backup compatibility key exports true.
- Pause info card defaults to `Liquid Glass`; old `Signal Glass` setting displays with the real bounded tvOS `.ultraThinMaterial`. Added `Frosted Glass` using `.regularMaterial`, retained Cinema and Minimal. Only the pause card itself gets a material, not the entire screen, avoiding reintroduction of previous full-screen background-layer performance problems.
- Near 3D catalog side posters use 640px decode budget while far slots stay at 384px; focused landscape stays at its existing 1024px budget. This is a conservative focused-quality improvement, not a confirmed fix of every blurry poster source. Original URL upgrading and Kingfisher transport kept unchanged.

## Investigation: F40 poster comparison
F40 and F88 use original-size TMDB URLs in the major CatalogStore and CatalogHeroMetadataCache poster paths. F40 already used 384px preview-depth card decodes and the focused main card uses 1024px in F88. Newer F78 Kingfisher transport/metadata response caching differs substantially. If blur persists on-device, compare URL, downloaded source pixel dimensions, decoded image pixel dimensions, exact Kingfisher processor key, and cache HIT/MISS per card BEFORE changing global cache/decode rules.

## Search research — not implemented in this ZIP
Official Stremio addon documentation: catalogs with `extra` containing `search` support query requests; `isRequired=true` declares search-only catalog. Other catalogs should not be queried with `search`. NuvioTV public GitHub docs describe Search Sources selection, results grouped by type, suggestions/top result, addon readiness states and separate per-provider errors. The F88 CatalogStore already offers a `searchSingleCatalogAddonProviderNetworkOnly` pipeline and candidate endpoint discovery, so the next safe step is to harden manifest capability filtering, cancellation and bounded provider fan-out, not replace search architecture globally. This change was intentionally NOT conflated with the targeted UI fixes.

## Validation
Swift parser (`swiftc -frontend -parse Sources/*.swift`) passed. Full Xcode/tvOS compile and real device playback, material/performance checks are still required.
