# F80 / 1189 build-log diagnosis and fix

## Observed failure

The supplied F79 Actions run selected build 1188 and completed its earlier source and native preflight checks. The workflow then installed AetherEngine 7.44.0 successfully. XcodeGen's pre-generation command called Scripts/prepare_build_deps_vBRDC280.sh, whose new F79 checker rejected Vendor/AetherEngine/Package.swift against the packaged placeholder's hash. The assertion stopped generation before the app compilation step. It was not a Swift compiler failure.

The source archive deliberately contains a lightweight engine placeholder. Scripts/fetch_aether_f28_744.sh installs the pinned upstream engine, so both Package.swift and the old Sources/AetherEngine/Placeholder.swift necessarily change or disappear. The new F78 and F79 hash loops incorrectly treated those two build-managed files as immutable app source. After fixing F79 alone, F78 would have failed on the same condition immediately afterward.

## Change

Scripts/source_hash_integrity.py now validates both supported lifecycle states:

- Packaged: every manifest entry, including both engine placeholders, must match its exact original hash.
- Installed: only the two exact engine-placeholder paths are exempt from their placeholder hashes, and only after proving that the engine has its 7.44.0 marker, its own Git checkout rooted at the correct directory, the exact 7.44.0 tag, no leftover Placeholder.swift, and a passing existing verify_f28_aether_integration.py check. That existing checker validates gain/cache hooks and bridge parity. It is not replaced or weakened.

All other manifest entries retain their exact hash validation, including other Vendor files, app files, bridge files and test files. F78 keeps its existing historical-source reconstruction; F79 keeps its current-source checks. Neither historical manifests nor their expected hashes were rewritten. The helper is used by both affected checkers.

Six new Python regression tests cover packaged validation, unauthorized placeholder drift/missing files, installed fixture acceptance, incorrect marker/tag/missing checkout/broken hooks, non-engine app/vendor drift, and the actual F78/F79 checker sequence before and after fixture installation. These run at the beginning of the existing pre-generation script. The fixture is explicitly a small local test tree, not a downloaded or compiled AetherEngine.

## Scope and verification

No production Swift was modified: all 171 existing Swift files match F79 byte-for-byte, with none added or removed. Engine installer, engine integration checker, vendor files, resources, playback, UI and settings are unchanged. Only Python checking/test support, its shell invocation and app/extension/project build identity changed; release is Signal-F80 / 1.0.1189.

Passed locally:
- Six F80 lifecycle/order regression tests, including actual F78/F79 checker execution in both engine lifecycle states.
- Five existing F75/F76 fixture/compile-input regression tests.
- Current F79 and F78 contracts; F73 historical preview/audio-mode contracts and negative controls.
- Explicit app source membership, bridge parity and build identity checks.
- Shell syntax validation and complete Swift-file byte comparison against F79.
- Source ZIP CRC and every entry byte comparison during packaging.

F80_VALIDATION.json contains the actual outputs. Expected negative-test diagnostics show rejected bad configurations; the unittest result is successful.

Xcode, the Apple SDKs and an Apple TV are not available in this environment. Full native compilation and device playback were not run. This package fixes the observed pre-generation blocker; it does not claim a successful full Xcode build. Existing native compiler/SDK checks remain in the build preflight for the macOS runner.
