# Signal F31R1 — Top Menu Rebuild

**Build candidate: 1.0.1137 / build 1137. Based on the supplied F30 selector-fix ZIP.**

The 48-entry theme collection is replaced by ten canonical layouts:

- Liquid Glass Island: translucent capsule and moving selection lens.
- Cinema Segmented: connected, inset text segments.
- Studio Minimal: text navigation with a separate Settings utility icon.
- Obsidian Floating: individual dark glass tiles.
- Titanium Toolbar: divided media-library toolbar with a metallic edge.
- Icon Dock: vertically stacked icons and destination labels.
- Spotlight Ribbon: editorial text, vertical markers and a ribbon baseline.
- Neon Outline: individually outlined capsules.
- Broadcast Deck: two-line destination panels and channel-style markers.
- Classic Media Bar: traditional text toolbar and selection baseline.

Glass uses public SwiftUI materials with an opaque Reduce Transparency fallback.
It is a custom presentation, not a claim that tvOS 18 has the tvOS 26 glass API.

## Settings and migration

Open Appearance → Top Menu Theme. The grouped dropdown contains actual-renderer
thumbnails and a description for each layout. Select with the remote; the dropdown
stays open and the Settings category is retained. Press Back to close the dropdown.
Accent, font and the existing menu-size control remain independent. All 48 F30 names
have explicit migration entries. Canonical selections resolve exactly before any
legacy mapping; unknown values use Liquid Glass Island.

Theme changes do not replace the destination/focus subtree. Existing membership
gating, destination activation, Down-to-content behavior, Preview Mirror reveal and
auto-hide, Search routing and logo visibility rules remain in the original host.

## Validation status — read before installing

- New Swift files and model test: syntax parsed successfully with the Swift grammar.
- Protected source and navigation callback comparisons against the supplied ZIP: pass.
- All 48 migration entries, ten renderer mappings and XcodeGen membership: pass.
- App and Top Shelf metadata both identify F31R1 / 1137: pass.
- Existing build-log redaction and remote seek-thumbnail safety checks: pass.
- **Full Xcode/tvOS compilation has NOT been run in this Linux workspace.**
- **Physical Apple TV visual/focus testing has NOT been run.**

This ZIP is full source, not an IPA or a successfully compiled release. See
`F31_VALIDATION.json` for the verification limits. No playback engine source or
playback lifecycle code was modified.

## Build and collect compile evidence

Use a separate app-source branch named `signal/f31-top-menu-rebuild`. The supplied
`.github/workflows/signal-f31-tvos-compile.yml` runs for `signal/f31-*` pushes and can
also be dispatched manually once registered in the repository. It retains the
pinned AetherEngine 7.44.0 dependency checks and the existing redacted diagnostics.
It runs the standalone Swift model/persistence tests before an unsigned Release
build, and produces compile evidence only after Xcode succeeds.

On a Mac with the required Xcode/tvOS SDK:

```sh
python3 Scripts/check_f31_build_identity.py
python3 Scripts/check_f31_top_menu_regression.py
swiftc Sources/SignalTopMenuTheme.swift Tests/TopMenuThemeModelTests.swift -o /tmp/signal-f31-menu-tests
/tmp/signal-f31-menu-tests
bash Scripts/check_f28_source_preflight.sh
xcodegen generate --spec project.yml
xcodebuild -project DebridChannelsTVOS.xcodeproj -scheme 00_DebridChannelsTVOS \
  -configuration Release -destination 'generic/platform=tvOS' CODE_SIGNING_ALLOWED=NO build
```

After a successful build, test every layout, every destination and Search; change
themes with Settings open, close/reopen Settings, relaunch, and verify the selected
layout persists. Test Preview Mirror's hidden/persistent menu and Back/Down focus
handoffs, all five menu sizes, Reduce Motion and Reduce Transparency. The lens
respects Reduce Motion; no new timers or continuous animation loops were added.

See `README_F31R1_BUILD_AND_SPOTLIGHT_FIX.md` for the build-workflow repair and poster change.
