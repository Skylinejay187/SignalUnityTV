# Signal F59 — build 1168

Forward from F58 / build 1167. Addresses the reported resistance when moving Down from Search's query/filters into results, and the white focus background behind the selected card.

Search now uses one enum FocusState for the query, Close, scopes and result IDs. The earlier three independent bindings and the temporary clearing of query/header focus are removed. A requested destination scrolls into the lazy viewport without a second explicit scroll animation. Its mounted Button then assigns one result target while the source remains the owner until that transfer. Cancellation, request UUID, destination identity, active scene/surface and detail-ownership guards remain. The query can still own focus during mounting; the previous query-focused guard no longer rejects that legitimate handoff.

Down/Done enters the first result row; returning from Media Information restores the previously selected card. The filters no longer form a separate focus section. Results still have their own section and explicit directional fallback, including offscreen rows and a partial final row. Up from the first row returns to the filters. Asynchronous result publications only service a pending handoff; they do not reassert a card while the user navigates the header. Empty-query cleanup clears only a result target, preserving query/keyboard focus.

Result Buttons use the app's existing custom SportsNoPlatterButtonStyle instead of the tvOS plain style that showed a white focus background. This custom style draws only the label. The actual SearchResultCard, compact landscape dimensions, dark artwork treatment, sideways focus animation and Reduce Motion behavior are unchanged.

Production Swift changes are confined to GlobalSearchScreen in DebridChannelsTVOSApp.swift. All 141 other previous Swift files are byte-identical, including the entire VOD player and F57 playback-continuity fix, Live TV, Guide, network/router and engine code. Search's async query/debounce, hydration and prefetch work remain unchanged apart from empty-query focus cleanup. AetherEngine 7.44.0 and Kingfisher 8.11.0 remain pinned.

Executed locally: 20 available Python preflight checks, including rejection of the actual F58 Search as a negative control; exact production delta and unchanged-file checks; build identity and six identity tests; script/shell syntax; Swift grammar comparison and current extracted Search fixture parsing; ZIP CRC and every-entry/source byte comparison.

The macOS SDK fixture now extracts the actual query/filter header as well as the current result grid, focus methods, card, tilt and custom button style. Native Swift tests, tvOS SDK type-check, full Xcode build and physical Apple TV testing remain pending because this environment has no Swift compiler or Apple SDK. These source checks do not establish that the reported device behavior is resolved.

Device verification: search for a multi-row title; Done before/after results; Down from the query and each scope; continue Down through offscreen/partial rows; Up back to filters/query; open/close details; replace the query while loading; repeat Search over VOD/Live playback. The focused card should have its existing thin outline/tilt with no white backing panel.
