# Signal F78 / build 1187

Focused Kingfisher artwork caching update from the attached F77 source. See F78_ARTWORK_OPTIMIZATION_REPORT.md for verified root causes, exact settings, diagnostics, regression results, native checks and the F77/F78 device test plan.

Production changes are confined to RemoteImageFit.swift. All other existing Swift files and all app artwork/resources are unchanged. The NAS/Cloudflare delivery architecture remains intact.

Local source/grammar checks pass. Full Xcode, native transport tests and Apple TV/iOS runtime performance checks could not run here; they are not reported as passed. The normal macOS build pipeline now includes real Kingfisher HTTP/restart/repair tests and artwork-file SDK builds.
