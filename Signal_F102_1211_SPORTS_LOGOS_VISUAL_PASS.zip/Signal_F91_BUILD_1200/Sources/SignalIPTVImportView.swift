import SwiftUI

struct SignalIPTVImportView: View {
    let onApply: @MainActor () async -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var sourceID = ""
    @State private var kind: SignalIPTVImport.Kind = .live
    @State private var draft = SignalIPTVImport.Selection()
    @State private var categories: [SignalIPTVImport.Category] = []
    @State private var entries: [SignalIPTVImport.Entry] = []
    @State private var search = ""
    @State private var titleRequest = 0
    @State private var limit = 100
    @State private var status = "Choose a configured IPTV source."
    @State private var busy = false
    @State private var applying = false
    private var sources: [SignalIPTVImport.Source] { SignalIPTVImport.sources() }
    private var source: SignalIPTVImport.Source? { sources.first { $0.id == sourceID } }
    private var filteredEntries: [SignalIPTVImport.Entry] {
        entries.filter { row in
            (draft.categories[kind.rawValue]?.contains(row.categoryID) ?? true) &&
            (search.isEmpty || row.name.localizedCaseInsensitiveContains(search))
        }
    }
    private var categoryTaskKey: String { [sourceID, kind.rawValue].joined(separator: "|") }
    private var titleTaskKey: String { [sourceID, kind.rawValue, String(titleRequest)].joined(separator: "|") }
    var body: some View {
        NavigationStack {
            ScrollView(.vertical) {
                VStack(alignment: .leading, spacing: 14) {
                    providerSection
                    if source != nil {
                        destinationSection
                        HStack(alignment: .top, spacing: 22) {
                            ScrollView(.vertical) { categorySection }
                                .frame(maxWidth: .infinity, alignment: .topLeading)
                            ScrollView(.vertical) { titleSection }
                                .frame(maxWidth: .infinity, alignment: .topLeading)
                        }
                        .frame(minHeight: 310)
                        actionSection
                    } else if sources.isEmpty {
                        Text("Add an Xtream account or M3U playlist in Live TV Sources first.")
                    }
                }
                .padding(26)
            }
            .frame(minWidth: 1120, minHeight: 680)
            .navigationTitle("IPTV Import Organizer")
            .disabled(applying)
            .onAppear { if sourceID.isEmpty { sourceID = sources.first?.id ?? "" } }
            .onChange(of: sourceID) { _, _ in
                draft = source.map { SignalIPTVImport.selection(for: $0) } ?? .init()
                search = ""; limit = 100; titleRequest = 0
            }
            .onChange(of: kind) { _, _ in titleRequest = 0 }
            .task(id: categoryTaskKey) { await loadCategories() }
            .task(id: titleTaskKey) { await loadTitles() }
        }
    }

    @MainActor private func loadCategories() async {
                guard let source else { return }
                let owner = sourceID, requestedKind = kind
                busy = true; categories = []; entries = []
                defer { if owner == sourceID, requestedKind == kind { busy = false } }
                do {
                    let groups = try await SignalIPTVRepository.shared.categories(source, kind: requestedKind)
                    guard !Task.isCancelled, owner == sourceID, requestedKind == kind else { return }
                    categories = groups
                    limit = 100
                    status = "Loaded \(groups.count) categories. Choose categories and apply, or load their titles for individual selection."
                } catch {
                    guard !Task.isCancelled, owner == sourceID, requestedKind == kind else { return }
                    status = "Provider did not return a valid list. Check its connection and retry by selecting the content type again."
                }
            
    }

    @MainActor private func loadTitles() async {
                guard titleRequest > 0, let source else { return }
                let owner = sourceID, requestedKind = kind
                var filter = draft; filter.entries[requestedKind.rawValue] = nil
                busy = true
                defer { if owner == sourceID, requestedKind == kind { busy = false } }
                do {
                    let rows = try await SignalIPTVRepository.shared.entries(source, kind: requestedKind, selection: filter)
                    guard !Task.isCancelled, owner == sourceID, requestedKind == kind else { return }
                    entries = rows; limit = 100
                    status = "Loaded \(rows.count) titles from the selected categories. Apply to save your choices."
                } catch {
                    guard !Task.isCancelled, owner == sourceID, requestedKind == kind else { return }
                    status = "Could not load titles. Your saved selection is unchanged; choose fewer categories or retry."
                }
            
    }

    private var providerSection: some View {
                Section("Provider / playlist") {
                    Picker("Source", selection: $sourceID) {
                        Text("Choose source").tag("")
                        ForEach(sources) { source in Text(source.label).tag(source.id) }
                    }
                    Text("Each source has its own destinations and exact category/channel selection. IPTV URLs and credentials stay on this device and in your existing secure backup flow.")
                        .font(.footnote)
                }
    }

    private var destinationSection: some View {
                    Section("Import destination") {
                        Picker("Use this source for", selection: $draft.mode) {
                            ForEach(SignalIPTVImport.Mode.allCases, id: \.self) { mode in Text(mode.rawValue).tag(mode) }
                        }
                        Text("Full TV: Live TV only. Sports Only: Sports Hub only. Both: Live TV plus sports channels in Sports. VOD Only: IPTV movies/shows. All: all three destinations. An explicit category/channel choice in Sports Only includes those choices even with unusual provider names.")
                            .font(.footnote)
                    }
    }

    private var categorySection: some View {
                    Section("Browse provider categories") {
                        Picker("Content", selection: $kind) {
                            Text("Live channels / Sports").tag(SignalIPTVImport.Kind.live)
                            Text("Movies").tag(SignalIPTVImport.Kind.movie)
                            Text("TV Shows").tag(SignalIPTVImport.Kind.series)
                        }
                        Button("All categories") { draft.categories[kind.rawValue] = nil }
                        Button("No categories") { draft.categories[kind.rawValue] = [] }
                        ForEach(categories) { category in
                            Toggle(category.name, isOn: Binding(get: {
                                draft.categories[kind.rawValue]?.contains(category.id) ?? true
                            }, set: { enabled in
                                var ids = Set(draft.categories[kind.rawValue] ?? Set(categories.map(\.id)))
                                if enabled { ids.insert(category.id) } else { ids.remove(category.id) }
                                draft.categories[kind.rawValue] = ids
                            }))
                        }
                    }
    }

    private var titleSection: some View {
                    Section("Choose individual channels / titles") {
                        Button("Load titles in selected categories") { titleRequest += 1 }.disabled(busy)
                        TextField("Search loaded provider titles", text: $search)
                        Button("All titles in selected categories") { draft.entries[kind.rawValue] = nil }
                        Button("No titles") { draft.entries[kind.rawValue] = [] }
                        ForEach(Array(filteredEntries.prefix(limit))) { row in
                            Toggle(row.name, isOn: Binding(get: {
                                draft.entries[kind.rawValue]?.contains(row.id) ?? true
                            }, set: { enabled in
                                var ids = Set(draft.entries[kind.rawValue] ?? Set(entries.map(\.id)))
                                if enabled { ids.insert(row.id) } else { ids.remove(row.id) }
                                draft.entries[kind.rawValue] = ids
                            }))
                        }
                        if filteredEntries.count > limit { Button("Show more titles") { limit += 100 } }
                        Text(titleRequest == 0 ? "Choose Load titles to browse individual channels. Empty selections import nothing; All removes the restriction." : "\(filteredEntries.count) matching provider titles. Empty selections import nothing; All removes the restriction.")
                            .font(.footnote)
                    }
    }

    private var actionSection: some View {
                    Section {
                        Text(status).font(.footnote)
                        if busy || applying { ProgressView() }
                        Button(applying ? "Applying…" : "Apply selection & refresh") {
                            guard let source, !busy, !applying else { return }
                            SignalIPTVImport.save(draft, for: source)
                            // Save immediately; provider refresh must never lock the modal
                            // or leave an unresponsive Applying button after slow EPG work.
                            applying = false
                            status = "Saved selection. Refreshing Live TV, Sports and IPTV catalogs in background."
                            dismiss()
                            Task { @MainActor in await onApply() }
                        }.disabled(busy || applying)
                        Button("Close") { dismiss() }
                    }
    }
}
