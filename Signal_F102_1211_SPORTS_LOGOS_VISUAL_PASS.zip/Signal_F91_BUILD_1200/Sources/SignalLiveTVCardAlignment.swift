import Foundation

struct SignalCardProjectedPoint: Equatable {
    let x: Double
    let y: Double
}

/// Row-major numerator coefficients: x'=(ax+cy+tx)/(px+qy+r), and similarly for y'.
/// Pure math: no view state, screen-origin dependence, timeline, player or focus target.
struct SignalLiveTVCardProjection: Equatable {
    let a: Double; let b: Double; let c: Double; let d: Double
    let tx: Double; let ty: Double; let p: Double; let q: Double; let r: Double
    static let identity = Self(a: 1, b: 0, c: 0, d: 1, tx: 0, ty: 0, p: 0, q: 0, r: 1)

    func project(x: Double, y: Double) -> SignalCardProjectedPoint {
        let denominator = p * x + q * y + r
        return .init(x: (a * x + c * y + tx) / denominator,
                     y: (b * x + d * y + ty) / denominator)
    }

    static func fitted(pose: SignalLiveTVCardPose, width: Double, height: Double) -> Self {
        fitted(pose: pose, width: width, height: height, uniform: false)
    }

    /// A centered, bounded quad with one scale on both axes: no stretched contour.
    static func uniformlyFitted(pose: SignalLiveTVCardPose, width: Double, height: Double) -> Self {
        fitted(pose: pose, width: width, height: height, uniform: true)
    }

    private static func fitted(pose: SignalLiveTVCardPose, width: Double, height: Double, uniform: Bool) -> Self {
        guard width.isFinite, height.isFinite, width > 0, height > 0,
              [pose.yaw, pose.pitch, pose.roll].allSatisfy({ $0.isFinite }) else { return .identity }
        let yaw = pose.yaw * .pi / 180
        let pitch = pose.pitch * .pi / 180
        let roll = pose.roll * .pi / 180
        let cy = cos(yaw), sy = sin(yaw), cp = cos(pitch), sp = sin(pitch)
        let cr = cos(roll), sr = sin(roll)
        let aa = cr * cy - sr * sp * sy
        let cc = -sr * cp
        let bb = sr * cy + cr * sp * sy
        let dd = cr * cp
        let camera = max(width, height) * 2.4
        let pp = cp * sy / camera
        let qq = -sp / camera
        let cx = width / 2, centerY = height / 2
        let local = [(-cx, -centerY), (cx, -centerY), (-cx, centerY), (cx, centerY)]
        let projected = local.map { point -> SignalCardProjectedPoint in
            let (u, v) = point
            let w = 1 + pp * u + qq * v
            return .init(x: (aa * u + cc * v) / w, y: (bb * u + dd * v) / w)
        }
        guard projected.allSatisfy({ $0.x.isFinite && $0.y.isFinite }),
              let minX = projected.map(\.x).min(), let maxX = projected.map(\.x).max(),
              let minY = projected.map(\.y).min(), let maxY = projected.map(\.y).max(),
              maxX - minX > 0.000001, maxY - minY > 0.000001 else { return .identity }
        // Normalize the projected quad back into exactly the original cell rectangle.
        // The same column therefore repeats identical top/bottom/left/right bounds.
        let fitX = width / (maxX - minX), fitY = height / (maxY - minY)
        let sx = uniform ? min(fitX, fitY) : fitX
        let ssY = uniform ? min(fitX, fitY) : fitY
        let padX = (width - (maxX - minX) * sx) / 2
        let padY = (height - (maxY - minY) * ssY) / 2
        let a = (aa - minX * pp) * sx + padX * pp, c = (cc - minX * qq) * sx + padX * qq
        let b = (bb - minY * pp) * ssY + padY * pp, d = (dd - minY * qq) * ssY + padY * qq
        return .init(a: a, b: b, c: c, d: d,
            tx: -minX * sx + padX - a * cx - c * centerY,
            ty: -minY * ssY + padY - b * cx - d * centerY,
            p: pp, q: qq, r: 1 - pp * cx - qq * centerY)
    }
}

/// The outside magnifier keeps a real top margin; the header reserves its label gap.
enum SignalMirrorSearchLayout {
    static let fixedCenterY: Double = 55
    static let iconDiameter: Double = 42
    static let minimumCenterY: Double = 48
    static let headingGap: Double = 12
    static let headingTopPadding: Double = 38
    static func centerY(headingTop: Double?) -> Double {
        guard let headingTop, headingTop.isFinite else { return minimumCenterY }
        return max(minimumCenterY, headingTop - iconDiameter / 2 - headingGap)
    }
}
