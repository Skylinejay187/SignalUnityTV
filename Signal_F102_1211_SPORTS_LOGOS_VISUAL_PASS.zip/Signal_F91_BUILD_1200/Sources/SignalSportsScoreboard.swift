import Foundation
import SwiftUI

struct SignalSportsGame: Identifiable, Equatable {
    enum State: String { case live, upcoming, final }
    struct Team: Equatable {
        var name: String
        var score: String?
        var logo: String?
        var fullName: String? = nil
    }
    let id: String
    let league: String
    let away: Team
    let home: Team
    let state: State
    let detail: String
    let start: Date?
    var receivedAt = Date()

    static func distinct(_ games: [Self]) -> [Self] {
        var seen = Set<String>()
        return games.filter { game in
            // No cross-feed identity guesses: preserve ambiguous fixtures separately.
            seen.insert(game.id).inserted
        }.sorted { ($0.start ?? .distantFuture) < ($1.start ?? .distantFuture) }
    }
    static func espn(_ event: [String: Any], league: String) -> Self? {
        guard let id = event["id"] as? String,
              let competition = (event["competitions"] as? [[String: Any]])?.first,
              let sides = competition["competitors"] as? [[String: Any]], sides.count == 2,
              let away = sides.first(where: { $0["homeAway"] as? String == "away" }),
              let home = sides.first(where: { $0["homeAway"] as? String == "home" }),
              let type = (event["status"] as? [String: Any])?["type"] as? [String: Any],
              let rawState = type["state"] as? String else { return nil }
        let state: State
        switch rawState {
        case "in": state = .live
        case "post": guard type["completed"] as? Bool == true else { return nil }; state = .final
        case "pre":
            let name = (type["name"] as? String ?? "").uppercased()
            guard !["POSTPONED", "CANCELED", "CANCELLED", "DELAYED"].contains(where: name.contains) else { return nil }
            state = .upcoming
        default: return nil
        }
        func team(_ side: [String: Any]) -> Team? {
            guard let value = side["team"] as? [String: Any], let name = value["shortDisplayName"] as? String ?? value["displayName"] as? String else { return nil }
            let score = (side["score"] as? String) ?? (side["score"] as? NSNumber)?.stringValue
            return Team(name: name, score: state == .upcoming ? nil : score, logo: value["logo"] as? String, fullName: value["displayName"] as? String)
        }
        guard let awayTeam = team(away), let homeTeam = team(home) else { return nil }
        let rawDate = event["date"] as? String ?? ""
        let formatter = ISO8601DateFormatter()
        let date = formatter.date(from: rawDate)
        return Self(id: "espn-\(league)-\(id)", league: league, away: awayTeam, home: homeTeam,
            state: state, detail: type["shortDetail"] as? String ?? type["description"] as? String ?? "", start: date)
    }
}

struct SignalSportsScoreboard: View {
    let games: [SignalSportsGame]
    @AppStorage("sportsWidgetStyleV1") private var style = "Glass"
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("SPORTS CENTER", systemImage: "sportscourt.fill")
                    .font(.system(size: 18, weight: .heavy, design: .rounded)).tracking(2)
                Spacer()
                if let updated = games.map(\.receivedAt).max() {
                    Text("Updated \(updated, style: .time)").font(.system(size: 12)).foregroundStyle(.white.opacity(0.6))
                }
            }
            HStack(alignment: .top, spacing: 18) {
                panel("LIVE SCORES", state: .live, accent: .red)
                panel("NEXT GAMES", state: .upcoming, accent: .cyan)
                panel("FINAL RESULTS", state: .final, accent: .orange)
            }
        }.foregroundStyle(.white)
    }
    private func panel(_ title: String, state: SignalSportsGame.State, accent: Color) -> some View {
        let fixtures = Array(games.filter { $0.state == state }.prefix(style == "Compact" ? 2 : 3))
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                RoundedRectangle(cornerRadius: 2).fill(accent).frame(width: 4, height: 16)
                Text(title).font(.system(size: 13, weight: .heavy, design: .rounded)).tracking(1.4)
                Spacer()
                Text(String(games.filter { $0.state == state }.count)).font(.system(size: 12, weight: .bold)).foregroundStyle(accent)
            }
            if fixtures.isEmpty {
                Text(state == .live ? "No confirmed live scores available" : state == .upcoming ? "No upcoming fixtures available" : "No completed results available")
                    .font(.system(size: 15, weight: .medium)).foregroundStyle(.white.opacity(0.6))
                    .frame(maxWidth: .infinity, minHeight: 160, alignment: .center)
            } else {
                ForEach(fixtures) { game in gameRow(game, accent: accent) }
            }
        }
        .padding(16).frame(maxWidth: .infinity, minHeight: 230, alignment: .topLeading)
        .background(RoundedRectangle(cornerRadius: 22).fill(style == "Scoreboard" ? Color(red: 0.035, green: 0.06, blue: 0.1) : Color.black.opacity(style == "Compact" ? 0.8 : 0.12)))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(LinearGradient(colors: [.white.opacity(0.3), accent.opacity(0.16)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
    }
    private func gameRow(_ game: SignalSportsGame, accent: Color) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(game.league).font(.system(size: 10, weight: .heavy)).foregroundStyle(accent)
                Spacer()
                if game.state == .upcoming, let start = game.start {
                    Text(start, format: .dateTime.weekday(.abbreviated).hour().minute()).font(.system(size: 10))
                } else { Text(game.detail).font(.system(size: 10)).lineLimit(1) }
            }
            HStack(spacing: 8) {
                team(game.away)
                Text(game.state == .upcoming ? "vs" : "–").foregroundStyle(.white.opacity(0.5))
                team(game.home)
            }
        }.padding(.vertical, 5)
    }
    private func team(_ team: SignalSportsGame.Team) -> some View {
        HStack(spacing: 5) {
            if let logo = team.logo { RemoteImageFit(url: logo, mode: .fit, maxPixelSize: 96).frame(width: 25, height: 25) }
            Text(team.name).font(.system(size: 13, weight: .semibold)).lineLimit(1)
            Spacer(minLength: 0)
            if let score = team.score { Text(score).font(.system(size: 20, weight: .heavy, design: .rounded)).monospacedDigit() }
        }.frame(maxWidth: .infinity)
    }
}
