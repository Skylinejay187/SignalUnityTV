import Foundation

enum VODFeaturedCastPresentationMode: String, CaseIterable, Hashable {
    case off
    case compactOverlay
    case fullPoster

    var displayName: String {
        switch self {
        case .off: return "Off"
        case .compactOverlay: return "Cast Banner"
        case .fullPoster: return "Full Poster"
        }
    }

    var next: VODFeaturedCastPresentationMode {
        switch self {
        case .off: return .compactOverlay
        case .compactOverlay: return .fullPoster
        case .fullPoster: return .off
        }
    }
    // Off disables automatic presentation, never user-initiated cast browsing.
    func permitsManualBrowse(playbackReady: Bool, awake: Bool, memberCount: Int) -> Bool {
        playbackReady && awake && memberCount > 0
    }

    func showsPortrait(playbackReady: Bool, awake: Bool, memberCount: Int,
                       focusActive: Bool, showingOriginalPoster: Bool) -> Bool {
        guard permitsManualBrowse(playbackReady: playbackReady, awake: awake, memberCount: memberCount) else { return false }
        switch self {
        case .off: return focusActive
        case .compactOverlay: return false
        case .fullPoster: return !showingOriginalPoster
        }
    }

    var automaticallyRotates: Bool { self != .off }

    static func steppedIndex(_ current: Int, by delta: Int, count: Int) -> Int? {
        guard count > 1, delta != 0 else { return nil }
        let normalized = max(current, 0) % count
        // Reduce before adding so a large remote delta cannot overflow.
        return (normalized + delta % count + count) % count
    }
}
