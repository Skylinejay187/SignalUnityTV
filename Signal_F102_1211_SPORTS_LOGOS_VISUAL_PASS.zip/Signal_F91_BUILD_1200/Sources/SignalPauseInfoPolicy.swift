import Foundation

/// Presentation-only decisions. No player commands, metadata fetches or durable state.
enum SignalPauseInfoPolicy {
    static let revealDelayNanoseconds: UInt64 = 1_500_000_000

    struct Request: Equatable, Hashable {
        let presentationID: UUID
        let sourceID: String
        let renderGeneration: Int
        let paused: Bool
        let eligible: Bool
        var canReveal: Bool { paused && eligible && !sourceID.isEmpty }
    }

    static func sameOwner(_ a: Request, _ b: Request) -> Bool {
        a.presentationID == b.presentationID && a.sourceID == b.sourceID && a.renderGeneration == b.renderGeneration
    }

    static func delayNanoseconds(_ seconds: Double) -> UInt64 {
        let safe = seconds.isFinite ? min(10, max(0, seconds)) : 1.5
        return UInt64(safe * 1_000_000_000)
    }

    static func mayDismiss(_ lease: Lease, current: Lease?, request: Request) -> Bool {
        request.eligible && !request.paused && lease == current && lease.request == request
    }

    struct Lease: Equatable {
        let id = UUID()
        let request: Request
    }

    struct Metadata: Equatable {
        let title: String
        let episode: String
        let synopsis: String
    }

    struct MetadataInput: Equatable {
        let title: String
        let fallbackTitle: String
        let season: Int?
        let episode: Int?
        let synopsis: String

        var formatted: Metadata {
            SignalPauseInfoPolicy.metadata(title: title, fallbackTitle: fallbackTitle,
                season: season, episode: episode, synopsis: synopsis)
        }
    }

    static func mayReveal(_ lease: Lease, current: Lease?, request: Request) -> Bool {
        request.canReveal && lease == current && lease.request == request
    }

    static func waitForReveal(nanoseconds: UInt64 = revealDelayNanoseconds) async -> Bool {
        do { try await Task.sleep(nanoseconds: nanoseconds) }
        catch { return false }
        return !Task.isCancelled
    }

    /// While paused the estimate means "if resumed now". Unknown/invalid timelines
    /// omit the estimate; neither metadata nor a corrupt saved clock can produce overflow.
    static func estimatedEnd(now: Date, elapsed: Double, duration: Double, rate: Double = 1) -> Date? {
        guard now.timeIntervalSince1970.isFinite, elapsed.isFinite, elapsed >= 0,
              duration.isFinite, duration > elapsed, rate.isFinite, rate > 0 else { return nil }
        let remaining = (duration - elapsed) / rate
        guard remaining.isFinite, remaining > 0, remaining <= 31 * 24 * 60 * 60 else { return nil }
        return now.addingTimeInterval(remaining)
    }

    static func metadata(title: String, fallbackTitle: String, season: Int?, episode: Int?, synopsis: String) -> Metadata {
        let raw = title.trimmingCharacters(in: .whitespacesAndNewlines)
        let fallback = fallbackTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        var displayTitle = raw.isEmpty ? fallback : raw
        var episodeTitle = ""
        var parts: [String] = []
        if let season, season >= 0 { parts.append("S\(season)") }
        if let episode, episode > 0 { parts.append("E\(episode)") }
        // Signal's episode metadata uses "Series S01E05 Episode title". Do not
        // reinterpret a movie title or guess an episode name from a series synopsis.
        if !parts.isEmpty {
            let pattern = #"\s+[sS]\d{1,2}[eE]\d{1,3}(?:\s*[•:\-–—]*\s*)"#
            if let range = displayTitle.range(of: pattern, options: .regularExpression) {
                episodeTitle = String(displayTitle[range.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                let parent = String(displayTitle[..<range.lowerBound]).trimmingCharacters(in: .whitespacesAndNewlines)
                if !parent.isEmpty { displayTitle = parent }
            }
        }
        let episodeLabel = parts.joined(separator: " · ")
        return Metadata(title: displayTitle.isEmpty ? "Now Playing" : displayTitle,
            episode: [episodeLabel, episodeTitle].filter { !$0.isEmpty }.joined(separator: " — "),
            synopsis: synopsis.trimmingCharacters(in: .whitespacesAndNewlines))
    }
}
