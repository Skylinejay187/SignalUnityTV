import Foundation

/// One immutable player presentation owns this state. Closing a pre-EOF reminder
/// preserves the user's existing EOF-autoplay preference; closing an EOF prompt
/// cancels that handoff and cannot be undone by a delayed completion callback.
struct SignalUpNextDismissalState {
    private(set) var promptDismissed = false
    private(set) var autoplayCancelled = false

    mutating func dismiss(episodeEnded: Bool) {
        promptDismissed = true
        autoplayCancelled = autoplayCancelled || episodeEnded
    }

    mutating func reachedEnd() {
        if !autoplayCancelled { promptDismissed = false }
    }
}
