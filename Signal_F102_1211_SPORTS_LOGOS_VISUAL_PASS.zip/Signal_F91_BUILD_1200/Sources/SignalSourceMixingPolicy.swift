import Foundation

/// Preserve rank within an addon while rotating addons inside each service,
/// then rotate services. No account keys or stream URLs are used as group IDs.
enum SignalSourceMixingPolicy {
    static func interleaved<T>(_ items: [T], limit: Int,
                               service: (T) -> String, addon: (T) -> String) -> [T] {
        guard limit > 0 else { return [] }
        var services: [String] = []
        var addons: [String: [String]] = [:]
        var queues: [String: [String: [T]]] = [:]
        for item in items {
            let s = service(item), a = addon(item)
            if queues[s] == nil { services.append(s); queues[s] = [:]; addons[s] = [] }
            if queues[s]?[a] == nil { addons[s, default: []].append(a); queues[s]?[a] = [] }
            queues[s]?[a]?.append(item)
        }
        var addonCursors: [String: Int] = [:]
        var offsets: [String: [String: Int]] = [:]
        var output: [T] = []
        while output.count < limit {
            var advanced = false
            for s in services where output.count < limit {
                let order = addons[s] ?? []
                guard !order.isEmpty else { continue }
                let cursor = addonCursors[s, default: 0]
                for delta in 0..<order.count {
                    let index = (cursor + delta) % order.count, a = order[index]
                    let offset = offsets[s]?[a] ?? 0, values = queues[s]?[a] ?? []
                    guard values.indices.contains(offset) else { continue }
                    output.append(values[offset])
                    offsets[s, default: [:]][a] = offset + 1
                    addonCursors[s] = (index + 1) % order.count
                    advanced = true
                    break
                }
            }
            if !advanced { break }
        }
        return output
    }
}
