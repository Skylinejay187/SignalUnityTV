import Foundation

/// A category's vertical screen position never determines its destination channel.
/// Keep the selected channel if it belongs to that category, otherwise enter row one.
enum SignalGuideNavigation {
    static func targetIndex(ids: [Int], selectedID: Int) -> Int? {
        guard !ids.isEmpty else { return nil }
        return ids.firstIndex(of: selectedID) ?? 0
    }
}
