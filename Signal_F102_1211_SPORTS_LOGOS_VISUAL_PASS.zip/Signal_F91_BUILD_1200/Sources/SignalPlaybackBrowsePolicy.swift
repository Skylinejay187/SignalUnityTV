import Foundation

/// A foreground browser is a narrow exception, never a release of the player gate.
enum SignalPlaybackBrowsePolicy {
    static func searchAllowed(inPlayer: Bool, browserActive: Bool, exclusivePlayback: Bool) -> Bool {
        inPlayer ? browserActive : !exclusivePlayback
    }
}
