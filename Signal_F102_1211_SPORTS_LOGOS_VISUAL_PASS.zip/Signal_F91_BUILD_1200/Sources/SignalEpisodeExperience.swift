import Foundation
import Security

struct SignalEpisodeOptions: Equatable {
    static var defaults: [String: Any] {
        SignalPortableSettings.defaults.filter { $0.key.hasPrefix("episode") || $0.key == "metadataCacheEnabledV1" }
    }
    let skipDB: Bool, introDB: Bool, introHater: Bool, theIntroDB: Bool, aniSkip: Bool
    let autoIntro: Bool, autoRecap: Bool, submit: Bool, metadataCache: Bool
    let credits: String, nextStyle: String, continuous: String
    let appearance: Int, countdown: Int, stillCount: Int, stillMinutes: Int
    static func load(_ store: UserDefaults = .standard) -> Self {
        let fallback = defaults
        func b(_ k: String) -> Bool { (store.object(forKey: k) ?? fallback[k]) as? Bool ?? false }
        func n(_ k: String, _ lo: Int, _ hi: Int) -> Int { max(lo, min(hi, ((store.object(forKey: k) ?? fallback[k]) as? NSNumber)?.intValue ?? lo)) }
        func s(_ k: String, _ values: [String]) -> String {
            let value = store.string(forKey: k) ?? fallback[k] as? String ?? values[0]
            return values.contains(value) ? value : values[0]
        }
        return Self(skipDB: b("episodeSkipDBV1"), introDB: b("episodeIntroDBV1"), introHater: b("episodeIntroHaterV1"), theIntroDB: b("episodeTheIntroDBV1"), aniSkip: b("episodeAniSkipV1"),
            autoIntro: b("episodeAutoIntroV1"), autoRecap: b("episodeAutoRecapV1"), submit: b("episodeSubmitIntrosV1"), metadataCache: b("metadataCacheEnabledV1"),
            credits: s("episodeCreditsV1", ["keep", "skip", "next"]), nextStyle: s("episodeNextStyleV1", ["countdown", "button"]), continuous: s("episodeContinuousV1", ["series", "season", "off"]),
            appearance: n("episodeNextAppearanceV1", 10, 600), countdown: n("episodeCountdownV1", 3, 60), stillCount: n("episodeStillCountV1", 0, 20), stillMinutes: n("episodeStillMinutesV1", 0, 480))
    }
    var providerKey: String { [skipDB, introDB, introHater, theIntroDB, aniSkip].map { $0 ? "1" : "0" }.joined() }
    func allowsNext(currentSeason: Int?, nextSeason: Int?) -> Bool {
        continuous != "off" && (continuous != "season" || (currentSeason != nil && currentSeason == nextSeason))
    }
}

/// Cached Keychain credential; never placed in general settings or diagnostic output.
enum SignalIntroDBCredential {
    private static let lock = NSLock()
    private static var cached: String?
    private static var query: [String: Any] { [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "com.signal.introdb", kSecAttrAccount as String: "user-api-key"] }
    static func read() -> String {
        lock.lock(); defer { lock.unlock() }
        if let cached { return cached }
        var q = query; q[kSecReturnData as String] = true; q[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(q as CFDictionary, &result)
        let value = status == errSecSuccess ? (result as? Data).flatMap { String(data: $0, encoding: .utf8) } ?? "" : ""
        cached = value; return value
    }
    @discardableResult static func save(_ value: String) -> Bool {
        let value = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard value.count <= 4096 else { return false }
        lock.lock()
        let status: OSStatus
        if value.isEmpty {
            let result = SecItemDelete(query as CFDictionary)
            status = result == errSecItemNotFound ? errSecSuccess : result
        } else {
            let attributes: [String: Any] = [kSecValueData as String: Data(value.utf8), kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
            let result = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
            if result == errSecItemNotFound { var q = query; attributes.forEach { q[$0.key] = $0.value }; status = SecItemAdd(q as CFDictionary, nil) }
            else { status = result }
        }
        if status == errSecSuccess { cached = value }
        lock.unlock()
        if status == errSecSuccess { UserDefaults.standard.set(!value.isEmpty, forKey: "episodeIntroDBKeyPresentV1") }
        return status == errSecSuccess
    }
}

@MainActor final class SignalContinuousPlaybackSession {
    static let shared = SignalContinuousPlaybackSession()
    private var owner: UUID?
    private var episodes = 0
    private var watchedSeconds = 0.0
    private var lastClock: Double?
    func begin(_ id: UUID, continuing: Bool) {
        guard owner != id else { return }
        if !continuing { acknowledge() }
        owner = id; episodes += 1; lastClock = nil
    }
    func tick(_ clock: Double, playing: Bool) {
        defer { lastClock = clock.isFinite ? clock : nil }
        guard playing, clock.isFinite, let lastClock else { return }
        let delta = clock - lastClock
        if delta > 0 && delta <= 15 { watchedSeconds += delta }
    }
    func needsPrompt(_ options: SignalEpisodeOptions) -> Bool {
        (options.stillCount > 0 && episodes >= options.stillCount) || (options.stillMinutes > 0 && watchedSeconds >= Double(options.stillMinutes) * 60)
    }
    func acknowledge() { episodes = 0; watchedSeconds = 0; lastClock = nil }
}
