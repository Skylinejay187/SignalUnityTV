import Foundation

// F32: background identity is independent of Live TV card styling. Previous
// solid-color names are migration inputs, never duplicate picker choices.
enum SignalBackgroundTheme: String, CaseIterable, Identifiable {
    case pureBlack = "Pure Black"
    case channelAtmosphere = "Dynamic Channel Artwork"
    case frostedChannel = "Frosted Channel Artwork"
    case smokedGlass = "Smoked Glass"
    case polarGlass = "Polar Frost"
    case prismGlass = "Prismatic Glass"
    case silkDunes = "Silk Dunes"
    case auroraVeil = "Aurora Veil"
    case contourStudio = "Contour Studio"
    case orbitBloom = "Orbital Bloom"
    case midnightFacets = "Midnight Facets"
    case cinemaHalo = "Cinema Halo"

    var id: String { rawValue }
    static let defaultTheme: Self = .smokedGlass
    var usesChannelArtwork: Bool { self == .channelAtmosphere || self == .frostedChannel }
    var summary: String {
        switch self {
        case .pureBlack: return "A true black canvas; optional smoke follows the independent atmosphere setting"
        case .channelAtmosphere: return "The focused channel's programme artwork becomes a soft full-screen atmosphere"
        case .frostedChannel: return "Focused programme colors diffuse through a soft frosted-glass veil"
        case .smokedGlass: return "Neutral charcoal glass, diffused light and a soft studio vignette"
        case .polarGlass: return "Cool translucent light with a broad frosted horizon"
        case .prismGlass: return "Intersecting translucent planes with restrained spectral edges"
        case .silkDunes: return "Sculpted flowing folds with warm light and deep shadows"
        case .auroraVeil: return "Wide blue-green curtains of diffused light"
        case .contourStudio: return "Fine topographic contours beneath a dark gallery wash"
        case .orbitBloom: return "Large atmospheric halos with a subtle elliptical orbit"
        case .midnightFacets: return "Overlapping geometric surfaces cut from dark glass"
        case .cinemaHalo: return "A warm projector halo above a dark cinematic floor"
        }
    }

    // Keep exact historic values readable in restored backups. New selections persist
    // canonical names using the existing key; no additional account/device state.
    static func resolve(_ raw: String) -> Self {
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if let exact = allCases.first(where: { $0.rawValue.lowercased() == key }) { return exact }
        switch key {
        case "deep navy", "ocean blue", "steel blue", "cinema blue": return .polarGlass
        case "forest", "deep teal", "emerald night": return .auroraVeil
        case "royal purple", "plum": return .prismGlass
        case "burgundy", "deep red": return .cinemaHalo
        case "espresso", "warm bronze": return .silkDunes
        default: return defaultTheme
        }
    }

    // All additive artwork/abstract work is mounted only for its visible dashboard.
    // The stateful LiveTVScreen itself remains resident for existing focus restoration.
    static func ownsArtworkBudget(sceneActive: Bool, dashboardVisible: Bool,
                                  guideVisible: Bool, covered: Bool, playbackActive: Bool) -> Bool {
        sceneActive && dashboardVisible && !guideVisible && !covered && !playbackActive
    }
}

// Independent persisted controls: blur changes image detail, transparency changes
// the shared glass tint. Neither setting silently changes the smoke selection.
struct SignalBackgroundTreatment {
    static let defaultBlur = 70
    static let defaultTransparency = 35
    let blurPercent: Int
    let glassTransparency: Int

    init(blurPercent: Int, glassTransparency: Int) {
        self.blurPercent = Self.clamped(blurPercent)
        self.glassTransparency = Self.clamped(glassTransparency)
    }
    static func clamped(_ value: Int) -> Int { min(100, max(0, value)) }
    func blurRadius(frosted: Bool) -> Double {
        Double(blurPercent) / 100 * (frosted ? 96 : 64)
    }
    var glassOpacity: Double { (1 - Double(glassTransparency) / 100) * 0.68 }
    var smokeSoftness: Double { 4 + Double(blurPercent) / 100 * 8 }
    var artworkMaxPixelSize: Int {
        // Clearer backgrounds need enough detail for a TV, while strongly blurred
        // artwork keeps the original small decode budget during remote browsing.
        if blurPercent < 20 { return 1920 }
        if blurPercent < 50 { return 1280 }
        return 640
    }

    static let retiredWallpaperKeys: [String] = [
        "dynamicMainGridWallpaperEnabled", "dynamicMainGridWallpaperPreset",
        "dynamicMainGridWallpaperCustomEnabledV1", "dynamicMainGridWallpaperCustomURLV1"
    ]
    static func retireStandaloneWallpaper(defaults: UserDefaults = .standard) {
        for key in retiredWallpaperKeys where defaults.object(forKey: key) != nil {
            defaults.removeObject(forKey: key)
        }
    }
}
