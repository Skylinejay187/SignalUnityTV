import Foundation
import CryptoKit

// F82: provider-scoped extraction. No player, artwork or global polling work lives here.
enum SignalIPTVImport {
    static let settingsKey = "iptvImportSelectionsV1"
    enum Kind: String, Codable, CaseIterable, Hashable, Sendable { case live, movie, series }
    enum Mode: String, Codable, CaseIterable, Hashable, Sendable {
        case live = "Full TV", sports = "Sports Only", both = "Both", vod = "VOD Only", all = "All", disabled = "Disabled"
        var includesLive: Bool { self == .live || self == .both || self == .all }
        var includesSports: Bool { self == .sports || self == .both || self == .all }
        var includesVOD: Bool { self == .vod || self == .all }
        static func legacy(_ value: String) -> Mode {
            if let mode = Mode(rawValue: value) { return mode }
            let lower = value.lowercased()
            if lower.contains("both") { return .both }
            if lower.contains("sport") { return .sports }
            if lower.contains("vod") { return .vod }
            return .live
        }
    }
    struct Selection: Codable, Equatable, Sendable {
        var mode: Mode = .live
        // Missing key means all. An explicitly empty array means none, never all.
        var categories: [String: Set<String>] = [:]
        var entries: [String: Set<String>] = [:]
        var requestsLive: Bool {
            mode.includesLive && categories[Kind.live.rawValue]?.isEmpty != true && entries[Kind.live.rawValue]?.isEmpty != true
        }
        func allows(kind: Kind, category: String, id: String) -> Bool {
            if let ids = categories[kind.rawValue], !ids.contains(category) { return false }
            if let ids = entries[kind.rawValue], !ids.contains(id) { return false }
            return true
        }
        func sports(_ row: Entry) -> Bool {
            guard mode.includesSports, allows(kind: .live, category: row.categoryID, id: row.id) else { return false }
            // An explicit Sports-only category/channel choice is authoritative.
            if mode == .sports, categories[Kind.live.rawValue] != nil || entries[Kind.live.rawValue] != nil { return true }
            return SignalIPTVImport.looksSports(row.name + " " + row.category)
        }
    }
    struct Source: Identifiable, Equatable, Sendable {
        let id: String
        let label: String
        let server: String
        let username: String
        let password: String
        let playlist: String?
        let legacyMode: Mode
        var isPlaylist: Bool { playlist != nil }
        func api(_ action: String, extra: [URLQueryItem] = []) -> URL? {
            guard var parts = URLComponents(string: server + "/player_api.php") else { return nil }
            parts.queryItems = [URLQueryItem(name: "username", value: username), URLQueryItem(name: "password", value: password), URLQueryItem(name: "action", value: action)] + extra
            parts.percentEncodedQuery = parts.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
            return parts.url
        }
        func stream(kind: Kind, id: String, ext: String) -> String {
            let folder = kind == .live ? "live" : kind == .movie ? "movie" : "series"
            var allowed = CharacterSet.urlPathAllowed
            allowed.remove(charactersIn: "/?#%")
            func part(_ raw: String) -> String { raw.addingPercentEncoding(withAllowedCharacters: allowed) ?? "" }
            let clean = ext.range(of: "^[A-Za-z0-9]+$", options: .regularExpression) != nil ? ext : (kind == .live ? "m3u8" : "mp4")
            return server + "/" + folder + "/" + part(username) + "/" + part(password) + "/" + part(id) + "." + clean
        }
    }
    struct Category: Identifiable, Hashable, Sendable { let id: String; let name: String }
    struct Entry: Identifiable, Codable, Hashable, Sendable {
        let id: String
        let kind: Kind
        let name: String
        let categoryID: String
        let category: String
        let image: String
        let url: String
        let epgID: String
        let number: String
        let year: String
        let tmdb: String
        let imdb: String
        var season: Int? = nil
        var episode: Int? = nil
    }
    static func digest(_ value: String) -> String { SHA256.hash(data: Data(value.utf8)).map { String(format: "%02x", $0) }.joined() }
    static func server(_ value: String) -> String {
        var raw = value.trimmingCharacters(in: .whitespacesAndNewlines)
        if !raw.lowercased().hasPrefix("http://") && !raw.lowercased().hasPrefix("https://") { raw = "http://" + raw }
        guard var parts = URLComponents(string: raw), parts.host != nil,
              ["http", "https"].contains(parts.scheme?.lowercased() ?? "") else { return "" }
        parts.query = nil; parts.fragment = nil
        if parts.path.lowercased().hasSuffix("/player_api.php") { parts.path = String(parts.path.dropLast(15)) }
        while parts.path.hasSuffix("/") { parts.path.removeLast() }
        return parts.string ?? ""
    }
    static func sourceURLs(_ raw: String) -> [String] {
        let lines = raw.replacingOccurrences(of: #"[,;](?=\s*https?://)"#, with: "\n", options: [.regularExpression, .caseInsensitive])
        var seen = Set<String>()
        return lines.components(separatedBy: .newlines).compactMap { line in
            let value = line.trimmingCharacters(in: .whitespacesAndNewlines)
            guard let url = URL(string: value), ["http", "https"].contains(url.scheme?.lowercased() ?? ""), url.host != nil, seen.insert(value).inserted else { return nil }
            return value
        }
    }
    static func sources(defaults: UserDefaults = .standard) -> [Source] {
        var output: [Source] = []
        func add(_ base: String, _ user: String, _ pass: String, _ mode: String) {
            let base = server(base), user = user.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !base.isEmpty, !user.isEmpty, !pass.isEmpty else { return }
            let id = digest("xtream\u{0}" + base + "\u{0}" + user)
            guard !output.contains(where: { $0.id == id }) else { return }
            output.append(Source(id: id, label: "Xtream #\(output.count + 1)", server: base, username: user, password: pass, playlist: nil, legacyMode: Mode.legacy(mode)))
        }
        for line in (defaults.string(forKey: "liveXtreamAccounts") ?? "").components(separatedBy: .newlines) {
            let fields = line.components(separatedBy: "|")
            if fields.count >= 3 { add(fields[0], fields[1], fields[2], fields.count > 3 ? fields[3] : "Full TV") }
        }
        add(defaults.string(forKey: "liveXtreamServer") ?? "", defaults.string(forKey: "liveXtreamUsername") ?? "", defaults.string(forKey: "liveXtreamPassword") ?? "", defaults.string(forKey: "sportsXtreamImportMode") ?? "Full TV")
        for raw in sourceURLs(defaults.string(forKey: "liveM3UURL") ?? "") {
            let raw = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            guard let url = URL(string: raw), ["http", "https"].contains(url.scheme?.lowercased() ?? "") else { continue }
            let id = digest("m3u\u{0}" + raw)
            guard !output.contains(where: { $0.id == id }) else { continue }
            output.append(Source(id: id, label: "M3U #\(output.filter(\.isPlaylist).count + 1)", server: "", username: "", password: "", playlist: raw, legacyMode: .live))
        }
        return output
    }
    static func selections(defaults: UserDefaults = .standard) -> [String: Selection] {
        let raw = defaults.string(forKey: settingsKey) ?? "{}"
        return (try? JSONDecoder().decode([String: Selection].self, from: Data(raw.utf8))) ?? [:]
    }
    static func selection(for source: Source, defaults: UserDefaults = .standard) -> Selection {
        selections(defaults: defaults)[source.id] ?? Selection(mode: source.legacyMode)
    }
    static func save(_ selection: Selection, for source: Source, defaults: UserDefaults = .standard) {
        var values = selections(defaults: defaults); values[source.id] = selection
        if let data = try? JSONEncoder().encode(values), let text = String(data: data, encoding: .utf8) { defaults.set(text, forKey: settingsKey) }
    }
    static func looksSports(_ raw: String) -> Bool {
        let text = " " + raw.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "en_US_POSIX")).lowercased().replacingOccurrences(of: "[^a-z0-9]+", with: " ", options: .regularExpression) + " "
        return ["sport", "sports", "ppv", "nfl", "nba", "mlb", "nhl", "ufc", "mma", "wwe", "aew", "espn", "espn2", "espnu", "fs1", "fs2", "bein", "soccer", "football", "basketball", "baseball", "hockey", "boxing", "wrestling", "tennis", "golf", "nascar", "formula", "f1", "rugby", "cricket", "motogp", "dazn", "redzone"].contains { text.contains(" " + $0 + " ") }
    }
    static func titleKey(_ raw: String) -> String {
        raw.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "en_US_POSIX"))
            .replacingOccurrences(of: #"\s*[\[(](?:19|20)\d{2}[\])]\s*$"#, with: "", options: .regularExpression)
            .lowercased().replacingOccurrences(of: "[^a-z0-9]+", with: " ", options: .regularExpression)
            .split(separator: " ").joined(separator: " ")
    }
    static func matches(_ row: Entry, title: String, year: String, tmdb: String?, imdb: String?) -> Bool {
        if let tmdb, !tmdb.isEmpty, !row.tmdb.isEmpty, tmdb != row.tmdb { return false }
        if let imdb, !imdb.isEmpty, !row.imdb.isEmpty, imdb != row.imdb { return false }
        if let tmdb, !tmdb.isEmpty, tmdb == row.tmdb { return true }
        if let imdb, !imdb.isEmpty, imdb == row.imdb { return true }
        guard !titleKey(title).isEmpty, titleKey(row.name) == titleKey(title) else { return false }
        // Avoid silently substituting remakes when provider identity/year is absent.
        if !year.isEmpty { return !row.year.isEmpty && row.year == year }
        return true
    }
}

actor SignalIPTVRepository {
    static let shared = SignalIPTVRepository()
    private struct Cached { let date: Date; let data: Data }
    private var memory: [String: Cached] = [:]
    private let session: URLSession
    private let cacheDirectory: URL?
    init(session: URLSession = .shared, cacheDirectory: URL? = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first?.appendingPathComponent("SignalIPTVSourceCache-v1")) {
        self.session = session; self.cacheDirectory = cacheDirectory
    }
    enum ProviderError: Error { case invalidURL, response, tooLarge, malformed }
    private func data(_ url: URL) async throws -> Data {
        try Task.checkCancellation()
        let key = SignalIPTVImport.digest(url.absoluteString)
        if let value = memory[key], Date().timeIntervalSince(value.date) < 1800 { return value.data }
        let disk = cacheDirectory?.appendingPathComponent(key + ".data")
        var previous: Data?
        if let disk, let attributes = try? FileManager.default.attributesOfItem(atPath: disk.path),
           let date = attributes[.modificationDate] as? Date, let size = attributes[.size] as? NSNumber,
           size.intValue <= 48 * 1024 * 1024, Date().timeIntervalSince(date) < 86400 {
            previous = try? Data(contentsOf: disk)
            if Date().timeIntervalSince(date) < 1800, let previous { return previous }
        }
        do {
            var request = URLRequest(url: url, timeoutInterval: 25)
            request.setValue("application/json,audio/x-mpegurl,text/plain,*/*", forHTTPHeaderField: "Accept")
            let result: Data
            let code: Int
            if url.scheme?.lowercased() == "http" {
                let plain = try await PlainHTTPClient.fetchData(from: url, accept: "application/json,audio/x-mpegurl,text/plain,*/*", maxBytes: 48 * 1024 * 1024, timeout: 25)
                result = plain.data; code = plain.statusCode
            } else {
                let response = try await session.data(for: request)
                result = response.0; code = (response.1 as? HTTPURLResponse)?.statusCode ?? 0
            }
            try Task.checkCancellation()
            guard (200...299).contains(code) else { throw ProviderError.response }
            guard result.count <= 48 * 1024 * 1024 else { throw ProviderError.tooLarge }
            guard result.first != 60 else { throw ProviderError.malformed }
            if memory.values.reduce(0, { $0 + $1.data.count }) + result.count > 12 * 1024 * 1024 || memory.count >= 12 { memory.removeAll() }
            if result.count <= 12 * 1024 * 1024 { memory[key] = Cached(date: Date(), data: result) }
            if let disk, let cacheDirectory {
                try? FileManager.default.createDirectory(at: cacheDirectory, withIntermediateDirectories: true)
                try? result.write(to: disk, options: .atomic)
                try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: disk.path)
                let files = (try? FileManager.default.contentsOfDirectory(at: cacheDirectory, includingPropertiesForKeys: [.fileSizeKey, .contentModificationDateKey])) ?? []
                var total = files.reduce(0) { $0 + ((try? $1.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0) }
                for file in files.sorted(by: { ((try? $0.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast) < ((try? $1.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast) }) where total > 64 * 1024 * 1024 {
                    let count = (try? file.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                    try? FileManager.default.removeItem(at: file); total -= count
                }
            }
            return result
        } catch {
            if Task.isCancelled { throw CancellationError() }
            if let previous { return previous }
            throw error
        }
    }
    func clear() {
        memory.removeAll()
        if let cacheDirectory { try? FileManager.default.removeItem(at: cacheDirectory) }
    }
    private func discard(_ url: URL) {
        let key = SignalIPTVImport.digest(url.absoluteString)
        memory[key] = nil
        if let path = cacheDirectory?.appendingPathComponent(key + ".data") { try? FileManager.default.removeItem(at: path) }
    }
    private func rows(_ url: URL?) async throws -> [[String: Any]] {
        guard let url else { throw ProviderError.invalidURL }
        let data = try await self.data(url)
        try Task.checkCancellation()
        do {
            guard let rows = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { throw ProviderError.malformed }
            return rows
        } catch {
            discard(url)
            throw ProviderError.malformed
        }
    }
    static func string(_ row: [String: Any], _ keys: String...) -> String {
        for key in keys {
            if let text = row[key] as? String, !text.isEmpty { return text }
            if let number = row[key] as? NSNumber { return number.stringValue }
        }
        return ""
    }
    func categories(_ source: SignalIPTVImport.Source, kind: SignalIPTVImport.Kind) async throws -> [SignalIPTVImport.Category] {
        if source.isPlaylist {
            let entries = try await playlist(source)
            return Array(Set(entries.filter { $0.kind == kind }.map { SignalIPTVImport.Category(id: $0.categoryID, name: $0.category) })).sorted { $0.name < $1.name }
        }
        let action = kind == .live ? "get_live_categories" : kind == .movie ? "get_vod_categories" : "get_series_categories"
        return try await rows(source.api(action)).compactMap { row in
            let id = Self.string(row, "category_id")
            return id.isEmpty ? nil : .init(id: id, name: Self.string(row, "category_name", "name"))
        }
    }
    func entries(_ source: SignalIPTVImport.Source, kind: SignalIPTVImport.Kind, selection: SignalIPTVImport.Selection? = nil) async throws -> [SignalIPTVImport.Entry] {
        if let selection, selection.categories[kind.rawValue]?.isEmpty == true || selection.entries[kind.rawValue]?.isEmpty == true { return [] }
        let raw: [SignalIPTVImport.Entry]
        if source.isPlaylist { raw = try await playlist(source).filter { $0.kind == kind } }
        else {
            let categories = (try? await categories(source, kind: kind)) ?? []
            let map = Dictionary(categories.map { ($0.id, $0.name) }, uniquingKeysWith: { first, _ in first })
            let action = kind == .live ? "get_live_streams" : kind == .movie ? "get_vod_streams" : "get_series"
            var payload: [[String: Any]] = []
            if let selected = selection?.categories[kind.rawValue], selected.count <= 8 {
                for id in selected.sorted() { try Task.checkCancellation(); payload += try await rows(source.api(action, extra: [URLQueryItem(name: "category_id", value: id)])) }
            } else { payload = try await rows(source.api(action)) }
            raw = payload.prefix(30000).compactMap { row in
                let id = Self.string(row, kind == .series ? "series_id" : "stream_id")
                guard !id.isEmpty else { return nil }
                let cat = Self.string(row, "category_id")
                let ext = Self.string(row, "container_extension")
                let direct = Self.string(row, "direct_source")
                let directURL = URL(string: direct)
                let validDirect = ["http", "https"].contains(directURL?.scheme?.lowercased() ?? "")
                return .init(id: id, kind: kind, name: Self.string(row, "name"), categoryID: cat,
                    category: map[cat] ?? Self.string(row, "category_name"), image: Self.string(row, "stream_icon", "cover"),
                    url: kind == .series ? "" : (validDirect ? direct : source.stream(kind: kind, id: id, ext: ext)),
                    epgID: Self.string(row, "epg_channel_id", "tvg_id"), number: Self.string(row, "num"),
                    year: String(Self.string(row, "year", "releaseDate", "releasedate").prefix(4)), tmdb: Self.string(row, "tmdb", "tmdb_id"), imdb: Self.string(row, "imdb_id"))
            }
        }
        try Task.checkCancellation()
        var seen = Set<String>()
        return raw.filter { seen.insert($0.id).inserted && (selection?.allows(kind: kind, category: $0.categoryID, id: $0.id) ?? true) }
    }
    func episodes(_ source: SignalIPTVImport.Source, series: SignalIPTVImport.Entry) async throws -> [SignalIPTVImport.Entry] {
        guard let url = source.api("get_series_info", extra: [URLQueryItem(name: "series_id", value: series.id)]) else { return [] }
        let data = try await self.data(url)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any], let seasons = root["episodes"] as? [String: Any] else { throw ProviderError.malformed }
        var output: [SignalIPTVImport.Entry] = []
        for (key, value) in seasons {
            guard let rows = value as? [[String: Any]] else { continue }
            for row in rows {
                let id = Self.string(row, "id"), season = Int(Self.string(row, "season")) ?? Int(key), episode = Int(Self.string(row, "episode_num"))
                guard !id.isEmpty, let season, let episode, episode > 0 else { continue }
                let info = row["info"] as? [String: Any] ?? [:]
                output.append(.init(id: id, kind: .series, name: Self.string(row, "title").isEmpty ? series.name : Self.string(row, "title"),
                    categoryID: series.categoryID, category: series.category, image: Self.string(info, "movie_image").isEmpty ? series.image : Self.string(info, "movie_image"),
                    url: source.stream(kind: .series, id: id, ext: Self.string(row, "container_extension")), epgID: "", number: "", year: series.year, tmdb: "", imdb: "", season: season, episode: episode))
            }
        }
        return output.sorted { ($0.season ?? 0, $0.episode ?? 0) < ($1.season ?? 0, $1.episode ?? 0) }
    }
    private func playlist(_ source: SignalIPTVImport.Source) async throws -> [SignalIPTVImport.Entry] {
        guard let raw = source.playlist, let url = URL(string: raw) else { return [] }
        let data = try await self.data(url)
        guard let text = String(data: data, encoding: .utf8), text.contains("#EXTM3U") || text.contains("#EXTINF") else { discard(url); throw ProviderError.malformed }
        return Self.parseM3U(text, base: url)
    }
    static func parseM3U(_ text: String, base: URL) -> [SignalIPTVImport.Entry] {
        let regex = try? NSRegularExpression(pattern: #"([\w-]+)="([^"]*)""#)
        var attrs: [String: String] = [:], name = "", output: [SignalIPTVImport.Entry] = []
        for line in text.components(separatedBy: .newlines) {
            let line = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.hasPrefix("#EXTINF") {
                attrs.removeAll(); let ns = line as NSString
                for match in regex?.matches(in: line, range: NSRange(location: 0, length: ns.length)) ?? [] { attrs[ns.substring(with: match.range(at: 1)).lowercased()] = ns.substring(with: match.range(at: 2)) }
                // Last comma is safe for typical EXTINF names; prefer explicit tvg-name.
                name = attrs["tvg-name"] ?? String(line.split(separator: ",").last ?? "Channel")
            } else if !line.isEmpty, !line.hasPrefix("#"), !name.isEmpty,
                      let url = URL(string: line, relativeTo: base)?.absoluteURL, ["http", "https"].contains(url.scheme?.lowercased() ?? "") {
                let group = attrs["group-title"] ?? "IPTV"
                let path = url.path.lowercased()
                let kind: SignalIPTVImport.Kind = path.contains("/live/") ? .live : path.contains("/series/") ? .series :
                    (path.contains("/movie/") || path.contains("/vod/") || ["mp4", "mkv", "m4v", "avi", "mov"].contains(url.pathExtension.lowercased())) ? .movie : .live
                output.append(.init(id: SignalIPTVImport.digest(url.absoluteString), kind: kind, name: name, categoryID: group, category: group,
                    image: attrs["tvg-logo"] ?? "", url: url.absoluteString, epgID: attrs["tvg-id"] ?? "", number: attrs["tvg-chno"] ?? "", year: "", tmdb: "", imdb: ""))
                name = ""; attrs.removeAll()
                if output.count >= 30000 { break }
            }
        }
        return output
    }
}
