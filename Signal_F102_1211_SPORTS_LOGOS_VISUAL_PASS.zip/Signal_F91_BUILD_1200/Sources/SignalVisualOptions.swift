import Foundation

enum SignalGlassAtmosphereStyle: String, CaseIterable {
    case off = "Off"
    case caustics = "Smoke · Soft"
    case liquid = "Smoke · Cinematic"
    case aurora = "Smoke · Drift"
    case refraction = "Smoke · Wisps"
    case ocean = "Smoke · Deep Blue"
    static func resolve(_ raw: String) -> Self {
        if let exact = Self(rawValue: raw) { return exact }
        return ["Soft Caustics": Self.caustics, "Liquid Light": .liquid, "Aurora Drift": .aurora,
                "Glass Refraction": .refraction, "Ocean Glow": .ocean][raw] ?? .off
    }
    static func next(_ raw: String) -> String {
        let all = Array(allCases), i = all.firstIndex(of: resolve(raw)) ?? 0
        return all[(i+1) % all.count].rawValue
    }
    static func fromRetiredSmoke(_ raw: String) -> String {
        switch raw {
        case "Subtle", "Cinematic": return Self.caustics.rawValue
        case "Heavy": return Self.liquid.rawValue
        case "Orbs": return Self.ocean.rawValue
        default: return Self.off.rawValue
        }
    }
    static func migrateRetiredSmoke(defaults: UserDefaults = .standard) {
        if defaults.object(forKey: "signalGlassAtmosphereV1") == nil {
            defaults.set(fromRetiredSmoke(defaults.string(forKey: "ambientClassicSmokeModeV378") ?? "Off"), forKey: "signalGlassAtmosphereV1")
        }
        defaults.removeObject(forKey: "ambientClassicSmokeModeV378")
    }
}

enum SignalSearchEffectStyle: String, CaseIterable {
    case off = "Off"
    case orbit = "Orbit Glint"
    case breathe = "Breathing Halo"
    case scan = "Glass Sweep"
    case prism = "Prism Arc"
    case comet = "Comet Trail"
    case doubleOrbit = "Double Orbit"
    case ripple = "Soft Ripple"
    case star = "Starlight"
    case aurora = "Aurora Ring"
    case focusOnly = "Focus Only"
    static func resolve(_ raw: String) -> Self { Self(rawValue: raw) ?? .orbit }
    static func next(_ raw: String) -> String {
        let all = Array(allCases), i = all.firstIndex(of: resolve(raw)) ?? 1
        return all[(i+1) % all.count].rawValue
    }
    func animates(focused: Bool) -> Bool { self != .off && (self != .focusOnly || focused) }
}
