import Foundation

/// Reads the existing decoder clock without waking the hidden SwiftUI timeline.
/// A new presentation always gets its own first evaluation; seek/lookup edges can force one.
struct SignalEpisodeClockGate {
    private(set) var owner: UUID?
    private(set) var lastUptime: Double?
    mutating func shouldEvaluate(owner: UUID, uptime: Double, force: Bool = false, precision: Bool = false) -> Bool {
        guard uptime.isFinite, uptime >= 0 else { return false }
        if self.owner != owner { self.owner = owner; lastUptime = nil }
        if !force, let lastUptime, uptime >= lastUptime, uptime - lastUptime < (precision ? 0.15 : 0.5) { return false }
        lastUptime = uptime
        return true
    }
}
