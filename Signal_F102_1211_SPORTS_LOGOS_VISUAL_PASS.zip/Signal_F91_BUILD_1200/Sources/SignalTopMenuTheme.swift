import Foundation

// F31: exactly one canonical identity for each structurally different renderer.
// Legacy names are migration inputs only and never appear as extra picker choices.
enum TopMenuThemeGroup: String, CaseIterable, Identifiable {
    case glass = "Glass & depth"
    case compact = "Compact navigation"
    case studio = "Studio & broadcast"
    var id: String { rawValue }
}

enum TopMenuThemeStyle: String, CaseIterable, Identifiable {
    case liquidGlassIsland = "Liquid Glass Island"
    case cinemaSegmented = "Cinema Segmented"
    case studioMinimal = "Studio Minimal"
    case obsidianFloating = "Obsidian Floating"
    case titaniumToolbar = "Titanium Toolbar"
    case iconDock = "Icon Dock"
    case spotlightRibbon = "Spotlight Ribbon"
    case neonOutline = "Neon Outline"
    case broadcastDeck = "Broadcast Deck"
    case classicMediaBar = "Classic Media Bar"
    case crystalSlabs = "Crystal Slabs"
    case orbitRail = "Orbit Rail"
    case cinemaTicket = "Cinema Ticket"
    case stackedCards = "Stacked Cards"
    case signalTerminal = "Signal Terminal"
    case galleryTabs = "Gallery Tabs"
    case beaconRail = "Beacon Rail"
    case haloDock = "Halo Dock"
    case auroraReborn = "Luminous Glass"
    case marqueeReborn = "Cinema Pearl"
    case retroReborn = "Opal Glass"
    case graphiteReborn = "Slate Atelier"
    case copperReborn = "Satin Rail"
    case polarReborn = "Frosted Ribbon"

    case signalOriginal = "Signal Original Glass"
    case floatingLens = "Floating Lens"
    case graphiteCapsule = "Graphite Capsule"
    case cinemaRail = "Cinema Rail"
    case crystalOutline = "Crystal Outline"
    case slimDock = "Slim Dock"

    var id: String { rawValue }
    static let defaultTheme: TopMenuThemeStyle = .liquidGlassIsland
    static let implementedThemes: [TopMenuThemeStyle] = [
        .signalOriginal, .floatingLens, .graphiteCapsule, .cinemaRail, .crystalOutline, .slimDock,
        .liquidGlassIsland, .obsidianFloating, .cinemaSegmented, .iconDock,
        .neonOutline, .studioMinimal, .titaniumToolbar, .spotlightRibbon,
        .broadcastDeck, .classicMediaBar, .crystalSlabs, .orbitRail, .cinemaTicket,
        .stackedCards, .signalTerminal, .galleryTabs, .beaconRail, .haloDock,
        .auroraReborn, .marqueeReborn, .retroReborn, .graphiteReborn, .copperReborn, .polarReborn
    ]
    static let implementedNames: [String] = implementedThemes.map { (theme: TopMenuThemeStyle) -> String in theme.rawValue }

    var group: TopMenuThemeGroup {
        switch self {
        case .signalOriginal, .floatingLens, .graphiteCapsule, .crystalOutline, .liquidGlassIsland, .obsidianFloating, .crystalSlabs, .stackedCards, .auroraReborn, .polarReborn: return .glass
        case .cinemaSegmented, .iconDock, .neonOutline, .orbitRail, .haloDock: return .compact
        default: return .studio
        }
    }

    var summary: String {
        switch self {
        case .signalOriginal: return "Restored compact smoked-glass capsule with icon labels and a restrained inset selection"
        case .floatingLens: return "A floating lens over a thin shared glass channel"
        case .graphiteCapsule: return "Continuous graphite capsule with polished selection brackets"
        case .cinemaRail: return "Open cinema labels with an illuminated baseline and subtle glass ledge"
        case .crystalOutline: return "Clear framed navigation with a luminous etched selection"
        case .slimDock: return "Compact icon and label dock with a slim raised selection plate"
        case .liquidGlassIsland: return "Floating glass capsule with a sliding selection lens"
        case .cinemaSegmented: return "Compact connected segments with inset selection"
        case .studioMinimal: return "Text navigation with separate utility controls"
        case .obsidianFloating: return "Individual dark-glass tiles with depth"
        case .titaniumToolbar: return "Divided media-library toolbar with a metallic edge"
        case .iconDock: return "Vertical icon dock with labels below each destination"
        case .spotlightRibbon: return "Editorial ribbon with vertical selection markers"
        case .neonOutline: return "Outlined capsules with restrained focus illumination"
        case .broadcastDeck: return "Two-line destination panels with channel-style markers"
        case .classicMediaBar: return "Traditional text toolbar with an accent baseline"
        case .crystalSlabs: return "Beveled frosted tiles with a luminous upper edge"
        case .orbitRail: return "Circular destination emblems on a fine connecting rail"
        case .cinemaTicket: return "Notched cinema tickets with perforated icon stubs"
        case .stackedCards: return "Layered floating cards with offset backing plates"
        case .signalTerminal: return "Monospaced station numbers and bracketed selection"
        case .galleryTabs: return "Angled gallery tabs attached to a shared ledge"
        case .beaconRail: return "Open text navigation with illuminated beacon dots"
        case .haloDock: return "Circular icon medallions above compact destination labels"
        case .auroraReborn: return "Curved luminous edge over a dark translucent glass island"
        case .marqueeReborn: return "Pearlescent segmented navigation with inset satin selection"
        case .retroReborn: return "Opalescent lens with a fine diagonal reflection"
        case .graphiteReborn: return "Floating slate controls with a polished icon inset"
        case .copperReborn: return "Minimal satin rail with a soft luminous selection ledge"
        case .polarReborn: return "Continuous frosted ribbon with an etched selection window"
        }
    }

    private static let legacy: [String: TopMenuThemeStyle] = [
        "aurora glass reborn": .auroraReborn,
        "cinema marquee reborn": .marqueeReborn,
        "retro wave reborn": .retroReborn,
        "graphite studio reborn": .graphiteReborn,
        "copper cinema reborn": .copperReborn,
        "polar frost reborn": .polarReborn,
        "classic": .classicMediaBar,
        "transparent black glass": .cinemaSegmented,
        "darker glass": .obsidianFloating,
        "lighter glass": .iconDock,
        "minimal / no background": .studioMinimal,
        "artwork blend mode": .spotlightRibbon,
        "aurora glass": .cinemaSegmented,
        "sapphire glass": .iconDock,
        "emerald glass": .studioMinimal,
        "ruby noir": .classicMediaBar,
        "sunset glass": .obsidianFloating,
        "purple nebula": .iconDock,
        "monochrome": .titaniumToolbar,
        "copper cinema": .classicMediaBar,
        "icon dock": .iconDock,
        "floating tiles": .obsidianFloating,
        "cinema marquee": .classicMediaBar,
        "studio ribbon": .spotlightRibbon,
        "segmented control": .cinemaSegmented,
        "compact icons": .iconDock,
        "neon line": .studioMinimal,
        "poster tabs": .broadcastDeck,
        "liquid glass pro": .liquidGlassIsland,
        "crystal navigation": .liquidGlassIsland,
        "obsidian glass": .liquidGlassIsland,
        "studio chrome": .titaniumToolbar,
        "graphite studio": .titaniumToolbar,
        "executive minimal": .titaniumToolbar,
        "broadcast deck": .broadcastDeck,
        "network console": .broadcastDeck,
        "modern capsules": .neonOutline,
        "cinema capsules": .neonOutline,
        "polar frost": .iconDock,
        "midnight prism": .liquidGlassIsland,
        "solar flare": .classicMediaBar,
        "jade circuit": .broadcastDeck,
        "violet pulse": .cinemaSegmented,
        "golden hour": .neonOutline,
        "arctic chrome": .titaniumToolbar,
        "retro wave": .spotlightRibbon,
        "deep ocean": .obsidianFloating,
        "ember noir": .broadcastDeck,
        "moonstone": .titaniumToolbar,
        "cosmic dust": .iconDock,
        "plasma edge": .studioMinimal,
        "rose quartz": .liquidGlassIsland,
        "cyber mint": .broadcastDeck,
        "velvet cinema": .classicMediaBar,
        "liquid glass": .liquidGlassIsland, "liquid nav": .liquidGlassIsland,
        "crystal nav": .liquidGlassIsland, "obsidian": .obsidianFloating,
        "chrome": .titaniumToolbar, "graphite": .titaniumToolbar,
        "executive": .studioMinimal, "broadcast": .broadcastDeck,
        "network": .broadcastDeck, "modern pills": .neonOutline,
        "cinema pills": .cinemaSegmented, "black glass": .liquidGlassIsland,
        "dark glass": .obsidianFloating, "frosted glass": .liquidGlassIsland,
        "artwork blend": .spotlightRibbon
    ]

    static func resolve(_ raw: String) -> TopMenuThemeStyle {
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            .folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "en_US_POSIX"))
        // Exact canonical lookup MUST precede legacy migration (not substring matching).
        if let exact = implementedThemes.first(where: { $0.rawValue.lowercased() == key }) { return exact }
        return legacy[key] ?? defaultTheme
    }
}


// Relative luminance chooses readable text on BOTH pale and dark user accents.
// The SwiftUI adapter supplies resolved sRGB components; no theme overrides it.
enum SignalMenuContrast {
    static func prefersDarkInk(red: Double, green: Double, blue: Double) -> Bool {
        func linear(_ value: Double) -> Double {
            let v = min(1, max(0, value.isFinite ? value : 0))
            return v <= 0.04045 ? v / 12.92 : pow((v + 0.055) / 1.055, 2.4)
        }
        let luminance = 0.2126 * linear(red) + 0.7152 * linear(green) + 0.0722 * linear(blue)
        return (luminance + 0.05) / 0.05 >= 1.05 / (luminance + 0.05)
    }
}
