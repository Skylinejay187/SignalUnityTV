import Foundation

/// Presentation values only. Never changes a channel ID, grid slot or remote target.
struct SignalLiveTVCardPose: Equatable {
    var yaw: Double = 0
    var pitch: Double = 0
    var roll: Double = 0
    var x: Double = 0
    var y: Double = 0
    var depth: Double = 0
    var bevel: Double = 0
}

/// Shared by original/aligned layouts. No timers, springs or render-loop state.
enum SignalLiveTVCardMotion {
    static func scale(focused: Bool, preview: Bool, reduceMotion: Bool) -> CGFloat {
        guard focused, !reduceMotion else { return 1 }
        return preview ? 1.09 : 1.025
    }
    static func lift(focused: Bool, preview: Bool = false, reduceMotion: Bool) -> CGFloat {
        guard focused, !reduceMotion else { return 0 }
        return preview ? -8 : -3
    }
}

enum SignalLiveTVCardEffect {
    static let baseNames = ["Original", "Tilt Left", "Tilt Right", "Dual Inward", "Split Inward",
        "Dual Inward Strong", "Split Inward Strong", "Dual Inward Max", "Split Inward Max",
        "Dual Outward", "Raised Glass", "Deep Float", "Beveled Cinema", "Layered Slate",
        "Curved Wall", "Tilted Pedestal", "Inset Lens", "Gallery Lift", "Prism Bevel", "Curved Wall Soft", "Curved Wall Strong", "Curved Wall Deep", "Curved Wall Max",
        "Dual Outward Strong", "Dual Outward Max", "Split Outward", "Split Outward Strong", "Split Outward Max"]
    static let alignedSuffix = " · Aligned"
    static let names = baseNames + baseNames.map { $0 + alignedSuffix }
    private static let migrations = ["Gallery Fan": "Gallery Lift", "Cinema Arc": "Curved Wall",
        "Floating Shelf": "Deep Float", "Isometric Deck": "Tilted Pedestal", "Cascade Stack": "Layered Slate",
        "Dual Outward Split": "Split Outward", "Dual Outward Split Strong": "Split Outward Strong", "Dual Outward Split Max": "Split Outward Max"]
    static func normalized(_ raw: String) -> String {
        if names.contains(raw) { return raw }
        if raw.hasSuffix(alignedSuffix) {
            let base = String(raw.dropLast(alignedSuffix.count))
            if let migrated = migrations[base] { return migrated + alignedSuffix }
        }
        return migrations[raw] ?? "Original"
    }
    static func isAligned(_ raw: String) -> Bool { normalized(raw).hasSuffix(alignedSuffix) }
    static func baseName(_ raw: String) -> String {
        let value = normalized(raw)
        return value.hasSuffix(alignedSuffix) ? String(value.dropLast(alignedSuffix.count)) : value
    }
    static func togglingAlignment(_ raw: String) -> String {
        isAligned(raw) ? baseName(raw) : baseName(raw) + alignedSuffix
    }
    static func resolved(_ raw: String, legacyShape: String) -> String {
        if normalized(raw) == "Original" {
            if legacyShape == "UNITY 3D Left" { return "Tilt Left" }
            if legacyShape == "UNITY 3D Right" { return "Tilt Right" }
        }
        return normalized(raw)
    }
    static func label(_ raw: String) -> String {
        let title = baseLabel(baseName(raw))
        return isAligned(raw) ? title + alignedSuffix : title
    }
    private static func baseLabel(_ raw: String) -> String {
        switch raw {
        case "Raised Glass": return "Gentle Tilt"
        case "Deep Float": return "Hover Lift"
        case "Beveled Cinema": return "Cinema Tilt"
        case "Layered Slate": return "Split Lean"
        case "Tilted Pedestal": return "Pedestal Tilt"
        case "Inset Lens": return "Steady Front"
        case "Gallery Lift": return "Gallery Rise"
        case "Prism Bevel": return "Prism Tilt"
        default: return raw
        }
    }
    static func next(_ raw: String) -> String { names[((names.firstIndex(of: normalized(raw)) ?? 0) + 1) % names.count] }
    static func usesCenterGutter(_ raw: String) -> Bool { baseName(raw).hasPrefix("Split ") }
    static func pose(_ raw: String, column: Int, focused: Bool) -> SignalLiveTVCardPose {
        // Use the full selected style at every slot. Alignment fixes the lattice;
        // the motion host still supplies its independent, small focus pop.
        if isAligned(raw) {
            var fixed = basePose(baseName(raw), column: column, focused: true)
            fixed.x = 0; fixed.y = 0
            return fixed
        }
        return basePose(baseName(raw), column: column, focused: focused)
    }
    private static func basePose(_ raw: String, column: Int, focused: Bool) -> SignalLiveTVCardPose {
        let column = min(3, max(0, column))
        let side = column < 2 ? 1.0 : -1.0
        let lane = Double(column) - 1.5
        switch raw {
        case "Tilt Left": return .init(yaw: focused ? -7 : 0)
        case "Tilt Right": return .init(yaw: focused ? 7 : 0)
        case "Dual Inward", "Split Inward": return .init(yaw: side * (focused ? 8.5 : 4))
        case "Dual Inward Strong", "Split Inward Strong": return .init(yaw: side * (focused ? 14 : 8))
        case "Dual Inward Max", "Split Inward Max": return .init(yaw: side * (focused ? 20 : 12))
        case "Dual Outward", "Split Outward": return .init(yaw: -side * (focused ? 12 : 7))
        case "Dual Outward Strong", "Split Outward Strong": return .init(yaw: -side * (focused ? 18 : 12))
        case "Dual Outward Max", "Split Outward Max": return .init(yaw: -side * (focused ? 24 : 16))
        case "Raised Glass": return .init(pitch: focused ? -5 : 0)
        case "Deep Float": return .init(pitch: focused ? -8 : -2, y: focused ? -5 : 0)
        case "Beveled Cinema": return .init(yaw: side * 3, pitch: -2)
        case "Layered Slate": return .init(yaw: side * 5)
        case "Curved Wall Soft": return .init(yaw: -lane * 4, pitch: -1)
        case "Curved Wall": return .init(yaw: -lane * 7, pitch: -1)
        case "Curved Wall Strong": return .init(yaw: -lane * 10, pitch: -2)
        case "Curved Wall Deep": return .init(yaw: -lane * 13, pitch: -3)
        case "Curved Wall Max": return .init(yaw: -lane * 16, pitch: -4)
        case "Tilted Pedestal": return .init(yaw: side * 8, pitch: 5)
        case "Inset Lens": return .init()
        case "Gallery Lift": return .init(pitch: focused ? -3 : 0, y: focused ? -3 : 0)
        case "Prism Bevel": return .init(yaw: side * 6, pitch: -3)
        default: return .init(pitch: focused ? -1.55 : 0)
        }
    }
}

/// One Search target has one owner in Preview Mirror. Invalid saved values use the menu.
enum SignalMirrorSearchPlacement: String, CaseIterable {
    case menu = "Inside Top Menu"
    case clock = "Beside Clock"
    static func resolve(_ raw: String) -> Self { Self(rawValue: raw) ?? .menu }
    var next: Self { self == .menu ? .clock : .menu }
}

/// Fast repeated input reduces decorative motion without delaying selection or dropping presses.
enum SignalCatalogMotionBudget {
    static func rapidRepeat(now: TimeInterval, previous: TimeInterval) -> Bool {
        previous > 0 && now >= previous && now - previous < 0.18
    }
    static func duration(rapid: Bool, expressive: Bool) -> TimeInterval {
        rapid ? 0.10 : (expressive ? 0.28 : 0.18)
    }
}

struct SignalLiveTVCardSurface: Equatable {
    let depth: Double
    let bevel: Double
}

/// Shape owns contour, bevel and physical frame. Motion never supplies these values.
enum SignalLiveTVCardTheme {
    static let names = ["Original UNITY", "Squared", "Soft Rounded", "Cinema Curve", "Pill",
        "Raised Glass", "Deep Float", "Beveled Cinema", "Layered Slate", "Curved Wall",
        "Tilted Pedestal", "Inset Lens", "Gallery Lift", "Prism Bevel",
        "Cinema Soft Curve", "Cinema Glass", "Cinema Slate", "Studio Frame", "Gallery Frame", "Panorama Curve", "Obsidian Frame", "Pearl Edge"]
    static func normalized(_ raw: String) -> String { names.contains(raw) ? raw : "Original UNITY" }
    static func next(_ raw: String) -> String { names[((names.firstIndex(of: normalized(raw)) ?? 0) + 1) % names.count] }
    static func radius(_ raw: String) -> CGFloat {
        switch normalized(raw) {
        case "Squared", "Layered Slate": return 3
        case "Soft Rounded", "Beveled Cinema": return 13
        case "Cinema Curve", "Curved Wall": return 38
        case "Pill": return 72
        case "Cinema Soft Curve": return 32
        case "Cinema Glass": return 34
        case "Cinema Slate": return 26
        case "Studio Frame": return 18
        case "Gallery Frame": return 30
        case "Panorama Curve": return 42
        case "Obsidian Frame": return 20
        case "Pearl Edge": return 36
        case "Raised Glass", "Inset Lens": return 22
        case "Deep Float", "Gallery Lift": return 28
        case "Tilted Pedestal", "Prism Bevel": return 16
        default: return 24
        }
    }
    static func surface(_ raw: String, focused: Bool) -> SignalLiveTVCardSurface {
        switch normalized(raw) {
        case "Cinema Soft Curve": return .init(depth: 3, bevel: 0.18)
        case "Cinema Glass": return .init(depth: 6, bevel: 0.42)
        case "Cinema Slate": return .init(depth: 5, bevel: 0.24)
        case "Studio Frame": return .init(depth: 4, bevel: 0.48)
        case "Gallery Frame": return .init(depth: 7, bevel: 0.28)
        case "Panorama Curve": return .init(depth: 2, bevel: 0.14)
        case "Obsidian Frame": return .init(depth: 6, bevel: 0.35)
        case "Pearl Edge": return .init(depth: 3, bevel: 0.60)
        case "Raised Glass": return .init(depth: focused ? 10 : 4, bevel: 0.55)
        case "Deep Float": return .init(depth: focused ? 18 : 8, bevel: 0.22)
        case "Beveled Cinema": return .init(depth: focused ? 12 : 6, bevel: 0.85)
        case "Layered Slate": return .init(depth: focused ? 16 : 10, bevel: 0.35)
        case "Curved Wall": return .init(depth: focused ? 9 : 3, bevel: 0.25)
        case "Tilted Pedestal": return .init(depth: focused ? 17 : 8, bevel: 0.50)
        case "Inset Lens": return .init(depth: 3, bevel: focused ? 0.90 : 0.65)
        case "Gallery Lift": return .init(depth: focused ? 15 : 2, bevel: 0.30)
        case "Prism Bevel": return .init(depth: focused ? 13 : 5, bevel: 0.75)
        default: return .init(depth: 0, bevel: 0)
        }
    }
    static func migrateSurfaceSplit(defaults: UserDefaults = .standard) {
        guard !defaults.bool(forKey: "signalSurfaceSplitF36V1") else { return }
        let shape = defaults.string(forKey: "signalLiveTVCardThemeV342") ?? "Original UNITY"
        let effect = defaults.string(forKey: "signalLiveTVCardEffectV344") ?? "Dual Inward"
        if shape == "Original UNITY", names.dropFirst(5).contains(effect) {
            defaults.set(effect, forKey: "signalLiveTVCardThemeV342")
        }
        defaults.set(true, forKey: "signalSurfaceSplitF36V1")
    }
}
