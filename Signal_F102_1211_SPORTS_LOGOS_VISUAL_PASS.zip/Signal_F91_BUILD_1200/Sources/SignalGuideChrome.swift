import SwiftUI

/// The full Guide and Bottom Quick Guide use the same translucent black surface.
/// No material blur, offscreen drawing group, or per-cell animation is required.
enum SignalGuideChrome {
    static let panelFill = Color.black.opacity(0.78)
    static let cellFill = Color.white.opacity(0.085)
    static let cellBorder = Color.white.opacity(0.055)
}

struct SignalUpNextButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    let focused: Bool
    let primary: Bool
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundStyle(primary && enabled ? Color.black : Color.white.opacity(enabled ? 1 : 0.65))
            .background {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(primary && enabled ? Color.orange : Color.white.opacity(focused ? 0.25 : 0.14))
            }
            .overlay {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(Color.white.opacity(focused ? 1 : 0.40), lineWidth: focused ? 3 : 1)
            }
            .opacity(configuration.isPressed ? 0.78 : 1)
            .contentShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}
