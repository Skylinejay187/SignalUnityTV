import Foundation
import CoreFoundation
import CryptoKit

struct SignalEpisodeSegment: Equatable, Identifiable, Codable {
    enum Kind: String, Codable { case intro, recap, credits, postCredits }
    let kind: Kind
    let start: Double
    let end: Double
    let provider: String
    var id: String { "\(provider):\(kind.rawValue):\(start):\(end)" }
    func valid(duration: Double) -> Bool {
        guard start.isFinite, end.isFinite, duration.isFinite, start >= 0, end > start,
              end - start >= 5, end - start <= (kind == .intro ? 300 : 900) else { return false }
        return duration <= 0 || (start < duration && end <= duration + 1)
    }
}

/// Title identities and timing values only; never receives playback URLs or debrid keys.
struct SignalEpisodeSegmentReport: Equatable {
    var segments: [SignalEpisodeSegment] = []
    var providers: [String: String] = [:]
    var complete = false
}

actor SignalEpisodeSegmentService {
    static let shared = SignalEpisodeSegmentService()
    private var cache: [String: (Date, SignalEpisodeSegmentReport)] = [:]
    private let session: URLSession
    private var diagnosticOwner = UUID()
    init(session: URLSession = .shared) { self.session = session }
    private var status: [String: String] = [:]
    private var submissions: Set<String> = []
    private var attempted: [String: Date] = [:]
    func statuses() -> [String: String] { status }
    static func imdb(_ item: MediaItem) -> String? {
        for value in [item.imdbId ?? "", item.id] {
            if let range = value.range(of: #"tt\d{5,12}"#, options: .regularExpression) { return String(value[range]) }
        }
        return nil
    }
    static func parse(_ json: Any, provider: String, duration: Double) -> [SignalEpisodeSegment] {
        func number(_ value: Any?) -> Double? {
            if let n = value as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID() { return n.doubleValue }
            if let s = value as? String { return Double(s) }
            return nil
        }
        func segment(_ value: [String: Any], kind: SignalEpisodeSegment.Kind) -> SignalEpisodeSegment? {
            if value["match"] as? String == "out-of-range" { return nil }
            let start = number(value["start_sec"]) ?? number(value["start_ms"]).map { $0 / 1000 } ?? number(value["start"]) ?? ((kind == .intro || kind == .recap) && (value["start_ms"] is NSNull || value["start_sec"] is NSNull || value["start"] is NSNull) ? 0 : nil)
            let end = number(value["end_sec"]) ?? number(value["end_ms"]).map { $0 / 1000 } ?? number(value["end"]) ?? (kind == .credits && value["end_ms"] is NSNull && duration > 0 ? duration : nil)
            guard let start, let end else { return nil }
            let result = SignalEpisodeSegment(kind: kind, start: start, end: end, provider: provider)
            return result.valid(duration: duration) ? result : nil
        }
        if let array = json as? [[String: Any]] {
            return array.prefix(128).compactMap { value in
                let raw = (value["type"] as? String ?? value["category"] as? String ?? value["label"] as? String ?? "").lowercased()
                let kind: SignalEpisodeSegment.Kind?
                switch raw { case "intro", "opening": kind = .intro; case "recap": kind = .recap; case "outro", "credits", "ending", "end credits": kind = .credits; case "post-credits", "post_credits": kind = .postCredits; default: kind = nil }
                return kind.flatMap { segment(value, kind: $0) }
            }
        }
        guard let root = json as? [String: Any] else { return [] }
        let values = root["segments"] as? [String: Any] ?? root
        return [("intro", SignalEpisodeSegment.Kind.intro), ("recap", .recap), ("outro", .credits), ("credits", .credits), ("post_credits", .postCredits)].flatMap { key, kind -> [SignalEpisodeSegment] in
            if let value = values[key] as? [String: Any] { return segment(value, kind: kind).map { [$0] } ?? [] }
            if let windows = values[key] as? [[String: Any]] { return windows.prefix(32).compactMap { segment($0, kind: kind) } }
            return []
        }
    }
    static func chapterRecaps(_ chapters: [PlaybackChapterMarker], duration: Double) -> [SignalEpisodeSegment] {
        chapters.prefix(512).compactMap { chapter in
            let title = chapter.title.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            let named = title == "recap" || title.hasPrefix("recap:") || title.hasPrefix("recap ")
                || title.hasPrefix("previously on") || title == "previously"
            guard named, chapter.startSeconds <= 600, chapter.endSeconds <= 900 else { return nil }
            let segment = SignalEpisodeSegment(kind: .recap, start: chapter.startSeconds,
                end: chapter.endSeconds, provider: "embedded-chapter")
            return segment.valid(duration: duration) ? segment : nil
        }
    }
    static func coordinates(_ item: MediaItem) -> (Int, Int)? {
        if let season = item.seasonNumber, let episode = item.episodeNumber, season >= 0, episode >= 0 {
            return (season, episode)
        }
        // Standard Stremio video identities carry the series and exact S/E coordinates.
        let parts = item.id.split(separator: ":")
        if parts.count >= 3, let season = Int(parts[parts.count - 2]), let episode = Int(parts[parts.count - 1]), season >= 0, episode >= 0 {
            return (season, episode)
        }
        return nil
    }
    private static func numericID(_ value: String?) -> String? {
        guard let value = value?.trimmingCharacters(in: .whitespacesAndNewlines),
              !value.isEmpty, value.allSatisfy({ $0.isASCII && $0.isNumber }),
              let number = Int(value), number > 0 else { return nil }
        return value
    }
    static func identityKey(_ item: MediaItem) -> String {
        let coordinate = coordinates(item)
        return [item.id, imdb(item) ?? "", numericID(item.tvdbId) ?? "", numericID(item.tmdbId) ?? "",
                coordinate.map { "\($0.0):\($0.1)" } ?? item.type.lowercased()].joined(separator: "|")
    }
    static func requests(for item: MediaItem, duration: Double, options: SignalEpisodeOptions) -> [(String, URL)] {
        let coordinate = coordinates(item)
        let series = ["series", "tv", "show", "episode"].contains(item.type.lowercased())
        guard !series || coordinate != nil else { return [] }
        let imdb = imdb(item)
        var query: [URLQueryItem] = []
        if let imdb { query.append(URLQueryItem(name: "imdb_id", value: imdb)) }
        if let coordinate {
            query += [URLQueryItem(name: "season", value: String(coordinate.0)), URLQueryItem(name: "episode", value: String(coordinate.1))]
        }
        var urls: [(String, URL)] = []
        func append(_ provider: String, _ base: String, _ items: [URLQueryItem]) {
            var c = URLComponents(string: base)!; c.queryItems = items
            if let url = c.url { urls.append((provider, url)) }
        }
        let timed = duration.isFinite && duration >= 60 && duration <= 21600
        if options.skipDB, imdb != nil {
            append("skipdb", "https://api.skipdb.tv/api/segments", query + (timed ? [URLQueryItem(name: "duration", value: String(Int(duration.rounded())))] : []))
        }
        if options.introDB, imdb != nil {
            append("introdb", "https://api.introdb.app/segments", query + (coordinate == nil ? [URLQueryItem(name: "is_movie", value: "true")] : []))
        }
        if options.theIntroDB {
            var alternate = query.filter { $0.name != "imdb_id" }
            if let tvdb = numericID(item.tvdbId) { alternate.append(URLQueryItem(name: "tvdb_id", value: tvdb)) }
            else if let tmdb = numericID(item.tmdbId) { alternate.append(URLQueryItem(name: "tmdb_id", value: tmdb)) }
            else if let imdb { alternate.append(URLQueryItem(name: "imdb_id", value: imdb)) }
            if alternate.contains(where: { ["tvdb_id", "tmdb_id", "imdb_id"].contains($0.name) }) {
                append("theintrodb", "https://api.theintrodb.org/v4/media", alternate + (timed ? [URLQueryItem(name: "duration_ms", value: String(Int((duration * 1000).rounded())))] : []))
            }
        }
        if options.introHater, let imdb {
            let videoID = coordinate.map { "\(imdb):\($0.0):\($0.1)" } ?? imdb
            urls.append(("introhater", URL(string: "https://introhater.com/api/segments/")!.appendingPathComponent(videoID)))
        }
        return urls
    }
    static func ranked(_ segments: [SignalEpisodeSegment]) -> [SignalEpisodeSegment] {
        let ranks = ["skipdb": 4, "theintrodb": 3, "introdb": 2, "introhater": 1]
        return Array(segments.sorted {
            let left = ranks[$0.provider] ?? 0, right = ranks[$1.provider] ?? 0
            if left != right { return left > right }
            return $0.id < $1.id
        }.prefix(64))
    }
    func segments(for item: MediaItem, duration: Double, options: SignalEpisodeOptions, forceRefresh: Bool = false) async -> [SignalEpisodeSegment] {
        await lookup(for: item, duration: duration, options: options, forceRefresh: forceRefresh).segments
    }
    func lookup(for item: MediaItem, duration: Double, options: SignalEpisodeOptions, forceRefresh: Bool = false,
                onUpdate: (@Sendable (SignalEpisodeSegmentReport) async -> Void)? = nil) async -> SignalEpisodeSegmentReport {
        let owner = UUID(); diagnosticOwner = owner
        let cacheKey = "\(Self.identityKey(item)):\(duration.isFinite && duration > 0 ? Int(min(duration, 21600) / 5) : 0):\(options.providerKey)"
        if !forceRefresh, let cached = cache[cacheKey], cached.0 > Date() {
            status = cached.1.providers
            if let onUpdate { await onUpdate(cached.1) }
            return cached.1
        }
        let urls = Self.requests(for: item, duration: duration, options: options)
        var report = SignalEpisodeSegmentReport()
        for (provider, enabled) in [("skipdb", options.skipDB), ("introdb", options.introDB), ("theintrodb", options.theIntroDB), ("introhater", options.introHater)] where enabled {
            report.providers[provider] = urls.contains(where: { $0.0 == provider }) ? "Looking up this episode…" : "Title identity or season/episode missing"
        }
        if report.providers.isEmpty { report.providers["providers"] = "All community timing providers are off" }
        status = report.providers
        if let onUpdate { await onUpdate(report) }
        await withTaskGroup(of: (String, [SignalEpisodeSegment], String).self) { group in
            for (provider, url) in urls {
                group.addTask {
                    let result = await self.fetch(url: url, provider: provider, duration: duration, forceRefresh: forceRefresh)
                    return (provider, result.0, result.1)
                }
            }
            for await (provider, segments, message) in group {
                guard !Task.isCancelled else { group.cancelAll(); continue }
                report.segments = Self.ranked(report.segments + segments)
                report.providers[provider] = message
                if diagnosticOwner == owner { status = report.providers }
                // A slow/offline provider must not withhold another provider's ready recap.
                if let onUpdate { await onUpdate(report) }
            }
        }
        guard !Task.isCancelled else { return report }
        report.complete = true
        if diagnosticOwner == owner { status = report.providers }
        cache = cache.filter { $0.value.0 > Date() }
        if cache.count >= 64, let oldest = cache.min(by: { $0.value.0 < $1.value.0 })?.key { cache.removeValue(forKey: oldest) }
        cache[cacheKey] = (Date().addingTimeInterval(report.segments.isEmpty ? 10 : 21600), report)
        if let onUpdate { await onUpdate(report) }
        return report
    }
    private func fetch(url: URL, provider: String, duration: Double, forceRefresh: Bool) async -> ([SignalEpisodeSegment], String) {
        do {
            var request = URLRequest(url: url); request.timeoutInterval = 5
            if forceRefresh { request.cachePolicy = .reloadIgnoringLocalCacheData }
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            let (data, response) = try await session.data(for: request)
            try Task.checkCancellation()
            guard let http = response as? HTTPURLResponse else { return ([], "Invalid provider response") }
            guard http.statusCode == 200, data.count <= 1_000_000 else {
                return ([], http.statusCode == 404 ? "No timings for this episode" : "Unavailable (\(http.statusCode))")
            }
            let json = try JSONSerialization.jsonObject(with: data)
            let result = Self.parse(json, provider: provider, duration: duration)
            if let root = json as? [String: Any], root["no_recap"] as? Bool == true,
               !result.contains(where: { $0.kind == .recap }) { return (result, "Episode marked as having no recap") }
            let recaps = result.filter { $0.kind == .recap }.count
            return (result, recaps > 0 ? "\(recaps) validated recap(s) • \(result.count) total segments" : "No validated recap • \(result.count) other segments")
        } catch {
            return ([], Task.isCancelled ? "Lookup cancelled" : "Unavailable; playback continues")
        }
    }
    func submitDiscoveredIntro(_ marker: VODIntroMarker, item: MediaItem, duration: Double, options: SignalEpisodeOptions) async {
        // Never re-submit a provider's work or publish an unverified recurrence guess.
        guard !Task.isCancelled, options.submit, options.introDB, marker.chapterIndex != nil, marker.isStorySafe,
              duration.isFinite, duration > marker.endSeconds, let imdb = Self.imdb(item),
              let season = item.seasonNumber, let episode = item.episodeNumber,
              season >= 0, episode > 0 else { return }
        let key = SignalIntroDBCredential.read(); guard !key.isEmpty else { return }
        let raw = "\(imdb):\(season):\(episode):\(marker.startSeconds):\(marker.endSeconds):\(key)"
        let id = SHA256.hash(data: Data(raw.utf8)).map { String(format: "%02x", $0) }.joined()
        let defaults = UserDefaults.standard
        var sent = defaults.stringArray(forKey: "episodeSubmittedTimingIDsV1") ?? []
        guard !sent.contains(id), Date().timeIntervalSince(attempted[id] ?? .distantPast) >= 60,
              submissions.insert(id).inserted else { return }
        attempted = attempted.filter { Date().timeIntervalSince($0.value) < 3600 }
        attempted[id] = Date()
        defer { submissions.remove(id) }
        do {
            var request = URLRequest(url: URL(string: "https://api.introdb.app/submit")!)
            request.httpMethod = "POST"; request.timeoutInterval = 6
            request.setValue(key, forHTTPHeaderField: "X-API-Key")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: ["imdb_id": imdb, "season": season, "episode": episode, "segment_type": "intro", "start_sec": marker.startSeconds, "end_sec": marker.endSeconds])
            let (_, response) = try await URLSession.shared.data(for: request)
            try Task.checkCancellation()
            if let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) {
                sent.append(id); defaults.set(Array(sent.suffix(256)), forKey: "episodeSubmittedTimingIDsV1")
                status["submission"] = "Discovered intro submitted"
            } else { status["submission"] = "Submission not accepted; playback unaffected" }
        } catch { status["submission"] = "Submission unavailable; playback unaffected" }
    }
}

/// A pure decision: no timers, I/O or player commands. The mounted player owns execution.
enum SignalEpisodeSkipPlan {
    enum Action: Equatable { case none, seek(Double, String), next(String) }
    static func recap(segments: [SignalEpisodeSegment], consumed: Set<String>, position: Double, duration: Double, lead: Double = 0) -> SignalEpisodeSegment? {
        guard position.isFinite, position >= 0, duration.isFinite, duration > 0 else { return nil }
        return segments.first { $0.kind == .recap && $0.valid(duration: duration) && $0.start <= 600 && $0.end <= 900
            && position >= max(0, $0.start - min(1, max(0, lead)))
            && position < $0.end - 0.5 && !consumed.contains($0.id) }
    }

    static func action(segments: [SignalEpisodeSegment], consumed: Set<String>, position: Double,
                       duration: Double, options: SignalEpisodeOptions) -> Action {
        guard position.isFinite, position >= 0, duration.isFinite, duration > 0 else { return .none }
        for kind in [SignalEpisodeSegment.Kind.recap, .credits] {
            guard let segment = segments.first(where: { $0.kind == kind && $0.valid(duration: duration) && position >= $0.start && position < $0.end - 0.5 }),
                  !consumed.contains(segment.id) else { continue }
            if kind == .recap {
                if options.autoRecap && segment.start <= 600 && segment.end <= 900 { return .seek(segment.end, segment.id) }
                continue
            }
            guard segment.start >= duration * 0.5, options.credits != "keep" else { continue }
            if options.credits == "next" { return .next(segment.id) }
            let scenes = segments.filter { $0.kind == .postCredits && $0.valid(duration: duration) }
            guard !scenes.contains(where: { position >= $0.start && position < $0.end }) else { return .none }
            let target = min(segment.end, scenes.filter { $0.start > position }.map(\.start).min() ?? segment.end, duration - 0.5)
            return target > position + 0.5 ? .seek(target, segment.id) : .none
        }
        return .none
    }
    static func chapterTarget(_ chapters: [PlaybackChapterMarker], position: Double, duration: Double, forward: Bool) -> Double? {
        guard position.isFinite else { return nil }
        let candidates = chapters.filter { $0.startSeconds.isFinite && $0.startSeconds >= 0 &&
            (duration <= 0 || $0.startSeconds < duration) }.sorted { $0.startSeconds < $1.startSeconds }
        return (forward ? candidates.first(where: { $0.startSeconds > position + 1 }) : candidates.last(where: { $0.startSeconds < position - 3 }))?.startSeconds
    }
}
