import SwiftUI

struct SignalEpisodeExperienceSettings: View {
    var playbackStatus: String? = nil
    @Environment(\.dismiss) private var dismiss
    @AppStorage("episodeSkipDBV1") private var skipDB = true
    @AppStorage("episodeIntroDBV1") private var introDB = true
    @AppStorage("episodeIntroHaterV1") private var introHater = true
    @AppStorage("episodeTheIntroDBV1") private var theIntroDB = true
    @AppStorage("episodeAniSkipV1") private var aniSkip = true
    @AppStorage("episodeAutoIntroV1") private var autoIntro = false
    @AppStorage("episodeAutoRecapV1") private var autoRecap = false
    @AppStorage("episodeSubmitIntrosV1") private var submit = false
    @AppStorage("episodeCreditsV1") private var credits = "keep"
    @AppStorage("episodeNextStyleV1") private var nextStyle = "countdown"
    @AppStorage("episodeNextAppearanceV1") private var appearance = 240
    @AppStorage("episodeCountdownV1") private var countdown = 15
    @AppStorage("episodeContinuousV1") private var continuous = "series"
    @AppStorage("episodeStillCountV1") private var stillCount = 3
    @AppStorage("episodeStillMinutesV1") private var stillMinutes = 120
    @AppStorage("quickGuideFocusPreviewEnabledV1") private var quickGuidePreview = false
    @AppStorage("quickGuideFocusPreviewModeV1") private var quickGuideMode = "Pause main + preview audio"
    @AppStorage("pauseInfoShowDelayV1") private var pauseShowDelay = 1.5
    @AppStorage("pauseInfoHideDelayV1") private var pauseHideDelay = 1.5
    @AppStorage("pauseInfoIdleDimV1") private var pauseIdleDim = false
    @AppStorage("pauseInfoThemeV1") private var pauseTheme = "Liquid Glass"
    @AppStorage("metadataCacheEnabledV1") private var metadataCache = true
    @AppStorage("episodeIntroDBKeyPresentV1") private var keyPresent = false
    @State private var key = ""
    @State private var message = ""
    @State private var statuses: [String: String] = [:]
    @State private var cacheStatus = ""
    var body: some View {
        NavigationStack {
            Form {
                if let playbackStatus { Section("This playback • skip status") { Text(playbackStatus).font(.caption) } }
                Section("Quick Guide previews • Live TV & VOD") {
                    Toggle("Preview focused channel (VOD 1.5s / Live TV 3s)", isOn: $quickGuidePreview)
                    Picker("Main playback and preview audio", selection: $quickGuideMode) {
                        ForEach(SignalQuickGuidePreviewMode.allCases, id: \.rawValue) { Text($0.rawValue).tag($0.rawValue) }
                    }
                    Text("Off by default. Continuing the main video uses two video pipelines. Only one audio source is audible; closing the preview restores the previous main playback state.").font(.caption)
                }
                Section("Paused playback card") {
                    Toggle("Dim paused video after 1 minute without remote activity", isOn: $pauseIdleDim)
                    Text("Keeps the pause card bright. Remote activity or resuming playback removes the dimming.").font(.caption)
                    Picker("Show after pausing", selection: $pauseShowDelay) {
                        ForEach([0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0], id: \.self) { value in
                            Text(String(format: "%.1f seconds", value)).tag(value)
                        }
                    }
                    Picker("Hide after resuming", selection: $pauseHideDelay) {
                        ForEach([0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0], id: \.self) { value in
                            Text(String(format: "%.1f seconds", value)).tag(value)
                        }
                    }
                    Picker("Card theme", selection: $pauseTheme) {
                        ForEach(["Liquid Glass", "Signal Glass", "Frosted Glass", "Cinema", "Minimal"], id: \.self) { Text($0).tag($0) }
                    }
                    Text("Playback resumes immediately. Only the passive card waits before fading away.").font(.caption)
                }
                Section("Metadata & scrolling") {
                    Toggle("Cache main Unity catalogs, Live TV grid and Guide metadata", isOn: $metadataCache)
                    Text("Reuses the shared catalog/search metadata in main Unity and VOD browsing, and current-program/guide rows in the main Live TV grid and Guide while scrolling. Catalog responses use up to 8 MB memory and 32 MB disk; Guide row/layout reuse is bounded separately and clears when listings change. Artwork and video caches keep their existing controls.").font(.caption)
                    if !cacheStatus.isEmpty { Text(cacheStatus).font(.caption) }
                    Button("Refresh cache activity") { Task { cacheStatus = await SignalMetadataResponseCache.shared.diagnostics() } }
                    Button("Clear metadata cache") { Task { await CatalogHeroMetadataCache.shared.clearCachedMetadata(); await SignalMetadataResponseCache.shared.clear(); await MainActor.run { SignalGuideMetadataCacheControl.clear() }; message = "Metadata cache cleared" } }
                }
                Section("Skip providers") {
                    Toggle("SkipDB", isOn: $skipDB)
                    Toggle("IntroHater", isOn: $introHater)
                    Toggle("IntroDB", isOn: $introDB)
                    Toggle("TheIntroDB", isOn: $theIntroDB)
                    Toggle("AniSkip", isOn: $aniSkip)
                    Text("Unavailable providers never prevent playback. Exact-file chapters take priority. Coverage and timestamp accuracy vary by title and release.").font(.caption)
                    ForEach(statuses.keys.sorted(), id: \.self) { provider in Text("\(provider): \(statuses[provider] ?? "")").font(.caption) }
                    Button("Refresh provider status") { Task { statuses = await SignalEpisodeSegmentService.shared.statuses() } }
                    Text(keyPresent ? "IntroDB API key: saved" : "IntroDB API key: not configured").font(.caption)
                    SecureField("Optional IntroDB API key", text: $key)
                    Button("Save IntroDB key") { message = SignalIntroDBCredential.save(key) ? "IntroDB key saved" : "Key could not be saved"; key = "" }
                    Button("Remove IntroDB key") { message = SignalIntroDBCredential.save("") ? "IntroDB key removed" : "Key could not be removed" }
                    Toggle("Submit discovered intro timings to IntroDB", isOn: $submit)
                    Text("Requires your IntroDB key. Shares only title identity and validated exact-file intro chapter timings; never your media URL or debrid credentials. Provider timings and uncertain audio guesses are not re-submitted.").font(.caption)
                }
                Section("Episode behavior") {
                    Toggle("Automatically skip verified intros", isOn: $autoIntro)
                    Toggle("Automatically skip verified recaps", isOn: $autoRecap)
                    Picker("Credits", selection: $credits) {
                        Text("Keep playing").tag("keep")
                        Text("Skip credits, retain known post-credit scenes").tag("skip")
                        Text("Jump to next episode when ready").tag("next")
                    }
                    Picker("Next episode presentation", selection: $nextStyle) { Text("Up Next countdown").tag("countdown"); Text("Next button (manual)").tag("button") }
                    Picker("Show Up Next before end", selection: $appearance) {
                        ForEach([10, 30, 60, 120, 180, 240, 300, 600], id: \.self) { Text("\($0) seconds").tag($0) }
                    }
                    Picker("Countdown length", selection: $countdown) { ForEach([3, 5, 10, 15, 20, 30, 60], id: \.self) { Text("\($0) seconds").tag($0) } }
                    Picker("Continuous playback", selection: $continuous) {
                        Text("Off — choose each episode").tag("off")
                        Text("Current season only").tag("season")
                        Text("Continue across seasons").tag("series")
                    }
                    Text("Auto Next Episode in main playback settings must also be on. Dismiss remains available. Chapter Previous/Next is in the player's Settings menu.").font(.caption)
                }
                Section("Still watching?") {
                    Picker("Ask after episodes", selection: $stillCount) { ForEach([0, 2, 3, 5, 10], id: \.self) { Text($0 == 0 ? "Disabled" : "\($0) episodes").tag($0) } }
                    Picker("Ask after viewing time", selection: $stillMinutes) { ForEach([0, 60, 90, 120, 180, 240], id: \.self) { Text($0 == 0 ? "Disabled" : "\($0) minutes").tag($0) } }
                    Text("Asks before the next automatic episode when either limit is reached. Pauses and large seeks do not count as watched time.").font(.caption)
                }
                if !message.isEmpty { Section { Text(message) } }
                Button("Done") { dismiss() }
            }
            .navigationTitle("Episode behavior & metadata")
        }
        .task { statuses = await SignalEpisodeSegmentService.shared.statuses(); cacheStatus = await SignalMetadataResponseCache.shared.diagnostics() }
        .onChange(of: metadataCache) { _, enabled in if !enabled { Task { await CatalogHeroMetadataCache.shared.clearCachedMetadata(); await SignalMetadataResponseCache.shared.clear(); await MainActor.run { SignalGuideMetadataCacheControl.clear() } } } }
        .onExitCommand { dismiss() }
    }
}

struct SignalStillWatchingPrompt: View {
    let continueEnabled: Bool
    let continuePlaying: () -> Void
    let stop: () -> Void
    var body: some View {
        VStack(spacing: 30) {
            Text("Still watching?").font(.largeTitle.bold())
            Text("The next episode is ready. Choose Continue to keep watching.")
            if !continueEnabled { Text("Playback route verification is required before continuing.").font(.caption) }
            HStack(spacing: 35) {
                Button("Continue", action: continuePlaying).disabled(!continueEnabled)
                Button("Stop autoplay", action: stop)
            }
        }.padding(70).onExitCommand(perform: stop)
    }
}
