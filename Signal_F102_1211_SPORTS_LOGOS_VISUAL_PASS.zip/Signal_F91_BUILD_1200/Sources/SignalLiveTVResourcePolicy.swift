import Foundation

enum SignalLiveTVResourcePolicy {
    static let quickGuideWindow = 48
    static let smokeSprites = 12
    static let smokeTexturePixels = 256
    static func rows(_ value: Int) -> Int { value == 4 ? 4 : 3 }
    static func pageSize(rows value: Int) -> Int { rows(value) * 4 }
    static func window(count: Int, anchor: Int, limit: Int = quickGuideWindow) -> Range<Int> {
        let count = max(0, count), size = min(max(1, limit), max(0, count))
        let start = min(max(0, anchor - size / 2), max(0, count - size))
        return start..<(start + size)
    }
    static func cardHeight(width: Double, height: Double, rows value: Int,
                           mirror: Bool, spread: Bool, expanded: Bool, split: Bool) -> Double {
        let rowCount = rows(value)
        let columnGap = mirror ? 29.0 : 28.0
        let rowGap = mirror ? 23.0 : (spread ? 30.0 : 25.0)
        let horizontal = mirror ? 80.0 : (expanded ? 98.0 : 148.0)
        let cardWidth = max(1, (width - horizontal - (split ? 4 : 3) * columnGap - (split ? 46 : 0)) / 4)
        // Mirror: 50 top + 92 header + 13 gap + 150 footer/bottom reserve.
        // Golden: 132 (104 expanded) top + 48 header + 30 gap/badge + 64 bottom.
        let reserved = mirror ? 305.0 : (expanded ? 246.0 : 274.0)
        let fit = max(1, (height - reserved - Double(rowCount - 1) * rowGap) / Double(rowCount))
        if mirror {
            return min(cardWidth * 9 / 16, fit)
        }
        return rowCount == 3 ? min(spread ? 252 : 210, fit) : min(cardWidth * 9 / 16, fit)
    }
}

/// Counts requested render owners, not a claim about decoder internals or GPU utilization.
@MainActor enum SignalLiveTVResourceLedger {
    private static var hosts: [UUID: Bool] = [:]
    private static var smokeOwners: Set<UUID> = []
    private static var backdropOwners: Set<UUID> = []
    static func beginHost(auxiliary: Bool) -> UUID { let id = UUID(); hosts[id] = auxiliary; return id }
    static func endHost(_ id: UUID?) { if let id { hosts.removeValue(forKey: id) } }
    static func smoke(_ id: UUID, active: Bool) { if active { smokeOwners.insert(id) } else { smokeOwners.remove(id) } }
    static func backdrop(_ id: UUID, active: Bool) { if active { backdropOwners.insert(id) } else { backdropOwners.remove(id) } }
    static var summary: String {
        "hosts=\(hosts.count) auxiliary=\(hosts.values.filter { $0 }.count) smoke=\(smokeOwners.count) backdrops=\(backdropOwners.count)"
    }
}

/// Explicit user choice; one audible lane even when two video pipelines run.
enum SignalQuickGuidePreviewMode: String, CaseIterable {
    case pauseMain = "Pause main + preview audio"
    case silentPreview = "Continue main + silent preview"
    case previewAudio = "Continue main muted + preview audio"
    static func resolved(_ raw: String) -> Self { Self(rawValue: raw) ?? .pauseMain }
    var pausesMain: Bool { self == .pauseMain }
    var mutesMain: Bool { self == .previewAudio }
    var mutesPreview: Bool { self == .silentPreview }
}
