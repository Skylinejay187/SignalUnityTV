import SwiftUI
import UIKit
import ImageIO
import Kingfisher

// F78 shared Kingfisher transport. Kept independent of SwiftUI view/focus state.
final class SignalArtworkDiagnostics: NSObject, NSCacheDelegate, @unchecked Sendable {
    static let shared = SignalArtworkDiagnostics()
    private let lock = NSLock()
    private var counters: [String: Double] = [:]
    func record(_ key: String, _ amount: Double = 1) {
        lock.lock(); counters[key, default: 0] += amount; lock.unlock()
    }
    func latency(_ milliseconds: Double) {
        lock.lock(); defer { lock.unlock() }
        counters["loadMaxMilliseconds"] = max(counters["loadMaxMilliseconds", default: 0], milliseconds)
        let bucket = milliseconds < 16 ? "loadsUnder16ms" : milliseconds < 50 ? "loadsUnder50ms" : milliseconds < 200 ? "loadsUnder200ms" : "loadsOver200ms"
        counters[bucket, default: 0] += 1
    }
    func snapshot() -> [String: Double] {
        lock.lock(); defer { lock.unlock() }
        var result = counters
        let count = result["loadsCompleted", default: 0]
        result["localLoadHitRatio"] = count > 0 ? result["localLoadsCompleted", default: 0] / count : 0
        result["meanLoadMilliseconds"] = count > 0 ? result["loadMilliseconds", default: 0] / count : 0
        return result
    }
    func reset() { lock.lock(); counters.removeAll(); lock.unlock() }
    func cache(_ cache: NSCache<AnyObject, AnyObject>, willEvictObject obj: Any) {
        record("decodedEvictions")
    }
}

private final class SignalArtworkImageCache: ImageCache, @unchecked Sendable {
    override func retrieveImage(forKey key: String, options: KingfisherParsedOptionsInfo,
        callbackQueue: CallbackQueue = .mainCurrentOrAsync,
        completionHandler: (@Sendable (Result<ImageCacheResult, KingfisherError>) -> Void)?) {
        super.retrieveImage(forKey: key, options: options, callbackQueue: callbackQueue) { result in
            if case .success(let hit) = result {
                switch hit.cacheType {
                case .memory: SignalArtworkDiagnostics.shared.record("kingfisherMemoryHits")
                case .disk: SignalArtworkDiagnostics.shared.record("kingfisherDiskHits")
                case .none: break
                }
            }
            if case .failure = result, self === SignalArtworkTransport.originalCache {
                SignalArtworkDiagnostics.shared.record("cacheRepairs")
                self.removeImage(forKey: key, processorIdentifier: options.processor.identifier) {
                    callbackQueue.execute { completionHandler?(.success(.none)) }
                }
            } else { completionHandler?(result) }
        }
    }
}

private final class SignalArtworkDownloadObserver: ImageDownloaderDelegate, @unchecked Sendable {
    func imageDownloader(_ downloader: ImageDownloader, didDownload data: Data, with task: SessionDataTask) -> Data? {
        // Called once for an underlying URLSession transfer, not once per subscriber/size.
        SignalArtworkDiagnostics.shared.record("networkTransfers")
        SignalArtworkDiagnostics.shared.record("networkBytes", Double(data.count))
        if let response = task.task.response as? HTTPURLResponse {
            switch response.value(forHTTPHeaderField: "CF-Cache-Status")?.uppercased() {
            case "HIT": SignalArtworkDiagnostics.shared.record("cloudflareHits")
            case "MISS": SignalArtworkDiagnostics.shared.record("cloudflareMisses")
            default: break
            }
        }
        return data
    }
}

@MainActor
final class SignalArtworkRequest {
    private(set) var cancelled = false
    private var task: DownloadTask?
    func install(_ task: DownloadTask?) {
        if cancelled { task?.cancel() } else { self.task = task }
    }
    func cancel() {
        cancelled = true; task?.cancel(); task = nil
        SignalArtworkDiagnostics.shared.record("requestCancellations")
    }
}

// Kingfisher 8.11's standard .image downsampling path first re-encodes the full
// original image. Reuse the committed encoded bytes on the utility processing queue
// instead. Identifier and pixel processing remain exactly the standard downsampler's.
private struct SignalArtworkDownsamplingProcessor: ImageProcessor {
    let url: URL
    let base: DownsamplingImageProcessor
    var identifier: String { base.identifier }
    func process(item: ImageProcessItem, options: KingfisherParsedOptionsInfo) -> KFCrossPlatformImage? {
        if case .image = item,
           let data = try? SignalArtworkTransport.originalCache.diskStorage.value(forKey: url.absoluteString) {
            if let image = base.process(item: .data(data), options: options) {
                SignalArtworkDiagnostics.shared.record("rawDownsampleReuses")
                return image
            }
        }
        return base.process(item: item, options: options)
    }
}

private struct SignalArtworkFullSizeProcessor: ImageProcessor {
    let identifier = "Signal.FullSize.v1"
    func process(item: ImageProcessItem, options: KingfisherParsedOptionsInfo) -> KFCrossPlatformImage? {
        DefaultImageProcessor.default.process(item: item, options: options)
    }
}

enum SignalArtworkTransport {
    // Preserve F77's processed cache name so exact-size disk entries can migrate lazily.
    static let processedCache: ImageCache = {
        let cache = SignalArtworkImageCache(name: "SignalProcessedArtworkF43")
        cache.memoryStorage.config.totalCostLimit = 8 * 1024 * 1024
        cache.memoryStorage.config.countLimit = 24
        cache.memoryStorage.config.expiration = .seconds(60)
        cache.diskStorage.config.sizeLimit = 256 * 1024 * 1024
        cache.diskStorage.config.expiration = .days(30)
        return cache
    }()
    static let originalCache: ImageCache = {
        let cache = SignalArtworkImageCache(name: "SignalOriginalArtworkF78")
        // Originals are disk bytes, not an additional reservoir of full-size decoded images.
        cache.memoryStorage.config.totalCostLimit = 1
        cache.memoryStorage.config.countLimit = 1
        cache.memoryStorage.config.expiration = .expired
        cache.diskStorage.config.sizeLimit = 384 * 1024 * 1024
        cache.diskStorage.config.expiration = .days(30)
        return cache
    }()
    private static let downloadObserver = SignalArtworkDownloadObserver()
    static let downloader: ImageDownloader = {
        let downloader = ImageDownloader(name: "SignalSharedArtworkF78")
        let configuration = URLSessionConfiguration.ephemeral
        configuration.urlCache = nil
        configuration.httpMaximumConnectionsPerHost = 4
        configuration.timeoutIntervalForRequest = 24
        configuration.timeoutIntervalForResource = 36
        downloader.sessionConfiguration = configuration
        downloader.downloadTimeout = 24
        downloader.delegate = downloadObserver
        return downloader
    }()
    private static let processingQueue = DispatchQueue(label: "Signal.Artwork.Kingfisher.processing", qos: .utility)
    private static let cleanupObserver: NSObjectProtocol = NotificationCenter.default.addObserver(
        forName: .KingfisherDidCleanDiskCache, object: nil, queue: nil) { notification in
            guard let cache = notification.object as? ImageCache,
                  cache === processedCache || cache === originalCache,
                  let hashes = notification.userInfo?[KingfisherDiskCacheCleanedHashKey] as? [String] else { return }
            SignalArtworkDiagnostics.shared.record("diskEvictions", Double(hashes.count))
        }

    // Only known immutable, content-addressed CatalogServer objects receive a long TTL.
    // Never strip signed query parameters or assume every provider URL is immutable.
    static func expiration(for url: URL) -> StorageExpiration {
        let name = url.path
        let hasContentHash = name.range(of: "[a-fA-F0-9]{16,}", options: .regularExpression) != nil
        return url.path.hasPrefix("/assets/") && url.query == nil && hasContentHash ? .days(365) : .days(30)
    }
    static func options(url: URL, maxPixelSize: Int, speculative: Bool) -> KingfisherOptionsInfo {
        _ = cleanupObserver
        var options: KingfisherOptionsInfo = [
            .targetCache(processedCache), .originalCache(originalCache), .cacheOriginalImage,
            .downloader(downloader), .processingQueue(.dispatch(processingQueue)),
            .callbackQueue(.mainAsync), .asyncCacheTypeCheck, .waitForCache,
            .memoryCacheExpiration(.seconds(60)), .diskCacheExpiration(expiration(for: url)),
            .downloadPriority(speculative ? 0.1 : 0.8)
        ]
        if maxPixelSize > 0 {
            let side = CGFloat(maxPixelSize)
            options.append(.processor(SignalArtworkDownsamplingProcessor(url: url,
                base: DownsamplingImageProcessor(size: CGSize(width: side, height: side)))))
        } else {
            // Non-default identity ensures KF also retains original bytes for full-size callers.
            options.append(.processor(SignalArtworkFullSizeProcessor()))
        }
        return options
    }
    @MainActor private static var prefetched: [String] = []
    @MainActor private static var missing: [String: (until: Date, error: KingfisherError)] = [:]

    @MainActor
    static func retrieve(url: URL, maxPixelSize: Int, speculative: Bool,
        legacyKey: String? = nil, completion: @escaping @MainActor (Result<RetrieveImageResult, KingfisherError>) -> Void
    ) -> SignalArtworkRequest {
        let request = SignalArtworkRequest()
        let started = ProcessInfo.processInfo.systemUptime
        if let failure = missing[url.absoluteString], failure.until > Date() {
            SignalArtworkDiagnostics.shared.record("negativeCacheHits")
            DispatchQueue.main.async { if !request.cancelled { completion(.failure(failure.error)) } }
            return request
        }
        missing.removeValue(forKey: url.absoluteString)
        // Source identity is URL-only. Kingfisher appends the processor identifier itself.
        let resource = KF.ImageResource(downloadURL: url, cacheKey: url.absoluteString)
        let baseOptions = options(url: url, maxPixelSize: maxPixelSize, speculative: speculative)
        var sourceWasLocal = false
        func finish(_ result: Result<RetrieveImageResult, KingfisherError>, local: Bool = false) {
            guard !request.cancelled else { return }
            SignalArtworkDiagnostics.shared.record("loadsCompleted")
            if local { SignalArtworkDiagnostics.shared.record("localLoadsCompleted") }
            let milliseconds = (ProcessInfo.processInfo.systemUptime - started) * 1000
            SignalArtworkDiagnostics.shared.record("loadMilliseconds", milliseconds)
            SignalArtworkDiagnostics.shared.latency(milliseconds)
            if case .success = result {
                if speculative {
                    prefetched.removeAll { $0 == url.absoluteString }; prefetched.append(url.absoluteString)
                    if prefetched.count > 128 { prefetched.removeFirst(prefetched.count - 128) }
                } else if let index = prefetched.firstIndex(of: url.absoluteString) {
                    prefetched.remove(at: index); SignalArtworkDiagnostics.shared.record("prefetchReuses")
                }
            } else {
                SignalArtworkDiagnostics.shared.record("loadFailures")
                if case .failure(let error) = result,
                   case .responseError(reason: .invalidHTTPStatusCode(let response)) = error,
                   response.statusCode == 404 || response.statusCode == 410 {
                    if missing.count >= 256, let oldest = missing.min(by: { $0.value.until < $1.value.until })?.key {
                        missing.removeValue(forKey: oldest)
                    }
                    missing[url.absoluteString] = (Date().addingTimeInterval(60), error)
                }
            }
            completion(result)
        }
        func retrieveNetworkAllowed(repaired: Bool = false) {
            guard !request.cancelled else { return }
            request.install(KingfisherManager.shared.retrieveImage(with: resource, options: baseOptions) { result in
                DispatchQueue.main.async {
                    guard !request.cancelled else { return }
                    // A disk entry can disappear between the async existence check and read,
                    // or contain corrupt bytes. Remove only this exact presentation and retry once.
                    if !repaired, case .failure(let error) = result, case .cacheError = error {
                        SignalArtworkDiagnostics.shared.record("cacheRepairs")
                        let identifier = KingfisherParsedOptionsInfo(baseOptions).processor.identifier
                        processedCache.removeImage(forKey: url.absoluteString, processorIdentifier: identifier) {
                            DispatchQueue.main.async { retrieveNetworkAllowed(repaired: true) }
                        }
                    } else {
                        let cached: Bool
                        if case .success(let value) = result { cached = sourceWasLocal || value.cacheType.cached }
                        else { cached = false }
                        finish(result, local: cached)
                    }
                }
            })
        }
        func migrateOriginal() {
            guard !request.cancelled else { return }
            // Reads the common original store and then F77's legacy .art file, off-main.
            PersistentArtworkSourceCache.read(url) { data in
                guard data != nil else {
                    DispatchQueue.main.async { retrieveNetworkAllowed() }; return
                }
                DispatchQueue.main.async {
                    guard !request.cancelled else { return }
                    SignalArtworkDiagnostics.shared.record("sourceByteReuses")
                    sourceWasLocal = true
                    retrieveNetworkAllowed()
                }
            }
        }
        func migrateProcessed() {
            guard let legacyKey else { migrateOriginal(); return }
            let legacy = KF.ImageResource(downloadURL: url, cacheKey: legacyKey)
            let legacyOptions = maxPixelSize == 0 ? baseOptions + [.processor(DefaultImageProcessor.default), .onlyFromCache] : baseOptions + [.onlyFromCache]
            request.install(KingfisherManager.shared.retrieveImage(with: legacy, options: legacyOptions) { result in
                DispatchQueue.main.async {
                    guard !request.cancelled else { return }
                    if case .success(let value) = result {
                        processedCache.store(value.image, forKey: url.absoluteString,
                            processorIdentifier: KingfisherParsedOptionsInfo(baseOptions).processor.identifier) { _ in
                                DispatchQueue.main.async {
                                    SignalArtworkDiagnostics.shared.record("legacyProcessedReuses")
                                    finish(result, local: true)
                                }
                            }
                    } else { migrateOriginal() }
                }
            })
        }
        // Cache-only pass means prefetch and visible presentation never probe the CDN for a
        // resident poster. Cache misses can also reuse F77 files without any network request.
        request.install(KingfisherManager.shared.retrieveImage(with: resource, options: baseOptions + [.onlyFromCache]) { result in
            DispatchQueue.main.async {
                guard !request.cancelled else { return }
                if case .success = result { finish(result, local: true) }
                else {
                    // Clear a corrupt/raced processed entry before the normal retry path.
                    let identifier = KingfisherParsedOptionsInfo(baseOptions).processor.identifier
                    processedCache.removeImage(forKey: url.absoluteString, processorIdentifier: identifier) {
                        DispatchQueue.main.async {
                            guard !request.cancelled else { return }
                            migrateProcessed()
                        }
                    }
                }
            }
        })
        return request
    }
}
// End F78 shared transport.

/// vBRDC297: Nuvio-inspired global ImageIO gate. A fast network can otherwise
/// finish many poster requests at once and fan out into a burst of concurrent
/// thumbnail decodes. Limiting decode work protects the tvOS focus/compositor
/// thread while still allowing enough parallelism to keep visible rows warm.
private final class SignalArtworkDecodeGate: @unchecked Sendable {
    private let semaphore: DispatchSemaphore

    init(maxConcurrent: Int) {
        semaphore = DispatchSemaphore(value: max(1, maxConcurrent))
    }

    func withPermit<T>(_ work: () -> T) -> T {
        semaphore.wait()
        defer { semaphore.signal() }
        return work()
    }
}

private let signalArtworkDecodeGate = SignalArtworkDecodeGate(maxConcurrent: 2)

/// Central artwork URL upgrader used before every image request.
/// v703: Premium decode path. Do not let SwiftUI/URLCache reuse low-res image entries,
/// and do not downsample artwork before the view displays it. TMDB gets /original/;
/// provider/Cinemeta/Stremio URLs stay intact so signed URLs and catalog art do not break.
enum PremiumArtworkURL {
    static func upgraded(_ input: String?) -> String? {
        guard var raw = input?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty else { return nil }
        if raw.hasPrefix("//") { raw = "https:" + raw }
        if raw.hasPrefix("http://"), !isPrivateLocalHTTP(raw) {
            raw = raw.replacingOccurrences(of: "http://", with: "https://")
        }

        if raw.contains("image.tmdb.org/t/p/") {
            let tmdbSizes = ["/w45/", "/w92/", "/w154/", "/w185/", "/w300/", "/w342/", "/w500/", "/h632/", "/w780/", "/w1280/", "/original/"]
            for size in tmdbSizes where raw.contains(size) {
                raw = raw.replacingOccurrences(of: size, with: "/original/")
            }
            for size in ["w45", "w92", "w154", "w185", "w300", "w342", "w500", "h632", "w780", "w1280"] {
                raw = raw.replacingOccurrences(of: "/t/p/\(size)", with: "/t/p/original")
            }
        }

        // vBRDC315: restore the shared backend artwork byte cache. The direct-origin
        // experiment in v314 regressed poster readiness on hardware. Visible cards still use
        // display-sized local decode buckets; the backend simply gives every poster one
        // durable, deduplicated source-byte path before local caching.
        return sharedBackendArtworkURL(raw)
    }

    // vBRDC224 Phase 6 shared-cache hardening (built on vBRDC223 Phase 5): every public artwork request is routed
    // through the configured Debrid Channels backend. The backend downloads each unique
    // source once into its persistent shared cache, so one user's cache miss warms the
    // exact same asset for every other user. Backend/local URLs are never re-proxied.
    private static func sharedBackendArtworkURL(_ raw: String) -> String {
        guard let source = URL(string: raw), let scheme = source.scheme?.lowercased(), ["http", "https"].contains(scheme) else { return raw }
        if isPrivateLocalHTTP(raw) { return raw }

        let configured = (UserDefaults.standard.string(forKey: "backendBaseURL") ?? "https://api.skylinejay187.it.com")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard !configured.isEmpty, let backend = URL(string: configured), let backendHost = backend.host?.lowercased() else { return raw }
        if source.host?.lowercased() == backendHost { return raw }
        // vBRDC332: the official catalog has already saved immutable artwork in MinIO.
        // Sending its /assets/ URLs through Signal's *different* /api/image service
        // adds an extra upstream fetch and another cache key on every cold device.
        // Keep the authoritative catalog asset URL direct (the local-server case is
        // already handled above), so all clients share the same immutable object.
        let sourceHost = source.host?.lowercased() ?? ""
        if source.path.hasPrefix("/assets/"),
           (sourceHost == "catalog.skylinejay187.it.com" || sourceHost.hasSuffix(".catalog.debridchannels")) {
            return raw
        }

        guard var components = URLComponents(string: configured + "/api/image") else { return raw }
        components.queryItems = [URLQueryItem(name: "url", value: raw)]
        return components.url?.absoluteString ?? raw
    }

    private static func isPrivateLocalHTTP(_ raw: String) -> Bool {
        guard let host = URL(string: raw)?.host?.lowercased() else { return false }
        if host == "localhost" || host == "127.0.0.1" || host.hasSuffix(".local") { return true }
        if host.hasPrefix("10.") || host.hasPrefix("192.168.") { return true }
        let parts = host.split(separator: ".").compactMap { Int($0) }
        if parts.count == 4, parts[0] == 172, (16...31).contains(parts[1]) { return true }
        return false
    }

    static func url(_ input: String?) -> URL? {
        guard let raw = upgraded(input), !raw.isEmpty else { return nil }
        if let direct = URL(string: raw), direct.scheme != nil { return direct }
        if let encoded = raw.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed), let url = URL(string: encoded), url.scheme != nil { return url }
        return nil
    }

    /// vBRDC321: recover the public origin embedded by Signal's /api/image proxy.
    /// The backend remains the preferred shared byte-cache path, but a slow/unavailable
    /// image relay must never strand a visible poster or themed logo indefinitely.
    static func directOriginURL(from routedURL: URL) -> URL? {
        guard routedURL.path.hasSuffix("/api/image"),
              let components = URLComponents(url: routedURL, resolvingAgainstBaseURL: false),
              let raw = components.queryItems?.first(where: { $0.name == "url" })?.value,
              let origin = URL(string: raw),
              let scheme = origin.scheme?.lowercased(),
              ["http", "https"].contains(scheme),
              !isPrivateLocalHTTP(raw) else { return nil }
        return origin
    }
}

// vBRDC091: artwork loaded by short-lived heavyweight surfaces must never evict the
// warm Home/Movies/Shows cache. Sports and Favorites get isolated decoded caches that
// are released on surface exit; persistent catalog/Live TV artwork keeps the donor cache.
enum PremiumArtworkCacheDomain: Hashable {
    case persistent
    case sports
    case favorites
}

private struct PremiumArtworkCacheDomainEnvironmentKey: EnvironmentKey {
    static let defaultValue: PremiumArtworkCacheDomain = .persistent
}

extension EnvironmentValues {
    var premiumArtworkCacheDomain: PremiumArtworkCacheDomain {
        get { self[PremiumArtworkCacheDomainEnvironmentKey.self] }
        set { self[PremiumArtworkCacheDomainEnvironmentKey.self] = newValue }
    }
}


/// vBRDC296: app-owned source-byte artwork cache.
///
/// URLCache is still kept as the normal HTTP cache, but it is not the source of truth for
/// warm posters anymore. Some artwork CDNs/proxies change cache headers or revalidate even
/// when the bytes are unchanged. This cache keys the final upgraded URL directly and stores
/// the original response bytes under Caches so a previously-seen poster can be decoded
/// locally on the next launch without another network round trip.
enum PersistentArtworkSourceCache {
    private static let queue = DispatchQueue(label: "com.debridchannels.artwork-source-cache", qos: .utility)
    private static let directoryName = "SignalArtworkSourceCache-v296"
    private static let byteLimit: Int64 = 768 * 1024 * 1024
    private static var writesSincePrune = 0
    // vBRDC297: do not turn every cache hit into a filesystem metadata write. The prior
    // implementation touched mtime on every read, serializing fast poster hits behind disk
    // attribute updates. Keep LRU usefulness with a coarse access touch instead.
    private static var lastTouchByPath: [String: Date] = [:]
    private static let accessTouchInterval: TimeInterval = 15 * 60

    private static func directoryURL() -> URL? {
        guard let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first else { return nil }
        let directory = base.appendingPathComponent(directoryName, isDirectory: true)
        if !FileManager.default.fileExists(atPath: directory.path) {
            try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        }
        return directory
    }

    private static func stableFileName(for url: URL) -> String {
        var hash: UInt64 = 14_695_981_039_346_656_037
        for byte in url.absoluteString.utf8 {
            hash ^= UInt64(byte)
            hash &*= 1_099_511_628_211
        }
        return String(format: "%016llx.art", hash)
    }

    private static func fileURL(for url: URL) -> URL? {
        directoryURL()?.appendingPathComponent(stableFileName(for: url), isDirectory: false)
    }

    static func read(_ url: URL, completion: @escaping (Data?) -> Void) {
        queue.async {
            if let data = try? SignalArtworkTransport.originalCache.diskStorage.value(forKey: url.absoluteString),
               validImageData(data) {
                SignalArtworkDiagnostics.shared.record("sourceDiskHits")
                completion(data); return
            }
            // F77 prefetch used .art files invisible to Kingfisher. Reuse valid bytes once.
            guard let file = fileURL(for: url),
                  let data = try? Data(contentsOf: file, options: [.mappedIfSafe]),
                  validImageData(data) else {
                if let file = fileURL(for: url) { try? FileManager.default.removeItem(at: file) }
                completion(nil); return
            }
            SignalArtworkDiagnostics.shared.record("legacySourceHits")
            let now = Date()
            let lastTouch = lastTouchByPath[file.path] ?? .distantPast
            if now.timeIntervalSince(lastTouch) >= accessTouchInterval {
                lastTouchByPath[file.path] = now
                try? FileManager.default.setAttributes([.modificationDate: now], ofItemAtPath: file.path)
            }
            SignalArtworkTransport.originalCache.storeToDisk(data, forKey: url.absoluteString,
                expiration: SignalArtworkTransport.expiration(for: url)) { result in
                    if case .success = result.diskCacheResult {
                        queue.async {
                            try? FileManager.default.removeItem(at: file)
                            lastTouchByPath.removeValue(forKey: file.path)
                        }
                    }
                    completion(data)
                }
        }
    }

    static func data(for url: URL) async -> Data? {
        await withCheckedContinuation { continuation in
            read(url) { data in
                continuation.resume(returning: data)
            }
        }
    }

    static func remove(_ url: URL) {
        queue.async {
            guard let file = fileURL(for: url) else { return }
            try? FileManager.default.removeItem(at: file)
            lastTouchByPath.removeValue(forKey: file.path)
        }
    }

    private static func validImageData(_ data: Data) -> Bool {
        guard !data.isEmpty, let source = CGImageSourceCreateWithData(data as CFData, nil),
              CGImageSourceGetCount(source) > 0 else { return false }
        return true
    }

    static func write(_ data: Data, for url: URL) {
        queue.async {
            guard validImageData(data) else { SignalArtworkDiagnostics.shared.record("invalidSourceBytes"); return }
            SignalArtworkTransport.originalCache.storeToDisk(data, forKey: url.absoluteString,
                expiration: SignalArtworkTransport.expiration(for: url)) { result in
                    if case .success = result.diskCacheResult {
                        queue.async {
                            if let file = fileURL(for: url) {
                                try? FileManager.default.removeItem(at: file)
                                lastTouchByPath.removeValue(forKey: file.path)
                            }
                        }
                    }
                }
        }
    }

    private static func pruneIfNeeded() {
        guard let directory = directoryURL(),
              let files = try? FileManager.default.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: [.fileSizeKey, .contentModificationDateKey],
                options: [.skipsHiddenFiles]
              ) else { return }
        var entries: [(url: URL, bytes: Int64, date: Date)] = []
        entries.reserveCapacity(files.count)
        var total: Int64 = 0
        for file in files {
            guard let values = try? file.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey]) else { continue }
            let bytes = Int64(values.fileSize ?? 0)
            total += bytes
            entries.append((file, bytes, values.contentModificationDate ?? .distantPast))
        }
        guard total > byteLimit else { return }
        for entry in entries.sorted(by: { $0.date < $1.date }) {
            try? FileManager.default.removeItem(at: entry.url)
            total -= entry.bytes
            if total <= byteLimit { break }
        }
    }
}

// vBRDC099: mounted catalog artwork gets a direct generation-based recovery signal after
// playback/foreground/surface handoffs. This intentionally is NOT an ObservableObject:
// publishing one global epoch through SwiftUI would invalidate every mounted artwork view
// at once and could recreate the very return/scroll hitch this recovery path is meant to fix.
// The coordinator talks directly to weakly registered loaders; healthy images are untouched.
@MainActor
final class PremiumArtworkRehydrationCoordinator {
    static let shared = PremiumArtworkRehydrationCoordinator()
    private var generation: UInt64 = 0

    private init() {}

    func force(reason: String) {
        generation &+= 1
        PremiumRemoteImageLoader.forceMountedBlankRehydration(reason: reason, generation: generation)
    }
}

@MainActor
private final class SignalArtworkCancelableTask {
    private let cancelAction: () -> Void
    init(_ cancelAction: @escaping () -> Void) { self.cancelAction = cancelAction }
    func cancel() { cancelAction() }
}

@MainActor
final class PremiumRemoteImageLoader: ObservableObject {
    @Published var image: UIImage?
    @Published private(set) var imageURL: URL? = nil
    @Published var failed = false

    // vBRDC088: a single original source URL may legitimately be decoded at different
    // display budgets (small rail poster vs. focused card vs. full-screen hero). Keep the
    // decode bucket in every cache/in-flight key so a display-sized card bitmap can never
    // poison a full-resolution presentation that requests the same source URL.
    private struct LoadKey: Hashable {
        let url: URL
        let maxPixelSize: Int
        let domain: PremiumArtworkCacheDomain

        var cacheKey: NSString {
            "\(url.absoluteString)|decode=\(maxPixelSize)|domain=\(String(describing: domain))" as NSString
        }
    }

    private static let memoryCache: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        // Same 96 MB persistent process budget as the donor build. vBRDC088 makes high-churn card
        // entries display-sized, allowing more useful warm images inside the same ceiling.
        cache.countLimit = 220
        cache.totalCostLimit = 96 * 1024 * 1024
        cache.delegate = SignalArtworkDiagnostics.shared
        return cache
    }()
    private static let sportsMemoryCache: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        cache.countLimit = 64
        cache.totalCostLimit = 16 * 1024 * 1024
        cache.delegate = SignalArtworkDiagnostics.shared
        return cache
    }()
    private static let favoritesMemoryCache: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        cache.countLimit = 48
        cache.totalCostLimit = 16 * 1024 * 1024
        cache.delegate = SignalArtworkDiagnostics.shared
        return cache
    }()

    // vBRDC099: playback may release the large persistent decode reservoir, but the exact
    // artwork visible immediately before playback is useful return-state. Snapshot only
    // mounted persistent card/hero owners into this small bounded cache so Home/Movies/Shows
    // can repaint synchronously on return without carrying the full 96 MB catalog cache.
    private static let playbackReturnMemoryCache: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        cache.countLimit = 36
        cache.totalCostLimit = 16 * 1024 * 1024
        cache.delegate = SignalArtworkDiagnostics.shared
        return cache
    }()

    private final class WeakBox {
        weak var value: PremiumRemoteImageLoader?
        init(_ value: PremiumRemoteImageLoader) { self.value = value }
    }
    private static var mountedLoaders: [WeakBox] = []

    private static func cache(for domain: PremiumArtworkCacheDomain) -> NSCache<NSString, UIImage> {
        switch domain {
        case .persistent: return memoryCache
        case .sports: return sportsMemoryCache
        case .favorites: return favoritesMemoryCache
        }
    }

    // vBRDC092: a popup/focused card may request a larger decode bucket than the same
    // artwork already visible on the row. Use that warm lower-resolution bitmap as an
    // immediate provisional frame, then replace it directly when the requested decode
    // finishes. This removes black/transparent reload flashes without lowering final quality.
    private static let reusableDecodeBuckets = [3072, 2560, 2048, 1600, 1280, 1024, 768, 640, 512, 384, 320]

    /// Nuvio-style decode bucketing: cards that request nearly the same pixel size
    /// should reuse one decoded bitmap instead of occupying separate cache entries.
    /// Full-screen Signal artwork keeps 2K/3K/4K buckets so this does not reduce quality.
    private static func normalizedDecodeBudget(_ requested: Int?) -> Int {
        guard let requested, requested > 0 else { return 0 }
        let bounded = min(max(requested, 160), 3840)
        let buckets = [320, 384, 512, 640, 768, 1024, 1280, 1600, 2048, 2560, 3072, 3840]
        return buckets.first(where: { $0 >= bounded }) ?? 3840
    }

    private static func bestProvisionalCachedImage(
        url: URL,
        requestedMaxPixelSize: Int,
        domain: PremiumArtworkCacheDomain
    ) -> UIImage? {
        let candidates: [Int]
        if requestedMaxPixelSize == 0 {
            candidates = reusableDecodeBuckets
        } else {
            candidates = reusableDecodeBuckets.filter { $0 < requestedMaxPixelSize }
        }
        let domains: [PremiumArtworkCacheDomain] = domain == .persistent ? [.persistent] : [domain, .persistent]
        for candidateDomain in domains {
            for bucket in candidates {
                let candidate = LoadKey(url: url, maxPixelSize: bucket, domain: candidateDomain)
                if let image = cache(for: candidateDomain).object(forKey: candidate.cacheKey) { return image }
                if candidateDomain == .persistent,
                   let image = playbackReturnMemoryCache.object(forKey: candidate.cacheKey) { return image }
            }
        }
        return nil
    }
    private static var inFlightLoads: [LoadKey: [ObjectIdentifier: (UIImage?) -> Void]] = [:]
    private static var pendingSubscriberCancellationTasks: [LoadKey: Task<Void, Never>] = [:]
    private static var prefetchTasks: [URL: SignalArtworkCancelableTask] = [:]
    // vBRDC317 Phase 2: stable poster hydration queue. A catalog snapshot may request
    // more URLs than the two concurrent network slots. Keep the remaining identities queued
    // and pump them as slots finish instead of silently abandoning everything after URL #2.
    private static var pendingPrefetchURLs: [URL] = []
    private static var desiredPrefetchURLs: Set<URL> = []
    private static var prefetchOwnerTokens: [URL: UUID] = [:]
    private static var activeNetworkTasks: [LoadKey: SignalArtworkCancelableTask] = [:]
    private static var nonRetryableFailures: Set<LoadKey> = []
    private static var networkLoadTokens: [LoadKey: UUID] = [:]
    // vBRDC092: detail artwork may be warmed after focus settles, but that speculative
    // decode must never survive into the next Siri Remote movement. Once a real view
    // subscribes to the key it stops being speculative and is allowed to finish.
    private static var idlePrewarmKeys: Set<LoadKey> = []
    private static var exclusivePlaybackActive = false
    private static let maxActivePrefetchTasks = 2
    private static var prefetchPumpTask: Task<Void, Never>?
    private static let processedTransportCache = SignalArtworkTransport.processedCache
    private static let normalDecodedCacheLimitBytes = 96 * 1024 * 1024
    private static let exclusiveVODDecodedCacheLimitBytes = 32 * 1024 * 1024
    private var currentURL: URL?
    private var currentKey: LoadKey?
    // vBRDC090: decoded pixels may finish on the same frame as a Siri Remote move.
    // Cache them immediately, but defer the ObservableObject publication until focus
    // settles so artwork completion cannot steal the navigation frame budget.
    private var deferredPublicationTask: Task<Void, Never>?
    // vBRDC118: full-screen decorative artwork must not begin a new high-resolution
    // network/decode job for every fly-by card while Siri Remote geometry owns the frame.
    // Card/poster owners keep their immediate path; only explicit heavyweight callers opt in.
    private var deferredNavigationLoadTask: Task<Void, Never>?
    // vBRDC099: a transient CDN/DNS miss must not pin a mounted catalog card blank until
    // the user scrolls it away. Keep retries view-owned and bounded so cancellation still
    // follows normal SwiftUI lifecycle.
    private var transientRetryTask: Task<Void, Never>?
    private var transientRetryAttempt: Int = 0
    // vBRDC101: visible catalog hero/card/logo artwork is transition-critical. It may
    // publish during the bounded UNITY surface handoff while ordinary/background image
    // completions remain deferred. Navigation bursts and playback exclusivity still win.
    private var allowPublicationDuringSurfaceHandoff: Bool = false
    // vBRDC106: opt-in permission for visible VOD overlay/Cast Explorer artwork.
    // Default false keeps catalog/wallpaper/background image publication blocked while
    // full-screen playback owns the session.
    private var allowPublicationDuringPlayback: Bool = false
    // vBRDC123: opt-in for bounded artwork that is itself part of visible foreground
    // VOD UI (Cast Explorer, Featured Cast, episode browser, Up Next). Those surfaces must
    // never remain blank behind an indefinite navigation waiter. Ordinary/decorative VOD
    // artwork keeps the durable frame-budget path.
    private var forceVisiblePlaybackPublication: Bool = false

    init() {
        Self.mountedLoaders.removeAll { $0.value == nil }
        Self.mountedLoaders.append(WeakBox(self))
    }

    private static func snapshotMountedPersistentArtworkForPlaybackReturn(reason: String) {
        // Do not clear the rolling reservoir here. Catalog views may already have unmounted
        // (for example Home -> Live -> channel playback), and their recently decoded cards
        // are exactly what we want to keep for a later smooth catalog return.
        var retained: [WeakBox] = []
        retained.reserveCapacity(mountedLoaders.count)
        var captured = 0
        for box in mountedLoaders {
            guard let loader = box.value else { continue }
            retained.append(box)
            guard let key = loader.currentKey,
                  key.domain == .persistent,
                  key.maxPixelSize > 0,
                  key.maxPixelSize <= 1280,
                  let image = loader.image,
                  loader.imageURL == key.url else { continue }
            let cost = image.cgImage.map { $0.bytesPerRow * $0.height } ?? 0
            playbackReturnMemoryCache.setObject(image, forKey: key.cacheKey, cost: cost)
            captured += 1
        }
        mountedLoaders = retained
        print("[ArtworkContinuity][vBRDC099] captured=\(captured) mounted=\(retained.count) reason=\(reason)")
    }

    /// vBRDC118 peak-smooth path for heavyweight full-screen artwork. Exact cached
    /// decodes still publish synchronously. A cache miss that arrives during active Siri
    /// Remote navigation retains the previous decoded frame and waits until navigation
    /// geometry releases ownership before starting URLSession/ImageIO work. Repeated focus
    /// moves replace this one pending request instead of creating/cancelling 4K decode jobs.
    func loadAfterNavigationSettles(
        _ url: URL?,
        preserveCurrentImage: Bool = true,
        maxPixelSize: Int? = nil,
        cacheDomain: PremiumArtworkCacheDomain = .persistent,
        allowPublicationDuringSurfaceHandoff: Bool = false,
        allowPublicationDuringPlayback: Bool = false,
        forceVisiblePlaybackPublication: Bool = false
    ) {
        deferredNavigationLoadTask?.cancel()
        deferredNavigationLoadTask = nil

        guard let url else {
            load(
                nil,
                preserveCurrentImage: preserveCurrentImage,
                maxPixelSize: maxPixelSize,
                cacheDomain: cacheDomain,
                allowPublicationDuringSurfaceHandoff: allowPublicationDuringSurfaceHandoff,
                allowPublicationDuringPlayback: allowPublicationDuringPlayback,
                forceVisiblePlaybackPublication: forceVisiblePlaybackPublication
            )
            return
        }

        let decodeBudget = Self.normalizedDecodeBudget(maxPixelSize)
        let key = LoadKey(url: url, maxPixelSize: decodeBudget, domain: cacheDomain)
        let exactCached = Self.cache(for: key.domain).object(forKey: key.cacheKey) != nil
            || (key.domain == .persistent && Self.playbackReturnMemoryCache.object(forKey: key.cacheKey) != nil)

        // Cached pixels cost no network/decode budget, so keep single-step browsing crisp.
        if exactCached {
            load(
                url,
                preserveCurrentImage: preserveCurrentImage,
                maxPixelSize: maxPixelSize,
                cacheDomain: cacheDomain,
                allowPublicationDuringSurfaceHandoff: allowPublicationDuringSurfaceHandoff,
                allowPublicationDuringPlayback: allowPublicationDuringPlayback,
                forceVisiblePlaybackPublication: forceVisiblePlaybackPublication
            )
            return
        }

        // A focus callback and the backdrop URL change can land on the same MainActor turn.
        // Yield once before deciding whether this is a navigation-owned frame so the focus
        // coordinator gets a chance to claim geometry first. Outside navigation this is only
        // a microtask delay; during a burst it prevents the first fly-by card from escaping
        // the heavyweight gate and starting a 4K decode.
        deferredNavigationLoadTask = Task { @MainActor [weak self] in
            guard let self else { return }
            await Task.yield()
            guard !Task.isCancelled else { return }

            if UnityFrameRuntime.shared.snapshot.navigationActive {
                let permitted = await UnityFrameRuntime.shared.waitUntilPermitted(
                    .criticalArtwork,
                    maxWait: 1.80,
                    poll: 0.020
                )
                guard permitted, !Task.isCancelled else { return }
            }

            self.load(
                url,
                preserveCurrentImage: preserveCurrentImage,
                maxPixelSize: maxPixelSize,
                cacheDomain: cacheDomain,
                allowPublicationDuringSurfaceHandoff: allowPublicationDuringSurfaceHandoff,
                allowPublicationDuringPlayback: allowPublicationDuringPlayback,
                forceVisiblePlaybackPublication: forceVisiblePlaybackPublication
            )
            self.deferredNavigationLoadTask = nil
        }
    }

    func load(
        _ url: URL?,
        preserveCurrentImage: Bool = false,
        maxPixelSize: Int? = nil,
        cacheDomain: PremiumArtworkCacheDomain = .persistent,
        allowPublicationDuringSurfaceHandoff: Bool = false,
        allowPublicationDuringPlayback: Bool = false,
        forceVisiblePlaybackPublication: Bool = false
    ) {
        self.allowPublicationDuringSurfaceHandoff = allowPublicationDuringSurfaceHandoff
        self.allowPublicationDuringPlayback = allowPublicationDuringPlayback
        self.forceVisiblePlaybackPublication = forceVisiblePlaybackPublication
        guard let url else {
            cancel()
            image = nil
            imageURL = nil
            failed = false
            currentURL = nil
            currentKey = nil
            return
        }
        let decodeBudget = Self.normalizedDecodeBudget(maxPixelSize)
        let key = LoadKey(url: url, maxPixelSize: decodeBudget, domain: cacheDomain)
        if currentKey == key, image != nil { SignalArtworkDiagnostics.shared.record("mountedImageReuses"); return }

        let keyChanged = currentKey != key
        if keyChanged {
            transientRetryTask?.cancel()
            transientRetryTask = nil
            transientRetryAttempt = 0
        }

        if let previousKey = currentKey {
            Self.removeInFlightSubscriber(for: previousKey, owner: self)
        }
        deferredPublicationTask?.cancel()
        deferredPublicationTask = nil
        currentURL = url
        currentKey = key
        failed = false
        if !preserveCurrentImage {
            image = nil
            imageURL = nil
        }

        if let cached = Self.cache(for: key.domain).object(forKey: key.cacheKey) {
            SignalArtworkDiagnostics.shared.record("decodedMemoryHits")
            imageURL = url
            image = cached
            transientRetryAttempt = 0
            return
        }
        if key.domain == .persistent,
           let cached = Self.playbackReturnMemoryCache.object(forKey: key.cacheKey) {
            SignalArtworkDiagnostics.shared.record("decodedMemoryHits")
            let cost = cached.cgImage.map { $0.bytesPerRow * $0.height } ?? 0
            Self.memoryCache.setObject(cached, forKey: key.cacheKey, cost: cost)
            imageURL = url
            image = cached
            transientRetryAttempt = 0
            return
        }
        // vBRDC091: transient Sports/Favorites surfaces may reuse an already-warm
        // persistent catalog bitmap, but they never write their own new decode into the
        // persistent cache. This preserves fast entry without allowing those surfaces to
        // evict Home/Movies/Shows artwork.
        if key.domain != .persistent {
            let persistentKey = LoadKey(url: url, maxPixelSize: decodeBudget, domain: .persistent)
            if let cached = Self.memoryCache.object(forKey: persistentKey.cacheKey) {
                SignalArtworkDiagnostics.shared.record("decodedMemoryHits")
                imageURL = url
                image = cached
                return
            }
        }

        // Show the already-decoded row/card image immediately while the larger requested
        // bucket upgrades in place. Do not return: the final decode still proceeds.
        if let provisional = Self.bestProvisionalCachedImage(
            url: url,
            requestedMaxPixelSize: decodeBudget,
            domain: key.domain
        ) {
            imageURL = url
            image = provisional
        }

        if Self.enqueueInFlightLoad(for: key, owner: self) { return }
        let networkToken = UUID()
        Self.networkLoadTokens[key] = networkToken

        Self.startSharedArtworkLoad(for: key, token: networkToken, speculative: false)
    }

    private static func startSharedArtworkLoad(for key: LoadKey, token: UUID, speculative: Bool) {
        func retrieve(_ url: URL, fallback: Bool) {
            guard networkLoadTokens[key] == token, inFlightLoads[key] != nil else { return }
            let request = SignalArtworkTransport.retrieve(url: url, maxPixelSize: key.maxPixelSize,
                speculative: speculative, legacyKey: fallback ? nil : key.cacheKey as String) { result in
                guard networkLoadTokens[key] == token, inFlightLoads[key] != nil else { return }
                switch result {
                case .success(let value):
                    networkLoadTokens.removeValue(forKey: key)
                    activeNetworkTasks.removeValue(forKey: key)
                    idlePrewarmKeys.remove(key)
                    nonRetryableFailures.remove(key)
                    if speculative {
                        let cost = value.image.cgImage.map { $0.bytesPerRow * $0.height } ?? 0
                        cache(for: key.domain).setObject(value.image, forKey: key.cacheKey, cost: cost)
                    }
                    finishInFlightLoad(for: key, image: value.image)
                case .failure:
                    if !fallback, let origin = PremiumArtworkURL.directOriginURL(from: key.url) {
                        // Origin bytes keep the origin's identity, never the failed proxy URL.
                        retrieve(origin, fallback: true)
                    } else {
                        networkLoadTokens.removeValue(forKey: key)
                        activeNetworkTasks.removeValue(forKey: key)
                        idlePrewarmKeys.remove(key)
                        finishInFlightLoad(for: key, image: nil)
                    }
                }
            }
            activeNetworkTasks[key] = SignalArtworkCancelableTask { request.cancel() }
        }
        retrieve(key.url, fallback: false)
    }

    func cancel() {
        deferredNavigationLoadTask?.cancel()
        deferredNavigationLoadTask = nil
        transientRetryTask?.cancel()
        transientRetryTask = nil
        transientRetryAttempt = 0
        if let key = currentKey {
            Self.removeInFlightSubscriber(for: key, owner: self)
        }
        deferredPublicationTask?.cancel()
        deferredPublicationTask = nil
        currentURL = nil
        currentKey = nil
        image = nil
        imageURL = nil
        failed = false
    }

    private func forceRehydrateCurrentIfBlank() {
        // vBRDC388R1: visible playback UI owns its artwork even while Aether owns the
        // decoder. The old global playback guard stranded mounted VOD/Cast/Episode/
        // Spotlight loaders blank after a cancelled/deferred first request; reopening the
        // surface merely created a fresh loader against a warm cache. Keep decorative and
        // catalog artwork gated, but allow explicitly opted-in playback artwork to recover.
        let playbackGateActive = Self.exclusivePlaybackActive || VODExclusivePlaybackGate.isActive
        guard (!playbackGateActive || allowPublicationDuringPlayback),
              image == nil,
              let key = currentKey,
              !Self.nonRetryableFailures.contains(key) else { return }
        // A playback/background cancellation can leave a mounted owner with a valid request
        // identity but no URLSession task. Restart exactly that request. In-flight work remains
        // deduplicated by LoadKey, and a real 4xx is deliberately not hammered again.
        failed = false
        load(
            key.url,
            preserveCurrentImage: true,
            maxPixelSize: key.maxPixelSize > 0 ? key.maxPixelSize : nil,
            cacheDomain: key.domain,
            allowPublicationDuringSurfaceHandoff: allowPublicationDuringSurfaceHandoff,
            allowPublicationDuringPlayback: allowPublicationDuringPlayback,
            forceVisiblePlaybackPublication: forceVisiblePlaybackPublication
        )
    }

    static func forceMountedBlankRehydration(reason: String, generation: UInt64) {
        // vBRDC388R1: do not abort the whole recovery pass during VOD playback. Each
        // mounted loader enforces its own ownership contract, so only explicit visible
        // playback artwork can restart while the decoder is active.
        var retained: [WeakBox] = []
        retained.reserveCapacity(mountedLoaders.count)
        var restarted = 0
        for box in mountedLoaders {
            guard let loader = box.value else { continue }
            retained.append(box)
            let before = loader.image
            loader.forceRehydrateCurrentIfBlank()
            if before == nil, loader.image == nil, loader.currentKey != nil { restarted += 1 }
        }
        mountedLoaders = retained
        print("[ArtworkRehydrate][vBRDC099] generation=\(generation) mounted=\(retained.count) blankCandidates=\(restarted) reason=\(reason)")
    }

    static func prefetch(_ urls: [URL], keeping keepAliveURLs: Set<URL> = []) {
        guard !exclusivePlaybackActive, !VODExclusivePlaybackGate.isActive else { return }

        // Preserve caller order: current/visible posters are first, near-visible posters follow.
        var seen = Set<URL>()
        let ordered = urls.filter { seen.insert($0).inserted }
        let requested = Array(ordered.prefix(24))
        desiredPrefetchURLs = Set(requested).union(keepAliveURLs)

        cancelObsoletePrefetches(keeping: desiredPrefetchURLs)

        let active = Set(prefetchTasks.keys)
        pendingPrefetchURLs = requested.filter { !active.contains($0) }
        pumpPrefetchQueue()
    }

    private static func pumpPrefetchQueue() {
        guard !exclusivePlaybackActive, !VODExclusivePlaybackGate.isActive,
              UnityFrameRuntime.shared.snapshot.sceneActive else { return }
        guard UnityFrameRuntime.shared.permits(.backgroundPrefetch) else {
            if prefetchPumpTask == nil {
                prefetchPumpTask = Task { @MainActor in
                    let permitted = await UnityFrameRuntime.shared.waitUntilPermittedDurably(.backgroundPrefetch)
                    guard !Task.isCancelled else { return }
                    prefetchPumpTask = nil
                    guard permitted else { return }
                    pumpPrefetchQueue()
                }
            }
            return
        }
        while prefetchTasks.count < maxActivePrefetchTasks, !pendingPrefetchURLs.isEmpty {
            let url = pendingPrefetchURLs.removeFirst()
            guard desiredPrefetchURLs.contains(url), prefetchTasks[url] == nil else { continue }
            let token = UUID(); prefetchOwnerTokens[url] = token
            let request = SignalArtworkTransport.retrieve(url: url, maxPixelSize: 320, speculative: true) { _ in
                guard prefetchOwnerTokens[url] == token else { return }
                prefetchTasks.removeValue(forKey: url); prefetchOwnerTokens.removeValue(forKey: url)
                pumpPrefetchQueue()
            }
            prefetchTasks[url] = SignalArtworkCancelableTask { request.cancel() }
        }
    }

    /// vBRDC092: warm one exact presentation bucket without creating a view-owned loader.
    /// If the destination view mounts while this request is still running it subscribes to
    /// the same in-flight key rather than starting a duplicate network/decode operation.
    static func prewarm(
        _ url: URL?,
        maxPixelSize: Int,
        cacheDomain: PremiumArtworkCacheDomain = .persistent
    ) {
        guard !exclusivePlaybackActive, !VODExclusivePlaybackGate.isActive,
              UnityFrameRuntime.shared.snapshot.sceneActive, let url else { return }
        let key = LoadKey(url: url, maxPixelSize: normalizedDecodeBudget(maxPixelSize), domain: cacheDomain)
        if cache(for: cacheDomain).object(forKey: key.cacheKey) != nil { return }
        if inFlightLoads[key] != nil || activeNetworkTasks[key] != nil { return }

        // Empty subscriber map marks a speculative in-flight decode. A view that arrives
        // later joins this map through enqueueInFlightLoad() and promotes it to required.
        inFlightLoads[key] = [:]
        idlePrewarmKeys.insert(key)
        let token = UUID(); networkLoadTokens[key] = token
        startSharedArtworkLoad(for: key, token: token, speculative: true)
    }

    /// Cancel only speculative detail prewarms that no visible image loader has joined.
    /// Called at the start of a new navigation burst so high-resolution decode/network work
    /// cannot become a hidden source of frame loss while the user is scrolling again.
    static func cancelIdlePrewarmsForNavigation() {
        let keys = idlePrewarmKeys
        for key in keys {
            guard inFlightLoads[key]?.isEmpty == true else {
                idlePrewarmKeys.remove(key)
                continue
            }
            activeNetworkTasks[key]?.cancel()
            activeNetworkTasks.removeValue(forKey: key)
            networkLoadTokens.removeValue(forKey: key)
            pendingSubscriberCancellationTasks[key]?.cancel()
            pendingSubscriberCancellationTasks.removeValue(forKey: key)
            inFlightLoads.removeValue(forKey: key)
            idlePrewarmKeys.remove(key)
        }
    }

    // vBRDC388R3F1: foreground playback artwork is an explicit ownership contract, not a
    // decode-size heuristic. A VOD overlay can mount on the same run-loop turn that Aether
    // enters exclusive playback. Older builds cancelled those just-started requests here,
    // leaving the still-mounted StateObject with a valid URL but no completion to publish.
    // Reopening the overlay created a new loader against a warm cache, which is why the
    // artwork appeared only on the second visit.
    private static func foregroundPlaybackOwnedKeys() -> Set<LoadKey> {
        var keys = Set<LoadKey>()
        var retained: [WeakBox] = []
        retained.reserveCapacity(mountedLoaders.count)
        for box in mountedLoaders {
            guard let loader = box.value else { continue }
            retained.append(box)
            guard loader.allowPublicationDuringPlayback,
                  let key = loader.currentKey else { continue }
            keys.insert(key)
        }
        mountedLoaders = retained
        return keys
    }

    static func beginExclusivePlayback() {
        snapshotMountedPersistentArtworkForPlaybackReturn(reason: "VOD playback entry")
        exclusivePlaybackActive = true

        // Preserve requests that belong to artwork already mounted in the visible VOD UI.
        // Decorative/catalog/prewarm work is still cancelled aggressively.
        let protectedForegroundKeys = foregroundPlaybackOwnedKeys()
        let networkKeysToCancel = activeNetworkTasks.keys.filter { !protectedForegroundKeys.contains($0) }
        for key in networkKeysToCancel {
            activeNetworkTasks[key]?.cancel()
            activeNetworkTasks.removeValue(forKey: key)
        }
        let cancellationKeysToDrop = pendingSubscriberCancellationTasks.keys.filter { !protectedForegroundKeys.contains($0) }
        for key in cancellationKeysToDrop {
            pendingSubscriberCancellationTasks[key]?.cancel()
            pendingSubscriberCancellationTasks.removeValue(forKey: key)
        }
        let inFlightKeysToDrop = inFlightLoads.keys.filter { !protectedForegroundKeys.contains($0) }
        for key in inFlightKeysToDrop { inFlightLoads.removeValue(forKey: key) }
        idlePrewarmKeys.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        prefetchOwnerTokens.removeAll()
        pendingPrefetchURLs.removeAll()
        desiredPrefetchURLs.removeAll()
        prefetchPumpTask?.cancel(); prefetchPumpTask = nil
        memoryCache.removeAllObjects()
        sportsMemoryCache.removeAllObjects()
        favoritesMemoryCache.removeAllObjects()
        processedTransportCache.clearMemoryCache()
        SignalArtworkTransport.originalCache.clearMemoryCache()
        memoryCache.totalCostLimit = exclusiveVODDecodedCacheLimitBytes
        print("[ReleaseStability][v1133] VOD entry released decoded artwork cache and reduced playback cache ceiling to 32 MB")
    }

    static func releaseDecodedArtworkForHiddenVODOverlay() {
        guard exclusivePlaybackActive || VODExclusivePlaybackGate.isActive else { return }

        // vBRDC159: VOD title logos are small playback-owned foreground assets. The chrome
        // can hide while their request is still in flight, but the SwiftUI owner remains
        // mounted; cancelling that request here can leave the owner permanently blank because
        // no new onAppear is guaranteed when chrome returns. Preserve only actively-subscribed
        // <=640px foreground work and continue cancelling every heavyweight/decorative request.
        let protectedForegroundKeys = foregroundPlaybackOwnedKeys()
        let networkKeysToCancel = activeNetworkTasks.keys.filter { !protectedForegroundKeys.contains($0) }
        for key in networkKeysToCancel {
            activeNetworkTasks[key]?.cancel()
            activeNetworkTasks.removeValue(forKey: key)
        }
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        prefetchOwnerTokens.removeAll()
        pendingPrefetchURLs.removeAll()
        desiredPrefetchURLs.removeAll()
        prefetchPumpTask?.cancel(); prefetchPumpTask = nil

        let cancellationKeysToDrop = pendingSubscriberCancellationTasks.keys.filter { !protectedForegroundKeys.contains($0) }
        for key in cancellationKeysToDrop {
            pendingSubscriberCancellationTasks[key]?.cancel()
            pendingSubscriberCancellationTasks.removeValue(forKey: key)
        }
        let inFlightKeysToDrop = inFlightLoads.keys.filter { !protectedForegroundKeys.contains($0) }
        for key in inFlightKeysToDrop { inFlightLoads.removeValue(forKey: key) }
        print("[ReleaseStability][vBRDC159] hidden VOD overlay cancelled decorative artwork work while preserving active title-logo foreground loads")
    }

    static func endExclusivePlayback() {
        guard exclusivePlaybackActive else {
            memoryCache.totalCostLimit = normalDecodedCacheLimitBytes
            return
        }
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        // Entry already released heavyweight caches. Clearing again on exit races the
        // remounting catalog and can erase artwork that just finished during focus recovery.
        memoryCache.totalCostLimit = normalDecodedCacheLimitBytes
        exclusivePlaybackActive = false
    }

    static func suspendForBackground() {
        snapshotMountedPersistentArtworkForPlaybackReturn(reason: "scene inactive")
        // Background is a real lifecycle boundary. Cancel the underlying request owners too;
        // otherwise a request started before sleep can finish afterward and repopulate a cache
        // the app intentionally released. Foreground rehydration restarts only mounted blanks.
        for task in activeNetworkTasks.values { task.cancel() }
        activeNetworkTasks.removeAll()
        networkLoadTokens.removeAll()
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        prefetchOwnerTokens.removeAll()
        pendingPrefetchURLs.removeAll()
        desiredPrefetchURLs.removeAll()
        prefetchPumpTask?.cancel(); prefetchPumpTask = nil
        inFlightLoads.removeAll()
        idlePrewarmKeys.removeAll()
        memoryCache.removeAllObjects()
        sportsMemoryCache.removeAllObjects()
        favoritesMemoryCache.removeAllObjects()
        print("[ArtworkCache][F78] \(artworkCacheDiagnostics())")
        print("[ArtworkLifecycle][vBRDC099] suspended all artwork request owners and released decoded cache")
    }

    static func handleMemoryPressure() {
        SignalArtworkDiagnostics.shared.record("memoryPressureEvents")
        cancelIdlePrewarmsForNavigation()
        print("[ArtworkCache][F78] \(artworkCacheDiagnostics())")
        processedTransportCache.clearMemoryCache()
        SignalArtworkTransport.originalCache.clearMemoryCache()
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        prefetchOwnerTokens.removeAll()
        pendingPrefetchURLs.removeAll()
        desiredPrefetchURLs.removeAll()
        prefetchPumpTask?.cancel(); prefetchPumpTask = nil
        memoryCache.removeAllObjects()
        sportsMemoryCache.removeAllObjects()
        favoritesMemoryCache.removeAllObjects()
        playbackReturnMemoryCache.removeAllObjects()
        nonRetryableFailures.removeAll(keepingCapacity: false)
        print("[ArtworkLifecycle][Phase7] released decoded artwork cache and prefetch work")
    }

    static func releaseTransientSurfaceResources(domain: PremiumArtworkCacheDomain, reason: String) {
        guard domain != .persistent else { return }

        let keys = activeNetworkTasks.keys.filter { $0.domain == domain }
        for key in keys {
            activeNetworkTasks[key]?.cancel()
            activeNetworkTasks.removeValue(forKey: key)
            networkLoadTokens.removeValue(forKey: key)
        }

        let pendingKeys = pendingSubscriberCancellationTasks.keys.filter { $0.domain == domain }
        for key in pendingKeys {
            pendingSubscriberCancellationTasks[key]?.cancel()
            pendingSubscriberCancellationTasks.removeValue(forKey: key)
        }

        let inFlightKeys = inFlightLoads.keys.filter { $0.domain == domain }
        for key in inFlightKeys {
            inFlightLoads.removeValue(forKey: key)
        }

        cache(for: domain).removeAllObjects()
        print("[ArtworkLifecycle][vBRDC091] released \(domain) transient surface artwork reason=\(reason)")
    }

    static func cancelObsoletePrefetches(keeping urlsToKeep: Set<URL>) {
        desiredPrefetchURLs = urlsToKeep
        pendingPrefetchURLs.removeAll { !urlsToKeep.contains($0) }
        let obsolete = prefetchTasks.keys.filter { !urlsToKeep.contains($0) }
        for url in obsolete {
            prefetchOwnerTokens.removeValue(forKey: url)
            prefetchTasks[url]?.cancel()
            prefetchTasks.removeValue(forKey: url)
        }
        pumpPrefetchQueue()
    }

    static func releaseDecodedArtworkForLiveTVPlayback() {
        processedTransportCache.clearMemoryCache()
        SignalArtworkTransport.originalCache.clearMemoryCache()
        snapshotMountedPersistentArtworkForPlaybackReturn(reason: "Live TV playback entry")
        for task in activeNetworkTasks.values { task.cancel() }
        activeNetworkTasks.removeAll()
        networkLoadTokens.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        prefetchOwnerTokens.removeAll()
        pendingPrefetchURLs.removeAll()
        desiredPrefetchURLs.removeAll()
        prefetchPumpTask?.cancel(); prefetchPumpTask = nil
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        inFlightLoads.removeAll()
        memoryCache.removeAllObjects()
        sportsMemoryCache.removeAllObjects()
        favoritesMemoryCache.removeAllObjects()
        print("[LiveTVMemory][v975] released decoded artwork cache for full-screen Live TV playback")
    }

    private static func enqueueInFlightLoad(for key: LoadKey, owner: PremiumRemoteImageLoader) -> Bool {
        pendingSubscriberCancellationTasks[key]?.cancel()
        pendingSubscriberCancellationTasks.removeValue(forKey: key)
        let ownerID = ObjectIdentifier(owner)
        let callback: (UIImage?) -> Void = { [weak owner] decoded in
            guard let owner, owner.currentKey == key else { return }
            if let decoded {
                let cost = decoded.cgImage.map { $0.bytesPerRow * $0.height } ?? 0
                cache(for: key.domain).setObject(decoded, forKey: key.cacheKey, cost: cost)
                // Keep a small rolling set of recent catalog-card decodes even after those
                // views unmount. This covers Home -> Live -> playback -> Home as well as VOD
                // return without retaining full-screen/original artwork during playback.
                if key.domain == .persistent, key.maxPixelSize > 0, key.maxPixelSize <= 1280 {
                    playbackReturnMemoryCache.setObject(decoded, forKey: key.cacheKey, cost: cost)
                }
            }
            owner.publishDecodedImage(decoded, for: key)
        }

        if inFlightLoads[key] != nil {
            inFlightLoads[key]?[ownerID] = callback
            idlePrewarmKeys.remove(key)
            return true
        }
        inFlightLoads[key] = [ownerID: callback]
        return false
    }

    private func publishDecodedImage(_ decoded: UIImage?, for key: LoadKey) {
        deferredPublicationTask?.cancel()
        deferredPublicationTask = nil

        let apply: @MainActor () -> Void = { [weak self] in
            guard let self, self.currentKey == key else { return }
            if let decoded {
                self.imageURL = key.url
                self.image = decoded
                self.failed = false
                self.transientRetryAttempt = 0
                self.transientRetryTask?.cancel()
                self.transientRetryTask = nil
            } else {
                self.imageURL = nil
                self.failed = true
                self.scheduleTransientRetryIfNeeded(for: key)
            }
        }

        guard UnityAnimationCoordinator.shared.shouldDeferVisualPublication(
            allowDuringSurfaceHandoff: allowPublicationDuringSurfaceHandoff,
            allowDuringPlayback: allowPublicationDuringPlayback
        ) else {
            apply()
            return
        }

        deferredPublicationTask = Task { @MainActor [weak self] in
            // vBRDC102: decoded image publication no longer owns a private 35 ms polling
            // clock or force-publishes after 350 ms. It joins the exact same frame lane as
            // navigation/UNITY. Obsolete owners cancel naturally as focus changes.
            guard let self else { return }
            let lane: UnityFrameRuntime.Lane
            if self.allowPublicationDuringPlayback {
                lane = .playbackArtwork
            } else if self.allowPublicationDuringSurfaceHandoff {
                lane = .criticalArtwork
            } else {
                lane = .backgroundPrefetch
            }
            let permitted: Bool
            if self.forceVisiblePlaybackPublication && self.allowPublicationDuringPlayback {
                // vBRDC123: bounded foreground VOD artwork gets a short courtesy wait for
                // active Siri Remote geometry, then paints anyway instead of remaining blank.
                // Callers cap decode size and are explicit visible UI, so this cannot unleash
                // full-screen/decorative 4K publication during playback.
                permitted = await UnityFrameRuntime.shared.waitUntilPermitted(
                    lane,
                    // vBRDC159: Source Intelligence -> player handoff can legitimately
                    // outlive the old 450 ms window. Visible 640px title logos keep their
                    // decoded result pending through that handoff instead of silently
                    // missing the only publication opportunity.
                    maxWait: 1.80,
                    poll: 0.020
                )
            } else {
                permitted = await UnityFrameRuntime.shared.waitUntilPermittedDurably(lane)
            }
            guard !Task.isCancelled, self.currentKey == key else {
                self.deferredPublicationTask = nil
                return
            }
            let runtime = UnityFrameRuntime.shared.snapshot
            if permitted || (self.forceVisiblePlaybackPublication
                              && self.allowPublicationDuringPlayback
                              && runtime.sceneActive
                              && runtime.playbackActive
                              && !runtime.trailerActive) {
                // vBRDC293: once the frame coordinator grants publication, publish
                // immediately. v292's extra randomized delay made visible rows feel sticky
                // even though it reduced same-frame completion bursts.
                apply()
            }
            self.deferredPublicationTask = nil
        }
    }

    private func scheduleTransientRetryIfNeeded(for key: LoadKey) {
        guard currentKey == key,
              image == nil,
              transientRetryAttempt < 2,
              !Self.nonRetryableFailures.contains(key),
              (allowPublicationDuringPlayback || (!Self.exclusivePlaybackActive && !VODExclusivePlaybackGate.isActive)) else { return }

        transientRetryTask?.cancel()
        transientRetryAttempt += 1
        let delay: UInt64 = transientRetryAttempt == 1 ? 500_000_000 : 1_400_000_000
        transientRetryTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: delay)
            guard !Task.isCancelled,
                  let self,
                  self.currentKey == key,
                  self.image == nil,
                  (self.allowPublicationDuringPlayback || (!Self.exclusivePlaybackActive && !VODExclusivePlaybackGate.isActive)) else { return }
            self.failed = false
            self.load(
                key.url,
                preserveCurrentImage: true,
                maxPixelSize: key.maxPixelSize > 0 ? key.maxPixelSize : nil,
                cacheDomain: key.domain,
                allowPublicationDuringSurfaceHandoff: self.allowPublicationDuringSurfaceHandoff,
                allowPublicationDuringPlayback: self.allowPublicationDuringPlayback,
                forceVisiblePlaybackPublication: self.forceVisiblePlaybackPublication
            )
        }
    }

    private static func removeInFlightSubscriber(for key: LoadKey, owner: PremiumRemoteImageLoader) {
        guard var subscribers = inFlightLoads[key] else { return }
        subscribers.removeValue(forKey: ObjectIdentifier(owner))
        guard subscribers.isEmpty else {
            inFlightLoads[key] = subscribers
            return
        }

        inFlightLoads[key] = subscribers
        pendingSubscriberCancellationTasks[key]?.cancel()
        pendingSubscriberCancellationTasks[key] = Task { @MainActor in
            let grace: UInt64 = UnityFrameRuntime.shared.snapshot.navigationActive ? 60_000_000 : 160_000_000
            try? await Task.sleep(nanoseconds: grace)
            guard !Task.isCancelled, inFlightLoads[key]?.isEmpty == true else {
                pendingSubscriberCancellationTasks[key] = nil
                return
            }
            inFlightLoads.removeValue(forKey: key)
            activeNetworkTasks[key]?.cancel()
            activeNetworkTasks.removeValue(forKey: key)
            networkLoadTokens.removeValue(forKey: key)
            pendingSubscriberCancellationTasks[key] = nil
        }
    }

    private static func finishInFlightLoad(for key: LoadKey, image: UIImage?) {
        pendingSubscriberCancellationTasks[key]?.cancel()
        pendingSubscriberCancellationTasks.removeValue(forKey: key)
        guard let callbacks = inFlightLoads.removeValue(forKey: key) else { return }
        callbacks.values.forEach { $0(image) }
    }

    nonisolated private static func decodedForDisplay(data: Data, maxPixelSize: Int) -> UIImage? {
        signalArtworkDecodeGate.withPermit {
            autoreleasepool {
                if maxPixelSize > 0,
                   let imageSource = CGImageSourceCreateWithData(data as CFData, nil) {
                    let options: [CFString: Any] = [
                        kCGImageSourceCreateThumbnailFromImageAlways: true,
                        kCGImageSourceCreateThumbnailWithTransform: true,
                        kCGImageSourceShouldCacheImmediately: true,
                        kCGImageSourceThumbnailMaxPixelSize: maxPixelSize
                    ]
                    if let cgImage = CGImageSourceCreateThumbnailAtIndex(imageSource, 0, options as CFDictionary) {
                        return UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
                    }
                }

                // Full-screen/default callers preserve donor behavior exactly. Also serves as a
                // compatibility fallback for formats ImageIO cannot thumbnail directly.
                guard let source = UIImage(data: data) else { return nil }
                guard source.cgImage != nil else { return source }
                let format = UIGraphicsImageRendererFormat.default()
                format.scale = source.scale
                format.opaque = false
                let renderer = UIGraphicsImageRenderer(size: source.size, format: format)
                return renderer.image { _ in
                    source.draw(in: CGRect(origin: .zero, size: source.size))
                }
            }
        }
    }

    static func artworkCacheDiagnostics() -> [String: Double] { SignalArtworkDiagnostics.shared.snapshot() }

    static var releaseStabilityActiveWorkCount: Int {
        activeNetworkTasks.count + prefetchTasks.count + inFlightLoads.count + (prefetchPumpTask == nil ? 0 : 1)
    }

    static var releaseStabilityDecodedCacheLimitBytes: Int {
        exclusivePlaybackActive ? exclusiveVODDecodedCacheLimitBytes : normalDecodedCacheLimitBytes
    }

    deinit {
        deferredNavigationLoadTask?.cancel()
        transientRetryTask?.cancel()
    }
}


// vBRDC392: a narrowly scoped signal, not a global image-cache flush.
extension Notification.Name {
    static let signalVODArtworkReveal = Notification.Name("signal.vod.artwork.reveal")
}

private struct RemoteImageFitAspectModifier: ViewModifier {
    let mode: RemoteImageFit.Mode

    @ViewBuilder
    func body(content: Content) -> some View {
        switch mode {
        case .fill:
            content.scaledToFill()
        case .fit:
            content.scaledToFit()
        case .stretch:
            content
        }
    }
}

struct RemoteImageFit: View {
    enum Mode { case fill, fit, stretch }
    let url: String?
    var mode: Mode = .fill
    var showPlaceholder: Bool = true
    // Optional display decode budget. nil keeps the donor's original-resolution decode.
    // High-churn card surfaces set a generous cap above their rendered size in vBRDC088.
    var maxPixelSize: Int? = nil
    // vBRDC021: opt-in only. Keeps the previous decoded frame visible while a new URL
    // is downloaded/decoded, then swaps directly to the ready replacement.
    var preservePreviousOnURLChange: Bool = false
    // vBRDC101: opt-in for visible hero/card/logo layers that must be allowed to paint
    // while the outer UNITY branch itself is animating. All other exclusivity rules remain.
    var publishDuringSurfaceHandoff: Bool = false
    // vBRDC106: opt-in only for artwork that is part of visible playback UI. The default
    // remains false so catalog/wallpaper/background images still yield to full-screen video.
    var publishDuringPlayback: Bool = false
    // vBRDC123: bounded foreground VOD UI only. After a short navigation courtesy wait,
    // visible artwork may publish so an event-gate stall cannot leave blank cards.
    var forceVisiblePlaybackPublication: Bool = false
    // vBRDC118: opt-in for large decorative backdrops. During a D-pad burst, keep the
    // current pixels and delay only a cache-miss network/decode start until geometry settles.
    // Small cards/logos remain immediate and therefore keep the exact current focus feel.
    var deferHeavyLoadDuringNavigation: Bool = false
    // Called only when the loader has actually committed a decoded bitmap for the requested URL.
    // Featured Cast uses this to keep the visible name/role/select identity paired with the
    // retained portrait until the replacement portrait is genuinely on screen.
    var onDisplayedURLChange: ((URL?) -> Void)? = nil
    // vBRDC108: optional text is a *true failure fallback*, never a resident underlay.
    // This is used by Live TV logos so a transparent PNG cannot reveal a duplicate generic
    // text logo underneath it. While a real URL is loading the slot stays clear; text appears
    // only when there is no usable URL or the image loader has definitively failed.
    var fallbackText: String? = nil

    @StateObject private var loader = PremiumRemoteImageLoader()
    @Environment(\.premiumArtworkCacheDomain) private var cacheDomain

    private var resolvedURL: URL? {
        PremiumArtworkURL.url(url)
    }

    private func requestLoad(
        _ resolvedURL: URL?,
        preserveCurrentImage: Bool,
        maxPixelSize: Int?,
        cacheDomain: PremiumArtworkCacheDomain
    ) {
        if deferHeavyLoadDuringNavigation {
            loader.loadAfterNavigationSettles(
                resolvedURL,
                preserveCurrentImage: preserveCurrentImage,
                maxPixelSize: maxPixelSize,
                cacheDomain: cacheDomain,
                allowPublicationDuringSurfaceHandoff: publishDuringSurfaceHandoff,
                allowPublicationDuringPlayback: publishDuringPlayback,
                forceVisiblePlaybackPublication: forceVisiblePlaybackPublication
            )
        } else {
            loader.load(
                resolvedURL,
                preserveCurrentImage: preserveCurrentImage,
                maxPixelSize: maxPixelSize,
                cacheDomain: cacheDomain,
                allowPublicationDuringSurfaceHandoff: publishDuringSurfaceHandoff,
                allowPublicationDuringPlayback: publishDuringPlayback,
                forceVisiblePlaybackPublication: forceVisiblePlaybackPublication
            )
        }
    }

    var body: some View {
        Group {
            if let image = loader.image, preservePreviousOnURLChange || loader.imageURL == resolvedURL {
                Image(uiImage: image)
                    .resizable()
                    .interpolation(.high)
                    .antialiased(true)
                    .modifier(RemoteImageFitAspectModifier(mode: mode))
                    // vBRDC023: the seamless catalog path already retains the old decoded
                    // frame until the replacement is ready. Do not then fade the ready
                    // replacement from transparent; that final opacity transition was the
                    // remaining small brightness flash seen on physical Apple TV.
                    .transition(preservePreviousOnURLChange ? .identity : .opacity)
            } else {
                placeholder(showSpinner: !loader.failed && resolvedURL != nil)
            }
        }
        .clipped()
        .animation(preservePreviousOnURLChange ? nil : .easeInOut(duration: 0.18), value: loader.imageURL)
        .onAppear {
            // Preserve the donor's mount semantics: a fresh mount starts from its own
            // request state. Retained-frame continuity remains an URL-change behavior.
            requestLoad(
                resolvedURL,
                preserveCurrentImage: false,
                maxPixelSize: maxPixelSize,
                cacheDomain: cacheDomain
            )
        }
        .onChange(of: resolvedURL) { newValue in
            requestLoad(
                newValue,
                preserveCurrentImage: preservePreviousOnURLChange,
                maxPixelSize: maxPixelSize,
                cacheDomain: cacheDomain
            )
        }
        .onChange(of: maxPixelSize) { newValue in
            requestLoad(
                resolvedURL,
                preserveCurrentImage: preservePreviousOnURLChange,
                maxPixelSize: newValue,
                cacheDomain: cacheDomain
            )
        }
        .onChange(of: cacheDomain) { newDomain in
            requestLoad(
                resolvedURL,
                preserveCurrentImage: preservePreviousOnURLChange,
                maxPixelSize: maxPixelSize,
                cacheDomain: newDomain
            )
        }
        .onReceive(NotificationCenter.default.publisher(for: .signalVODArtworkReveal)) { _ in
            // Only missing artwork explicitly owned by foreground VOD playback.
            // Background catalogs, loaded images, and nil URLs are untouched.
            guard (publishDuringPlayback || forceVisiblePlaybackPublication),
                  resolvedURL != nil, loader.image == nil else { return }
            requestLoad(
                resolvedURL,
                preserveCurrentImage: false,
                maxPixelSize: maxPixelSize,
                cacheDomain: cacheDomain
            )
        }
        .onChange(of: loader.imageURL) { _, newValue in
            onDisplayedURLChange?(newValue)
        }
        .onDisappear { loader.cancel() }
    }

    private func placeholder(showSpinner: Bool) -> some View {
        ZStack {
            if let fallbackText,
               !fallbackText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
               resolvedURL == nil || loader.failed {
                Text(fallbackText)
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.30)
            } else if showPlaceholder {
                LinearGradient(colors: [.black.opacity(0.92), .gray.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
                if showSpinner {
                    ProgressView().scaleEffect(0.78).opacity(0.30)
                }
            } else {
                Color.clear
            }
        }
    }
}
