import SwiftUI
import UIKit

/// Native layers animate inside a fixed viewport. No per-frame SwiftUI timeline,
/// preference publication, focus assignment or view-tree reconstruction.
struct SignalSearchGlyph: View {
    let accent: Color
    let focused: Bool
    var compact: Bool = true
    var active: Bool = true
    @AppStorage("signalSearchEffectV1") private var effectRaw: String = SignalSearchEffectStyle.orbit.rawValue
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    private var effect: SignalSearchEffectStyle { SignalSearchEffectStyle.resolve(effectRaw) }
    var body: some View {
        let diameter: CGFloat = compact ? 42 : 50
        ZStack {
            SignalSearchLayerHost(effect: effect, accent: UIColor(accent), focused: focused,
                moving: active && scenePhase == .active && !reduceMotion && effect.animates(focused: focused))
                .allowsHitTesting(false)
            Text("🔍").font(.system(size: compact ? 25 : 30))
        }
        .frame(width: diameter, height: diameter)
        .overlay(Circle().stroke(Color.white.opacity(focused ? 0.6 : 0.13), lineWidth: 1))
        .clipped()
    }
}

struct SignalMirrorCategoryFrameKey: PreferenceKey {
    static let defaultValue: CGRect = .zero
    static func reduce(value: inout CGRect, nextValue: () -> CGRect) {
        let next = nextValue()
        if next.width > 0 { value = next }
    }
}

private struct SignalSearchLayerHost: UIViewRepresentable {
    let effect: SignalSearchEffectStyle
    let accent: UIColor
    let focused: Bool
    let moving: Bool
    func makeUIView(context: Context) -> SignalSearchLayerView { SignalSearchLayerView() }
    func updateUIView(_ view: SignalSearchLayerView, context: Context) {
        view.configure(effect: effect, accent: accent, focused: focused, moving: moving)
    }
    static func dismantleUIView(_ view: SignalSearchLayerView, coordinator: ()) { view.stop() }
}

private final class SignalSearchLayerView: UIView {
    private var effect = SignalSearchEffectStyle.off
    private var accent = UIColor.clear
    private var glyphHasFocus = false
    private var moving = false
    private var renderedSize = CGSize.zero
    private let artwork = CALayer()
    override var canBecomeFocused: Bool { false }
    override init(frame: CGRect) {
        super.init(frame: frame)
        isUserInteractionEnabled = false
        isAccessibilityElement = false
        backgroundColor = .clear
        layer.addSublayer(artwork)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    func configure(effect: SignalSearchEffectStyle, accent: UIColor, focused: Bool, moving: Bool) {
        guard self.effect != effect || !self.accent.isEqual(accent) || self.glyphHasFocus != focused || self.moving != moving else { return }
        self.effect = effect; self.accent = accent; self.glyphHasFocus = focused; self.moving = moving
        rebuild()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        if renderedSize != bounds.size { rebuild() }
    }
    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window == nil { stop() } else { rebuild() }
    }
    func stop() {
        artwork.removeAllAnimations()
        artwork.sublayers?.forEach { $0.removeAllAnimations(); $0.removeFromSuperlayer() }
    }
    private func animate(_ target: CALayer, key: String, from: Any, to: Any, duration: Double,
                         autoreverses: Bool = false) {
        guard moving, window != nil else { return }
        let animation = CABasicAnimation(keyPath: key)
        animation.fromValue = from; animation.toValue = to
        animation.duration = duration; animation.autoreverses = autoreverses
        animation.repeatCount = .infinity
        animation.timingFunction = CAMediaTimingFunction(name: autoreverses ? .easeInEaseOut : .linear)
        target.add(animation, forKey: key)
    }
    private func rebuild() {
        CATransaction.begin(); CATransaction.setDisableActions(true)
        defer { CATransaction.commit() }
        stop()
        renderedSize = bounds.size
        artwork.frame = bounds
        guard bounds.width > 0, bounds.height > 0, effect != .off,
              effect != .focusOnly || glyphHasFocus else { return }
        let center = CGPoint(x: bounds.midX, y: bounds.midY)
        let radius = min(bounds.width, bounds.height) / 2 - 3
        func ring(start: CGFloat, length: CGFloat, inset: CGFloat = 0, color: UIColor, width: CGFloat = 1.5) -> CAShapeLayer {
            let shape = CAShapeLayer(); shape.frame = bounds
            shape.path = UIBezierPath(arcCenter: center, radius: max(1, radius - inset),
                startAngle: start, endAngle: start + length, clockwise: true).cgPath
            shape.fillColor = UIColor.clear.cgColor; shape.strokeColor = color.cgColor
            shape.lineWidth = width; shape.lineCap = .round
            artwork.addSublayer(shape)
            return shape
        }
        let tau = CGFloat.pi * 2
        switch effect {
        case .off: break
        case .breathe:
            let halo = ring(start: 0, length: tau, color: accent.withAlphaComponent(0.7), width: 2.5)
            animate(halo, key: "opacity", from: 0.25, to: 0.95, duration: 1.8, autoreverses: true)
        case .ripple:
            let ripple = ring(start: 0, length: tau, color: accent.withAlphaComponent(0.65))
            animate(ripple, key: "transform.scale", from: 0.72, to: 1, duration: 1.6, autoreverses: true)
            animate(ripple, key: "opacity", from: 0.9, to: 0.3, duration: 1.6, autoreverses: true)
        case .star:
            let star = CAShapeLayer(); star.frame = bounds
            let x = center.x + radius
            let path = UIBezierPath(); path.move(to: CGPoint(x: x, y: center.y - 3))
            path.addLine(to: CGPoint(x: x + 2, y: center.y)); path.addLine(to: CGPoint(x: x, y: center.y + 3))
            path.addLine(to: CGPoint(x: x - 2, y: center.y)); path.close()
            star.path = path.cgPath; star.fillColor = UIColor.white.cgColor; artwork.addSublayer(star)
            animate(star, key: "transform.rotation.z", from: 0, to: Double.pi * 2, duration: 4)
        case .comet:
            for i in 0..<5 {
                _ = ring(start: -CGFloat(i) * 0.24, length: 0.2,
                    color: accent.withAlphaComponent(CGFloat(0.85 - Double(i) * 0.15)), width: 1.8)
            }
            animate(artwork, key: "transform.rotation.z", from: 0, to: Double.pi * 2, duration: 4)
        case .doubleOrbit:
            let outer = ring(start: 0, length: 1.65, color: accent)
            let inner = ring(start: .pi, length: 1.4, inset: 4, color: UIColor.white.withAlphaComponent(0.55))
            animate(outer, key: "transform.rotation.z", from: 0, to: Double.pi * 2, duration: 4)
            animate(inner, key: "transform.rotation.z", from: 0, to: -Double.pi * 2, duration: 4)
        case .prism:
            for (i, color) in [accent, UIColor.cyan, UIColor.systemPurple].enumerated() {
                _ = ring(start: CGFloat(i) * tau / 3, length: 1.0, color: color)
            }
            animate(artwork, key: "transform.rotation.z", from: 0, to: Double.pi * 2, duration: 4)
        case .scan, .aurora:
            let length: CGFloat = effect == .scan ? .pi / 2 : .pi * 0.88
            _ = ring(start: 0, length: length, color: accent.withAlphaComponent(0.8), width: 2)
            _ = ring(start: .pi, length: length, color: UIColor.white.withAlphaComponent(0.4))
            animate(artwork, key: "transform.rotation.z", from: 0, to: Double.pi * 2, duration: 4)
        case .orbit, .focusOnly:
            _ = ring(start: 0, length: 1.15, color: accent)
            _ = ring(start: 0.9, length: 0.2, color: UIColor.white.withAlphaComponent(0.85))
            animate(artwork, key: "transform.rotation.z", from: 0, to: Double.pi * 2, duration: 4)
        }
    }
}

/// Custom label rendering prevents tvOS from installing an oversized focus platter.
struct SignalCustomizationChipStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        SignalCustomizationChipLabel(label: configuration.label, pressed: configuration.isPressed)
    }
}
private struct SignalCustomizationChipLabel<Label: View>: View {
    let label: Label
    let pressed: Bool
    @Environment(\.isFocused) private var focused
    var body: some View {
        label
            .foregroundStyle(focused ? Color.black : .white)
            .padding(.horizontal, 18)
            .padding(.vertical, 12)
            .background(Capsule().fill(focused ? Color.cyan : Color.white.opacity(0.12)))
            .overlay(Capsule().stroke(focused ? Color.white.opacity(0.9) : Color.white.opacity(0.18), lineWidth: focused ? 2 : 1))
            .clipShape(Capsule())
            .scaleEffect(pressed ? 0.98 : 1)
    }
}

struct SignalCardDepthPlate: View {
    let depth: Double
    let bevel: Double
    let radius: CGFloat
    let accent: Color
    var body: some View {
        Canvas { context, size in
            guard depth > 0, size.width > 0, size.height > 0 else { return }
            let d = CGFloat(min(18, max(0, depth)))
            let bounds = CGRect(x: 2, y: 0, width: max(0, size.width - 4), height: max(0, size.height - d))
            // Three physically bounded ledges, no blur or unbounded raster texture.
            for level in (1...3).reversed() {
                let y = d * CGFloat(level) / 3
                let rect = bounds.offsetBy(dx: 0, dy: y)
                let path = Path(roundedRect: rect, cornerRadius: radius)
                context.fill(path, with: .linearGradient(Gradient(colors: [Color(white: 0.17), Color(white: 0.035), accent.opacity(0.12)]), startPoint: rect.origin, endPoint: CGPoint(x: rect.maxX,y:rect.maxY)))
                context.stroke(path, with: .color(Color.white.opacity(0.045 + bevel * 0.06)), lineWidth: 1)
            }
        }
        .offset(y: CGFloat(min(18, max(0, depth))))
    }
}
