import Foundation

enum SignalPlaybackRefreshPolicy {
    static func gain(_ value: Double) -> Double { value.isFinite ? min(12, max(0, value)) : 0 }
    static func needsForegroundReload(returned: Bool, ready: Bool) -> Bool { returned && !ready }
    static func currentGuideRow(title: String, realTiming: Bool, start: Date?, end: Date?, now: Date) -> Bool {
        guard realTiming, !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              let start, let end, end > start else { return false }
        return end > now && start < now.addingTimeInterval(6 * 60 * 60)
    }
}
