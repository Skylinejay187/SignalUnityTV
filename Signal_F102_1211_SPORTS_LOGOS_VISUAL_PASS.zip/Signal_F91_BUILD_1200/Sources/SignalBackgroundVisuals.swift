import SwiftUI

struct MainGridBackgroundStyle {
    static let presets: [String] = SignalBackgroundTheme.allCases.map { $0.rawValue }
    static func gradientColors(for preset: String) -> [Color] {
        switch SignalBackgroundTheme.resolve(preset) {
        case .pureBlack: return [.black, .black, .black]
        case .smokedGlass: return [Color(white: 0.055), Color(white: 0.14), Color(white: 0.025)]
        case .polarGlass: return [Color(red: 0.035, green: 0.075, blue: 0.10), Color(red: 0.16, green: 0.23, blue: 0.27), .black]
        case .channelAtmosphere, .frostedChannel: return [Color(white: 0.035), Color(red: 0.075, green: 0.11, blue: 0.13), .black]
        case .prismGlass: return [Color(red: 0.04, green: 0.035, blue: 0.07), Color(red: 0.12, green: 0.12, blue: 0.20), .black]
        case .silkDunes: return [Color(red: 0.06, green: 0.045, blue: 0.04), Color(red: 0.16, green: 0.12, blue: 0.10), .black]
        case .auroraVeil: return [Color(red: 0.02, green: 0.065, blue: 0.09), Color(red: 0.035, green: 0.14, blue: 0.13), .black]
        case .contourStudio: return [Color(white: 0.035), Color(red: 0.07, green: 0.10, blue: 0.12), .black]
        case .orbitBloom: return [Color(red: 0.04, green: 0.03, blue: 0.08), Color(red: 0.10, green: 0.075, blue: 0.17), .black]
        case .midnightFacets: return [Color(white: 0.025), Color(red: 0.085, green: 0.10, blue: 0.13), .black]
        case .cinemaHalo: return [Color(red: 0.07, green: 0.04, blue: 0.025), Color(red: 0.13, green: 0.085, blue: 0.06), .black]
        }
    }
    static func swatch(for preset: String) -> Color { gradientColors(for: preset)[1] }
    static func atmosphereColors(for preset: String) -> [Color] {
        switch SignalBackgroundTheme.resolve(preset) {
        case .silkDunes, .cinemaHalo:
            return [Color(red: 0.85, green: 0.66, blue: 0.42), Color(red: 0.48, green: 0.28, blue: 0.16), Color(red: 0.95, green: 0.86, blue: 0.72)]
        case .prismGlass, .orbitBloom:
            return [Color(red: 0.66, green: 0.60, blue: 0.90), Color(red: 0.30, green: 0.27, blue: 0.66), Color(red: 0.84, green: 0.81, blue: 0.98)]
        case .auroraVeil:
            return [Color(red: 0.35, green: 0.77, blue: 0.73), Color(red: 0.12, green: 0.35, blue: 0.48), Color(red: 0.74, green: 0.93, blue: 0.90)]
        default:
            return [Color(red: 0.36, green: 0.65, blue: 0.92), Color(red: 0.13, green: 0.32, blue: 0.65), Color(red: 0.72, green: 0.85, blue: 0.95)]
        }
    }
    static func glassColor(for preset: String) -> Color {
        switch SignalBackgroundTheme.resolve(preset) {
        case .channelAtmosphere, .frostedChannel, .polarGlass:
            return Color(red: 0.08, green: 0.22, blue: 0.34)
        default: return swatch(for: preset)
        }
    }
}

struct MainGridBackgroundView: View {
    let preset: String
    var artworkURL: String? = nil
    var active: Bool = true
    var atmosphereMode: String = "Off"
    var atmosphereActive: Bool = false
    var atmosphereFrameInterval: TimeInterval = 1.0 / 15.0
    @AppStorage("liveTVBackgroundBlurPercentV1") private var blurPercent: Int = SignalBackgroundTreatment.defaultBlur
    @AppStorage("liveTVBackgroundGlassTransparencyV1") private var glassTransparency: Int = SignalBackgroundTreatment.defaultTransparency
    @State private var settledArtworkURL: String? = nil
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    init(preset: String, artworkURL: String? = nil, active: Bool = true,
         atmosphereMode: String = "Off", atmosphereActive: Bool = false,
         atmosphereFrameInterval: TimeInterval = 1.0 / 15.0) {
        self.preset = preset
        self.artworkURL = artworkURL
        self.active = active
        self.atmosphereMode = atmosphereMode
        self.atmosphereActive = atmosphereActive
        self.atmosphereFrameInterval = atmosphereFrameInterval
    }
    private var treatment: SignalBackgroundTreatment {
        SignalBackgroundTreatment(blurPercent: blurPercent,
            glassTransparency: reduceTransparency ? min(glassTransparency, 25) : glassTransparency)
    }
    private var theme: SignalBackgroundTheme { SignalBackgroundTheme.resolve(preset) }
    private var requestKey: String { active && theme.usesChannelArtwork ? "\(preset)|\(artworkURL ?? "")" : "" }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                if theme == .pureBlack {
                    Color.black
                } else {
                    LinearGradient(colors: MainGridBackgroundStyle.gradientColors(for: preset), startPoint: .topLeading, endPoint: .bottomTrailing)
                    if active {
                        if theme.usesChannelArtwork, let url = settledArtworkURL {
                            SignalBackdropArtwork(url: url, maxPixelSize: treatment.artworkMaxPixelSize,
                                blurRadius: treatment.blurRadius(frosted: theme == .frostedChannel),
                                saturation: theme == .frostedChannel ? 0.75 : 1.08)
                                .frame(width: geo.size.width, height: geo.size.height)
                                .scaleEffect(1.13)
                                .frame(width: geo.size.width, height: geo.size.height)
                                .clipped()
                        } else if !theme.usesChannelArtwork {
                            SignalAbstractBackdrop(theme: theme).equatable()
                        }
                        Rectangle().fill(MainGridBackgroundStyle.glassColor(for: preset).opacity(treatment.glassOpacity))
                        if theme == .frostedChannel || theme == .smokedGlass || theme == .polarGlass {
                            LinearGradient(colors: [Color.white.opacity(treatment.glassOpacity * 0.12), .clear], startPoint: .topLeading, endPoint: .bottomTrailing)
                        }



                    }
                    // Protect programme labels and the broadcast header from bright artwork.
                    LinearGradient(colors: [Color.black.opacity(0.40), .clear, Color.black.opacity(0.56)], startPoint: .top, endPoint: .bottom)
                    RadialGradient(colors: [.clear, Color.black.opacity(0.46)], center: .center, startRadius: 100, endRadius: max(geo.size.width, geo.size.height) * 0.72)
                }
                // Smoke is independent of the wallpaper, including Pure Black.
                if active && atmosphereActive && SignalGlassAtmosphereStyle.resolve(atmosphereMode) != .off {
                    SignalGlassAtmosphere(style: SignalGlassAtmosphereStyle.resolve(atmosphereMode), active: true,
                        frameInterval: atmosphereFrameInterval, palette: MainGridBackgroundStyle.atmosphereColors(for: preset))
                        .frame(width: geo.size.width, height: geo.size.height).clipped()
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .clipped()
        }
        .task(id: requestKey) {
            // Coalesce rapid D-pad focus changes before mounting the single bounded
            // image loader. SwiftUI cancels this task on identity change or removal.
            guard !requestKey.isEmpty else { settledArtworkURL = nil; return }
            do {
                try await Task.sleep(nanoseconds: 300_000_000)
                try Task.checkCancellation()
                settledArtworkURL = artworkURL
            } catch { /* a newer focus or inactive surface owns the request */ }
        }
        .onDisappear { settledArtworkURL = nil }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

// Resolution-independent original artwork. Static Canvas has no timer, animation
// timeline, player, network, or observer. It redraws only when its input/size changes.
private struct SignalAbstractBackdrop: View, Equatable {
    let theme: SignalBackgroundTheme
    var body: some View {
        Canvas(rendersAsynchronously: true) { context, size in
            switch theme {
            case .smokedGlass:
                bloom(&context, size, x: 0.74, y: 0.22, radius: 0.63, color: Color(white: 0.55), opacity: 0.24)
                bloom(&context, size, x: 0.18, y: 0.82, radius: 0.48, color: .gray, opacity: 0.14)
            case .polarGlass:
                bloom(&context, size, x: 0.72, y: 0.15, radius: 0.68, color: Color(red: 0.50, green: 0.78, blue: 0.92), opacity: 0.33)
                ribbon(&context, size, index: 0, warm: false)
            case .prismGlass:
                for i in 0..<4 { facet(&context, size, index: i, prism: true) }
            case .silkDunes:
                for i in 0..<6 { ribbon(&context, size, index: i, warm: true) }
            case .auroraVeil:
                bloom(&context, size, x: 0.8, y: 0.4, radius: 0.65, color: .teal, opacity: 0.22)
                for i in 0..<5 { ribbon(&context, size, index: i, warm: false) }
            case .contourStudio:
                for i in 0..<17 { contour(&context, size, index: i) }
            case .orbitBloom:
                bloom(&context, size, x: 0.77, y: 0.32, radius: 0.55, color: .indigo, opacity: 0.48)
                bloom(&context, size, x: 0.27, y: 0.8, radius: 0.5, color: .cyan, opacity: 0.16)
                let orbit = CGRect(x: size.width * 0.27, y: size.height * 0.10, width: size.width * 0.70, height: size.height * 0.70)
                context.stroke(Path(ellipseIn: orbit), with: .color(Color.white.opacity(0.07)), lineWidth: 1)
            case .midnightFacets:
                for i in 0..<6 { facet(&context, size, index: i, prism: false) }
            case .cinemaHalo:
                bloom(&context, size, x: 0.5, y: 0.06, radius: 0.68, color: Color(red: 1, green: 0.65, blue: 0.36), opacity: 0.25)
                let rect = CGRect(x: 0, y: size.height * 0.78, width: size.width, height: size.height * 0.22)
                context.fill(Path(rect), with: .linearGradient(Gradient(colors: [Color.white.opacity(0.045), .clear]), startPoint: CGPoint(x: 0, y: rect.minY), endPoint: CGPoint(x: 0, y: rect.maxY)))
            case .pureBlack, .channelAtmosphere, .frostedChannel: break
            }
        }
    }
    private func bloom(_ ctx: inout GraphicsContext, _ size: CGSize, x: CGFloat, y: CGFloat, radius: CGFloat, color: Color, opacity: Double) {
        let center = CGPoint(x: size.width * x, y: size.height * y)
        ctx.fill(Path(CGRect(origin: .zero, size: size)), with: .radialGradient(Gradient(colors: [color.opacity(opacity), .clear]), center: center, startRadius: 0, endRadius: size.width * radius))
    }
    private func ribbon(_ ctx: inout GraphicsContext, _ size: CGSize, index: Int, warm: Bool) {
        let shift = CGFloat(index) * 0.105
        var p = Path()
        p.move(to: CGPoint(x: -size.width * 0.1, y: size.height * (0.3 + shift)))
        p.addCurve(to: CGPoint(x: size.width * 1.12, y: size.height * (0.12 + shift)), control1: CGPoint(x: size.width * 0.28, y: size.height * (1.0 + shift)), control2: CGPoint(x: size.width * 0.62, y: -size.height * 0.30))
        p.addLine(to: CGPoint(x: size.width * 1.12, y: size.height))
        p.addLine(to: CGPoint(x: -size.width * 0.1, y: size.height))
        p.closeSubpath()
        let tint = warm ? Color(red: 0.68, green: 0.53, blue: 0.40) : Color(red: 0.22, green: 0.68, blue: 0.72)
        ctx.fill(p, with: .linearGradient(Gradient(colors: [tint.opacity(0.09), .black.opacity(0.09), .clear]), startPoint: .zero, endPoint: CGPoint(x: size.width, y: size.height)))
        ctx.stroke(p, with: .color(tint.opacity(0.07)), lineWidth: 1)
    }
    private func facet(_ ctx: inout GraphicsContext, _ size: CGSize, index: Int, prism: Bool) {
        let x = CGFloat(index) * 0.22 - 0.28
        var p = Path()
        p.move(to: CGPoint(x: size.width * x, y: 0))
        p.addLine(to: CGPoint(x: size.width * (x + 0.38), y: 0))
        p.addLine(to: CGPoint(x: size.width * (x + 0.83), y: size.height))
        p.addLine(to: CGPoint(x: size.width * (x + 0.22), y: size.height))
        p.closeSubpath()
        let tints: [Color] = prism ? [.cyan, .indigo, .purple, .teal] : [Color(white: 0.40), Color(white: 0.18)]
        let tint = tints[index % tints.count]
        ctx.fill(p, with: .linearGradient(Gradient(colors: [tint.opacity(prism ? 0.13 : 0.10), .black.opacity(0.20)]), startPoint: .zero, endPoint: CGPoint(x: size.width, y: size.height)))
        ctx.stroke(p, with: .color(tint.opacity(0.13)), lineWidth: 1)
    }
    private func contour(_ ctx: inout GraphicsContext, _ size: CGSize, index: Int) {
        var p = Path()
        let offset = CGFloat(index) * 0.045
        p.move(to: CGPoint(x: -20, y: size.height * (0.1 + offset)))
        p.addCurve(to: CGPoint(x: size.width + 20, y: size.height * (0.02 + offset)), control1: CGPoint(x: size.width * 0.35, y: size.height * (0.8 + offset)), control2: CGPoint(x: size.width * 0.60, y: size.height * (-0.25 + offset)))
        ctx.stroke(p, with: .color(Color.white.opacity(index.isMultiple(of: 4) ? 0.09 : 0.035)), lineWidth: 1)
    }
}

struct MainGridBackgroundPicker: View {
    @Binding var selectedPreset: String
    @FocusState private var focusedTheme: SignalBackgroundTheme?
    private let columns: [GridItem] = [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)]
    var body: some View {
        LazyVGrid(columns: columns, spacing: 10) {
            ForEach(SignalBackgroundTheme.allCases) { theme in
                button(theme)
            }
        }
        .padding(.top, 6)
    }
    private func button(_ theme: SignalBackgroundTheme) -> some View {
        let selected = SignalBackgroundTheme.resolve(selectedPreset) == theme
        let focused = focusedTheme == theme
        return Button { selectedPreset = theme.rawValue } label: {
            VStack(alignment: .leading, spacing: 7) {
                ZStack(alignment: .bottomTrailing) {
                    MainGridBackgroundView(preset: theme.rawValue)
                    if theme.usesChannelArtwork {
                        Image(systemName: "photo.on.rectangle.angled").font(.system(size: 24)).foregroundStyle(Color.white.opacity(0.55)).padding(12)
                    }
                    if selected { Image(systemName: "checkmark.circle.fill").foregroundStyle(Color.cyan).padding(8) }
                }
                .frame(height: 76).clipShape(RoundedRectangle(cornerRadius: 8))
                Text(theme.rawValue).font(.system(size: 14, weight: .bold)).lineLimit(1)
                Text(theme.summary).font(.system(size: 11)).foregroundStyle(Color.white.opacity(0.65)).lineLimit(3)
            }
            .foregroundStyle(Color.white).padding(10).frame(maxWidth: .infinity, minHeight: 152, alignment: .topLeading)
            .background(RoundedRectangle(cornerRadius: 13).fill(Color.white.opacity(focused ? 0.14 : 0.055)))
            .overlay(RoundedRectangle(cornerRadius: 13).stroke(focused ? .white : (selected ? .cyan : Color.white.opacity(0.12)), lineWidth: focused || selected ? 2 : 1))
        }
        .modifier(SettingsRoundedFocusVisual(cornerRadius: 13)).focusEffectDisabled().focused($focusedTheme, equals: theme)
        .accessibilityLabel(theme.rawValue + (selected ? ", selected" : ""))
        .accessibilityHint(theme.summary)
    }
}
