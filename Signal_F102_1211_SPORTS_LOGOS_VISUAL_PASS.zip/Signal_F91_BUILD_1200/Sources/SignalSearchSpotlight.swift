import SwiftUI

/// The actual icon bounds travel through the existing view tree, including its
/// menu size transform. No second icon, focus target or global-coordinate guess.
struct SignalSearchSpotlightAnchorKey: PreferenceKey {
    static var defaultValue: Anchor<CGRect>? { nil }
    static func reduce(value: inout Anchor<CGRect>?, nextValue: () -> Anchor<CGRect>?) {
        if let next = nextValue() { value = next }
    }
}

struct SignalSearchSpotlightTarget: ViewModifier {
    let active: Bool
    func body(content: Content) -> some View {
        content.anchorPreference(key: SignalSearchSpotlightAnchorKey.self, value: .bounds) {
            active ? $0 : nil
        }
    }
}

/// Static light appears only for focused Search; the existing glyph can animate
/// independently. No timer, blur texture, extra player or navigation mutations.
struct SignalSearchFocusSpotlight: View {
    let anchor: Anchor<CGRect>?
    let enabled: Bool
    let accent: Color
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    private var shown: Bool { enabled && anchor != nil && scenePhase == .active }
    var body: some View {
        GeometryReader { proxy in
            if shown, let anchor {
                let icon = proxy[anchor]
                Canvas { context, size in
                    let radius = max(icon.width, icon.height) / 2 + 14
                    let center = CGPoint(x: icon.midX, y: icon.midY)
                    let aperture = CGRect(x: center.x - radius, y: center.y - radius, width: radius * 2, height: radius * 2)
                    var shade = Path(CGRect(origin: .zero, size: size))
                    shade.addEllipse(in: aperture)
                    context.fill(shade, with: .color(.black.opacity(0.58)), style: FillStyle(eoFill: true))
                    // A broad pool of light and a fine rim keep the real icon readable.
                    let pool = aperture.insetBy(dx: -80, dy: -80)
                    context.fill(Path(ellipseIn: pool), with: .radialGradient(
                        Gradient(stops: [.init(color: .clear, location: 0), .init(color: .clear, location: 0.20),
                            .init(color: accent.opacity(0.24), location: 0.40), .init(color: .clear, location: 1)]),
                        center: center, startRadius: 0, endRadius: radius + 80))
                    context.stroke(Path(ellipseIn: aperture), with: .color(accent.opacity(0.8)), lineWidth: 1.5)
                    context.stroke(Path(ellipseIn: aperture.insetBy(dx: -4, dy: -4)), with: .color(.white.opacity(0.20)), lineWidth: 1)
                }
                .transition(.opacity)
            }
        }
        .animation(reduceMotion ? nil : .easeOut(duration: 0.18), value: shown)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}
