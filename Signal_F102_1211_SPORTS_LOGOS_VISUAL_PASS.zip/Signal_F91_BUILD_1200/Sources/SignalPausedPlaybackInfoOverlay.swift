import SwiftUI

/// Passive, session-owned information. Delays never control playback transport.
struct SignalPausedPlaybackInfoOverlay: View {
    let request: SignalPauseInfoPolicy.Request
    let metadata: SignalPauseInfoPolicy.MetadataInput
    let elapsed: Double
    let duration: Double
    var titleArtwork: AnyView? = nil
    var accent: Color = Color(red: 0.38, green: 0.62, blue: 1)
    var remoteActivity: UInt64 = 0
    @AppStorage("pauseInfoIdleDimV1") private var idleDimEnabled = false
    @State private var idleDimmed = false
    private struct IdleKey: Hashable {
        let request: SignalPauseInfoPolicy.Request
        let enabled: Bool
        let activity: UInt64
    }
    private var idleKey: IdleKey { .init(request: request, enabled: idleDimEnabled, activity: remoteActivity) }
    @AppStorage("pauseInfoShowDelayV1") private var showDelay = 1.5
    @AppStorage("pauseInfoHideDelayV1") private var hideDelay = 1.5
    @AppStorage("pauseInfoThemeV1") private var theme = "Liquid Glass"
    @State private var revealLease: SignalPauseInfoPolicy.Lease?
    @State private var displayOwner: SignalPauseInfoPolicy.Request?
    @State private var revealed = false
    private struct TransitionKey: Hashable {
        let request: SignalPauseInfoPolicy.Request
        let show: UInt64
        let hide: UInt64
    }
    private var transitionKey: TransitionKey {
        .init(request: request, show: SignalPauseInfoPolicy.delayNanoseconds(showDelay),
              hide: SignalPauseInfoPolicy.delayNanoseconds(hideDelay))
    }
    private var cardFont: Font.Design { theme == "Cinema" ? .serif : theme == "Minimal" ? .default : .rounded }

    var body: some View {
        ZStack(alignment: .topLeading) {
            if idleDimmed && revealed && request.canReveal {
                Color.black.opacity(0.72).ignoresSafeArea().transition(.opacity)
            }
            if revealed {
                TimelineView(.periodic(from: .now, by: 30)) { context in
                    information(at: context.date)
                }
                .transition(.opacity.combined(with: .offset(y: 12)).combined(with: .scale(scale: 0.985, anchor: .topLeading)))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .animation(.easeInOut(duration: 0.6), value: idleDimmed)
        .onChange(of: idleKey) { _, _ in idleDimmed = false }
        .task(id: idleKey) {
            guard idleDimEnabled, request.canReveal else { return }
            do { try await Task.sleep(nanoseconds: 60_000_000_000) } catch { return }
            guard !Task.isCancelled, idleDimEnabled, request.canReveal else { return }
            idleDimmed = true
        }
        .allowsHitTesting(false)
        .accessibilityHidden(!revealed || !request.eligible)
        .onChange(of: request) { _, updated in
            if revealLease?.request != updated { revealLease = nil }
            // A different source, scene, modal or playback owner clears immediately.
            // Only an ordinary resume may retain the visible card for its hide delay.
            if !updated.eligible || updated.sourceID.isEmpty
                || displayOwner.map({ !SignalPauseInfoPolicy.sameOwner($0, updated) }) == true {
                revealed = false
                displayOwner = nil
            }
        }
        .task(id: transitionKey) {
            let key = transitionKey
            guard !Task.isCancelled else { return }
            guard request.eligible, !request.sourceID.isEmpty else {
                revealed = false; displayOwner = nil; revealLease = nil
                return
            }
            let lease = SignalPauseInfoPolicy.Lease(request: request)
            revealLease = lease
            if request.canReveal {
                // Re-pausing during the hide delay cancels dismissal without flashing.
                if revealed, let owner = displayOwner, SignalPauseInfoPolicy.sameOwner(owner, request) { return }
                guard await SignalPauseInfoPolicy.waitForReveal(nanoseconds: key.show),
                      !Task.isCancelled,
                      SignalPauseInfoPolicy.mayReveal(lease, current: revealLease, request: request) else { return }
                displayOwner = request
                withAnimation(.easeInOut(duration: 0.65)) { revealed = true }
            } else if revealed {
                guard await SignalPauseInfoPolicy.waitForReveal(nanoseconds: key.hide),
                      !Task.isCancelled,
                      SignalPauseInfoPolicy.mayDismiss(lease, current: revealLease, request: request) else { return }
                withAnimation(.easeInOut(duration: 0.65)) { revealed = false }
            }
        }
        .onDisappear {
            idleDimmed = false
            revealLease = nil; displayOwner = nil; revealed = false
        }
    }

    private func information(at now: Date) -> some View {
        let details = metadata.formatted
        return HStack(alignment: .top, spacing: 10) {
            RoundedRectangle(cornerRadius: 3).fill(accent)
                .frame(width: 4, height: theme == "Minimal" ? 56 : 88)
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 9) {
                    Image(systemName: request.paused ? "pause.fill" : "play.fill")
                    Text(request.paused ? "PAUSED" : "NOW PLAYING").tracking(3)
                    Spacer(minLength: 12)
                }
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(accent)
                if let titleArtwork {
                    titleArtwork
                } else {
                    Text(details.title)
                        .font(.system(size: 26, weight: .bold, design: cardFont))
                        .lineLimit(2)
                }
                if !details.episode.isEmpty {
                    Text(details.episode)
                        .font(.system(size: 16, weight: .medium, design: cardFont))
                        .foregroundStyle(.white.opacity(0.86))
                        .lineLimit(2)
                }
                if let end = SignalPauseInfoPolicy.estimatedEnd(now: now, elapsed: elapsed, duration: duration) {
                    HStack(spacing: 9) {
                        Image(systemName: "clock")
                        Text("Ends at")
                        Text(end, style: .time).monospacedDigit()
                    }
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.88))
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(Capsule().fill(accent.opacity(0.14)))
                }
            }
        }
        .padding(theme == "Minimal" ? 14 : 18)
        .frame(width: 390, alignment: .leading)
        .background {
            if theme == "Liquid Glass" || theme == "Signal Glass" || theme == "Frosted Glass" {
                // A single bounded tvOS material surface, only while paused and revealed.
                // No full-screen blur, no duplicate material layers and no animation loop.
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(theme == "Frosted Glass" ? .regularMaterial : .ultraThinMaterial)
                    .overlay {
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .fill(Color.black.opacity(theme == "Frosted Glass" ? 0.28 : 0.38))
                    }
                    .overlay {
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .strokeBorder(.white.opacity(0.26), lineWidth: 1)
                    }
            } else if theme == "Cinema" {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(LinearGradient(colors: [Color.black.opacity(0.90), accent.opacity(0.10), Color.black.opacity(0.84)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .overlay(RoundedRectangle(cornerRadius: 8, style: .continuous).stroke(.white.opacity(0.12), lineWidth: 1))
            }
        }
        .foregroundStyle(.white)
        .multilineTextAlignment(.leading)
        .shadow(color: .black.opacity(0.45), radius: 8, y: 4)
        .padding(.top, 64).padding(.leading, 64)
        .accessibilityElement(children: .combine)
    }
}
