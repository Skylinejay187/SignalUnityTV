import Foundation

/// A focus change never pauses or cancels autoplay. Only the stored preference,
/// a stopped/settled decoder, source readiness, and explicit dismissal control it.
enum SignalUpNextAutoplayPolicy {
    enum Decision: Equatable { case wait, prepareEpisode, prepareSource, offer, arm, play }
    static func decision(endSettled: Bool, cancelled: Bool, automatic: Bool,
                         hasEpisode: Bool, sourceReady: Bool, armed: Bool, countdown: Int) -> Decision {
        guard endSettled, !cancelled else { return .wait }
        guard hasEpisode else { return .prepareEpisode }
        guard sourceReady else { return .prepareSource }
        guard automatic else { return .offer }
        if armed { return countdown <= 0 ? .play : .wait }
        return .arm
    }
}
