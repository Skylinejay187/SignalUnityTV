import Foundation
#if canImport(Network)
import Network
#endif
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

/// The first sample seeds the monitor; repeated equal path snapshots do no work.
struct SignalProtectedPathDeduplicator<Value: Equatable> {
    private var previous: Value?
    init() { previous = nil }
    mutating func changed(_ value: Value) -> Bool {
        let old = previous
        previous = value
        guard let old else { return false }
        return old != value
    }
}

/// A prepared player owns its verified URL/headers until that network epoch changes.
/// Background source/API checks cannot silently replace a running transport.
struct SignalProtectedPlaybackRoute: Equatable {
    let sessionID: UUID
    let sourceURL: URL
    let networkURL: URL
    let headers: [String: String]
    let epoch: UInt64
    let isHomeDirect: Bool

    func matches(sourceURL: URL, sessionID: UUID) -> Bool {
        self.sourceURL == sourceURL && self.sessionID == sessionID
    }
    func requiresRecheck(eventEpoch: UInt64, sessionID: UUID) -> Bool {
        self.sessionID == sessionID && isHomeDirect && eventEpoch > epoch
    }
    func canContinue(with verified: Self) -> Bool {
        matches(sourceURL: verified.sourceURL, sessionID: verified.sessionID)
            && isHomeDirect && verified.isHomeDirect
            && networkURL == verified.networkURL && headers == verified.headers
    }
}

/// Only a live, credential-free public-IP check can authorize a direct home route.
/// Neither a restored preference nor a proxy's On/Off switch is such a proof.
enum SignalProtectedNetworkState {
    static let homeIPKey = "signalVerifiedProxyHomeIPV1"
    static let homeProxyKey = "signalVerifiedProxyHomeIdentityV1"
    static let revoked = Notification.Name("SignalProtectedHomeRouteRevoked")
    private static let lock = NSLock()
    private static var generation: UInt64 = 0
    private static var homeProof: String?
    private static var homeVerifiedInEpoch = false
#if canImport(Network)
    private static var monitor: NWPathMonitor?
    private static var pathUpdates = SignalProtectedPathDeduplicator<NWPath>()
#endif
    static func canonicalIP(_ value: String) -> Data? {
        let value = value.trimmingCharacters(in: .whitespacesAndNewlines)
        var v4 = in_addr(), v6 = in6_addr()
        if inet_pton(AF_INET, value, &v4) == 1 { return withUnsafeBytes(of: &v4) { Data($0) } }
        if inet_pton(AF_INET6, value, &v6) == 1 { return withUnsafeBytes(of: &v6) { Data($0) } }
        return nil
    }
    static func sameIP(_ a: String, _ b: String) -> Bool {
        guard let a = canonicalIP(a), let b = canonicalIP(b) else { return false }
        return a == b
    }
    static func proxyIdentity(_ config: MediaFlowProxySnapshot, light: Bool) -> String {
        config.trimmedProxyURLString + (light ? "|light" : "|full")
    }
    private static func proofIdentity(_ config: MediaFlowProxySnapshot, light: Bool) -> String {
        proxyIdentity(config, light: light) + "|" + config.trimmedPassword + "|" + homeIP(config, light: light)
    }
    static func homeIP(_ config: MediaFlowProxySnapshot, light: Bool, defaults: UserDefaults = .standard) -> String {
        guard defaults.string(forKey: homeProxyKey) == proxyIdentity(config, light: light) else { return "" }
        let saved = defaults.string(forKey: homeIPKey) ?? ""
        guard canonicalIP(saved) != nil else { return "" }
        if !config.trimmedPublicIPOverride.isEmpty, !sameIP(saved, config.trimmedPublicIPOverride) { return "" }
        return saved
    }
    static func learnProxyIP(_ ip: String, config: MediaFlowProxySnapshot, light: Bool) {
        guard canonicalIP(ip) != nil else { return }
        UserDefaults.standard.set(ip, forKey: homeIPKey)
        UserDefaults.standard.set(proxyIdentity(config, light: light), forKey: homeProxyKey)
    }
    static func epoch() -> UInt64 { lock.lock(); defer { lock.unlock() }; return generation }
    static func authorizeHome(_ ip: String, config: MediaFlowProxySnapshot, light: Bool, epoch: UInt64) -> Bool {
        guard sameIP(ip, homeIP(config, light: light)) else { return false }
        let identity = proofIdentity(config, light: light)
        lock.lock(); defer { lock.unlock() }
        guard generation == epoch else { return false }
        homeProof = identity
        homeVerifiedInEpoch = true
        return true
    }
    static func isHome(_ config: MediaFlowProxySnapshot, light: Bool) -> Bool {
        let identity = proofIdentity(config, light: light)
        lock.lock(); defer { lock.unlock() }
        return homeProof == identity
    }
    static func clearHomeProofForNewRequests() {
        // A diagnostic timeout is not evidence that an already verified session moved.
        lock.lock(); homeProof = nil; lock.unlock()
    }
    @discardableResult
    static func revokeHomeProof() -> UInt64 {
        lock.lock()
        let hadHome = homeVerifiedInEpoch
        homeProof = nil; homeVerifiedInEpoch = false
        if hadHome { generation &+= 1 }
        let epoch = generation
        lock.unlock()
        if hadHome { notifyRevoked(epoch: epoch) }
        return epoch
    }
    static func invalidate(notify: Bool = false) {
        lock.lock()
        homeProof = nil; homeVerifiedInEpoch = false; generation &+= 1
        let epoch = generation
        lock.unlock()
        if notify { notifyRevoked(epoch: epoch) }
    }
    private static func notifyRevoked(epoch: UInt64) {
        DispatchQueue.main.async {
            lock.lock()
            let current = generation == epoch
            lock.unlock()
            // Drop queued updates superseded by a newer network. Each player separately
            // checks its own session/epoch, including routes already re-prepared.
            guard current else { return }
            NotificationCenter.default.post(name: revoked, object: nil, userInfo: ["epoch": epoch])
        }
    }
    static func startMonitoring() {
#if canImport(Network)
        lock.lock(); defer { lock.unlock() }
        guard monitor == nil else { return }
        let value = NWPathMonitor(); monitor = value
        value.pathUpdateHandler = { path in
            lock.lock(); let changed = pathUpdates.changed(path); lock.unlock()
            if changed { invalidate(notify: true) }
        }
        value.start(queue: DispatchQueue(label: "signal.debrid.network-path", qos: .utility))
#endif
    }
}

/// Coalesces the small diagnostic request. It never contacts a debrid service or
/// receives an account token, stream URL, cookie or proxy password.
actor SignalPublicIPVerifier {
    static let shared = SignalPublicIPVerifier()
    private var cached: (String, Date, UInt64)?
    private var failed: (Date, UInt64)?
    private var pending: (UUID, UInt64, Task<String?, Never>)?
    func currentIP(session: URLSession) async -> String? {
        let epoch = SignalProtectedNetworkState.epoch()
        if let (date, savedEpoch) = failed, savedEpoch == epoch, Date().timeIntervalSince(date) < 5 { return nil }
        if let (ip, date, savedEpoch) = cached, savedEpoch == epoch, Date().timeIntervalSince(date) < 15 { return ip }
        let id: UUID
        let task: Task<String?, Never>
        if let current = pending, current.1 == epoch { id = current.0; task = current.2 }
        else {
            id = UUID()
            task = Task {
                async let v4 = Self.fetchIP(host: "api.ipify.org", session: session)
                async let preferred = Self.fetchIP(host: "api64.ipify.org", session: session)
                guard let first = await v4, let second = await preferred,
                      SignalProtectedNetworkState.sameIP(first, second) else { return nil }
                return first
            }
            pending = (id, epoch, task)
        }
        let ip = await task.value
        if pending?.0 == id { pending = nil }
        guard SignalProtectedNetworkState.epoch() == epoch else { return nil }
        if let ip { cached = (ip, Date(), epoch); failed = nil }
        else { failed = (Date(), epoch) }
        return ip
    }
    private static func fetchIP(host: String, session: URLSession) async -> String? {
        guard let url = URL(string: "https://" + host + "?format=json") else { return nil }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 4)
        request.httpShouldHandleCookies = false
        do {
            let (data, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode),
                  response.url?.host == host, data.count < 256,
                  let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let ip = json["ip"] as? String, SignalProtectedNetworkState.canonicalIP(ip) != nil else { return nil }
            return ip
        } catch { return nil }
    }

}
