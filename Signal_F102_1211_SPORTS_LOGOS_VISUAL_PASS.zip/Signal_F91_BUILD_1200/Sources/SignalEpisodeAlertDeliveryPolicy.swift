import Foundation

/// A banner's lifetime belongs to the surface that acknowledged rendering it.
enum SignalEpisodeAlertDeliveryPolicy {
    struct Receipt: Equatable {
        let alertID: String
        let surfaceID: String
    }
    struct Lease: Equatable {
        let id = UUID()
        let receipt: Receipt
    }

    static func waitForDisplayDuration(nanoseconds: UInt64) async -> Bool {
        do { try await Task.sleep(nanoseconds: nanoseconds) }
        catch { return false } // cancelling a previous surface must never dismiss its successor
        return !Task.isCancelled
    }

    static func mayDismiss(_ lease: Lease, currentLease: Lease?, activeAlertID: String?, visibleSurfaceID: String?) -> Bool {
        lease == currentLease && lease.receipt.alertID == activeAlertID && lease.receipt.surfaceID == visibleSurfaceID
    }
}
