import Foundation

/// Small one-request-per-connection HTTP parser. No streaming, uploads or general file server.
enum SignalPhoneSetupHTTP {
    static let maximumHeader = 16_384
    static let maximumBody = 131_072
    struct Request {
        let method: String
        let path: String
        let headers: [String: String]
        let body: Data
    }
    enum ParseResult {
        case incomplete
        case rejected
        case request(Request)
    }
    static func parse(_ data: Data) -> ParseResult {
        guard data.count <= maximumHeader + maximumBody else { return .rejected }
        guard let divider = data.range(of: Data([13, 10, 13, 10])) else {
            return data.count > maximumHeader ? .rejected : .incomplete
        }
        guard divider.lowerBound <= maximumHeader,
              let head = String(data: data[..<divider.lowerBound], encoding: .utf8) else { return .rejected }
        let lines = head.components(separatedBy: "\r\n")
        let first = (lines.first ?? "").split(separator: " ", omittingEmptySubsequences: false)
        guard first.count == 3, ["GET", "POST"].contains(String(first[0])), first[2] == "HTTP/1.1",
              first[1].hasPrefix("/"), !first[1].contains("?"), !first[1].contains("#") else { return .rejected }
        var headers: [String: String] = [:]
        for line in lines.dropFirst() {
            guard let colon = line.firstIndex(of: ":"), !line.hasPrefix(" "), !line.hasPrefix("\t") else { return .rejected }
            let name = String(line[..<colon]).lowercased()
            guard !name.isEmpty, name.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "-") }), headers[name] == nil else { return .rejected }
            headers[name] = line[line.index(after: colon)...].trimmingCharacters(in: .whitespaces)
        }
        guard headers["host"] != nil, headers["transfer-encoding"] == nil, headers["expect"] == nil else { return .rejected }
        let rawLength = headers["content-length"] ?? "0"
        guard !rawLength.isEmpty, rawLength.allSatisfy({ $0 >= "0" && $0 <= "9" }),
              let length = Int(rawLength), length <= maximumBody else { return .rejected }
        if first[0] == "GET", length != 0 { return .rejected }
        let available = data.count - divider.upperBound
        guard available <= length else { return .rejected } // rejects pipelining/smuggled requests
        if available < length { return .incomplete }
        return .request(Request(method: String(first[0]), path: String(first[1]), headers: headers,
                                body: Data(data[divider.upperBound...])))
    }

    static func equalSecret(_ a: String, _ b: String) -> Bool {
        let a = Array(a.utf8), b = Array(b.utf8)
        guard a.count == b.count, !b.isEmpty else { return false }
        return zip(a, b).reduce(UInt8(0)) { $0 | ($1.0 ^ $1.1) } == 0
    }

    static func isPrivateIPv4(_ host: String) -> Bool {
        let text = host.split(separator: ".", omittingEmptySubsequences: false)
        guard text.count == 4 else { return false }
        let parts = text.compactMap { UInt8($0) }
        guard parts.count == 4 else { return false }
        return parts[0] == 10 || (parts[0] == 172 && (16...31).contains(parts[1])) ||
            (parts[0] == 192 && parts[1] == 168) || (parts[0] == 169 && parts[1] == 254)
    }

    static func response(status: Int, contentType: String = "application/json; charset=utf-8", body: Data) -> Data {
        let reason = [200: "OK", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found", 409: "Conflict", 429: "Too Many Requests", 503: "Unavailable"][status] ?? "Error"
        let head = "HTTP/1.1 \(status) \(reason)\r\nContent-Type: \(contentType)\r\nContent-Length: \(body.count)\r\nConnection: close\r\nCache-Control: no-store\r\nPragma: no-cache\r\nX-Content-Type-Options: nosniff\r\nReferrer-Policy: no-referrer\r\nX-Frame-Options: DENY\r\nContent-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'\r\n\r\n"
        return Data(head.utf8) + body
    }
}
