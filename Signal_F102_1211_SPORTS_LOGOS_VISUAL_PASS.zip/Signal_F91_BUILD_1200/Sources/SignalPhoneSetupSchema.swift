import Foundation

/// Deliberately limited to text-entry setup. No arbitrary defaults, appearance or safety switches.
enum SignalPhoneSetupSchema {
    struct Field: Codable {
        let key: String
        let label: String
        let group: String
        let kind: String
        let secret: Bool
        var multiline: Bool { kind == "urls" }
    }
    struct InputError: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }
    static let fields: [Field] = [
        Field(key: "liveM3UURL", label: "M3U playlists — one URL per line", group: "Live TV", kind: "urls", secret: false),
        Field(key: "liveXMLTVURL", label: "XMLTV guides — one URL per line", group: "Live TV", kind: "urls", secret: false),
        Field(key: "liveChannelsDvrBaseURL", label: "Channels DVR URL", group: "Live TV", kind: "url", secret: false),
        Field(key: "liveHDHomeRunManualURL", label: "HDHomeRun IP or lineup URL", group: "Live TV", kind: "host", secret: false),
        Field(key: "liveHDHomeRunManualGuideURL", label: "HDHomeRun guide URL", group: "Live TV", kind: "url", secret: false),
        Field(key: "liveXtreamServer", label: "Xtream server URL", group: "Xtream", kind: "url", secret: false),
        Field(key: "liveXtreamUsername", label: "Xtream username", group: "Xtream", kind: "text", secret: false),
        Field(key: "liveXtreamPassword", label: "Xtream password", group: "Xtream", kind: "text", secret: true),
        Field(key: "tmdbApiKey", label: "TMDB API key", group: "Artwork", kind: "text", secret: true),
        Field(key: "omdbApiKey", label: "OMDb API key", group: "Artwork", kind: "text", secret: true),
        Field(key: "fanartTvApiKey", label: "Fanart.tv API key", group: "Artwork", kind: "text", secret: true),
        Field(key: "tvdbApiToken", label: "TVDB API token", group: "Artwork", kind: "text", secret: true),
        Field(key: "realDebridApiKey", label: "Real-Debrid API key", group: "Providers", kind: "text", secret: true),
        Field(key: "torBoxApiKey", label: "TorBox API key", group: "Providers", kind: "text", secret: true),
        Field(key: "premiumizeApiKey", label: "Premiumize API key", group: "Providers", kind: "text", secret: true),
        Field(key: "allDebridApiKey", label: "AllDebrid API key", group: "Providers", kind: "text", secret: true),
        Field(key: "debridLinkApiKey", label: "Debrid-Link API key", group: "Providers", kind: "text", secret: true),
        Field(key: "easyDebridApiKey", label: "EasyDebrid API key", group: "Providers", kind: "text", secret: true),
        Field(key: "offcloudApiKey", label: "Offcloud API key", group: "Providers", kind: "text", secret: true),
        Field(key: "putioClientID", label: "Put.io client ID", group: "Providers", kind: "text", secret: true),
        Field(key: "putioToken", label: "Put.io token", group: "Providers", kind: "text", secret: true)
    ]

    static func webURL(_ raw: String) -> Bool {
        guard let url = URLComponents(string: raw), let scheme = url.scheme?.lowercased(),
              ["http", "https"].contains(scheme), let host = url.host, !host.isEmpty,
              !raw.contains(where: { $0.isWhitespace || $0.isNewline }) else { return false }
        return true
    }

    /// Validate the complete batch before the caller performs its first write.
    static func changes(_ payload: [String: Any]) throws -> [String: String] {
        guard Set(payload.keys).isSubset(of: ["values", "clear"]),
              let values = payload["values"] as? [String: String],
              let clear = payload["clear"] as? [String], Set(clear).count == clear.count else {
            throw InputError(message: "Invalid settings request. Nothing was changed.")
        }
        let allowed = Set(fields.map(\.key))
        guard Set(values.keys).isSubset(of: allowed), Set(clear).isSubset(of: allowed),
              Set(clear).isDisjoint(with: values.keys) else {
            throw InputError(message: "Only the listed setup fields can be changed.")
        }
        var result = Dictionary(uniqueKeysWithValues: clear.map { ($0, "") })
        for field in fields {
            guard let raw = values[field.key] else { continue }
            let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            // Blank replacement fields mean keep the current setting. Clearing is explicit.
            if value.isEmpty { continue }
            guard value.utf8.count <= (field.multiline ? 32_768 : 4096),
                  !value.unicodeScalars.contains(where: { $0.value == 0 || ($0.value < 32 && $0 != "\n" && $0 != "\r" && $0 != "\t") }) else {
                throw InputError(message: "\(field.label) is too large or contains unsupported characters.")
            }
            if field.key.hasPrefix("liveXtream"), value.contains("|") {
                throw InputError(message: "Xtream entries cannot contain the | separator used by saved accounts.")
            }
            if field.kind == "urls" {
                let lines = value.split(whereSeparator: \.isNewline).map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
                guard lines.count <= 100, lines.allSatisfy(webURL) else {
                    throw InputError(message: "\(field.label): enter HTTP or HTTPS URLs, one per line.")
                }
                result[field.key] = lines.joined(separator: "\n")
            } else if field.kind == "url" || field.kind == "host" {
                let candidate = field.kind == "host" && !value.contains("://") ? "http://" + value : value
                guard webURL(candidate) else { throw InputError(message: "\(field.label): enter a valid HTTP or HTTPS address.") }
                result[field.key] = candidate
            } else {
                guard !value.contains(where: \.isNewline) else { throw InputError(message: "\(field.label) must be on one line.") }
                result[field.key] = value
            }
        }
        return result
    }

    static func restoreCode(_ raw: String) throws -> String {
        let code = raw.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !code.isEmpty, code.utf8.count <= 128,
              code.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "-") }) else {
            throw InputError(message: "Enter the restore code shown by Signal, using letters, numbers and hyphens.")
        }
        return code
    }
}
