import AVFoundation
import UIKit

/// Isolated frame extraction for seek previews. This does not own a playback engine.
/// Network extraction is intentionally excluded until Aether's demux/frame API is
/// available: AVAssetImageGenerator on remote debrid URLs can open a second decoder.
@MainActor
final class VODSeekFrameExtractor {
    private var generator: AVAssetImageGenerator?
    private var asset: AVURLAsset?
    private var requestID: UInt64 = 0
    private var sourceURL: URL?
    private var sourceFingerprint: String?
    private let frames = NSCache<NSString, UIImage>()

    private static func fingerprint(for fileURL: URL) -> String? {
        guard let attributes = try? FileManager.default.attributesOfItem(atPath: fileURL.path),
              let size = attributes[.size] as? NSNumber, size.int64Value > 0,
              let modified = attributes[.modificationDate] as? Date else { return nil }
        let device = (attributes[.systemNumber] as? NSNumber)?.stringValue ?? "unknown-device"
        let inode = (attributes[.systemFileNumber] as? NSNumber)?.stringValue ?? "unknown-file"
        return "\(device):\(inode):\(size.int64Value):\(modified.timeIntervalSince1970)"
    }

    init() {
        // Keep a small, predictable memory footprint on Apple TV.
        frames.countLimit = 24
        frames.totalCostLimit = 24 * 360 * 204 * 4
    }

    func reset() {
        requestID &+= 1
        generator?.cancelAllCGImageGeneration()
        generator = nil
        asset = nil
        sourceURL = nil
        sourceFingerprint = nil
        frames.removeAllObjects()
    }

    /// Extract only from a locally cached, seekable VOD file. The completion is
    /// always delivered on the main actor and stale callbacks are discarded.
    func requestFrame(fileURL: URL, seconds: Double, completion: @escaping @MainActor (UIImage?) -> Void) {
        // CMTime and Int bucket conversions must never receive unbounded values.
        guard fileURL.isFileURL, seconds.isFinite, seconds >= 0,
              seconds <= 60 * 60 * 24,
              FileManager.default.isReadableFile(atPath: fileURL.path) else {
            // Revoke the previous request AND release its decoder/cache state.
            // In particular, never retain local movie frames after an invalid
            // (including remote URL) request changes the preview context.
            reset()
            completion(nil)
            return
        }
        // A downloaded local file may be replaced at the same path. Treat its
        // size and modification timestamp as part of the extraction session so
        // neither cached frames nor an old generator survive file replacement.
        guard let fingerprint = Self.fingerprint(for: fileURL) else {
            reset()
            completion(nil)
            return
        }
        if sourceURL != fileURL || sourceFingerprint != fingerprint {
            reset()
            sourceURL = fileURL
            sourceFingerprint = fingerprint
        }
        // Every request, including a cache hit, takes ownership of the preview.
        // Otherwise a slow earlier extraction can overwrite a newer cached frame.
        requestID &+= 1
        let owner = requestID
        generator?.cancelAllCGImageGeneration()
        let bucket = Int((seconds / 2).rounded(.down))
        let cacheKey = NSString(string: "\(fileURL.absoluteString)#\(bucket)")
        if let cached = frames.object(forKey: cacheKey) {
            completion(cached)
            return
        }
        // Reuse the asset metadata while scrubbing the same local file.
        let currentAsset: AVURLAsset
        if let asset {
            currentAsset = asset
        } else {
            let created = AVURLAsset(url: fileURL)
            asset = created
            currentAsset = created
        }
        // Reuse the decoder-facing generator for the same local asset. Creating a
        // fresh generator for every scrub target causes unnecessary track setup
        // and allocations on Apple TV, even when the asset is unchanged.
        let imageGenerator: AVAssetImageGenerator
        if let generator {
            imageGenerator = generator
        } else {
            let created = AVAssetImageGenerator(asset: currentAsset)
            created.appliesPreferredTrackTransform = true
            created.maximumSize = CGSize(width: 360, height: 204)
            created.requestedTimeToleranceBefore = CMTime(seconds: 1, preferredTimescale: 600)
            created.requestedTimeToleranceAfter = CMTime(seconds: 1, preferredTimescale: 600)
            generator = created
            imageGenerator = created
        }
        let time = CMTime(seconds: seconds, preferredTimescale: 600)
        imageGenerator.generateCGImagesAsynchronously(forTimes: [NSValue(time: time)]) { [weak self] _, image, _, result, _ in
            let frame = result == .succeeded ? image : nil
            Task { @MainActor [weak self] in
                guard let self, self.requestID == owner, self.sourceURL == fileURL,
                      self.sourceFingerprint == fingerprint else { return }
                // File replacement can happen after extraction starts. Do not
                // cache or display a frame from a file that is no longer current.
                guard Self.fingerprint(for: fileURL) == fingerprint else {
                    self.reset()
                    completion(nil)
                    return
                }
                let extracted = frame.map { UIImage(cgImage: $0) }
                if let extracted { self.frames.setObject(extracted, forKey: cacheKey, cost: (extracted.cgImage?.bytesPerRow ?? 360 * 4) * (extracted.cgImage?.height ?? 204)) }
                completion(extracted)
            }
        }
    }
}
