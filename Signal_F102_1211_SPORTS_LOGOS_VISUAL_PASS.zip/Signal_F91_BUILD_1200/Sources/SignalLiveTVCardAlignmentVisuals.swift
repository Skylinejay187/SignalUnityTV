import SwiftUI
import QuartzCore

struct SignalLiveTVAlignedCardGeometry: GeometryEffect {
    let pose: SignalLiveTVCardPose
    let enabled: Bool
    func effectValue(size: CGSize) -> ProjectionTransform {
        guard enabled else { return ProjectionTransform(CGAffineTransform.identity) }
        let m = SignalLiveTVCardProjection.fitted(pose: pose, width: Double(size.width), height: Double(size.height))
        var transform = CATransform3DIdentity
        transform.m11 = CGFloat(m.a); transform.m21 = CGFloat(m.c); transform.m41 = CGFloat(m.tx)
        transform.m12 = CGFloat(m.b); transform.m22 = CGFloat(m.d); transform.m42 = CGFloat(m.ty)
        transform.m14 = CGFloat(m.p); transform.m24 = CGFloat(m.q); transform.m44 = CGFloat(m.r)
        return ProjectionTransform(transform)
    }
}

