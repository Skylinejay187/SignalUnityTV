import SwiftUI
import UIKit
import CoreImage

/// One coalesced source owner; expensive filtering happens once on a small bitmap.
/// There is no display-sized live blur and no permanently mounted hidden image slot.
struct SignalBackdropArtwork: View {
    let url: String
    let maxPixelSize: Int
    var blurRadius: Double = 0
    var saturation: Double = 1
    @StateObject private var loader = PremiumRemoteImageLoader()
    @StateObject private var bitmap = SignalBackdropBitmapOwner()
    private var target: URL? { PremiumArtworkURL.url(url) }
    private var request: String { "\(url)|\(maxPixelSize)|\(blurRadius)|\(saturation)" }
    var body: some View {
        SignalBackdropImagePlane(image: bitmap.image)
            .onReceive(loader.$image) { image in
                guard loader.imageURL == target, let image else { return }
                bitmap.render(image, key: request, radius: blurRadius, saturation: saturation)
            }
            .task(id: request) {
                bitmap.invalidatePending()
                do { try await Task.sleep(nanoseconds: 450_000_000); try Task.checkCancellation() }
                catch { return }
                guard await UnityFrameRuntime.shared.waitUntilPermittedDurably(.backgroundPrefetch), !Task.isCancelled else { return }
                loader.loadAfterNavigationSettles(target, preserveCurrentImage: true, maxPixelSize: maxPixelSize)
                if loader.imageURL == target, let image = loader.image {
                    bitmap.render(image, key: request, radius: blurRadius, saturation: saturation)
                }
            }
            .onAppear { bitmap.activate() }
            .onDisappear { loader.cancel(); bitmap.cancel() }
    }
}

@MainActor private final class SignalBackdropBitmapOwner: ObservableObject {
    @Published private(set) var image: UIImage?
    private let id = UUID()
    private var generation = UUID()
    private var requestedKey: String?
    private var operation: BlockOperation?
    func activate() { SignalLiveTVResourceLedger.backdrop(id, active: true) }
    func invalidatePending() {
        generation = UUID(); operation?.cancel(); operation = nil; requestedKey = nil
    }
    func cancel() {
        invalidatePending(); image = nil
        SignalLiveTVResourceLedger.backdrop(id, active: false)
    }
    func render(_ input: UIImage, key: String, radius: Double, saturation: Double) {
        guard requestedKey != key else { return }
        invalidatePending(); requestedKey = key
        let token = generation
        guard let cgImage = input.cgImage else { return }
        let work = BlockOperation()
        work.addExecutionBlock { [weak self, weak work] in
            guard let work, !work.isCancelled else { return }
            let rendered = SignalBackdropFiltering.filtered(cgImage, longestEdge: Double(max(cgImage.width, cgImage.height)), radius: radius, referenceWidth: 1920, saturation: saturation)
            guard !work.isCancelled else { return }
            DispatchQueue.main.async { [weak self] in
                guard let self, self.generation == token, self.requestedKey == key else { return }
                if let rendered { self.image = rendered }
                self.operation = nil
            }
        }
        operation = work; SignalBackdropFiltering.queue.addOperation(work)
    }
    deinit { operation?.cancel() }
}

private struct SignalBackdropImagePlane: UIViewRepresentable {
    let image: UIImage?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeUIView(context: Context) -> UIImageView {
        let view = UIImageView(); view.contentMode = .scaleAspectFill; view.clipsToBounds = true
        view.isUserInteractionEnabled = false; return view
    }
    func updateUIView(_ view: UIImageView, context: Context) {
        guard view.image !== image else { return }
        if view.image != nil && image != nil && !reduceMotion {
            let fade = CATransition(); fade.type = .fade; fade.duration = 0.22
            view.layer.add(fade, forKey: "signal-backdrop-change")
        }
        view.image = image
    }
    static func dismantleUIView(_ view: UIImageView, coordinator: ()) {
        view.layer.removeAllAnimations(); view.image = nil
    }
}

/// Frosted card edges are prepared at 192 pixels once per source, not blurred
/// again over every moving/perspective card on every compositor frame.
struct SignalFrostedCardFill: UIViewRepresentable {
    let image: UIImage
    var radius: Double = 10
    func makeUIView(context: Context) -> SignalFrostedCardImageView { SignalFrostedCardImageView(frame: .zero) }
    func updateUIView(_ view: SignalFrostedCardImageView, context: Context) { view.render(image, radius: radius) }
    static func dismantleUIView(_ view: SignalFrostedCardImageView, coordinator: ()) { view.cancel() }
}

final class SignalFrostedCardImageView: UIImageView {
    private var input: UIImage?
    private var radius: Double = -1
    private var token = UUID()
    private var operation: BlockOperation?
    override init(frame: CGRect) { super.init(frame: frame); contentMode = .scaleAspectFill; clipsToBounds = true; isUserInteractionEnabled = false }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    func cancel() { token = UUID(); operation?.cancel(); operation = nil; input = nil; image = nil }
    func render(_ input: UIImage, radius: Double) {
        guard self.input !== input || self.radius != radius else { return }
        operation?.cancel(); self.input = input; self.radius = radius; token = UUID()
        let requested = token
        guard let source = input.cgImage else { return }
        let work = BlockOperation()
        work.addExecutionBlock { [weak self, weak work] in
            guard let work, !work.isCancelled else { return }
            let result = SignalBackdropFiltering.filtered(source, longestEdge: 192, radius: radius, referenceWidth: 440, saturation: 1.10)
            guard !work.isCancelled else { return }
            DispatchQueue.main.async { [weak self] in
                guard let self, self.token == requested else { return }
                self.image = result; self.operation = nil
            }
        }
        operation = work; SignalBackdropFiltering.queue.addOperation(work)
    }
}

private enum SignalBackdropFiltering {
    static let queue: OperationQueue = {
        let queue = OperationQueue(); queue.name = "Signal.Bounded.BitmapFilters"
        queue.qualityOfService = .utility; queue.maxConcurrentOperationCount = 1; return queue
    }()
    static let context = CIContext(options: [.cacheIntermediates: false])
    static func filtered(_ image: CGImage, longestEdge: Double, radius: Double, referenceWidth: Double, saturation: Double) -> UIImage? {
        autoreleasepool {
            let scale = min(1, longestEdge / Double(max(image.width, image.height)))
            let source = CIImage(cgImage: image).transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            let smallRadius = max(0, radius) * Double(image.width) * scale / referenceWidth
            let filtered = source.clampedToExtent()
                .applyingFilter("CIGaussianBlur", parameters: [kCIInputRadiusKey: smallRadius])
                .cropped(to: source.extent)
                .applyingFilter("CIColorControls", parameters: [kCIInputSaturationKey: saturation])
            guard let result = context.createCGImage(filtered, from: source.extent) else { return nil }
            return UIImage(cgImage: result)
        }
    }
}
