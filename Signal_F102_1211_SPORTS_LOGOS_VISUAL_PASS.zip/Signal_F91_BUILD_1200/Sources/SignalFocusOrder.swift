import Foundation

/// A remote command advances one logical slot. Boundaries clamp; no implicit wrap,
/// timers, wall-clock debounce or asynchronous second focus assignment.
enum SignalFocusOrder {
    static func step(index: Int, delta: Int, count: Int) -> Int {
        guard count > 0 else { return 0 }
        let current = min(count - 1, max(0, index))
        return min(count - 1, max(0, current + (delta < 0 ? -1 : delta > 0 ? 1 : 0)))
    }
}

enum SignalPreviewStartupPolicy {
    // Settle focus briefly so fly-by cards do not create a decoder/network connection.
    static let dwellNanoseconds: UInt64 = 650_000_000
    // Loading is independent of presentation. Never turn/pop/dim or play audio early.
    static let revealHoldSeconds: TimeInterval = 2.0
    static func revealWaitNanoseconds(focusedAt: TimeInterval, now: TimeInterval) -> UInt64 {
        guard focusedAt.isFinite, now.isFinite, now >= focusedAt else { return UInt64(revealHoldSeconds * 1_000_000_000) }
        let remaining = max(0, revealHoldSeconds - (now - focusedAt))
        return UInt64(ceil(remaining * 1_000_000_000))
    }
    static func mayReveal(frameReady: Bool, holdElapsed: Bool) -> Bool { frameReady && holdElapsed }
}

/// Filters only a duplicate delivery from the same card and direction. A command
/// from a newly focused card is never discarded by a global repeat delay.
struct SignalDuplicateCommandGate {
    private var lastIdentity: String? = nil
    private var lastTime: TimeInterval = -.infinity
    mutating func accept(identity: String, now: TimeInterval) -> Bool {
        guard now.isFinite else { return false }
        if lastIdentity == identity, now >= lastTime, now - lastTime < 0.12 { return false }
        lastIdentity = identity
        lastTime = now
        return true
    }
}
