import SwiftUI
import UIKit

/// Compositor-owned smoke. Twelve layers reuse two 256-pixel radial textures;
/// no per-frame SwiftUI TimelineView, Canvas invalidation or full-screen blur.
struct SignalGlassAtmosphere: View {
    let style: SignalGlassAtmosphereStyle
    let active: Bool
    var frameInterval: TimeInterval = 1.0 / 15.0
    let palette: [Color]
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    var body: some View {
        Group {
            if active && scenePhase == .active && style != .off {
                SignalSmokeSurface(style: style, tint: UIColor(style == .ocean ? (palette.first ?? .blue) : Color(red: 0.60, green: 0.70, blue: 0.82)), moving: !reduceMotion, framesPerSecond: Float(min(15, max(8, 1 / max(frameInterval, 1.0 / 15.0)))))
            }
        }
        .allowsHitTesting(false).accessibilityHidden(true)
    }
}

private struct SignalSmokeSurface: UIViewRepresentable {
    let style: SignalGlassAtmosphereStyle
    let tint: UIColor
    let moving: Bool
    let framesPerSecond: Float
    func makeUIView(context: Context) -> SignalSmokeLayerView { SignalSmokeLayerView(frame: .zero) }
    func updateUIView(_ view: SignalSmokeLayerView, context: Context) { view.configure(style: style, tint: tint, moving: moving, framesPerSecond: framesPerSecond) }
    static func dismantleUIView(_ view: SignalSmokeLayerView, coordinator: ()) { view.stop() }
}

private final class SignalSmokeLayerView: UIView {
    private let resourceID = UUID()
    private var style: SignalGlassAtmosphereStyle = .off
    private var tint = UIColor.clear
    private var moving = false
    private var framesPerSecond: Float = 15
    private var configuredSize = CGSize.zero
    private var sprites: [CALayer] = []
    private static let textures: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>(); cache.countLimit = 8; cache.totalCostLimit = 2 * 1024 * 1024; return cache
    }()
    override init(frame: CGRect) { super.init(frame: frame); isUserInteractionEnabled = false; clipsToBounds = true }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    func configure(style: SignalGlassAtmosphereStyle, tint: UIColor, moving: Bool, framesPerSecond: Float) {
        guard self.style != style || !self.tint.isEqual(tint) || self.moving != moving || self.framesPerSecond != framesPerSecond || sprites.isEmpty else { return }
        self.style = style; self.tint = tint; self.moving = moving; self.framesPerSecond = framesPerSecond
        rebuild()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        if bounds.size != configuredSize { rebuild() }
    }
    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window == nil { stop() } else { rebuild() }
    }
    func stop() {
        for sprite in sprites { sprite.removeAllAnimations(); sprite.contents = nil; sprite.removeFromSuperlayer() }
        sprites.removeAll(); configuredSize = .zero
        SignalLiveTVResourceLedger.smoke(resourceID, active: false)
    }
    private func rebuild() {
        stop()
        guard window != nil, bounds.width > 0, bounds.height > 0, style != .off else { return }
        configuredSize = bounds.size
        let light = Self.texture(tint), dark = Self.texture(UIColor(white: 0.015, alpha: 1))
        let count = style == .refraction ? 9 : SignalLiveTVResourcePolicy.smokeSprites
        let density = style == .liquid ? 0.42 : (style == .caustics ? 0.25 : 0.34)
        CATransaction.begin(); CATransaction.setDisableActions(true)
        for i in 0..<count {
            let sprite = CALayer(), phase = Double(i) * 2.399963
            let radius = bounds.height * (style == .refraction ? 0.13 : 0.22)
            sprite.bounds = CGRect(x: 0, y: 0, width: radius * 3.4, height: radius * 2)
            sprite.contents = (i.isMultiple(of: 3) ? dark : light).cgImage
            sprite.contentsGravity = .resize
            let positions = (0...16).map { step -> NSValue in
                let angle = Double(step) / 16 * 2 * Double.pi
                return NSValue(cgPoint: CGPoint(x: bounds.width * (0.5 + 0.34 * sin(angle + phase) + 0.1 * sin(2 * angle + phase * 0.7)),
                    y: bounds.height * (0.5 + 0.32 * cos(angle + phase * 1.3) + 0.1 * sin(2 * angle + phase))))
            }
            sprite.position = positions[0].cgPointValue
            sprite.opacity = Float(density * (0.65 + 0.35 * sin(phase)))
            layer.addSublayer(sprite); sprites.append(sprite)
            if moving {
                let drift = CAKeyframeAnimation(keyPath: "position"); drift.values = positions
                drift.duration = 44 + Double(i) * 2.5; drift.repeatCount = .infinity; drift.calculationMode = .linear
                let breathing = CAKeyframeAnimation(keyPath: "opacity")
                let alpha = sprite.opacity
                breathing.values = [alpha * 0.65, alpha, alpha * 0.8, alpha * 0.65]
                breathing.duration = 19 + Double(i); breathing.repeatCount = .infinity
                let pacing = CAFrameRateRange(minimum: 8, maximum: framesPerSecond, preferred: framesPerSecond)
                drift.preferredFrameRateRange = pacing; breathing.preferredFrameRateRange = pacing
                sprite.add(drift, forKey: "smoke-drift"); sprite.add(breathing, forKey: "smoke-density")
            }
        }
        CATransaction.commit()
        SignalLiveTVResourceLedger.smoke(resourceID, active: true)
    }
    private static func texture(_ color: UIColor) -> UIImage {
        let key = color.description as NSString
        if let existing = textures.object(forKey: key) { return existing }
        let size = CGFloat(SignalLiveTVResourcePolicy.smokeTexturePixels)
        let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = false
        let image = UIGraphicsImageRenderer(size: CGSize(width: size, height: size), format: format).image { renderer in
            let colors = [color.cgColor, color.withAlphaComponent(0.65).cgColor, color.withAlphaComponent(0.18).cgColor, color.withAlphaComponent(0).cgColor]
            guard let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors as CFArray, locations: [0, 0.32, 0.70, 1]) else { return }
            renderer.cgContext.drawRadialGradient(gradient, startCenter: CGPoint(x: size/2, y: size/2), startRadius: 0, endCenter: CGPoint(x: size/2, y: size/2), endRadius: size/2, options: [])
        }
        textures.setObject(image, forKey: key, cost: Int(size * size * 4)); return image
    }
}
