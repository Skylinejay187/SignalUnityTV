import SwiftUI

/// Tiny native SF Symbol animation. Mounted only with the visible Sports header;
/// no full-screen overlay, timer, blur, or independent rendering loop.
struct SignalSportsFrequencyMark: View {
    var body: some View {
        Image(systemName: "cellularbars")
            .font(.system(size: 17, weight: .semibold))
            .foregroundStyle(Color.cyan.opacity(0.94))
            .symbolEffect(.variableColor.iterative, options: .repeating)
            .accessibilityLabel("Signal Sports Frequency reception")
    }
}
