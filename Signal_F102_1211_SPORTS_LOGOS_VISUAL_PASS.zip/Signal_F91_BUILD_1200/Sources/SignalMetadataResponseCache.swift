import Foundation
import CryptoKit

/// Metadata JSON only. No stream resolution, player URLs, credentials or image bodies.
/// Disk I/O and decoding execute on this actor, outside SwiftUI/MainActor.
actor SignalMetadataResponseCache {
    static let shared = SignalMetadataResponseCache()
    struct Entry: Codable { let data: Data; let expires: Date; let staleUntil: Date }
    private var memory: [String: Entry] = [:]
    private var order: [String] = []
    private var flights: [String: Task<(Data, URLResponse), Error>] = [:]
    private var generation = UUID()
    private var cacheHits = 0, networkStarts = 0, sharedRequests = 0, bypassedRequests = 0
    func diagnostics() -> String {
        let enabled = UserDefaults.standard.object(forKey: "metadataCacheEnabledV1") as? Bool ?? true
        return "Metadata cache: \(enabled ? "On" : "Off") • \(cacheHits) cache hits • \(networkStarts) network requests • \(sharedRequests) shared requests • \(memory.count) memory entries • \(active) active • \(waiters.count) queued • \(bypassedRequests) bypassed"
    }
    func counters() -> (hits: Int, network: Int, shared: Int) { (cacheHits, networkStarts, sharedRequests) }
    private let folder: URL
    private let session: URLSession
    init(session: URLSession = .shared, folder: URL? = nil) {
        self.session = session
        self.folder = folder ?? FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!.appendingPathComponent("SignalMetadata-v1", isDirectory: true)
    }
    func resourceSnapshot() -> (memoryBytes: Int, entries: Int, active: Int, queued: Int) {
        (memory.values.reduce(0) { $0 + $1.data.count }, memory.count, active, waiters.count)
    }
    private let memoryLimit = 8 * 1024 * 1024
    private let diskLimit = 32 * 1024 * 1024
    private var active = 0
    private var waiters: [(UUID, CheckedContinuation<Void, Error>)] = []
    private func acquire() async throws {
        try Task.checkCancellation()
        if active < 4 { active += 1; return }
        guard waiters.count < 32 else { throw URLError(.cancelled) }
        let id = UUID()
        try await withTaskCancellationHandler(operation: {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                if Task.isCancelled { continuation.resume(throwing: CancellationError()) }
                else { waiters.append((id, continuation)) }
            }
        }, onCancel: { Task { await self.cancelWaiter(id) } })
        if Task.isCancelled { release(); throw CancellationError() }
    }
    private func cancelWaiter(_ id: UUID) {
        if let index = waiters.firstIndex(where: { $0.0 == id }) { waiters.remove(at: index).1.resume(throwing: CancellationError()) }
    }
    private func release() {
        if !waiters.isEmpty { waiters.removeFirst().1.resume() }
        else { active = max(0, active - 1) }
    }
    func data(for request: URLRequest) async throws -> (Data, URLResponse) {
        guard UserDefaults.standard.object(forKey: "metadataCacheEnabledV1") as? Bool ?? true,
              request.httpMethod == nil || request.httpMethod == "GET", let url = request.url else {
            bypassedRequests += 1
            return try await session.data(for: request)
        }
        let callGeneration = generation
        let headers = (request.allHTTPHeaderFields ?? [:]).map { $0.key.lowercased() + ":" + $0.value }.sorted().joined(separator: "|")
        let cookies = request.httpShouldHandleCookies ? (session.configuration.httpCookieStorage?.cookies(for: url) ?? []).map { $0.name + "=" + $0.value }.sorted().joined(separator: ";") : ""
        let fingerprint = url.absoluteString + "|" + headers + "|" + cookies + "|" + Locale.preferredLanguages.joined(separator: ",")
        let key = SHA256.hash(data: Data(fingerprint.utf8)).map { String(format: "%02x", $0) }.joined()
        var cached = memory[key]
        if cached == nil, let data = try? Data(contentsOf: folder.appendingPathComponent(key)), data.count <= 3_000_000 {
            cached = try? JSONDecoder().decode(Entry.self, from: data)
        }
        if let cached, cached.staleUntil > Date() {
            cacheHits += 1
            retain(cached, key: key)
            if cached.expires <= Date(), flights[key] == nil, active < 4 {
                active += 1; start(request, key: key)
            }
            return (cached.data, HTTPURLResponse(url: url, statusCode: 200, httpVersion: nil, headerFields: ["Content-Type": "application/json"])!)
        }
        if flights[key] != nil { sharedRequests += 1 }
        if flights[key] == nil {
            try await acquire()
            guard generation == callGeneration else { release(); throw CancellationError() }
            if flights[key] != nil { release() }
            else if let fresh = memory[key], fresh.expires > Date() {
                release()
                return (fresh.data, HTTPURLResponse(url: url, statusCode: 200, httpVersion: nil, headerFields: ["Content-Type": "application/json"])!)
            } else { start(request, key: key) }
        }
        guard let flight = flights[key] else { throw CancellationError() }
        let result = try await flight.value
        try Task.checkCancellation()
        return result
    }
    private func start(_ request: URLRequest, key: String) {
        networkStarts += 1
        let owner = generation
        flights[key] = Task {
            defer { release() }
            do {
                var request = request; request.cachePolicy = .reloadIgnoringLocalCacheData
                request.timeoutInterval = min(10, request.timeoutInterval)
                let result = try await session.data(for: request)
                try Task.checkCancellation()
                guard generation == owner else { throw CancellationError() }
                if let response = result.1 as? HTTPURLResponse, response.statusCode == 200,
                   result.0.count <= 2_000_000, (try? JSONSerialization.jsonObject(with: result.0)) != nil {
                    let ttl: Double = request.url?.path.contains("search") == true ? 300 : 21_600
                    let entry = Entry(data: result.0, expires: Date().addingTimeInterval(ttl), staleUntil: Date().addingTimeInterval(ttl * 2))
                    retain(entry, key: key)
                    try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                    if let encoded = try? JSONEncoder().encode(entry) { try? encoded.write(to: folder.appendingPathComponent(key), options: .atomic) }
                    pruneDisk()
                }
                flights[key] = nil
                return result
            } catch {
                if generation == owner { flights[key] = nil }
                throw error
            }
        }
    }
    private func retain(_ entry: Entry, key: String) {
        memory[key] = entry; order.removeAll { $0 == key }; order.append(key)
        var bytes = memory.values.reduce(0) { $0 + $1.data.count }
        while bytes > memoryLimit || memory.count > 192 {
            guard !order.isEmpty else { break }; let oldest = order.removeFirst()
            bytes -= memory.removeValue(forKey: oldest)?.data.count ?? 0
        }
    }
    private func pruneDisk() {
        let keys: Set<URLResourceKey> = [.fileSizeKey, .contentModificationDateKey]
        let files = ((try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: Array(keys))) ?? []).compactMap { url -> (URL, Int, Date)? in
            guard let values = try? url.resourceValues(forKeys: keys) else { return nil }
            return (url, values.fileSize ?? 0, values.contentModificationDate ?? .distantPast)
        }.sorted { $0.2 > $1.2 }
        var bytes = 0
        for (index, file) in files.enumerated() {
            bytes += file.1
            if index >= 256 || bytes > diskLimit || Date().timeIntervalSince(file.2) > 172_800 { try? FileManager.default.removeItem(at: file.0) }
        }
    }
    func suspend() {
        generation = UUID()
        flights.values.forEach { $0.cancel() }; flights.removeAll()
        let pending = waiters; waiters.removeAll()
        pending.forEach { $0.1.resume(throwing: CancellationError()) }
        memory.removeAll(); order.removeAll()
    }
    func clear() { suspend(); try? FileManager.default.removeItem(at: folder) }
}
