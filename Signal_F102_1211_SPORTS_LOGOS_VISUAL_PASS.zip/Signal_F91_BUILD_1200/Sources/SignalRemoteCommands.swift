import Foundation

/// One duplicate window per routed surface, rather than per focused card/row.
/// Native focus still owns native navigation; this filters app-routed commands only.
struct SignalRemoteRepeatGate {
    private struct Entry { let direction: String; let uptime: TimeInterval }
    private var entries: [String: Entry] = [:]
    mutating func accept(owner: String, direction: String, now: TimeInterval) -> Bool {
        guard now.isFinite else { return false }
        if let last = entries[owner], last.direction == direction,
           now >= last.uptime, now - last.uptime < 0.12 { return false }
        entries[owner] = Entry(direction: direction, uptime: now)
        return true
    }
}

@MainActor final class SignalRemoteCommands {
    static let shared = SignalRemoteCommands()
    private var gate = SignalRemoteRepeatGate()
    func accept(owner: String, direction: String) -> Bool {
        gate.accept(owner: owner, direction: direction, now: ProcessInfo.processInfo.systemUptime)
    }
}
