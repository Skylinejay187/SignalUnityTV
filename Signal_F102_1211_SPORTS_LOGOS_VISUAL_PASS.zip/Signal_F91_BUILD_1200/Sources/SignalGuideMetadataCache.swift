import Foundation

/// Bounded derived metadata only; the main-actor guide model owns access.
/// No network, timer, artwork decoding, or observed UI state is created here.
final class SignalGuideMetadataCache<Key: Hashable, Value> {
    private struct Entry { let value: Value; var access: UInt64 }
    private var entries: [Key: Entry] = [:]
    private var access: UInt64 = 0
    private let limit: Int
    private(set) var hits = 0
    private(set) var misses = 0
    var count: Int { entries.count }
    init(limit: Int) { self.limit = max(1, min(limit, 512)) }
    func value(for key: Key, build: () -> Value) -> Value {
        access &+= 1
        if var entry = entries[key] {
            hits += 1; entry.access = access; entries[key] = entry
            return entry.value
        }
        misses += 1
        let value = build()
        if entries.count >= limit, let oldest = entries.min(by: { $0.value.access < $1.value.access })?.key {
            entries.removeValue(forKey: oldest)
        }
        entries[key] = Entry(value: value, access: access)
        return value
    }
    func clear() { entries.removeAll(keepingCapacity: false) }
}

/// A lazy invalidation edge for retained guide models; no observer or timer is needed.
@MainActor enum SignalGuideMetadataCacheControl {
    static private(set) var revision: UInt64 = 0
    static func clear() { revision &+= 1 }
}
