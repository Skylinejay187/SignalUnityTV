import Foundation
import Combine
import Network
import Darwin

/// An explicit, foreground-only setup session; never a playback proxy or persistent service.
@MainActor
final class SignalPhoneSetupServer: ObservableObject {
    typealias Handler = @MainActor (String, [String: Any]) throws -> [String: Any]
    @Published private(set) var running = false
    @Published private(set) var address = ""
    @Published private(set) var qrURL = ""
    @Published private(set) var pin = ""
    @Published private(set) var remainingSeconds = 0
    @Published private(set) var message = "Disabled. Enable when you want to paste setup details from your phone."
    private var listener: NWListener?
    private var clock: DispatchSourceTimer?
    private var deadline: TimeInterval = 0
    private var token = ""
    private var authority = ""
    private var generation = UUID()
    private var handler: Handler?
    private var pairFailures = 0
    private var requestCount = 0
    private var peers: [UUID: Peer] = [:]

    private struct Peer {
        let connection: NWConnection
        var buffer = Data()
        let timeout: DispatchWorkItem
        var responding = false
    }

    func start(handler: @escaping Handler) {
        stop(message: "Starting…")
        guard let host = Self.localAddress() else {
            message = "Connect Apple TV to your home Wi-Fi or Ethernet, then try again."
            return
        }
        // Fresh random credentials per activation; never stored, backed up or synced.
        token = UUID().uuidString.replacingOccurrences(of: "-", with: "") + UUID().uuidString.replacingOccurrences(of: "-", with: "")
        pin = String(format: "%06d", Int.random(in: 0...999_999))
        deadline = ProcessInfo.processInfo.systemUptime + 600
        remainingSeconds = 600
        self.handler = handler
        let session = generation
        do {
            let parameters = NWParameters.tcp
            // Bind the physical LAN IPv4 address, never 0.0.0.0, a VPN or the public interface.
            parameters.requiredLocalEndpoint = .hostPort(host: NWEndpoint.Host(host), port: .any)
            let next = try NWListener(using: parameters)
            next.stateUpdateHandler = { [weak self] state in
                Task { @MainActor [weak self] in
                    guard let self, self.generation == session else { return }
                    switch state {
                    case .ready:
                        guard let port = self.listener?.port else { self.stop(message: "Unable to open a local port."); return }
                        self.authority = "\(host):\(port.rawValue)"
                        self.address = "http://" + self.authority
                        // Fragment credentials are not sent in HTTP URLs or Referer headers.
                        self.qrURL = self.address + "/#" + self.token
                        self.running = true
                        self.message = "Scan with your phone on the same trusted network. Keep About open."
                    case .failed:
                        self.stop(message: "Phone setup could not start. Check the local network and try again.")
                    case .waiting:
                        self.message = "Waiting for the local network…"
                    default: break
                    }
                }
            }
            next.newConnectionHandler = { [weak self] connection in
                Task { @MainActor [weak self] in
                    guard let self, self.generation == session else { connection.cancel(); return }
                    self.accept(connection, session: session)
                }
            }
            listener = next
            next.start(queue: .main)
            let timer = DispatchSource.makeTimerSource(queue: .main)
            timer.schedule(deadline: .now() + 1, repeating: 1, leeway: .milliseconds(200))
            timer.setEventHandler { [weak self] in
                Task { @MainActor [weak self] in
                    guard let self, self.generation == session else { return }
                    self.remainingSeconds = max(0, Int(ceil(self.deadline - ProcessInfo.processInfo.systemUptime)))
                    if self.remainingSeconds == 0 { self.stop(message: "Phone setup expired after 10 minutes. Enable a new session to reconnect.") }
                }
            }
            clock = timer
            timer.resume()
        } catch {
            stop(message: "Phone setup could not open a local connection. Try again.")
        }
    }

    func stop(message: String = "Phone setup disabled.") {
        generation = UUID()
        clock?.setEventHandler {}; clock?.cancel(); clock = nil
        listener?.newConnectionHandler = nil; listener?.stateUpdateHandler = nil
        listener?.cancel(); listener = nil
        for peer in peers.values { peer.timeout.cancel(); peer.connection.cancel() }
        peers.removeAll()
        handler = nil; token = ""; pin = ""; address = ""; qrURL = ""; authority = ""
        deadline = 0; remainingSeconds = 0; running = false; pairFailures = 0; requestCount = 0
        self.message = message
    }

    private func accept(_ connection: NWConnection, session: UUID) {
        guard running, deadline > ProcessInfo.processInfo.systemUptime, peers.count < 6,
              Self.isLocalPeer(connection.endpoint) else {
            connection.cancel(); return
        }
        let id = UUID()
        let timeout = DispatchWorkItem { [weak self] in
            Task { @MainActor [weak self] in
                guard let self, self.generation == session else { return }
                self.finish(id)
            }
        }
        peers[id] = Peer(connection: connection, timeout: timeout)
        DispatchQueue.main.asyncAfter(deadline: .now() + 8, execute: timeout)
        connection.start(queue: .main)
        read(id, session: session)
    }

    private func finish(_ id: UUID) {
        guard let peer = peers.removeValue(forKey: id) else { return }
        peer.timeout.cancel(); peer.connection.cancel()
    }

    private func read(_ id: UUID, session: UUID) {
        guard let peer = peers[id], !peer.responding else { return }
        peer.connection.receive(minimumIncompleteLength: 1, maximumLength: 16_384) { [weak self] data, _, complete, error in
            Task { @MainActor [weak self] in
                guard let self, self.generation == session, var current = self.peers[id], !current.responding else { return }
                if let data { current.buffer.append(data) }
                self.peers[id] = current
                guard self.deadline > ProcessInfo.processInfo.systemUptime else {
                    self.stop(message: "Phone setup expired after 10 minutes."); return
                }
                switch SignalPhoneSetupHTTP.parse(current.buffer) {
                case .rejected: self.send(id, status: 400, json: ["message": "Invalid request."])
                case .incomplete:
                    if error != nil || complete { self.finish(id) } else { self.read(id, session: session) }
                case .request(let request): self.route(request, id: id)
                }
            }
        }
    }

    private func route(_ request: SignalPhoneSetupHTTP.Request, id: UUID) {
        // Never extend the fixed ten-minute deadline on polling, pairing or saves.
        guard running, deadline > ProcessInfo.processInfo.systemUptime else { stop(message: "Phone setup expired."); return }
        requestCount += 1
        guard requestCount <= 1200 else { stop(message: "Request limit reached. Enable a new session on the TV."); return }
        guard request.headers["host"] == authority,
              request.headers["origin"].map({ $0 == "http://" + authority }) ?? true else {
            send(id, status: 403, json: ["message": "Use the address displayed on your TV."]); return
        }
        if request.method == "GET", request.path == "/" {
            send(id, status: 200, data: Data(SignalPhoneSetupPage.html.utf8), contentType: "text/html; charset=utf-8"); return
        }
        if request.path == "/api/pair", request.method == "POST" {
            guard pairFailures < 8 else { send(id, status: 429, json: ["message": "Pairing locked. Enable a new session on the TV."]); return }
            guard let payload = jsonBody(request), Set(payload.keys) == ["pin"], let supplied = payload["pin"] as? String,
                  SignalPhoneSetupHTTP.equalSecret(supplied, pin) else {
                pairFailures += 1
                send(id, status: 401, json: ["message": "Pairing code did not match the TV."]); return
            }
            send(id, status: 200, json: ["token": token]); return
        }
        guard SignalPhoneSetupHTTP.equalSecret(request.headers["authorization"] ?? "", "Bearer " + token) else {
            send(id, status: 401, json: ["message": "Pair with the code shown on your TV."]); return
        }
        if request.path == "/api/state", request.method == "GET" {
            do {
                var snapshot = try handler?("state", [:]) ?? [:]
                snapshot["remainingSeconds"] = max(0, Int(ceil(deadline - ProcessInfo.processInfo.systemUptime)))
                send(id, status: 200, json: snapshot)
            } catch { send(id, status: 409, json: ["message": "Setup status unavailable."]) }
            return
        }
        guard request.method == "POST", let payload = jsonBody(request) else {
            send(id, status: 400, json: ["message": "Expected a JSON setup request."]); return
        }
        if request.path == "/api/stop" {
            guard payload.isEmpty else { send(id, status: 400, json: ["message": "Invalid finish request."]); return }
            send(id, status: 200, json: ["message": "Connection closed."], stopAfterSending: true); return
        }
        let routes = ["/api/settings": "settings", "/api/restore": "restore", "/api/backup": "backup", "/api/addon": "addon", "/api/live": "live"]
        guard let action = routes[request.path], let handler else {
            send(id, status: 404, json: ["message": "Unknown setup action."]); return
        }
        do { send(id, status: 200, json: try handler(action, payload)) }
        catch let error as SignalPhoneSetupSchema.InputError { send(id, status: 400, json: ["message": error.message]) }
        catch { send(id, status: 409, json: ["message": "The action could not be completed. Check your TV."]) }
    }

    private func jsonBody(_ request: SignalPhoneSetupHTTP.Request) -> [String: Any]? {
        guard request.headers["content-type"]?.split(separator: ";").first?.trimmingCharacters(in: .whitespaces).lowercased() == "application/json" else { return nil }
        return (try? JSONSerialization.jsonObject(with: request.body)) as? [String: Any]
    }

    private func send(_ id: UUID, status: Int, json: [String: Any], stopAfterSending: Bool = false) {
        guard let data = try? JSONSerialization.data(withJSONObject: json) else { finish(id); return }
        send(id, status: status, data: data, contentType: "application/json; charset=utf-8", stopAfterSending: stopAfterSending)
    }

    private func send(_ id: UUID, status: Int, data: Data, contentType: String, stopAfterSending: Bool = false) {
        guard var peer = peers[id], !peer.responding else { return }
        peer.responding = true; peer.buffer = Data(); peers[id] = peer
        let session = generation
        peer.connection.send(content: SignalPhoneSetupHTTP.response(status: status, contentType: contentType, body: data), completion: .contentProcessed { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.generation == session else { return }
                self.finish(id)
                if stopAfterSending { self.stop(message: "Phone setup finished.") }
            }
        })
    }

    private static func isLocalPeer(_ endpoint: NWEndpoint) -> Bool {
        guard case .hostPort(let host, _) = endpoint else { return false }
        let octets: [UInt8]
        switch host {
        case .ipv4(let address): octets = Array(address.rawValue)
        case .ipv6(let address):
            // Network.framework may represent an IPv4 peer as an IPv4-mapped IPv6 endpoint.
            let bytes = Array(address.rawValue)
            guard bytes.count == 16, bytes.prefix(10).allSatisfy({ $0 == 0 }),
                  bytes[10] == 255, bytes[11] == 255 else { return false }
            octets = Array(bytes.suffix(4))
        default: return false
        }
        guard octets.count == 4 else { return false }
        return SignalPhoneSetupHTTP.isPrivateIPv4(octets.map { String($0) }.joined(separator: "."))
    }

    private static func localAddress() -> String? {
        var interfaces: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&interfaces) == 0, let first = interfaces else { return nil }
        defer { freeifaddrs(interfaces) }
        var fallback: String?
        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let current = cursor {
            defer { cursor = current.pointee.ifa_next }
            let interface = current.pointee
            guard let address = interface.ifa_addr, address.pointee.sa_family == UInt8(AF_INET),
                  String(cString: interface.ifa_name).hasPrefix("en"),
                  interface.ifa_flags & UInt32(IFF_UP) != 0, interface.ifa_flags & UInt32(IFF_RUNNING) != 0,
                  interface.ifa_flags & UInt32(IFF_LOOPBACK) == 0 else { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            guard getnameinfo(address, socklen_t(address.pointee.sa_len), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 else { continue }
            let value = String(cString: host)
            if SignalPhoneSetupHTTP.isPrivateIPv4(value) {
                if value.hasPrefix("169.254.") { fallback = value } else { return value }
            }
        }
        return fallback
    }

    deinit {
        clock?.cancel()
        listener?.cancel()
        for peer in peers.values { peer.timeout.cancel(); peer.connection.cancel() }
    }
}
