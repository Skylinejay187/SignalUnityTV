import Foundation
import SwiftUI
import UIKit
import Darwin

private enum DebridAetherRuntimeEvent {
    static let time = Notification.Name("DebridChannels.Aether.time")
    static let buffer = Notification.Name("DebridChannels.Aether.buffer")
    static let buffering = Notification.Name("DebridChannels.Aether.buffering")
    static let firstFrame = Notification.Name("DebridChannels.Aether.firstFrame")
    static let failure = Notification.Name("DebridChannels.Aether.failure")
    static let ended = Notification.Name("DebridChannels.Aether.ended")
    static let route = Notification.Name("DebridChannels.Aether.route")
    static let tracks = Notification.Name("DebridChannels.Aether.tracks")
    static let chapters = Notification.Name("DebridChannels.Aether.chapters")
    static let subtitleText = Notification.Name("DebridChannels.Aether.subtitleText")
    static let liveWindow = Notification.Name("DebridChannels.Aether.liveWindow")
}

/// vBRDC252: Xcode/SwiftPM owns native embedding of the bridge and its transitive Aether
/// frameworks. The app still creates no Aether engine/player object until an Aether playback
/// surface is requested; this preserves standard signed packaging for ATVLoadly/Signulous.
@MainActor
private final class DebridAetherRuntimeLoader {
    static let shared = DebridAetherRuntimeLoader()

    private typealias HostFactory = @convention(c) () -> UnsafeMutableRawPointer?
    private var frameworkHandle: UnsafeMutableRawPointer?
    private var hostFactory: HostFactory?
    private(set) var lastError: String?

    private init() {}

    func makeHostView() -> UIView? {
        guard loadIfNeeded(), let hostFactory else { return nil }
        guard let pointer = hostFactory() else {
            lastError = "AetherPlaybackBridge factory returned no view."
            return nil
        }
        let view = Unmanaged<UIView>.fromOpaque(pointer).takeRetainedValue()
        // vBRDC255 Phase 4: the bridge is a presentation island. Keep SwiftUI/UIKit SDR
        // artwork outside it from inheriting translucent/elevated-black presentation effects.
        view.backgroundColor = .black
        view.isOpaque = true
        view.clipsToBounds = true
        view.layer.backgroundColor = UIColor.black.cgColor
        view.layer.masksToBounds = true
        view.layer.shadowOpacity = 0
        view.layer.shadowRadius = 0
        view.layer.shadowOffset = .zero
        view.layer.compositingFilter = nil
        view.layer.filters = nil
        return view
    }

    private func loadIfNeeded() -> Bool {
        if frameworkHandle != nil, hostFactory != nil { return true }

        guard let frameworksURL = Bundle.main.privateFrameworksURL else {
            lastError = "The app bundle has no Frameworks directory."
            return false
        }
        let binaryURL = frameworksURL
            .appendingPathComponent("AetherPlaybackBridge.framework", isDirectory: true)
            .appendingPathComponent("AetherPlaybackBridge", isDirectory: false)
        guard FileManager.default.fileExists(atPath: binaryURL.path) else {
            lastError = "AetherPlaybackBridge.framework is missing from the installed app."
            return false
        }

        _ = dlerror()
        guard let handle = dlopen(binaryURL.path, RTLD_NOW | RTLD_LOCAL) else {
            lastError = dlerror().map { String(cString: $0) } ?? "dlopen failed for AetherPlaybackBridge."
            return false
        }
        guard let symbol = dlsym(handle, "DebridAetherCreateHostView") else {
            lastError = dlerror().map { String(cString: $0) } ?? "AetherPlaybackBridge factory symbol is missing."
            dlclose(handle)
            return false
        }

        frameworkHandle = handle
        hostFactory = unsafeBitCast(symbol, to: HostFactory.self)
        lastError = nil
        return true
    }
}

/// Aether surface with late object creation. There is intentionally no `import AetherPlaybackBridge`
/// here; the app communicates through KVC/selectors + NotificationCenter. The framework graph is
/// natively embedded/linked by Xcode, while Aether engine/player objects are created only on demand.
struct PlaybackKitAetherHost: UIViewRepresentable {
    let url: URL
    let shouldPlay: Bool
    let playAssertionSerial: Int
    let seekSerial: Int
    let seekSeconds: Double
    let seekIsAbsolute: Bool
    let reloadToken: Int
    var goLiveSerial: Int = 0
    let startTimeSeconds: Double
    var isLiveStream: Bool = false
    // Per-surface opt-in, separate from preview playback; defaults to stable startup.
    var fastLiveJoin: Bool = false
    var sourceHint: String = ""
    var httpHeaders: [String: String] = [:]
    var enableDisplayMatch: Bool = true
    // vBRDC389R2: VOD-overlay trailers inherit the already-established VOD display mode.
    // This keeps HDR-capable rendering enabled without asking tvOS to negotiate again.
    var inheritCurrentDisplayMode: Bool = false
    var videoGravityRaw: String = "resizeAspect"
    // Per-instance silence while a focused preview prepares behind its artwork.
    var playbackMuted: Bool = false
    var auxiliaryPlayback: Bool = false
    var selectedAudioTrackID: Int? = nil
    var selectedSubtitleTrackID: Int? = nil
    var trackSelectionSerial: Int = 0
    var allowSessionRebuild: Bool = true
    var audioGainDB: Double = 0
    var vodCachePolicy: String = "auto"
    var subtitleDelayMS: Int = 0
    var onPlaybackTimeUpdate: ((Double, Double) -> Void)? = nil
    var onBufferUpdate: ((Double, Double) -> Void)? = nil
    var onBufferingChanged: ((Bool) -> Void)? = nil
    var onFirstFrameReady: (() -> Void)? = nil
    var onPlaybackFailure: ((String) -> Void)? = nil
    var onPlaybackEnded: (() -> Void)? = nil
    var onRouteChanged: ((String) -> Void)? = nil
    var onTracksDiscovered: (([[String: Any]], [[String: Any]]) -> Void)? = nil
    var onSubtitleTextChanged: ((String) -> Void)? = nil
    var onLiveWindowChanged: ((Double, Double?, Double?, Bool, Double) -> Void)? = nil
    var onChaptersDiscovered: (([[String: Any]]) -> Void)? = nil

    @MainActor
    final class Coordinator {
        var currentURL: URL?
        var currentTime: Double = 0
        var lastReloadToken = -1
        var lastSeekSerial = 0
        var lastPlayAssertionSerial = 0
        var lastShouldPlay = false
        // Natural end is terminal until a new load or explicit Play intent.
        // Foreground activation must not accidentally restart an ended episode.
        var didReachNaturalEnd = false
        var lastTrackSelectionSerial = -1
        var lastGoLiveSerial = 0
        var lastAudioGainDB: Double = 0
        var lastPlaybackMuted = false
        var lastSubtitleDelayMS: Int = 0
        var isAetherHost = false
        var isDismantled = false
        var isAuxiliarySurface = false
        var quickGuideSavedMuted: Bool?
        var auxiliaryReleased = false
        var auxiliaryReleaseID: UUID?
        var resourceID: UUID?
        var observers: [NSObjectProtocol] = []
        var onPlaybackTimeUpdate: ((Double, Double) -> Void)?
        var onBufferUpdate: ((Double, Double) -> Void)?
        var onBufferingChanged: ((Bool) -> Void)?
        var onFirstFrameReady: (() -> Void)?
        var onPlaybackFailure: ((String) -> Void)?
        var onPlaybackEnded: (() -> Void)?
        var onRouteChanged: ((String) -> Void)?
        var onTracksDiscovered: (([[String: Any]], [[String: Any]]) -> Void)?
        var onSubtitleTextChanged: ((String) -> Void)?
        var onLiveWindowChanged: ((Double, Double?, Double?, Bool, Double) -> Void)?
        var onChaptersDiscovered: (([[String: Any]]) -> Void)?

        func installObservers(for view: UIView) {
            removeObservers()
            let center = NotificationCenter.default
            observers.append(center.addObserver(forName: Notification.Name("Signal.QuickGuide.primaryAudioControl"), object: nil, queue: .main) { [weak self, weak view] note in
                guard let self, let view, !self.isDismantled, self.isAetherHost,
                      !self.isAuxiliarySurface, let action = note.userInfo?["action"] as? String else { return }
                switch action {
                case "pause": PlaybackKitAetherHost.performNoArgumentSelector("aetherPause", on: view)
                case "mute":
                    if self.quickGuideSavedMuted == nil { self.quickGuideSavedMuted = (view.value(forKey: "configuredMuted") as? NSNumber)?.boolValue ?? false }
                    view.setValue(NSNumber(value: true), forKey: "configuredMuted")
                    self.lastPlaybackMuted = true
                    PlaybackKitAetherHost.performNoArgumentSelector("aetherApplyMute", on: view)
                case "restore":
                    if let muted = self.quickGuideSavedMuted {
                        view.setValue(NSNumber(value: muted), forKey: "configuredMuted")
                        self.lastPlaybackMuted = muted
                        PlaybackKitAetherHost.performNoArgumentSelector("aetherApplyMute", on: view)
                    }
                    self.quickGuideSavedMuted = nil
                default: return
                }
                (note.userInfo?["ack"] as? (() -> Void))?()
            })
            // A suspended tvOS scene may return without SwiftUI changing shouldPlay.
            // Reassert the existing playback intent on foreground; do not reload the
            // decoder, restart paused media, or revive a dismantled playback surface.
            observers.append(center.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main) { [weak self, weak view] _ in
                guard let self, let view, !self.isDismantled, self.isAetherHost else { return }
                let selector = NSSelectorFromString("aetherPrepareForBackground")
                if view.responds(to: selector) { _ = view.perform(selector) }
            })
            observers.append(center.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main) { [weak self, weak view] _ in
                guard let self, let view, !self.isDismantled, self.isAetherHost,
                      !self.didReachNaturalEnd, view.window != nil else { return }
                let selector = NSSelectorFromString("aetherRecoverAfterBackground")
                if view.responds(to: selector) { _ = view.perform(selector) }
            })
            observers.append(center.addObserver(forName: Notification.Name("DebridChannels.Aether.audioGain"), object: view, queue: .main) { [weak self] note in
                guard let self, !self.isDismantled, let url = self.currentURL else { return }
                var info = note.userInfo ?? [:]; info["url"] = url.absoluteString
                NotificationCenter.default.post(name: Notification.Name("DebridChannels.Aether.audioGainNotice"), object: nil, userInfo: info)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.time, object: view, queue: .main) { [weak self] note in
                guard let self, !self.isDismantled else { return }
                guard let current = (note.userInfo?["current"] as? NSNumber)?.doubleValue,
                      let duration = (note.userInfo?["duration"] as? NSNumber)?.doubleValue else { return }
                guard current.isFinite, current >= 0, duration.isFinite, duration >= 0 else { return }
                self.currentTime = current
                self.onPlaybackTimeUpdate?(current, duration)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.buffer, object: view, queue: .main) { [weak self] note in
                guard let self, !self.isDismantled else { return }
                guard let buffered = (note.userInfo?["buffered"] as? NSNumber)?.doubleValue,
                      let duration = (note.userInfo?["duration"] as? NSNumber)?.doubleValue else { return }
                guard buffered.isFinite, buffered >= 0, duration.isFinite, duration >= 0 else { return }
                self.onBufferUpdate?(buffered, duration)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.buffering, object: view, queue: .main) { [weak self] note in
                guard let self, !self.isDismantled else { return }
                // An incomplete event is not a real transition to unbuffered.
                // Preserve the existing UI state rather than fabricating false.
                guard let buffering = (note.userInfo?["isBuffering"] as? NSNumber)?.boolValue else { return }
                self.onBufferingChanged?(buffering)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.firstFrame, object: view, queue: .main) { [weak self] _ in
                guard let self, !self.isDismantled else { return }
                self.onFirstFrameReady?()
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.failure, object: view, queue: .main) { [weak self] note in
                guard let self, !self.isDismantled else { return }
                let message = note.userInfo?["message"] as? String ?? "AetherEngine runtime failure."
                self.onPlaybackFailure?(message)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.ended, object: view, queue: .main) { [weak self] _ in
                guard let self, !self.isDismantled, !self.didReachNaturalEnd else { return }
                // A decoder can emit duplicate terminal events. Notify Up Next
                // once per playback run so it cannot launch two handoffs.
                self.didReachNaturalEnd = true
                self.onPlaybackEnded?()
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.route, object: view, queue: .main) { [weak self] note in
                guard let self, !self.isDismantled else { return }
                let route = note.userInfo?["route"] as? String ?? "unknown"
                let reason = note.userInfo?["reason"] as? String
                self.onRouteChanged?(reason.map { "\(route) • \($0)" } ?? route)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.chapters, object: view, queue: .main) { [weak self] note in
                guard let self, !self.isDismantled, let chapters = note.userInfo?["chapters"] as? [[String: Any]] else { return }
                self.onChaptersDiscovered?(chapters)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.tracks, object: view, queue: .main) { [weak self] note in
                guard let self, !self.isDismantled else { return }
                // Empty arrays are legitimate (no tracks), but absent payloads
                // are not discovery results and must not erase selected tracks.
                guard let audio = note.userInfo?["audio"] as? [[String: Any]],
                      let subtitles = note.userInfo?["subtitles"] as? [[String: Any]] else { return }
                self.onTracksDiscovered?(audio, subtitles)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.subtitleText, object: view, queue: .main) { [weak self] note in
                guard let self, !self.isDismantled else { return }
                // An explicit empty cue clears the subtitle. Missing text is
                // an incomplete event, not an instruction to clear the overlay.
                guard let text = note.userInfo?["text"] as? String else { return }
                self.onSubtitleTextChanged?(text)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.liveWindow, object: view, queue: .main) { [weak self] note in
                guard let self, !self.isDismantled else { return }
                guard let edge = (note.userInfo?["edge"] as? NSNumber)?.doubleValue else { return }
                let lower = (note.userInfo?["lower"] as? NSNumber)?.doubleValue
                let upper = (note.userInfo?["upper"] as? NSNumber)?.doubleValue
                let atEdge = (note.userInfo?["atEdge"] as? NSNumber)?.boolValue ?? false
                guard let behind = (note.userInfo?["behind"] as? NSNumber)?.doubleValue else { return }
                guard edge.isFinite, edge >= 0, behind.isFinite, behind >= 0,
                      lower.map({ $0.isFinite && $0 >= 0 }) ?? true,
                      upper.map({ $0.isFinite && $0 >= 0 }) ?? true,
                      (lower.flatMap { low in upper.map { low <= $0 } } ?? true) else { return }
                self.onLiveWindowChanged?(edge, lower, upper, atEdge, behind)
            })
        }

        func removeObservers() {
            let center = NotificationCenter.default
            observers.forEach { center.removeObserver($0) }
            observers.removeAll()
        }

    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    @MainActor static func controlPrimaryForQuickGuide(_ action: String) -> Bool {
        var acknowledged = false
        let ack: () -> Void = { acknowledged = true }
        NotificationCenter.default.post(name: Notification.Name("Signal.QuickGuide.primaryAudioControl"), object: nil,
                                        userInfo: ["action": action, "ack": ack])
        return acknowledged
    }

    func makeUIView(context: Context) -> UIView {
        context.coordinator.isAuxiliarySurface = auxiliaryPlayback
        context.coordinator.onPlaybackTimeUpdate = onPlaybackTimeUpdate
        context.coordinator.onBufferUpdate = onBufferUpdate
        context.coordinator.onBufferingChanged = onBufferingChanged
        context.coordinator.onFirstFrameReady = onFirstFrameReady
        context.coordinator.onPlaybackFailure = onPlaybackFailure
        context.coordinator.onPlaybackEnded = onPlaybackEnded
        context.coordinator.onRouteChanged = onRouteChanged
        context.coordinator.onTracksDiscovered = onTracksDiscovered
        context.coordinator.onChaptersDiscovered = onChaptersDiscovered
        context.coordinator.onSubtitleTextChanged = onSubtitleTextChanged
        context.coordinator.onLiveWindowChanged = onLiveWindowChanged

        // A retired SwiftUI preview can reach makeUIView after an exclusive player
        // claimed the decoder. Revoke it before loading any Aether framework/host.
        if auxiliaryPlayback && AuxiliaryVideoPlaybackCoordinator.shared.isAuxiliaryPlaybackSuppressed() {
            context.coordinator.auxiliaryReleased = true
            return UIView(frame: .zero)
        }
        guard let view = DebridAetherRuntimeLoader.shared.makeHostView() else {
            let placeholder = UIView(frame: .zero)
            placeholder.backgroundColor = .black
            placeholder.isOpaque = true
            placeholder.layer.backgroundColor = UIColor.black.cgColor
            let message = DebridAetherRuntimeLoader.shared.lastError ?? "AetherEngine runtime bridge could not be loaded."
            // A queued failure must not outlive a replaced SwiftUI playback surface.
            // Deliver through the coordinator so teardown can revoke the callback.
            DispatchQueue.main.async { [weak coordinator = context.coordinator] in
                guard let coordinator, !coordinator.isDismantled else { return }
                coordinator.onPlaybackFailure?(message)
            }
            return placeholder
        }

        context.coordinator.isAetherHost = true
        context.coordinator.resourceID = SignalLiveTVResourceLedger.beginHost(auxiliary: auxiliaryPlayback)
        if auxiliaryPlayback {
            context.coordinator.auxiliaryReleaseID = AuxiliaryVideoPlaybackCoordinator.shared.registerReleaseHandler { [weak view, weak coordinator = context.coordinator] in
                guard let coordinator, !coordinator.auxiliaryReleased else { return }
                coordinator.auxiliaryReleased = true
                coordinator.lastShouldPlay = false
                if let view { Self.performNoArgumentSelector("aetherStop", on: view) }
                coordinator.removeObservers()
                SignalLiveTVResourceLedger.endHost(coordinator.resourceID)
                coordinator.resourceID = nil
            }
        }
        context.coordinator.installObservers(for: view)
        configure(view: view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: UIView, context: Context) {
        // A delayed SwiftUI update must not reattach callbacks or send playback
        // commands after dismantle has revoked this surface.
        guard !context.coordinator.isDismantled, !context.coordinator.auxiliaryReleased else { return }
        context.coordinator.onPlaybackTimeUpdate = onPlaybackTimeUpdate
        context.coordinator.onBufferUpdate = onBufferUpdate
        context.coordinator.onBufferingChanged = onBufferingChanged
        context.coordinator.onFirstFrameReady = onFirstFrameReady
        context.coordinator.onPlaybackFailure = onPlaybackFailure
        context.coordinator.onPlaybackEnded = onPlaybackEnded
        context.coordinator.onRouteChanged = onRouteChanged
        context.coordinator.onTracksDiscovered = onTracksDiscovered
        context.coordinator.onChaptersDiscovered = onChaptersDiscovered
        context.coordinator.onSubtitleTextChanged = onSubtitleTextChanged
        context.coordinator.onLiveWindowChanged = onLiveWindowChanged
        guard context.coordinator.isAetherHost else { return }
        configure(view: view, coordinator: context.coordinator)
    }

    static func dismantleUIView(_ view: UIView, coordinator: Coordinator) {
        coordinator.isDismantled = true
        AuxiliaryVideoPlaybackCoordinator.shared.unregisterReleaseHandler(coordinator.auxiliaryReleaseID)
        coordinator.auxiliaryReleaseID = nil
        SignalLiveTVResourceLedger.endHost(coordinator.resourceID)
        coordinator.resourceID = nil
        // Release every SwiftUI callback immediately. NotificationCenter can
        // still have an already-enqueued delivery when teardown begins.
        coordinator.onPlaybackTimeUpdate = nil
        coordinator.onBufferUpdate = nil
        coordinator.onBufferingChanged = nil
        coordinator.onFirstFrameReady = nil
        coordinator.onPlaybackFailure = nil
        coordinator.onPlaybackEnded = nil
        coordinator.onRouteChanged = nil
        coordinator.onTracksDiscovered = nil
        coordinator.onChaptersDiscovered = nil
        coordinator.onSubtitleTextChanged = nil
        coordinator.onLiveWindowChanged = nil
        if coordinator.isAetherHost {
            performNoArgumentSelector("aetherStop", on: view)
        }
        coordinator.removeObservers()
    }

    private func configure(view: UIView, coordinator: Coordinator) {
        guard !coordinator.auxiliaryReleased, !coordinator.isDismantled else { return }
        // The engine clamps gain but cannot safely handle NaN/infinity: clamp at
        // the SwiftUI boundary as well, including values restored from backups.
        let safeAudioGainDB = audioGainDB.isFinite ? min(12, max(0, audioGainDB)) : 0
        view.setValue(NSNumber(value: allowSessionRebuild && !auxiliaryPlayback), forKey: "configuredAllowSessionRebuild")
        Self.performNoArgumentSelector("aetherReconcileSessionConfiguration", on: view)
        let needsLoad = coordinator.currentURL != url || coordinator.lastReloadToken != reloadToken
        if needsLoad {
            view.setValue(NSNumber(value: auxiliaryPlayback), forKey: "configuredAuxiliaryPreview")
            coordinator.currentURL = url
            coordinator.currentTime = startTimeSeconds.isFinite ? max(0, startTimeSeconds) : 0
            coordinator.lastReloadToken = reloadToken
            coordinator.lastSeekSerial = seekSerial
            coordinator.lastPlayAssertionSerial = playAssertionSerial
            coordinator.lastShouldPlay = shouldPlay
            coordinator.didReachNaturalEnd = false
            coordinator.lastGoLiveSerial = goLiveSerial

            view.setValue(url.absoluteString, forKey: "configuredURLString")
            view.setValue(NSNumber(value: coordinator.currentTime), forKey: "configuredStartTimeSeconds")
            view.setValue(NSNumber(value: isLiveStream), forKey: "configuredIsLiveStream")
            view.setValue(NSNumber(value: isLiveStream && fastLiveJoin), forKey: "configuredFastLiveJoin")
            view.setValue(sourceHint, forKey: "configuredSourceHint")
            view.setValue(httpHeaders as NSDictionary, forKey: "configuredHTTPHeaders")
            view.setValue(NSNumber(value: enableDisplayMatch), forKey: "configuredEnableDisplayMatch")
            view.setValue(NSNumber(value: inheritCurrentDisplayMode), forKey: "configuredInheritCurrentDisplayMode")
            view.setValue(videoGravityRaw, forKey: "configuredVideoGravityRaw")
            view.setValue(NSNumber(value: playbackMuted), forKey: "configuredMuted")
            view.setValue(NSNumber(value: shouldPlay), forKey: "configuredAutoplay")
            view.setValue(NSNumber(value: selectedAudioTrackID ?? -1), forKey: "configuredAudioTrackID")
            view.setValue(NSNumber(value: selectedSubtitleTrackID ?? -1), forKey: "configuredSubtitleTrackID")
            view.setValue(NSNumber(value: safeAudioGainDB), forKey: "configuredAudioGainDB")
            view.setValue(vodCachePolicy, forKey: "configuredVODCachePolicy")
            view.setValue(NSNumber(value: subtitleDelayMS), forKey: "configuredSubtitleDelayMS")
            coordinator.lastTrackSelectionSerial = trackSelectionSerial
            coordinator.lastAudioGainDB = safeAudioGainDB
            coordinator.lastPlaybackMuted = playbackMuted
            coordinator.lastSubtitleDelayMS = subtitleDelayMS
            Self.performNoArgumentSelector("aetherLoadConfiguredMedia", on: view)
            return
        }

        if playbackMuted != coordinator.lastPlaybackMuted {
            coordinator.lastPlaybackMuted = playbackMuted
            view.setValue(NSNumber(value: playbackMuted), forKey: "configuredMuted")
            Self.performNoArgumentSelector("aetherApplyMute", on: view)
        }

        if goLiveSerial != coordinator.lastGoLiveSerial {
            coordinator.lastGoLiveSerial = goLiveSerial
            Self.performNoArgumentSelector("aetherGoLive", on: view)
        }

        if seekSerial != coordinator.lastSeekSerial {
            coordinator.lastSeekSerial = seekSerial
            // Swift's max does not sanitize NaN/infinity. Never pass a non-finite
            // target into the native engine (including relative-seek overflow).
            if seekSeconds.isFinite, coordinator.currentTime.isFinite {
                let target = seekIsAbsolute ? seekSeconds : coordinator.currentTime + seekSeconds
                if target.isFinite {
                    view.setValue(NSNumber(value: max(0, target)), forKey: "configuredSeekSeconds")
                    // An explicit seek after the end starts a new playback run;
                    // subsequent end events must be delivered again.
                    coordinator.didReachNaturalEnd = false
                    Self.performNoArgumentSelector("aetherSeekConfiguredPosition", on: view)
                }
            }
        }

        if trackSelectionSerial != coordinator.lastTrackSelectionSerial {
            coordinator.lastTrackSelectionSerial = trackSelectionSerial
            view.setValue(NSNumber(value: selectedAudioTrackID ?? -1), forKey: "configuredAudioTrackID")
            view.setValue(NSNumber(value: selectedSubtitleTrackID ?? -1), forKey: "configuredSubtitleTrackID")
            Self.performNoArgumentSelector("aetherApplyTrackSelection", on: view)
        }

        if abs(safeAudioGainDB - coordinator.lastAudioGainDB) > 0.01 {
            coordinator.lastAudioGainDB = safeAudioGainDB
            view.setValue(NSNumber(value: safeAudioGainDB), forKey: "configuredAudioGainDB")
            Self.performNoArgumentSelector("aetherApplyAudioGain", on: view)
        }

        if subtitleDelayMS != coordinator.lastSubtitleDelayMS {
            coordinator.lastSubtitleDelayMS = subtitleDelayMS
            view.setValue(NSNumber(value: subtitleDelayMS), forKey: "configuredSubtitleDelayMS")
            Self.performNoArgumentSelector("aetherRefreshSubtitlePresentation", on: view)
        }

        if playAssertionSerial != coordinator.lastPlayAssertionSerial {
            coordinator.lastPlayAssertionSerial = playAssertionSerial
            // A stale remote/foreground play assertion must never override an
            // explicit paused state. Playback intent is the authoritative gate.
            // If playback intent also changed in this SwiftUI update, let the
            // transition below issue the single authoritative play/pause call.
            if shouldPlay && shouldPlay == coordinator.lastShouldPlay && !coordinator.didReachNaturalEnd {
                // An assertion is not an explicit replay. Once a natural end
                // has been delivered to Up Next, never restart the old episode.
                Self.performNoArgumentSelector("aetherPlay", on: view)
            }
        }

        if shouldPlay != coordinator.lastShouldPlay {
            coordinator.lastShouldPlay = shouldPlay
            if shouldPlay { coordinator.didReachNaturalEnd = false }
            coordinator.lastGoLiveSerial = goLiveSerial
            Self.performNoArgumentSelector(shouldPlay ? "aetherPlay" : "aetherPause", on: view)
        }
    }

    private static func performNoArgumentSelector(_ name: String, on view: UIView) {
        let selector = NSSelectorFromString(name)
        guard view.responds(to: selector) else { return }
        _ = view.perform(selector)
    }
}
