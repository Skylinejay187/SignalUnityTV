import Foundation

/// A routing restriction, not an account-activity detector. Opaque addon/CDN URLs
/// cannot reliably identify a debrid provider; unknown VOD stays protected while
/// positively identified TorBox hosts are exempt from automatic enforcement.
enum SignalMediaFlowSafetyPolicy {
    static let enabledKey = "signalRequireMediaFlowForVODV1"

    static func enabled(defaults: UserDefaults = .standard) -> Bool {
        true // A synced legacy Off value can never disable network protection.
    }

    static func protects(vod: Bool, url: URL?, enabled: Bool) -> Bool {
        guard enabled else { return false }
        let host = url?.host?.lowercased() ?? ""
        // Positive host identity only. An opaque addon URL is not a TorBox proof.
        if host == "torbox.app" || host.hasSuffix(".torbox.app") { return false }
        if vod { return true }
        return ["real-debrid.com", "real-debrid.net", "rdeb.io", "alldebrid.com", "alldebrid.fr", "alld.io", "debrid.it", "premiumize.me", "debrid-link.com", "debrid-link.fr", "easydebrid.com", "offcloud.com", "put.io"].contains {
            host == $0 || host.hasSuffix("." + $0)
        }
    }

    static let deviceScopedKeys: Set<String> = [enabledKey, "mediaFlowProxyEnabledV1", "mediaFlowLightEnabledV2", "mediaFlowPreferredLocalProfileV1"]
    static func settingsForThisDevice(_ settings: [String: Any]) -> [String: Any] {
        settings.filter { !deviceScopedKeys.contains($0.key) }
    }
    static let networkChangedMessage = "The network changed. Protected direct playback stopped. Press Retry to verify home access or reconnect through MediaFlow."
    static let disabledMessage = "Protected-source safety: this device could not verify the home network or a usable MediaFlow profile. Configure the home proxy in Settings; direct playback away from home is blocked."
    static let unverifiedMessage = "Real-Debrid safety lock: verify MediaFlow's configured public IP in Settings before playback. A failed or unchecked IP never permits direct playback."
}
