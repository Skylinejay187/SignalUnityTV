import Foundation

/// One dashboard. The old setting key stays only for backup/upgrade compatibility.
enum SignalDashboardMode {
    static let name = "Preview Mirror"
    static let legacyKey = "liveTVDashboardStyleV348"
    static func migrate(_ defaults: UserDefaults = .standard) {
        if defaults.string(forKey: legacyKey) != name { defaults.set(name, forKey: legacyKey) }
    }
}
