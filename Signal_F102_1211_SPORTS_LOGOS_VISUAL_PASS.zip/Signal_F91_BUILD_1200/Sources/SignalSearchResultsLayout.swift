import Foundation

/// Search keeps the v228 landscape-card proportions independent of catalog artwork settings.
struct SignalSearchResultsLayout {
    let columnCount: Int
    let columnWidth: Double
    let cardWidth: Double
    var cardHeight: Double { cardWidth * 9 / 16 }
    static let columnSpacing: Double = 46
    static let rowSpacing: Double = 58
    static let horizontalInset: Double = 16

    static func make(width: Double) -> Self {
        let width = width.isFinite ? max(1, width) : 1
        let inner = max(1, width - horizontalInset * 2)
        let count = inner >= 1400 ? 4 : (inner >= 1050 ? 3 : (inner >= 650 ? 2 : 1))
        let slot = min(408, max(1, (inner - Double(count - 1) * columnSpacing) / Double(count)))
        return Self(columnCount: count, columnWidth: slot, cardWidth: min(360, slot))
    }

    static func targetIndex(ids: [String], rememberedID: String?, fallback: Int) -> Int? {
        guard !ids.isEmpty else { return nil }
        if let rememberedID, let index = ids.firstIndex(of: rememberedID) { return index }
        return min(max(0, fallback), ids.count - 1)
    }

    /// One D-pad step, including a partial final row. Boundaries never wrap.
    static func movedIndex(index: Int, count: Int, columns: Int, dx: Int, dy: Int) -> Int? {
        guard count > 0, columns > 0, index >= 0, index < count,
              (dx == 0) != (dy == 0) else { return nil }
        let row = index / columns, column = index % columns
        if dy != 0 {
            let nextRow = row + (dy < 0 ? -1 : 1)
            guard nextRow >= 0, nextRow <= (count - 1) / columns else { return nil }
            return min(nextRow * columns + column, count - 1)
        }
        let nextColumn = column + (dx < 0 ? -1 : 1)
        let next = row * columns + nextColumn
        guard nextColumn >= 0, nextColumn < columns, next < count else { return nil }
        return next
    }
}

/// Search cards decode at 768px. Request TMDB's matching CDN rendition instead
/// of downloading a multi-megabyte original before downsampling locally. MediaItem
/// retains its original URL for full-size detail/hero views; NAS hashed WebP is untouched.
enum SignalSearchArtwork {
    static func cardURL(for raw: String?) -> String? {
        guard let raw, var parts = URLComponents(string: raw), parts.scheme == "https",
              parts.host?.lowercased() == "image.tmdb.org", parts.user == nil,
              parts.password == nil, parts.port == nil, parts.query == nil, parts.fragment == nil,
              parts.path.hasPrefix("/t/p/original/"), !parts.path.lowercased().hasSuffix(".svg") else { return raw }
        parts.path = parts.path.replacingOccurrences(of: "/t/p/original/", with: "/t/p/w780/", options: .anchored)
        return parts.string ?? raw
    }
}
