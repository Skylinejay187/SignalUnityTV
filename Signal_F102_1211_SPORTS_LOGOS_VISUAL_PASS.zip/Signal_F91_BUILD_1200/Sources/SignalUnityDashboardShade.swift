import Foundation

/// Static compositing only: keep the shared shell's header clear, shade the content.
enum SignalUnityDashboardShadePolicy {
    static func headerStops(height: Double) -> (clear: Double, opaque: Double) {
        let height = height.isFinite ? max(1, height) : 1080
        return (min(0.28, 112 / height), min(0.42, 184 / height))
    }
    static func normalizedSportsStyle(_ value: String) -> String {
        ["Dimmed Dashboard", "Artwork 3 Hero", "Clear Dashboard"].contains(value) ? value : "Dimmed Dashboard"
    }
}

#if canImport(SwiftUI)
import SwiftUI
struct SignalUnityDashboardHeaderMask: View {
    let height: CGFloat
    var body: some View {
        let stops = SignalUnityDashboardShadePolicy.headerStops(height: Double(height))
        LinearGradient(stops: [.init(color: .clear, location: 0),
            .init(color: .clear, location: CGFloat(stops.clear)),
            .init(color: .white, location: CGFloat(stops.opaque)), .init(color: .white, location: 1)],
            startPoint: .top, endPoint: .bottom)
    }
}
struct SignalUnityDashboardShade: View {
    var hero: Bool = false
    var body: some View {
        // F88: one static gradient; never mount animated opacity, blur, or materials.
        // Header is masked by the existing parent. Hero stays intentionally subtle.
        LinearGradient(
            colors: hero
                ? [Color.black.opacity(0.075), Color.black.opacity(0.135)]
                : [Color.black.opacity(0.23), Color.black.opacity(0.33)],
            startPoint: .top, endPoint: .bottom
        )
        .allowsHitTesting(false)
    }
}
#endif
