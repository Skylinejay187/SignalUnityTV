import SwiftUI

private struct SignalLiveTVVisualWorkKey: EnvironmentKey { static let defaultValue = true }
extension EnvironmentValues {
    var signalLiveTVVisualWorkActive: Bool {
        get { self[SignalLiveTVVisualWorkKey.self] }
        set { self[SignalLiveTVVisualWorkKey.self] = newValue }
    }
}
