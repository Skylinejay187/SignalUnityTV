import Foundation

/// The header, every program rectangle, and the current-time marker share one axis.
/// Gaps remain gaps; small programs are never widened into neighboring time slots.
struct SignalGuideTimeline {
    struct Slot: Equatable { let x: Double; let width: Double }
    static let stationWidth: Double = 190
    static let stationGap: Double = 8
    static let horizonMinutes: Double = 120
    let start: Date
    let scheduleWidth: Double
    var end: Date { start.addingTimeInterval(Self.horizonMinutes * 60) }
    var scheduleOrigin: Double { Self.stationWidth + Self.stationGap }
    var pointsPerMinute: Double { scheduleWidth / Self.horizonMinutes }

    init(now: Date, width: Double, calendar: Calendar = .current) {
        let minute = calendar.component(.minute, from: now)
        start = calendar.date(bySettingHour: calendar.component(.hour, from: now),
                              minute: (minute / 30) * 30, second: 0, of: now) ?? now
        scheduleWidth = max(1, width - Self.stationWidth - Self.stationGap)
    }
    func x(at date: Date) -> Double { date.timeIntervalSince(start) / 60 * pointsPerMinute }
    func tick(_ index: Int) -> Date { start.addingTimeInterval(Double(index) * 30 * 60) }
    func slot(start programStart: Date, end programEnd: Date) -> Slot? {
        guard programEnd > programStart, programEnd > start, programStart < end else { return nil }
        let left = max(0, x(at: programStart))
        let right = min(scheduleWidth, x(at: programEnd))
        guard right > left else { return nil }
        return Slot(x: left, width: right - left)
    }
}

extension SignalGuideTimeline {
    struct Entry {
        let id: UInt64
        let start: Date
        let end: Date
    }
    struct ProgramSlot: Identifiable, Equatable {
        let id: UInt64
        let x: Double
        let width: Double
    }
    /// Providers may publish duplicate or overlapping EPG revisions. Keep unique
    /// identities and one rectangle per time interval before placing any glyphs.
    func slots(_ entries: [Entry]) -> [ProgramSlot] {
        let ordered = entries.filter { $0.end > $0.start && $0.end > start && $0.start < end }.sorted {
            if $0.start != $1.start { return $0.start < $1.start }
            if $0.end != $1.end { return $0.end > $1.end }
            return $0.id < $1.id
        }
        var seen = Set<UInt64>()
        var normalized: [Entry] = []
        for entry in ordered {
            guard seen.insert(entry.id).inserted else { continue }
            // Same-start revisions choose the longest, then stable ID, consistently.
            if normalized.last?.start == entry.start { continue }
            if let previous = normalized.last, previous.end > entry.start {
                normalized[normalized.count - 1] = Entry(id: previous.id, start: previous.start, end: entry.start)
            }
            normalized.append(entry)
        }
        return normalized.compactMap { entry in
            guard let frame = slot(start: entry.start, end: entry.end) else { return nil }
            return ProgramSlot(id: entry.id, x: frame.x, width: frame.width)
        }
    }
}
