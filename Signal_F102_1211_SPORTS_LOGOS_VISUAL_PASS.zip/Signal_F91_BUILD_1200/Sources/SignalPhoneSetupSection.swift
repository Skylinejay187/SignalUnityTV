import SwiftUI

/// Isolate the one-second countdown from the large Settings view's observation tree.
@MainActor
struct SignalPhoneSetupSection: View {
    @StateObject private var server = SignalPhoneSetupServer()
    @Environment(\.scenePhase) private var scenePhase
    let handler: SignalPhoneSetupServer.Handler
    let focused: FocusState<SettingsScreen.SettingsFocus?>.Binding

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Set Up from Phone")
                .font(.system(size: 28, weight: .bold, design: .rounded))
            Text("Paste playlists, guide URLs, provider and artwork API keys, catalog links or a restore code from your phone. Use the same trusted home network. Keep About open; access ends after 10 minutes.")
                .font(.system(size: 18)).foregroundStyle(.white.opacity(0.72))
                .frame(maxWidth: 1050, alignment: .leading)
            SettingsButton(title: server.running || server.remainingSeconds > 0 ? "Disable Phone Setup" : "Enable Phone Setup — 10 Minutes",
                           focus: .phoneSetup, focused: focused) {
                if server.running || server.remainingSeconds > 0 { server.stop() }
                else { server.start(handler: handler) }
            }
            if server.running {
                HStack(alignment: .center, spacing: 28) {
                    SignalPhoneSetupQR(text: server.qrURL).equatable()
                        .frame(width: 230, height: 230)
                        .padding(12).background(Color.white).clipShape(RoundedRectangle(cornerRadius: 16))
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Scan to connect, or open:")
                        Text(server.address).font(.system(size: 25, weight: .bold, design: .monospaced))
                        Text("Pairing code: \(server.pin)").font(.system(size: 27, weight: .bold, design: .monospaced))
                        Text(String(format: "Closes in %d:%02d", server.remainingSeconds / 60, server.remainingSeconds % 60))
                            .foregroundStyle(.orange).monospacedDigit()
                    }.font(.system(size: 18))
                }
            }
            Text(server.message).font(.system(size: 16)).foregroundStyle(.white.opacity(0.65))
        }
        .foregroundStyle(.white)
        .padding(.bottom, 22)
        .onDisappear { server.stop() }
        .onChange(of: scenePhase) { phase in
            if phase != .active { server.stop(message: "Phone setup closed because Signal left the foreground.") }
        }
    }
}

private struct SignalPhoneSetupQR: View, Equatable {
    let text: String
    var body: some View { QRCodeImage(text: text) }
}
