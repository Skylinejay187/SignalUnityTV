import Foundation

enum SignalPhoneSetupPage {
    // Everything is bundled; no third-party scripts, analytics, fonts or stored browser tokens.
    static let html = """
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Signal • Phone Setup</title>
<style>
:root{color-scheme:dark;font:16px system-ui,-apple-system,sans-serif;background:#101216;color:#f5f5f7}*{box-sizing:border-box}body{margin:0}main{max-width:760px;margin:auto;padding:28px 20px 80px}h1{font-size:30px;margin:8px 0}h2{font-size:21px;margin:4px 0 18px}p{line-height:1.5;color:#b8bdc8}.brand{font-size:12px;font-weight:800;letter-spacing:3px;color:#f9a85f}.status{position:sticky;top:0;z-index:2;background:#1c212b;padding:14px;border-radius:14px;white-space:pre-wrap;margin:18px 0}section{background:#1a1d24;border:1px solid #30343f;border-radius:20px;padding:20px;margin:18px 0}label{display:block;margin:18px 0 7px;font-weight:650}input,textarea{width:100%;font:inherit;color:#fff;background:#101217;border:1px solid #484e5d;border-radius:10px;padding:13px}textarea{min-height:105px;resize:vertical}input:focus,textarea:focus{outline:2px solid #f5a15c}button{font:inherit;font-weight:750;border:0;background:#f5a15c;color:#16120f;padding:13px 18px;border-radius:12px;margin:12px 7px 0 0;cursor:pointer}button.secondary{background:#343a48;color:#fff}button:disabled{opacity:.5;cursor:wait}.hint{font-size:13px;color:#a9b1c2}.clear{display:flex;align-items:center;gap:8px;margin:8px 0;font-size:13px;color:#bac1ce;font-weight:400}.clear input{width:18px;height:18px}.field{padding-bottom:14px;border-bottom:1px solid #30343f}.hidden{display:none!important}output{display:block;white-space:pre-wrap;overflow-wrap:anywhere;border-radius:10px;background:#101217;padding:14px;font:700 20px ui-monospace,monospace}.save{position:sticky;bottom:8px;border:1px solid #555;background:#f5a15c;box-shadow:0 4px 24px #0007}small{display:block;color:#a9b1c2;margin-top:7px}
</style></head><body><main>
<div class="brand">SIGNAL</div><h1>Set up from your phone</h1>
<p>Connect to the same trusted home network as your Apple TV. This page closes after 10 minutes, or when you leave About. Changes are saved only when you choose an action.</p>
<div id="status" class="status" role="status" aria-live="polite">Connecting…</div>
<section id="pair" class="hidden"><h2>Pair with Apple TV</h2><p>Enter the six-digit code shown on your TV, or scan its QR code.</p><label for="pin">Pairing code</label><input id="pin" inputmode="numeric" maxlength="6" autocomplete="off"><button id="pairButton">Connect</button></section>
<div id="setup" class="hidden">
<section><h2>Backup &amp; restore</h2><p>Paste an existing restore code below to restore this Apple TV. Restoring applies the full saved profile, including its appearance settings.</p>
<label for="restore">Restore code</label><input id="restore" autocapitalize="characters" autocomplete="off" spellcheck="false" maxlength="128"><button id="restoreButton">Restore this Apple TV</button>
<p class="hint">Your current backup code</p><output id="currentCode">No backup code yet</output><button class="secondary" id="copyButton">Copy code</button><button class="secondary" id="backupButton">Create / refresh backup</button><p id="backupStatus" class="hint"></p></section>
<section><h2>Add a catalog</h2><label for="manifest">Addon manifest URL</label><input id="manifest" type="url" autocomplete="off" spellcheck="false" placeholder="https://…/manifest.json"><button id="addonButton">Add catalog URL</button><small>Uses Signal's existing addon manager. Load catalogs on the TV when ready.</small></section>
<form id="fields" autocomplete="off"></form>
<button id="saveButton" class="save">Save entered settings</button><button id="refreshLiveButton" class="secondary">Import / refresh Live TV</button>
<p class="hint">Blank fields keep their current values. Entering playlists or guides replaces that entire saved list. This temporary local HTTP connection is not encrypted; use a trusted home network. Existing URLs, usernames and keys are never sent back to this page. Use a field's Clear checkbox to remove it. Saving keys does not enable provider attachments or change playback protection. Saved Xtream accounts remain managed on the TV. Themes, icons and playback controls stay on the TV.</p>
<button id="stopButton" class="secondary">Finish &amp; close connection</button>
</div></main><script>
(() => {
'use strict';
const byId = id => document.getElementById(id);
let token = location.hash.slice(1), state = null, timer = null, closed = false, busy = false, built = false;
history.replaceState(null, '', location.pathname);
const status = message => { byId('status').textContent = message; };
function disconnect(message) {
 closed = true; token = ''; clearTimeout(timer);
 document.querySelectorAll('input,textarea,button').forEach(element => { element.disabled = true; });
 document.querySelectorAll('input,textarea').forEach(element => { element.value = ''; });
 byId('currentCode').textContent = ''; status(message);
}
async function api(path, body) {
 if (closed) throw Error('This connection has closed. Enable a new session on your TV.');
 const controller = new AbortController(); const timeout = setTimeout(() => controller.abort(), 6000);
 let response;
 try { response = await fetch(path, {method:body === undefined ? 'GET' : 'POST', cache:'no-store', credentials:'omit', signal:controller.signal,
   headers:{'Authorization':'Bearer ' + token,'Content-Type':'application/json'}, body:body === undefined ? undefined : JSON.stringify(body)}); } finally { clearTimeout(timeout); }
 const result = await response.json();
 if (!response.ok) {
   if (response.status === 401 && path !== '/api/pair') { token = ''; byId('setup').classList.add('hidden'); byId('pair').classList.remove('hidden'); }
   throw Error(result.message || 'Request failed.');
 }
 return result;
}
function buildFields(fields) {
 const root = byId('fields'); let group = '', section;
 fields.forEach(field => {
   if (field.group !== group) { group = field.group; section = document.createElement('section'); const title = document.createElement('h2'); title.textContent = group; section.appendChild(title); root.appendChild(section); }
   const row = document.createElement('div'); row.className = 'field';
   const label = document.createElement('label'); label.htmlFor = field.key; label.textContent = field.label;
   const input = document.createElement(field.kind === 'urls' ? 'textarea' : 'input'); input.id = field.key; input.name = field.key;
   if (input.tagName === 'INPUT') input.type = field.secret ? 'password' : 'text';
   input.autocomplete = 'off'; input.spellcheck = false; input.setAttribute('autocapitalize','none');
   input.maxLength = field.kind === 'urls' ? 32768 : 4096;
   const clearLabel = document.createElement('label'); clearLabel.className = 'clear';
   const clear = document.createElement('input'); clear.type = 'checkbox'; clear.id = 'clear-' + field.key;
   clear.addEventListener('change', () => { input.disabled = clear.checked; if(clear.checked) input.value = ''; });
   clearLabel.append(clear, document.createTextNode('Clear saved value')); row.append(label,input,clearLabel); section.appendChild(row);
 }); built = true;
}
function paint(next) {
 state = next;
 if (!built) buildFields(next.fields);
 next.fields.forEach(field => { byId(field.key).placeholder = field.configured ? 'Configured on TV — enter to replace' : 'Not configured'; });
 byId('currentCode').textContent = next.restoreCode || 'No backup code yet';
 byId('backupStatus').textContent = next.backupMessage || '';
 byId('backupButton').disabled = next.backupBusy || busy;
 byId('restoreButton').disabled = next.backupBusy || busy;
 status('Connected to Signal • ' + Math.floor(next.remainingSeconds / 60) + ':' + String(next.remainingSeconds % 60).padStart(2,'0') + ' remaining' + (next.liveBusy ? '\\nImporting Live TV…' : ''));
}
async function refresh() {
 if (closed || !token) return;
 try { paint(await api('/api/state')); }
 catch(error) { if(!token) { status(error.message); return; } disconnect('Connection closed or unavailable. Enable Phone Setup on the TV and reconnect.'); return; }
 if (!closed && token) timer = setTimeout(refresh, 4000);
}
async function connect() {
 try {
   const next = await api('/api/state'); paint(next);
   byId('pair').classList.add('hidden'); byId('setup').classList.remove('hidden');
   clearTimeout(timer); timer = setTimeout(refresh,4000);
 } catch(error) { status(error.message); byId('pair').classList.remove('hidden'); }
}
async function perform(action) {
 if (busy || closed) return; busy = true;
 document.querySelectorAll('button').forEach(element => { element.disabled = true; });
 try { const result = await action(); if (result) status(result.message || 'Saved.'); }
 catch(error) { status(error.message); }
 finally { busy = false; if (!closed) { document.querySelectorAll('button').forEach(element => { element.disabled = false; }); if(state && state.backupBusy) {byId('backupButton').disabled=true;byId('restoreButton').disabled=true;} } }
}
byId('pairButton').addEventListener('click', () => perform(async () => { const result = await api('/api/pair',{pin:byId('pin').value.trim()}); token=result.token; byId('pin').value=''; await connect(); }));
byId('fields').addEventListener('submit', event => event.preventDefault());
byId('saveButton').addEventListener('click', () => perform(async () => {
 const values={}, clear=[]; state.fields.forEach(field => { if(byId('clear-'+field.key).checked) clear.push(field.key); else if(byId(field.key).value.trim()) values[field.key]=byId(field.key).value; });
 const result = await api('/api/settings',{values,clear});
 state.fields.forEach(field => { byId(field.key).value='';byId(field.key).disabled=false;byId('clear-'+field.key).checked=false; });
 paint(await api('/api/state')); return result;
}));
byId('restoreButton').addEventListener('click', () => { if(confirm('Restore this Apple TV from the pasted code? This applies the saved profile.')) perform(async () => { const result=await api('/api/restore',{code:byId('restore').value.trim()}); byId('restore').value='';paint(await api('/api/state'));return result; }); });
byId('backupButton').addEventListener('click', () => perform(async () => { const result=await api('/api/backup',{});paint(await api('/api/state'));return result; }));
byId('addonButton').addEventListener('click', () => perform(async () => { const result=await api('/api/addon',{url:byId('manifest').value.trim()});byId('manifest').value='';return result; }));
byId('refreshLiveButton').addEventListener('click', () => perform(() => api('/api/live',{})));
byId('copyButton').addEventListener('click', () => perform(async () => {
 if(!state || !state.restoreCode) throw Error('Create a backup first.');
 // HTTP on a private LAN may not expose the Clipboard API. Keep a native selection fallback.
 if(navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(state.restoreCode);
 else { const input=document.createElement('textarea'); input.value=state.restoreCode;document.body.appendChild(input);input.focus();input.select();input.setSelectionRange(0,input.value.length);const copied=document.execCommand('copy');input.remove();if(!copied)throw Error('Select and copy the code shown above.'); }
 return {message:'Restore code copied.'};
}));
byId('stopButton').addEventListener('click', () => perform(async () => { await api('/api/stop',{});disconnect('Setup finished. Connection closed.'); }));
window.addEventListener('pagehide', () => { disconnect('Page closed. Scan the TV QR code again to reconnect.'); });
if(token) connect(); else { byId('pair').classList.remove('hidden'); status('Enter the pairing code shown on your TV.'); }
})();
</script></body></html>
"""
}
