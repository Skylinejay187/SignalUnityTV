# Signal F66 — build 1175

Patch forward from the verified current F65/build1174 ZIP (Library version 30, SHA256 59f1e6bc03e459c55c9831f1887a7269ab47b90f8fc6364e011984cd05697f1e).

## Root cause and repair

The normal VOD overlay deliberately suppresses published SwiftUI timeline snapshots when controls hide. The new F64/F65 episode-experience evaluator was attached to `onChange(currentSeconds)`, so recap/credit checks and Still Watching accounting could lose their normal tick while the underlying Aether clock kept playing. A single visible popup did not prove that the hidden-control path kept evaluating.

F66 calls a bounded episode-control processor from the existing owned decoder clock callback, immediately after `PlaybackController.ingestClock`. It reads the existing authoritative clock, with at most two evaluations per second. It does not enable hidden overlay snapshots, assign a second UI clock, start another player, add a timer, or redraw the whole interface per decoder frame. Recap presentation state publishes only on entry/exit/consumption or a genuinely changed segment result. The visible timeline retains the same processor as a fallback for its existing clock path. Existing Up Next timing, natural-EOF handoff and protection logic remain unchanged.

Lookup state resets per presentation/episode. Request-owned deferred cleanup prevents an old/cancelled lookup from clearing a newer request or leaving its own finished task latched. Current playback metadata can supply identifiers that were absent at the original source selection. The lookup key includes the title identities, exact season/episode, runtime bucket and provider switches.

TheIntroDB now accepts a supported TVDB or TMDb identity when IMDb is absent, rather than being excluded by the IMDb-only guard shared with other providers. Existing Stremio S/E video IDs are recognized when explicit coordinates are missing. An identified TV series without episode coordinates is not queried as a movie. Provider results arrive progressively: a slow/offline provider no longer withholds another provider's validated recap or intro until all requests finish. Existing request timeouts, provider switches, release-duration checks and bounded retries remain.

## What the diagnostics show

VOD player Settings → Episode behavior & metadata → **This playback • skip status** displays the current episode, recap availability/current window, Auto Recap mode, and this lookup's individual provider results. It distinguishes missing identity, unavailable provider, no validated recap and a provider explicitly marking the episode as having no recap. It does not display media URLs, credentials or API keys.

The Metadata & scrolling section now shows actual cache-hit/network/shared-request counts and memory entries/active/queued requests. **Refresh cache activity** takes a fresh snapshot; there is no polling timer. Counts are process-local diagnostics, not invented frame-rate measurements. Metadata response caching and episode timing use separate actors and networking paths. A missing recap does not disable catalog/Search metadata caching. The existing memory/disk/concurrency budgets and artwork cache remain unchanged.

Skip Recap still requires valid timings or an explicitly named recap chapter. Not every episode has a recap or contributed data, and release differences can invalidate timings. Automatic recap mode skips a validated window automatically; a manual popup may therefore not remain visible. No story intervals are guessed.

## Validation

F66 source checks inspect the actual current decoder callback → throttled processor → episode evaluator → precise skip route and confirm that quiet overlay publication remains enabled. Historical regression checks reconstruct only exact reviewed prior source for their historical assertions. The F66 audit independently checks current source and unchanged files.

Mac preflight includes executable tests against the actual mounted clock-processing method, actual clock gate, parser/recap policy and provider service using local URLProtocol responses: hidden-control window entry/exit, throttling, inactive/stale owners, alternate IDs, consecutive episode identities, immediate fast-provider delivery and cache reuse. Existing actual metadata cache coalescing/concurrency/disk/cancellation tests remain, with assertions for the new hit/request counters.

No Swift compiler, Xcode, Apple SDK or Apple TV is available in this environment. Native executable tests, SDK/application compilation and device playback testing have NOT run here. Grammar/source checks are not runtime verification. See F66_VALIDATION.json for checks actually run.

## Apple TV checks

1. Build with the existing source-ZIP workflow. With Automatic Recaps off, start a known episode with verified recap timings, let controls disappear, and verify the prompt appears during the actual recap window. Press Select once and verify a single precise seek. Repeat with another episode/show without force-closing Signal.
2. Enable Automatic Recaps. Let controls disappear before a known recap; verify the player skips it without needing pause/play or opening controls. Check the same hidden-control path for the selected credits mode and Still Watching accounting.
3. Open episode settings for a show with no popup. Check the actual per-episode status: missing identity, no contributed timings, release mismatch/unavailable provider, or recap already past. Report the title, season/episode and status if a known supported window is missed.
4. Test a TVDB/TMDb-only title; verify TheIntroDB is queried while IMDb-only providers explain their missing identity. Test seek, app background/return and back-to-back episodes: retired results cannot change the active presentation.
5. Browse catalog/Search/detail, revisit the same entries, and refresh cache activity. Hits should increase on reused valid responses; network count increases for misses/revalidations. Assess scrolling frame pacing separately on Apple TV.

Primary provider identity/response references: https://theintrodb.github.io/theintrodb-npm/functions.html and https://theintrodb.github.io/theintrodb-npm/types.html .
