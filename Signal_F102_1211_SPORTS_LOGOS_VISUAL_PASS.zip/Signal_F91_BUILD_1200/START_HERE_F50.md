# Signal F50 — build 1159

Forward from F49/build 1158. This changes the Live TV card motion policy and its Settings explanation, preserving the F49 health-client build correction and all MediaFlow routing behavior.

## Stronger preview raise

Standard now uses a 1.025 focus scale and three-point upward lift. Pop Out uses a 1.09 scale and eight-point upward lift once the focused live preview is actually ready. Previously Standard used 1.018/two points and Pop Out used 1.03/two points, which made their difference hard to see.

The transition remains 140 ms ease-out on focus and 180 ms ease-out on preview Pop Out. Original and Aligned share this policy. The existing two-second reveal gate, first-frame readiness, decoder lifecycle, preview stop/cancellation and twelve-card navigation lattice are unchanged. Only the visible foreground transform grows; card slots and remote targets do not move. A raised card may cover some of its gutter as a foreground card, and the horizontal overhang remains inside the existing screen inset at supported 1280–1920 logical widths, including Large size.

Reduce Motion still removes the scale/lift. The edit adds no timer, spring, blur, shadow, new decoder, polling or per-frame state. Native video remains flat. Full-grid customization preview from F48 and F49's full-health-client compiler check remain in the package.

## How the existing safety lock works

The default-on Require MediaFlow for VOD lock applies at home and away. It does not detect your location or another person's account activity. It requires every VOD link to use the active MediaFlow route, covering opaque addon/CDN links and all VOD providers rather than attempting to classify each debrid service's sharing rules.

- Both MediaFlow switches off: direct VOD start is rejected, and the app sets its safety-lock status/error message explaining that MediaFlow must be enabled.
- Missing/invalid URL or password: the route is rejected with a configuration error.
- Proxy reachable and correctly configured: playback is routed through the configured proxy, including source fallback; it does not switch to the Apple TV's direct route.
- Proxy unreachable, wrong password or transport failure: the proxied request/playback fails and can show a connection/playback error. It is never retried directly as a fallback. A connection test checks authentication/status; the route wrapper is the protection even when the proxy becomes unreachable afterward.
- Expected proxy public IP entered: protected requests remain blocked until the current server/password/profile/expected-IP combination passes verification. Failed checks, profile/configuration changes or background entry revoke the process-only proof; the existing lifecycle initiates re-verification.

The current messages use the existing source/status/player error surfaces, not a new dedicated confirmation dialog. Blocking playback does not delete saved links. Switching the independent safety lock off explicitly removes this protection; merely switching Full/Light off does not disable the lock. The preference is already covered by app-wide backup, while current verification proof is never restored from a backup.

This controls this app only. It cannot detect or restrict another application, guarantee a proxy's outbound network configuration, instantly detect every server egress change during an active stream, or guarantee an account against restrictions. All devices must actually use the intended common route for a common egress. Ordinary Live TV retains its existing routing policy; recognized RD hosts cannot bypass the lock by being labeled Live TV.

## Validation

Local source checks passed for F50 and historical F49/F48/F47/F46/F43, changed Swift grammar, screen-edge motion bounds, build identity tests, Python, shell and YAML. F50's source guard requires the complete LiveTVScreen, VOD player, Search and customization screen to match F49 exactly, and restricts the app-file delta to the new lift argument and Settings wording. All safety/router/store/health and engine files remain byte-identical to F49. The existing native F48 motion assertions now check the stronger values and unfocused/Reduce Motion cases; F49's complete real health-client compiler/negative-control check remains mandatory in the macOS preflight.

Not run here: native Swift executables, complete Xcode/tvOS build, Apple TV focus/visual acceptance or CPU/GPU profiling. This environment has no Swift compiler or Apple SDK. See F50_VALIDATION.json for executed checks. Verify on Apple TV with Standard/Pop Out, original/aligned effects, all card sizes, first/last columns, rapid focus moves and Reduce Motion.
