# Signal F70 / build 1179 — automatic VOD continuation after seek

Based on verified F69/build1178 source ZIP SHA256 75553107984f95eafc396c39090d40fe507a37cf7b4165443a93c06916bdcb36. Focused change to the two mirrored Aether bridge sources plus tests/build preparation. No app UI, source-selection, MediaFlow policy, amplification policy, live routing, or cache-size policy changes.

## Change

After the winning VOD seek returns, Signal now reconciles the latest requested transport state on the existing engine. A seek previously awaited Aether and cleared its task without issuing any post-seek transport command; if Aether/native playback landed parked, SwiftUI's unchanged shouldPlay value sent no new Play. The new handoff issues Play for current playing intent or Pause for current paused intent. It does not reload the URL, rebuild the decoder, restart from the beginning, or perform an artificial pause/play toggle.

Readiness and seek-state publisher events, foreground return, and configuration reconciliation can finish a deferred handoff. The request is consumed before engine calls, so these events cannot send repeated Play commands. Existing generation/engine/seek identities reject cancelled or superseded seeks. Protection/scene gates remain authoritative. Errors, natural EOF, live playback, and a manually parked end frame cannot be resumed by this handoff.

After applying transport, actual contiguous cache coverage is refreshed at the new playhead; a seek into a hole never fabricates downloaded data. The existing growing-cache refresh remains unchanged.

## Cache reality and limits

Reviewed pinned AetherEngine 7.44.0 source: Video/SegmentCache.swift stores native fMP4 segments as files under a session-specific temporary directory. Native/SoftwarePacketReadAhead.swift serves compressed packets from a bounded disk FIFO; retained hits move the consumer cursor and misses reposition the source reader. Signal passes nativeRemoteHLS only for live sources and supplies VOD forwardBufferSegments. These are real disk caches, not a completed download of the entire title or a promise that every future position is resident. Cached seeks still require a usable keyframe, demux/decode and renderer preroll. Uncached seeks require source/network delivery. A paused transport requiring a manual pause/play is a separate handoff fault addressed here.

This source change does not establish measured seek latency or prove a particular device/source cache hit. No changes to Aether's cache storage or network timeout policy were made.

## Validation

See F70_VALIDATION.json for local source/grammar/build-identity results. Actual bridge methods are extracted into a controllable-await Swift fixture covering resident/miss scenarios, latest pause/play intent, supersession, replaced sessions, deferred proof/background/readiness gates, end parks/live/terminal exclusion, finite inputs and one-shot transport. This is transport orchestration, not a disk/AVPlayer test. It is wired into normal macOS build preparation before engine downloads.

No local Swift compiler, Apple SDK, Xcode or Apple TV is available. Native fixture execution, full Xcode compilation, actual remote/cache IO, visual seeking and device performance remain unverified. Grammar checking is not type checking.

## Apple TV acceptance

On one VOD session, seek repeatedly within the displayed cached range, beyond it, and backward into retained content. Playback should continue automatically after source/preroll readiness without manual pause/play. Seek while paused and press Pause during an uncached seek: the landing must remain paused. Start two quick seeks, exit playback during a seek, then test return from background. The old seek must never resume a new session. Seek near the end without restarting at zero or triggering a duplicate next-episode handoff. Test both native and software-decoded sources with a local file and a remote debrid link. Capture engine seek/cache/transport logs if a stall remains.
