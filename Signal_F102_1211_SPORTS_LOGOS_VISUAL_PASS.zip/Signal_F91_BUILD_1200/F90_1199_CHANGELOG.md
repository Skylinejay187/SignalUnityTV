# F90 Build 1199 — F89 source base

## Search logic only; UI unchanged
- Search configured Stremio catalog add-ons in parallel with built-in database, Cinemeta and TMDB providers.
- Show cached results immediately but refresh providers rather than stopping on a cache hit.
- Preserve existing progressive result merge, identity deduplication, cancellation, focus and UI.

## Sports verified content cleanup
- Do not generate fallback fake highlight, upcoming event or today's-game cards.
- Remove static placeholder Sports News and Highlights rails; show Highlights only when feed returns results.
- Show Live & Upcoming only when feed-backed data exists.
- Keep user-configured sports channels, live feed events, favorites, and removal controls.

## Verification
- Swift frontend parsing passed for modified source files.
- No full tvOS/Xcode build or device runtime validation performed.
