# Signal F47 — build 1156

Based on F46 / build 1155. Use the existing universal source-ZIP tvOS build workflow. App, Top Shelf, project metadata, dedicated workflow, and evidence label identify Signal-F47 / 1.0.1156 / build 1156.

## In-player TV and Search

The VOD Home chip is replaced by TV. Movies and TV Shows remain, and Search is added to both VOD and Live TV playback controls. Live TV retains its existing Quick Guide control rather than adding a duplicate TV control.

TV in VOD opens a top guide using the existing category strip, five-channel artwork window, current/next guide data and selection routing, inside the shared translucent black Quick Guide surface. It reads saved channel/guide snapshots; opening it creates no preview decoder, performs no lineup/guide network refresh, and does not pause, seek, stop or recreate the current player. Select or Play/Pause on a channel intentionally uses the existing startPlayback handoff. Back closes the panel and restores the TV chip. The existing 10-second Quick Guide inactivity dismissal also applies. No saved lineup produces a clear empty state, not demo channels.

Category/channel browse arrays are prepared when the guide opens, the category changes, or a favorite/Sports action changes its contents. Left/Right navigation reads the cached array and five-item window; it does not repeatedly filter the full provider lineup or rebuild category names.

Search opens through the same existing in-player browsing scope as Movies/TV Shows. The player continues underneath. The global exclusive-playback gate is never released: only the foreground Search request/detail interaction gets an explicit exception, and hidden catalog refresh, decorative prefetch, and preview work remain suspended. Closing Search cancels its request owners and restores the Search control/player canvas. Details use the existing playback-browse Media Information surface; Back restores Search results before returning to playback.

## Unity Search row

This build implements the requested catalog-row alternative, so the older source ZIP is not needed for this version. Removed the separate Search result-grid/card renderer. Main Search is a transparent branch over the retained Live TV dashboard, and results use the real GridOSFixedSlotCatalogRail with its card artwork, focus, selected-item behavior and bounded visible slots.

The search field owns focus on opening. Submit/Down enters results; Up returns to the field. All, Movies, TV Shows and Live TV filters share one result row. Results arriving asynchronously cannot take focus away from the field or filter controls. The remembered result identity is ordinary state, separate from native focus ownership.

One 250-millisecond debounced generation owns the search. Cached local matches publish before bounded remote search results. Channel matching and local catalog matching run off MainActor, cancellation propagates to their workers, and late generations cannot publish over a newer query. Live result card metadata is cached once per query, not rebuilt during every focus change. Unconfigured/demo streams are excluded from channel search, and live selections route directly to playback rather than VOD Find Links. In-player Search disables decorative metadata/artwork prefetch and starts no card-preview video.

## Sports and dashboard retirement

Sports now composites over the same retained Live TV root as Movies/TV Shows. Removed its independent full-screen artwork/background renderer, including the 3840-pixel backdrop path. Sports retains its existing rows, data sources, selection and direct-live tuning; its foreground work and the covered Live TV work remain separately gated.

The Golden/Classic Live TV dashboard selector, mode enum, alternate primary grid rendering branch and old Tools layer are removed from the active view tree. The existing Preview Mirror dashboard is the single dashboard, including the fixed twelve-card grid and subtle focus pop from F46. Saved older dashboard values migrate to Preview Mirror; the legacy settings key remains in backups for compatibility, and old backups cannot restore the retired view. VOD catalog layout choices, card themes, typography and other appearance preferences remain separate features.

## Preservation and validation

Up Next preparation, EOF bookkeeping/retries/countdown/dismissal/commit, seek behavior, and owned playback teardown functions match F46 exactly. Aether engine/bridge/cache-frontier patches and the other 125 prior Swift files are unchanged. App-wide settings and secure service/profile backup code remain; the retired dashboard key is explicitly canonicalized in backup snapshots.

Local checks passed: historical F31–F46 reviewed-delta regressions, current F47 ownership/scope contracts, all preference-key coverage, build identity tests, prior resource/geometry math, remote-thumbnail safety gate, changed Swift grammar, Python, shell and YAML checks. Final focus/cached-guide changes were rechecked against current F47 contracts, exact F46 scope projection, and F43 resource ownership locks.

Native F47 tests compile the actual production player control enum/order and destination enum, exercise the foreground-search permission truth table, and check legacy-dashboard migration/idempotence without changing other preferences. They are mandatory in the macOS preflight, alongside F45's explicit-self compiler check and existing native tests.

Not run here: those native Swift executables, full Xcode/tvOS compilation, Apple TV remote/keyboard focus behavior, real playback continuity, or measured CPU/GPU/RAM profiling. This environment has no Swift compiler or Apple SDK. No device-performance improvement or glitch-free runtime result is claimed solely from the source checks.

Device acceptance should cover playing and paused VOD: TV open/navigate/Back, intentional channel selection, Search typing/voice input/filters/Details/Back, rapid query changes, Search dismissal/source switch/background return, Live TV Search with timeshift intact, Sports -> Search -> Sports/Live continuity, old-backup dashboard migration, and existing Up Next/seek/cache controls.
