# Signal F68 — build 1177

Patch forward from verified F67/build1176 (version32; SHA256 a6bffa8a9fca1290b20038f7abaeb57987a6c208462f7e663c10ba02112d5d57).

## Paused information

The delayed top-left display now contains PAUSED, the movie/show title artwork, the episode label/title where available, and Ends at. Plot/synopsis text is neither passed into this display nor rendered. The main title uses the same Artwork4HeroLogoLayer and themedLogoURL as catalog/VOD titles, including the existing title fallback when no logo URL is available. The series title is normalized separately from the episode label. PAUSED follows the selected VOD overlay accent. No new logo service, artwork animation or player is introduced.

The existing three-second reveal, fade-in/resume fade-out, noninteractive focus behavior, lease/cancellation and 30-second paused end-time clock are retained.

## Recap timing

A validated manual recap prompt can appear up to one second before its start. The automatic seek still requires the actual verified start; the prompt lead is never applied to automatic skipping. Segment lookup begins on the first stable frame, and a ready provider result immediately reevaluates the existing episode processor. Near a known recap the gate accepts the existing engine samples at a 0.15-second minimum interval rather than the normal 0.5-second interval. Aether's existing roughly 3 Hz clock coalescing is unchanged. No high-rate UI timeline, extra timer or guessed timing offset is added.

Provider coverage, release accuracy and lookup latency still matter. A recap at the very beginning cannot be presented before its timings are known. Offsets are not invented to hide missing/late provider data.

## EPG scrolling metadata

Guide listings already have their own provider/disk retention. The catalog JSON response cache is not used to cache XMLTV or delay Refresh Guide. F68 adds bounded in-memory reuse of resolved program rows (192 channel keys) and timeline metadata/layout (96 channel/axis keys). Repeated focus/redraws reuse the same program lookup, by-ID map and normalized slots; the time marker and focused on-air highlight continue to use the current clock.

Keys include channel identity and timeline start/width. Channel changes, guide replacement, Quick Guide metadata changes and retained-session revisions invalidate derived rows. Current/next program timing keeps its existing boundary logic. Width/rail changes reproject onto the correct axis. These caches are cleared when entering full-screen playback, VOD or leaving the surface. No network calls, timers, decoded images, observed state publications or disk writes are performed by a cache hit.

The existing metadata-cache switch now includes Guide reuse. Disabling it bypasses the new Guide caches; Clear metadata cache lazily invalidates retained Guide models on their next metadata access. Authoritative listings remain intact. Catalog JSON memory/disk limits remain unchanged; the new Guide reference/projection caches have separate entry bounds. Catalog activity counters still measure the JSON cache, not Guide hits or FPS.

## Validation and limits

Current F68 source checks verify actual title renderer wiring, absence of synopsis, manual lead versus exact automatic start, adaptive clock entry, cache use from the EPG row, and every invalidation/toggle/clear path. Historical audits reconstruct only exact reviewed prior source for their historical locks; F68 has a separate current-source audit.

Native fixtures exercise the actual generic cache, axis projection and the actual extracted model methods for repeated scrolling/focus reuse, resizing, fresh listings, retained-session changes, Clear and disable. The native EPG test is now in the normal build's dependency-preparation path, before engine downloads. Existing SDK pause mapping uses the actual updated mapping/title builder with an artwork renderer type stand-in. Existing episode/cache native tests also include prompt-lead versus exact-auto-start assertions.

No Swift compiler, Xcode, Apple SDK or Apple TV is available here. Native executable/SDK/application tests and device performance/visual verification have NOT run here. Source/grammar checks do not establish runtime performance. See F68_VALIDATION.json for checks actually run.

Apple TV checks: pause a movie and episode for three seconds, confirm branded title/episode/end time with no plot, then resume to check the fade. Test a known recap with automatic skipping off and on while controls hide. Scroll Guide repeatedly, collapse/expand its rail, refresh listings, then disable/re-enable/clear metadata caching and verify current/future listings remain correct. Measure scrolling frame pacing separately on device.
