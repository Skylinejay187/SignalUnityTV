"""Source/geometry regression contract for vBRDC398R11. No tvOS runtime claims."""
from pathlib import Path
import math, re, plistlib
root = Path(__file__).resolve().parents[1]
src = (root/'Sources/DebridChannelsTVOSApp.swift').read_text()
# Exact annotated artwork, plus-or-minus-three-pixel measurements.
left_height=[185,181,169,157,137]
left_edge=[98,201,288,370,416]
right_height=[185,180,173,161,134,119]
right_edge=[85,174,252,327,374,408]
for nums in (left_height,left_edge,right_height,right_edge):
    assert '[' + ', '.join(str(n) for n in nums) + ']' in src
assert 'let focusWidth = 360 * scale' in src
assert 'let focusHeight = 217 * scale' in src
assert 'let sideBaseline = focusBottom - 12 * scale' in src
assert 'let reflectionHeight = 40 * scale' in src
assert 'coverFlowPerspective: true' in src
assert 'coverFlowPerspective ? 1.5 : 10' in src
assert src.count('private var coverFlowRail: some View') == 1
assert src.count('private func classicReflection(') == 1
assert 'dexterMirror(selectedItem' in src
assert 'dexterMirror(item' in src
assert src.count('focusedPreviewURL : nil') >= 1
# Geometry matches annotated reference, including hidden poster parts and asymmetric sides.
focus_center=773.0
focus_w=360.0
focus_left=focus_center-focus_w/2
focus_right=focus_center+focus_w/2
assert abs(focus_left-593)<1 and abs(focus_right-953)<1
last_x = float('inf')
for height,edge in zip(left_height,left_edge):
    left = focus_left - edge
    right = left + height*2/3
    assert left < last_x
    assert right > left
    last_x = left
assert abs((focus_left-left_edge[0]) + left_height[0]*2/3 - focus_left - 25.3) < 1
last_right=-float('inf')
for height,edge in zip(right_height,right_edge):
    right=focus_right + edge
    left=right-height*2/3
    assert right > last_right
    assert right > left
    last_right = right
# One catalog identity per fan; even counts reserve the extra left slot.
for count in range(1, 24):
    visible=[]
    for d in range(-5,7):
        if d==0: continue
        maxd = count//2 if d<0 else (count-1)//2
        if abs(d) <= maxd:
            visible.append((d % count))
    assert len(visible)==len(set(visible)), (count,visible)
# Focused card is only instantiated once by the Cover Flow code.
cover = src[src.index('    private var coverFlowRail: some View'):src.index('    // Classic layout remains unchanged.')]
assert cover.count('FixedSlotFocusedCatalogCard(')==1
assert 'FocusedCardPreviewSurface(' not in cover
assert 'scaleEffect(x: 1, y: -1)' not in src[src.index('private func dexterSideArt'):src.index('private func dexterMirror')]
for name in ['Sources/Info.plist','TopShelfExtension/Info.plist']:
    plist=plistlib.load((root/name).open('rb'))
    assert plist['CFBundleShortVersionString']=='1.0.1112'
    assert plist['CFBundleVersion']=='1112'
    assert plist['DebridChannelsReleaseID']=='vBRDC398R11'
print('PASS: source geometry, reflect/focus isolation, circular indices, metadata sync')
