# Signal F48 — build 1157

Built forward from F47/build 1156. Source release; no local Xcode or Apple TV execution is claimed. AetherEngine remains 7.44.0 and Kingfisher remains pinned to 8.11.0.

## Independent Real-Debrid safety lock

Settings → MediaFlow Proxy now includes **Require MediaFlow for VOD — Real-Debrid Safety Lock**, enabled by default on new and existing installations unless explicitly switched off. Turning either MediaFlow routing switch off does not disable this independent restriction. All VOD must use a configured MediaFlow route at home and away. There is no Wi-Fi-name, private-subnet or saved-IP exemption: those cannot prove which public address another device is using. Opaque addon and CDN links are covered by applying the restriction to all VOD, including non-Real-Debrid VOD. Ordinary Live TV retains its previous routing; recognizable Real-Debrid hosts cannot bypass the lock by being labeled Live TV.

The guard rejects an unsafe launch before changing presentation identity, current playback or the decoder. Final media URLs, source availability checks, resolver API forwarding and external-player handoffs use the guarded router. Native Real-Debrid account health checks also honor it. Alternate URLs still pass through the same player router. Turning routing off cannot silently return the original direct VOD URL. An unavailable proxy leaves playback pointed at the proxy; it never triggers a direct-device fallback.

If an expected public IP is entered in the active Full/Light profile, protected playback/API routes stay blocked until the current server URL, password, active profile and expected IP pass the connection test. The existing launch, Settings, foreground and idle verification paths perform this check; Test Connection can also be used. Verification failures revoke permission. Configuration changes and background entry clear the process-only proof. Saved status and restored backups do not authorize playback. A blocked IP check requires verification/retry rather than silently proceeding.

Already-wrapped URL recognition now compares scheme, hostname, effective port and the exact configured path prefix plus recognized proxy endpoint. A different port or unrelated path on the same host no longer bypasses wrapping. Original/full and Light settings remain separate. Existing Light limitations on forwarding non-GET/HEAD mutations remain fail-closed.

The lock preference is included in the app-wide portable backup with its default. Existing MediaFlow passwords remain in the protected credential vault, and live verification proof is never backed up. Restoring an old backup does not create a verification proof.

This app cannot reliably detect every other client streaming from a Real-Debrid account, enforce another app's settings, validate a proxy server's entire network configuration, or guarantee that an account cannot be restricted. For one common egress, all clients using the account must use the intended proxy/route; a client outside this app can still use another address. If direct home-only VOD is intentionally desired, the separate safety lock can be explicitly switched off, which removes its protection. No account credentials or real stream URLs are used in the new tests.

MediaFlow's documented `/proxy/forward` relays API requests from the proxy server, and `/proxy/ip` reports its outbound IP: https://github.com/mhdzumair/mediaflow-proxy/blob/main/docs/usage/forward.md . The app uses the existing endpoints, not a guessed account-session detector.

## Aligned focus pop and full-card preview

Original and aligned layouts use the same small compositor focus scale (1.018) and two-point lift, with 140 ms ease-out; preview Pop Out retains its bounded 1.03 scale. Navigation may disable broad layout animation, but the motion host now permits its own explicit focus animation. The card content still clears inherited animation so artwork, text and decoder surfaces do not acquire a second animation. Reduce Motion removes the focus movement. There is no new timer, spring, blur, display loop or decoder.

The full-screen customization preview applies the selected style pose and surface depth to every mounted card. Only the first card owns the sample focus ring; the other cards no longer need fake focus to display their selected theme. The existing twelve-card, four-column/three-row grid, real channel artwork and typography remain. The smaller dashboard confirmation renderer uses the same all-card pose behavior. Aligned styles now retain the full selected original style angles in every row; their X/Y lattice offsets remain zero. Card contour, size, perspective and layout are not stretched or fitted. The existing paired-pose native check was updated to compare the full selected pose, and the new F48 tests cover every effect/column pair.

## Validation

Local source/grammar checks, historical reviewed-delta regressions, current safety guards, backup-key coverage, build identity tests, Python, shell and YAML checks passed. Current Search and the complete VOD player implementation, including TV guide, Up Next/autoplay/dismissal, seeking and cache controls, remain byte-identical to F47. Engine/bridge sources are unchanged.

The mandatory macOS preflight now compiles the actual production router (with fake credential dependencies), runs it against a local HTTP proxy fixture, and exercises disabled-proxy blocking, known RD hosts, explicit opt-out, Full/Light identity, expected-IP success/mismatch/revocation, offline proxy wrapping, forwarding method/body preservation, exact proxy origin/path handling, default/saved backup values and original/aligned card pose/motion policy. No real account is contacted. Prior native compiler/engine checks remain in place.

Not run locally: native Swift executables, complete tvOS/Xcode build, actual proxy connectivity, Apple TV remote focus/visual acceptance or measured CPU/GPU/RAM performance. This environment has no Swift compiler or Apple SDK. See F48_VALIDATION.json for executed checks and limits.

Device acceptance: with the lock on, try Full/Light off, missing URL/password, unreachable proxy, expected-IP mismatch, valid connection, foreground return, source fallback, external-player handoff, Up Next, and backup restore. Verify direct VOD never starts in blocked cases and the error explains why. In customization, cycle each effect/shape through Original and Aligned, inspect all rows, apply it, and test rapid focus navigation plus Reduce Motion. Confirm Search/TV overlays and existing Live TV/Up Next behavior remain intact.
