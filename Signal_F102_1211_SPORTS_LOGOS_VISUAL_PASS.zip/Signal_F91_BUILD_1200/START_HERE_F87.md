# Signal F87 — Build 1196

Patch forward from the complete F86/build1195 source. Source ZIP for the existing workflow; no IPA or native build success is claimed locally.

## Unity composition

Sports already used the persistent Live TV root and a clear Sports backdrop. Catalogs used the same root, but their full-screen backdrop covered its header; Artwork 3 stacked a 72–80% dark base beneath another strong black/side gradient. This was a compositing difference, not a different capability or need to recreate the dashboard.

Home/Movies/Shows now mask their theme backdrop clear over the existing shared header, fading its shading in below it. Their artwork, hero logos, card themes, row motion, focus, Cover Flow and reflections remain. Artwork 3 uses the new shared static dashboard shade with a much lighter base so the actual grid remains visible. Other artwork themes keep their image/depth/color treatment below the header. RootView, LiveTVScreen and top navigation are unchanged.

Settings → Sports → Sports background offers **Dimmed Dashboard** (default), **Artwork 3 Hero**, and **Clear Dashboard**. The first two shade the retained dashboard while preserving its header. This is static gradient compositing: no image copy, timer, blur, animation timeline, duplicate grid or new background workload. The preference is registered in app-wide portable Backup & Restore.

## Sports playback

The old iSportsurge test player owned a separate Aether host, local Play/Pause state and a simple independent control panel. F87 removes that decoder/control path. Its cover now resolves the event on the viewer's device, validates membership/session/scene/cancellation, and calls the same CatalogStore.startPlayback entry used by Live TV with a live MediaItem and the exact resolved URL/HTTP headers. The standard root then mounts the existing player. There is one decoder, one remote-control owner, one standard Live TV overlay and the existing timeshift/cache/seek/Go Live/audio/subtitle/settings implementation. Those controls, transport methods, engine setup, native host and bridge are byte-for-byte unchanged.

Event title, league/status and available source artwork are attached to the shared Live TV overlay and Now Playing metadata. Online events have their own metadata projection; they do not borrow the quick guide's selected IPTV station, its unrelated EPG or Next listing. No artificial event end time is created. If the source supplies no artwork and no uniquely matched scoreboard logo exists, the normal Sports text fallback is used.

Sports signed URLs are resolved for the viewer's network, so the known HTTPS media host families already approved by the resolver remain device-direct for LIVE routing, even with MediaFlow enabled. VOD/debrid safety and all ordinary IPTV proxy routing remain unchanged. This exception never applies to .vod, arbitrary domains, credentials, explicit ports or HTTP URLs. No backend streaming or shared sessions were introduced.

The resolver's exclusive resource claim is released on cancel/failure dismissal, and transferred to the standard root on successful launch; an outgoing cover cannot resume dashboard work under active playback. Only the selected Sports row/item identifiers are retained across the standard player's root unmount to restore selection when returning.

Timeshift uses the existing Live TV settings and the media actually received/cached by Aether. Rewinding outside the available buffer is not promised. Resolver errors still offer Retry/Cancel; after launch, controls and retry behavior are the existing Live TV player's. StreamEast Premium is not part of this change.

## Verification

38 historical/current regression command groups passed and 27 Python unit tests passed, including source mutation guards, new-file history integrity and backup classification negative controls. App membership/build identity, bridge parity, FastZap wiring, geometry/resource audits, Python compilation and shell syntax passed. All changed standalone Swift and emitted native fixtures parse cleanly; the giant app retains only its two baseline tree-sitter min/m artifacts.

The new early native check compiles the real static shade views and live metadata properties, exercises the actual live-routing function with media/spoof/VOD/ordinary IPTV cases, and SDK-typechecks the production UI. The existing F85 native check now typechecks the real resolver-only cover against the store launch API. These native checks remain enabled but **could not run locally**: this environment has no Xcode/Swift compiler/Apple TV runtime. Full tvOS compilation and device playback must still be verified.

On device: test all three Sports background options; Home/Movies/Shows with Artwork 3 and other selected themes; confirm the existing logo/menu/clock/category placement. Open a live event, reveal the normal Live TV OSD, pause/play with chips and remote, rewind after the cache grows, forward/Go Live, Audio/Subtitles/Settings, then close back to the same Sports card. Also cancel while resolving, background the app during resolution, and test with MediaFlow on. Provider availability and the actual timeshift window remain runtime dependencies.
