#!/usr/bin/env python3
"""Portable preflight: fail before Xcode if Signal/Top Shelf versions drift."""
import pathlib, plistlib, re, sys
root = pathlib.Path(__file__).resolve().parent
app = plistlib.loads((root / "Sources/Info.plist").read_bytes())
ext = plistlib.loads((root / "TopShelfExtension/Info.plist").read_bytes())
project = (root / "project.yml").read_text()
expected = {"CFBundleShortVersionString": "MARKETING_VERSION", "CFBundleVersion": "CURRENT_PROJECT_VERSION"}
errors = []
for key, setting in expected.items():
    a, b = str(app.get(key)), str(ext.get(key))
    values = re.findall(r"(?m)^\s*" + setting + r":\s*([0-9.]+)\s*$", project)
    if a != b: errors.append(f"{key}: app={a} TopShelf={b}")
    if not values or any(v != a for v in values): errors.append(f"{setting}: project={values} expected={a}")
if errors:
    print("RELEASE VERSION PREFLIGHT FAILED\n" + "\n".join(errors), file=sys.stderr)
    sys.exit(1)
print(f"PASS: App and Top Shelf version {app['CFBundleShortVersionString']} build {app['CFBundleVersion']}; project.yml matches")
