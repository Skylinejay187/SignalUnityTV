# Signal F33 — build 1141 — accent-aware menus, picker focus and preview containment

Full source patched from F32R2. App, Top Shelf and project identity:
**1.0.1141 / build 1141 / Signal-F33**.

## Menu accent propagation

The selected accent now colors the Liquid Glass selection lens instead of a
hardcoded white pill. Capsule/bar chrome, toolbar backgrounds and independent
button surfaces receive accent-tinted fills rather than fixed black fills.
Pale and dark selection colors choose readable dark or white label ink using
relative sRGB luminance. Accent option resolution also tolerates case and
surrounding whitespace from restored settings. Auto Match Theme still uses the
individual theme's accent. Font, size, destination activation and remote routing
are unchanged.

## 24 layouts, including six revived directions

All 18 existing choices remain. These six have their own renderer and preview:

- Aurora Glass Reborn: glass panels with a curved canopy of light.
- Cinema Marquee Reborn: cinema signplates with an inset row of lights.
- Retro Wave Reborn: slanted arcade tabs with paired horizon stripes.
- Graphite Studio Reborn: split studio controls with inset icon wells.
- Copper Cinema Reborn: engraved labels with diamond brackets.
- Polar Frost Reborn: frosted two-level destination panels with etched labels.

These are new canonical names, so older saved theme migrations remain intact.
No extra timer or continuously animated menu renderer is introduced.

## White picker focus block

The top-menu and background pickers now use the app's established custom
no-platter button style and rounded clipping, rather than plain tvOS buttons.
Their own focus outline and selection check remain visible. This addresses the
large system white focus platter shown over Crystal Slabs in the supplied photo.
The preview thumbnails continue using the real menu renderers.

## Adult Swim preview rendering

The supplied photo appears to show oversized opaque layers around a focused
Live TV preview. This is a rendering correction, not a channel-source change:

- Explicit card-sized geometry bounds both the native Aether surface and its
  preview container, with clipping at both levels.
- SwiftUI brightness/contrast filters are removed from native preview video.
- Card focus shadows are generated from a bounded rounded rectangle behind the
  card, not by sampling the live video/UIKit content.
- Aether engine code, tuning, preview ownership/cancellation, stream URLs,
  focus commands and card tilt/scale calculations remain unchanged.

The exact visual cause cannot be confirmed from a still photo alone. Retest the
same Adult Swim card with focus previews enabled, then move between channels
and let the preview start/stop. Confirm no black rectangles spill across the
header or footer. Full-screen playback should retain its previous behavior.

## Previous changes retained

F32R2 smoke blending, independent saved Blur/Glass Transparency, removal of the
standalone Dynamic Wallpaper/custom URL system, Pure Black, manual VOD cast
browsing with automatic presentation off, and Spotlight clean posters remain.

## Validation

Completed locally: six identity tests; 48 legacy theme migrations; 24 exact menu
renderer branches; original menu navigation and protected playback source hashes;
118 unchanged Live TV interaction functions; 220 unrelated VOD functions;
picker style, accent lens/chrome and bounded preview wiring checks; diagnostic
redaction, seek-thumbnail safety and FastZap wiring; no new Swift grammar errors.

Swift executable tests include contrast on light/dark accents and the new theme
identities in the macOS CI workflow. They have not run in this Linux environment.
Full tvOS Xcode compilation and physical Apple TV visual validation remain
pending. This is complete source, not an IPA or a successful-build claim.
