# Signal F57 — build 1166

Forward from F56/build 1165. Corrects the protection-triggered playback restart loop reported on the Apple TV.

## Correction

F56 still released the active decoder, incremented its reload token, reset resume/seek state and reopened it after every accepted network update. A valid home check therefore restarted playback. That implementation is replaced.

Repeated identical path snapshots now do no work, using NWPath's native Equatable comparison. A changed path still invalidates the proof for new direct requests, but the active home player is paused in place during verification: its URL, headers, reload token, current position and seek state remain unchanged. A verified matching home route updates only the lease metadata and resumes the same decoder according to the user's current Play/Pause intent. It does not unmount the surface, reset the first-frame gate, reissue a resume seek or open another URL.

If the verified route would require a different transport, or verification fails, the old player stops once and waits for an explicit Retry. Further callbacks do not reopen it. Decoder failures arriving during the verification window also use this one-stop path, rather than triggering automatic source failover. Ordinary source failover outside protection verification remains unchanged. A superseded asynchronous verification is discarded/rechecked rather than treated as a playback failure. Foreground and Retry retain their existing session/source ownership guards.

Initial protected playback and new source/API routing still use the F56 verification policy. A remote/unknown cold start cannot fall back directly when no verified home route or usable proxy exists. The saved home anchor remains authenticated, network proofs remain process-only and synced Off switches remain unable to disable protection. This is a client routing guard, not a guarantee against provider restrictions or a network packet firewall.

## Regression protection

The current source check rejects F56's actual previous recheck method as a negative control. It forbids reload-token/start-time/seek changes in the accepted-home path and verifies that a genuine failure reaches an idempotent stop rather than an automatic reopen. It also checks the actual unchanged Aether surface: its load condition depends on URL/reload token, while a Play/Pause change calls the existing pause/play selectors.

The macOS preflight adds tests of the actual deduplication and continuity helpers: repeated equal paths, 100 successful metadata-only home refreshes, stale epochs and changed source/session/headers/proxy routes. The existing F56 actual-router mock-network tests remain, and its tvOS SDK fixture now type-checks the current recheck/stop methods. These native checks are wired but have not run in this environment.

Only the player integration and network-state helper change in production Swift. The other 138 prior Swift files are byte-identical, including the router, engine/bridge, compact Search and settings helpers. Guide fades/red season focus, Up Next, seek/cache behavior, live playback and backups are retained. AetherEngine stays 7.44.0; Kingfisher stays 8.11.0.

## Validation

Local: current no-restart guard with the F56 negative control, all available Python preflight checks, exact reviewed deltas and unchanged-source comparisons, no new Swift grammar errors, syntax checks, six build-identity tests and ZIP/source integrity. See F57_VALIDATION.json.

Not run locally: native Swift helper/router tests, the tvOS SDK type-check, full Xcode compilation or physical Apple TV playback. The environment has no Swift compiler/Apple SDK. In particular, this source release is not claimed to have passed a device restart stress test.

On-device priority: watch a show at home through repeated network callbacks and Up Next preparation; confirm a stable player position with no reloads. Check paused playback and app background/return, then verify that a genuinely unavailable/different route stops once and stays stopped until Retry. Finally check a fresh remote launch still uses the saved proxy or blocks.

API reference checked: https://developer.apple.com/documentation/network/nwpath .
