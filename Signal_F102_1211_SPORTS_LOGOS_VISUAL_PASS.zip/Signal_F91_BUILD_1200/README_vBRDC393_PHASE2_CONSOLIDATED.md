# Signal / DebridChannels vBRDC393 — Phase 2 consolidated source package

**Build metadata:** 1.0.1106 / 1106 / vBRDC393; Apple TV / tvOS, source/GitHub-ready project.
**Status:** Source changes integrated; Swift parser check completed. Xcode device build and Apple TV runtime verification NOT performed in this environment. Do not mistake syntax parsing for successful compile or on-device acceptance.

## All nine Up Next / Auto Next acceptance points (one package)

1. [ ] Identify the next episode with the correct show, season and episode metadata. Existing `fetchSeriesEpisodes`, `nextEpisode(after:from:)` and `playbackMetadata(for:)` paths retained.
2. [ ] Sort episodes numerically and move across season boundaries; `nextEpisode` sorts `(seasonNumber, episodeNumber)`.
3. [ ] Present Up Next near EOF and at natural EOF; existing watchdog/presentation logic retained.
4. [ ] Countdown is 15 seconds, session-owned and cancelable. Guard for lost prepared URLs retained.
5. [ ] Resolve a playable next source in decoder-safe phase, not during active outgoing decode; existing provider/source preparation retained.
6. [ ] Prevent duplicate launches with `upNextPlaybackStarting`, preparation/session ownership, task cancellation.
7. [ ] Missing-source flow remains visible without triggering a nonexistent playback source; EOF retries bounded.
8. [ ] NEW saved Auto Next toggle in **Settings → VOD Internal Player**. Off leaves manual Play Next available.
9. [ ] Verify manual Play, Cancel, natural EOF, and transitions to another season on Apple TV.

## Additional user-requested v393 features

- Local Continue Watching row: preserve one TV-show poster per series and most recent episode checkpoint.
- Trakt-backed TV-show Continue Watching rows: deduplicate multiple episodes for same series in both fast and full account refreshes.
- On Resume/Trakt Continue Watching card, **hold Select** for context menu, choose **Remove from Continue Watching**. This hides the local shelf card; it does not alter Trakt watched history or cross-device cloud progress. This setting persists locally.
- Separate **Delete from Trakt Watch History…** action, requiring explicit confirmation, making an authenticated Trakt request. For TV, deletion requires valid show IDs AND an explicit episode; show-wide deletion is deliberately refused. Network errors should be reported rather than claiming success.
- **Settings → Appearance → Media Information Glass Transparency:** adjustment in 10% increments from 0% to 100%, default 65%, saved via AppStorage. Affects background glass tint and catalog stage dim only; leaves text and controls fully legible.
- Catalog-owned Media Information now adds an isolation backdrop UNDER the catalog rows (not over them) while popup is active, so the persistent Live TV grid cannot ghost through the transparent popup. The existing Unity connector/rail transforms and focus remain retained.
- Preserves v392 Preview Mirror catalog wordmark removal, VOD artwork fixes and existing player architecture. KSPlayer removal is NOT in this phase.

## Apple TV pass/fail checklist

1. Open a multi-season show: Up Next must show exact next episode, including season boundary.
2. Let an episode play through last 120 seconds: Up Next should appear without audio/video stalling.
3. Verify countdown appears only when a playable prepared source is ready; timer resets if it becomes unavailable.
4. Let an eligible episode end: one (not two) next episode launches, with correct title/stream.
5. Test missing next-episode source/provider error: no black player or duplicate playback, usable Cancel.
6. In Settings disable Auto Next, reach EOF, verify ONLY manual Play can start the next episode. Re-enable and retest.
7. Select Play Next manually; cancel from a different episode; verify EOF and last episode of season handling.
8. Produce several unfinished episodes of the same show, refresh Trakt: one parent series poster in local Resume AND Trakt TV Continue Watching row. Confirm latest S/E and position.
9. Hold Select on Resume item, remove locally; verify card disappears after refresh without deleting Trakt history.
10. Hold Select and choose Trakt history deletion, cancel confirmation once; no deletion. Confirm on an item with a valid ID, then verify online Trakt history updates. On failures verify error status.
11. Settings → Appearance: cycle transparency 0, 30, 65, 100. Test after app restart; backgrounds should vary, buttons/cast text must remain readable.
12. With Live TV dashboard underneath catalogs, open Media Information: only active catalog rows should be visible through glass; no dashboard channel cards or duplicate Signal logo. Test popup Back/focus/scroll position and catalog animation.
13. Regression: Live TV, VOD playback, Bluetooth/Now Playing, and artwork from v392 still work.

## Validation

- Swift syntax parse on modified sources: pass.
- Both app and Top Shelf Info.plist parsed and version matched project.yml: pass.
- ZIP archive test: must be run after packaging.
- Full tvOS typechecking, signing, Xcode archive and actual Apple TV runtime test: **not available here**. Remain on v393 for any failures.
