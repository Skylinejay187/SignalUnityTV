# Signal F143 / 1252 — Diagnostic Center Foundation

## Based on
Exactly the supplied F143/1252 `Signal_F143_1252_API_KEY_ROUTING_AUDIT_METADATA_HEALTH.zip` source; no older donor used.

## New Settings surface
**Settings > Diagnostics**: Start/Stop Full Diagnostic Session; Run Local Self-Checks; Export Diagnostic ZIP to Phone / Computer; Close Diagnostic Export.

## Captured in first implementation
- Aether buffer frontier sampled at <=1 Hz, buffering transitions, first-frame / natural-end / live reset / failure notifications (never raw error strings).
- Preview decoder handoff/release events and released-player count; trailer exclusive-player begin/end.
- VOD production metadata request/completion and whether content exists, without title/ID.
- Live TV Guide forced-refresh and quick-guide snapshot counts.
- Trakt watched-history removal requests/success signals.
- TorBox Usenet selected job starts and successful playback handoffs.
- Existing frame-pacing performance trace, supplied to export after stopping session.
- Provider credential-present checks for TMDB/Fanart/OMDb/TVDB without credential values; local available storage; protected network route revocation.
- Only allowlisted event area/action/state and bounded numbers are recorded; no raw URLs, title names or account identities.

## Sharing
The app hosts a one-time, random-token, local-LAN HTTP ZIP download for up to ten minutes. It binds to the detected LAN address, not a publicly advertised backend. It is opt-in and shuts down after one successful transfer or timeout. Users open the address displayed on the TV in their phone/computer browser on the same LAN and can send the resulting ZIP to support themselves. No automatic upload.

## Deliberate limitations
- This is not a live provider end-to-end test and does not guarantee 100% coverage. Source probes are implemented for specified paths, not every function in 125 app Swift files.
- Current in-memory event timeline does not persist through a crash/power loss, and cannot supply Apple system callstacks or GPU Instruments traces. Apple TV crash/analytics logs are still valuable.
- Local LAN HTTP isn't encrypted. Use only a trusted LAN and keep the download URL private.
- First actual Xcode/tvOS build and device download test still required. Swift parser and source preflight are necessary but insufficient to establish hardware behavior.

## Tests run here
- Full bundled Swift syntax parse.
- F143 exact-source/bridge and project membership preflight (135 reviewed paths).
- Diagnostics privacy/export contract script.
- Isolated Swift ZIP assembler smoke test; verified generated archive via `unzip -t`.
- ZIP archive integrity and 25-MB upload-size check on delivered source.
