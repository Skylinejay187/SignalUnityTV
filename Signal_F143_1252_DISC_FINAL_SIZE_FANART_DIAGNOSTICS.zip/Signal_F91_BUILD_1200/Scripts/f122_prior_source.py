"""Validate the current F122 changes before entering an older source lock."""
import hashlib
from regression_manifest_cache import read_manifest

PATHS = {
    'Sources/MediaFlowProxyRouter.swift',
    'Sources/SignalSportsScoreboard.swift',
    'Sources/SportsScoresScheduleProvider.swift',
}

def before_f122(root, path, source):
    if path == 'EnginePatches/AetherEngine+SignalCacheFrontier.swift':
        record = read_manifest(root / 'Tests/F139ApprovedCacheFrontierDelta.json')
        digest = hashlib.sha256(source.encode()).hexdigest()
        if source == (root / path).read_text():
            assert digest == record['after_sha256'], 'Unreviewed F139 cache frontier source'
        if digest == record['after_sha256']:
            source = record['before']
            assert hashlib.sha256(source.encode()).hexdigest() == record['before_sha256']
        return source
    if path not in PATHS:
        return source
    records = read_manifest(root / 'Tests/F122ApprovedSourceDeltas.json')
    assert set(records) == PATHS, 'Unexpected F122 historical exceptions'
    record = records[path]
    digest = hashlib.sha256(source.encode()).hexdigest()
    if source == (root / path).read_text():
        assert digest == record['after_sha256'], 'Unreviewed F122 source: ' + path
        source = record['before']
        assert hashlib.sha256(source.encode()).hexdigest() == record['before_sha256']
    return source
