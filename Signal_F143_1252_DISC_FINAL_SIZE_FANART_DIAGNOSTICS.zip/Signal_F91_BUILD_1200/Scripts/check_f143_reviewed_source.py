#!/usr/bin/env python3
"""Exact F143 current snapshot + non-negotiable playback and source contracts.

Historical F86/F104 baselines remain unmodified; only this reviewed F143
source baseline is selected by the newer build ZIP.
"""
import hashlib, json
from pathlib import Path
from check_app_source_membership import main as check_membership
root=Path(__file__).resolve().parents[1]
check_membership()
records=json.loads((root/'Tests/F143ReviewedSourceHashes.json').read_text())
assert len(records)>=120, 'Incomplete reviewed F143 source manifest'
for name,expected in records.items():
    path=root/name
    assert path.is_file(), f'Missing F143 file: {name}'
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    assert actual==expected, f'Unreviewed F143 mutation: {name}'
app=(root/'Sources/DebridChannelsTVOSApp.swift').read_text()
bridge=(root/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
aux=(root/'Sources/AuxiliaryVideoPlaybackCoordinator.swift').read_text()
for marker in ('struct MediaInfoPopup: View', 'struct VODPlayerScreen: View',
    'struct LiveTVScreen: View', 'struct SportsHubScreen: View',
    'SignalCatalogPreviewPlayerPool', 'artworkFreeMediaProfile',
    'Open Channel in Full Guide'):
    assert marker in app, f'Missing F143 contract: {marker}'
assert 'if Thread.isMainThread { self?.releaseAll() }' in app
assert 'func beginExclusivePlayback(reason: String)' in aux
assert 'options.forwardBufferSegments = Self.vodForwardBufferSegments' in bridge
assert 'startTimeSeconds.isFinite ? max(0, startTimeSeconds) : 0' in bridge
assert (root/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_bytes()==(root/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_bytes()
print('F143 source integrity PASS:',len(records),'exact source files; source membership, exclusive preview, VOD policies and Unity contracts')
