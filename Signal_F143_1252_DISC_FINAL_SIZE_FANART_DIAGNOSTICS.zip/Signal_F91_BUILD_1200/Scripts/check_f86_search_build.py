from f87_approved_deltas import historical_source as pre_f87
"""Current F86 source contracts and exact scope; older locks remain active."""
from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from f86_approved_deltas import historical_source,previous_source
from source_hash_integrity import verify_unchanged_sources
from f122_prior_source import before_f122
ROOT=Path(__file__).resolve().parents[1]
def check():
    records=json.loads((ROOT/'Tests/F86ApprovedSourceDeltas.json').read_text())
    for name,record in records.items():
        source=pre_f87(ROOT/name)
        assert hashlib.sha256(source.encode()).hexdigest()==record['after_sha256'],name
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==record['before_sha256'],name
        try:previous_source(source+'\n// unreviewed mutation\n',name)
        except AssertionError:pass
        else:raise AssertionError('Source mutation accepted: '+name)
    # F103 intentionally rewrites Guide navigation. Validate its exact approved
    # current bytes, then replay historical F86 locks against the preserved,
    # separately hash-verified F87 snapshot (not the modified F103 source).
    guide='Sources/SignalGuideNavigation.swift'
    approved=json.loads((ROOT/'Tests/F103ApprovedGuideNavigationHashes.json').read_text())
    assert set(approved)=={guide}, 'Unexpected F103 source exception'
    assert hashlib.sha256((ROOT/guide).read_bytes()).hexdigest()==approved[guide], 'Unapproved F103 Guide navigation mutation'
    snapshot=ROOT/'Tests/F103HistoricalGuideNavigation.swift'
    assert snapshot.is_file(), 'Missing historical F87 Guide snapshot'
    f87=json.loads((ROOT/'Tests/F87UnchangedSourceHashes.json').read_text())
    assert guide in f87 and hashlib.sha256(snapshot.read_bytes()).hexdigest()==f87[guide], 'Historical F87 Guide snapshot changed'
    def historical_f86_source(path):
        relative=path.relative_to(ROOT).as_posix()
        return pre_f87(snapshot if relative==guide else path)
    # F86 historical baseline remains immutable. Later reviewed source snapshots
    # supersede only their explicitly named paths, never arbitrary drift.
    protected=json.loads((ROOT/'Tests/F86UnchangedSourceHashes.json').read_text())
    later={}
    for manifest in ('F91ApprovedPostF87Hashes.json','F104ApprovedSourceHashes.json','F104AdditionalSourceHashes.json'):
        for name,digest in json.loads((ROOT/'Tests'/manifest).read_text()).items():
            if name in protected: later[name]=digest
    protected.update(later)
    # The historical Guide snapshot is verified separately above; current
    # Guide is pinned by the F104 approved manifest.
    def verified_source(path):
        relative=path.relative_to(ROOT).as_posix()
        if relative in later:
            return before_f122(ROOT, relative, path.read_text())
        return historical_f86_source(path)
    verify_unchanged_sources(ROOT,protected,read_source=verified_source)
    app=pre_f87(ROOT/'Sources/DebridChannelsTVOSApp.swift');old=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
    for marker in ['struct VODPlayerScreen: View','struct LiveTVScreen: View','struct SportsHubScreen: View','struct GridOSFixedSlotCatalogRail: View','struct MediaInfoPopup: View','struct FocusedSidewaysCardEffect:']:
        assert block(app,marker)==block(old,marker),marker
    search=block(app,'struct GlobalSearchScreen: View');prior=block(old,'struct GlobalSearchScreen: View')
    for marker in ['    private func searchResultsGrid(', '    private func restoreSearchGridFocus(', '    private func openSearchResult(']:
        assert block(search,marker)==block(prior,marker),marker
    schedule=block(search,'    private func scheduleUnifiedSearch(')
    assert 'localResults: local) { partial in' in schedule
    for marker in ['token == unifiedSearchToken','scenePhase == .active','searchWorkAllowed','store.selectedDetail == nil','unifiedResults = partial','restoreSearchResultFocus(in: partial)']:
        assert marker in schedule,marker
    store=pre_f87(ROOT/'Sources/CatalogStore.swift');prior=historical_source(ROOT/'Sources/CatalogStore.swift')
    assert 'private(set) var fullScreenPlaybackResourceSuspended: Bool = false' in store
    for marker in ['    private func mergeUnifiedSearchSources(', '    private func mergeUnifiedSearchMetadata(', '    func searchHydratedDetailItem(', '    func setFullScreenPlaybackResourceSuspended(']:
        assert block(store,marker)==block(prior,marker),marker
    method=block(store,'    func unifiedSearchResults(')
    assert 'withTaskGroup(of: [MediaItem].self)' in method and 'for await batch in group' in method
    assert 'async let' not in method and 'onUpdate?(accumulated)' in method
    assert method.index('guard !Task.isCancelled else { return [] }',method.index('for await batch')) < method.index('rememberUnifiedSearchResults(accumulated')
    for marker in ['    private func cinemetaUnifiedSearchResults(for query: String, type:', '    func tmdbSearchResults(']:
        m=block(store,marker)
        assert 'SignalMetadataResponseCache.shared.data(for: request)' in m and 'URLSession.shared.data(for: request)' not in m
    assert 'URLQueryItem(name: "query", value: trimmed)' in block(store,'    func tmdbSearchResults(')
    assert 'SignalSearchArtwork.cardURL(for: item.landscapeURL ?? item.posterURL)' in block(app,'struct SearchResultCard: View')
    before=historical_source(ROOT/'Sources/SignalSearchResultsLayout.swift')
    assert pre_f87(ROOT/'Sources/SignalSearchResultsLayout.swift').startswith(before)
    for name in ['Scripts/check_f28_source_preflight.sh','Scripts/prepare_build_deps_vBRDC280.sh']:
        s=pre_f87(ROOT/name);assert s.index('check_f86_native_search.py')<s.index('check_f85_native_sports.py')
    print('F86 contracts PASS: read-only getter, progressive search, metadata cache, card-only TMDB sizing; playback/focus and other Swift preserved; source mutations rejected')
if __name__=='__main__':check()
