from regression_manifest_cache import read_manifest
"""Reverse only reviewed F79 source hunks for exact F60/historical checks."""
from pathlib import Path
import hashlib,json,re
from f82_approved_deltas import previous_source as previous_f82
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    source=previous_f82(source,path)
    record=read_manifest(ROOT/'Tests/F79ApprovedSourceDeltas.json').get(path)
    if record is None:return source
    digest=hashlib.sha256(source.encode()).hexdigest()
    accepted={record['before_sha256']}
    for previous in ROOT.glob('Tests/F*ApprovedSourceDeltas.json'):
        release=re.match(r'F(\d+)',previous.name)
        if not release or int(release[1])>=79:continue
        prior=read_manifest(previous).get(path)
        if prior:accepted.update((prior['before_sha256'],prior['after_sha256']))
    if digest in accepted:return source
    assert digest==record['after_sha256'],'Unreviewed F79 source change: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1,'Ambiguous F79 delta: '+path
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256']
    return source

def historical_source(path):
    from f87_approved_deltas import f103_approved_guide_history
    guide=f103_approved_guide_history(path)
    return previous_source(guide if guide is not None else path.read_text(),path.relative_to(ROOT).as_posix())
