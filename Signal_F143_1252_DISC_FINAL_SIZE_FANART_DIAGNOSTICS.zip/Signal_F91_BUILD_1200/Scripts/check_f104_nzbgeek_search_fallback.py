#!/usr/bin/env python3
"""Static F104 guard for structured NZBGeek episode search and safe fallback."""
from pathlib import Path
s = (Path(__file__).resolve().parents[1] / 'Sources' / 'TorBoxUsenetClient.swift').read_text()
start = s.index('private static func searchNZBGeek(')
end = s.index('private static func searchNewznabDirect(', start)
body = s[start:end]
for expected in ('"tvsearch"', '"season"', '"ep"', '"search"',
                 'try Task.checkCancellation()', 'try throwIfCancelled(error)',
                 '"api.nzbgeek.info"', 'link.scheme?.lowercased() == "https"',
                 'if index + 1 < searches.count { continue }'):
    assert expected in body, f'Missing NZBGeek search guard: {expected}'
assert body.index('"tvsearch"') < body.index('"search"'), 'TV search must precede fallback'
assert 'Bearer' not in body, 'Do not send TorBox bearer token to NZBGeek'
print('PASS: NZBGeek structured TV search, text fallback, cancellation and host filtering')
