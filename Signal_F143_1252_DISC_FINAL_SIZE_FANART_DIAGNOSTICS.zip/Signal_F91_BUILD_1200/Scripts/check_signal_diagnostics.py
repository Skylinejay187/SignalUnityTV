#!/usr/bin/env python3
"""F143 diagnostic module contract and privacy regression checks."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
module=(root/'Sources/SignalDiagnosticCenter.swift').read_text()
app=(root/'Sources/DebridChannelsTVOSApp.swift').read_text()
project=(root/'project.yml').read_text()
for phrase in (
    'let maxEvents = 2400', 'func startExport()', 'func stopExport()',
    'func selfCheck()', 'func attachPerformanceReport(',
    'DebridChannels.Aether.buffer', 'DebridChannels.Aether.buffering',
    'DebridChannels.Aether.failure', 'application/zip',
    'parameters.requiredLocalEndpoint', 'Date().addingTimeInterval(600)',
    'for token in monitoringTokens { NotificationCenter.default.removeObserver(token) }',
    'SignalDiagnosticZip.make(files:', '"session_timeline.json"',
    '"performance_trace.txt"', '"manifest.json"',
    'if events.count > maxEvents { events.removeFirst(events.count - maxEvents) }',
):
    assert phrase in module, 'Missing diagnostic privacy/export requirement: '+phrase
for phrase in ('case diagnostics = "Diagnostics"','case .diagnostics:','signalDiagnostics.startExport()',
    'signalDiagnostics.attachPerformanceReport(performanceTrace.report())',
    'SignalDiagnosticCenter.shared.mark("artwork"',
    'SignalDiagnosticCenter.shared.mark("guide"'):
    assert phrase in app, 'Missing Settings or event wiring: '+phrase
for name in ['tmdbApiKey','fanartTvApiKey','omdbApiKey','tvdbToken']:
    assert '"'+name+'"' in module, 'Missing provider health presence check: '+name
assert '      - path: Sources/SignalDiagnosticCenter.swift' in project
bridge=(root/'Sources/AuxiliaryVideoPlaybackCoordinator.swift').read_text()
assert 'SignalDiagnosticCenter.shared.mark("preview"' in bridge
assert 'POST /' not in module and 'Authorization:' not in module
print('Signal Diagnostic Center static/privacy contracts PASS')
