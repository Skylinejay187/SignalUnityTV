"""Reconstruct exact pre-F87 source without masking current source changes."""
from pathlib import Path
import hashlib,re
from regression_manifest_cache import read_manifest
from f122_prior_source import before_f122
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    if path == 'Sources/RemoteImageFit.swift':
        release = read_manifest(ROOT/'Tests/F138ApprovedArtworkDelta.json')
        digest = hashlib.sha256(source.encode()).hexdigest()
        if source == (ROOT/path).read_text():
            assert digest == release['after_sha256'], 'Unreviewed F138 artwork source'
        if digest == release['after_sha256']:
            for hunk in reversed(release['hunks']):
                assert source.count(hunk['after']) == 1
                source = source.replace(hunk['after'], hunk['before'], 1)
            assert hashlib.sha256(source.encode()).hexdigest() == release['before_sha256']
    source=before_f122(ROOT,path,source)
    for version in ('F114', 'F111'):
        later=read_manifest(ROOT/f'Tests/{version}ApprovedSourceDeltas.json').get(path)
        if later is not None:
            digest=hashlib.sha256(source.encode()).hexdigest()
            # F114's provider also has F83/F85 deltas. Historical callers can
            # enter this chain with those versions already reconstructed.
            if version == 'F111' or source == (ROOT/path).read_text():
                assert digest in {later['before_sha256'],later['after_sha256']}, f'Unreviewed {version} source: '+path
            if digest==later['after_sha256']:
                source=later['hunks'][0]['before']
    # Historical adapters for F45–F86 start with today's source. When F91 has
    # an independently pinned post-F87 edit, enter the reverse-delta chain
    # using the exact, separately SHA-verified F87 snapshot instead.
    # An unreviewed mutation remains rejected rather than silently normalized.
    snapshot=ROOT/'Tests/F91InheritedF87Baseline'/path
    if snapshot.is_file() and source == (ROOT/path).read_text():
        current_hashes=read_manifest(ROOT/'Tests/F91ApprovedPostF87Hashes.json')
        # The current release manifest independently pins later edits to these paths.
        # Accept them only when their exact current bytes match the F104
        # approved manifest AND the F87 snapshot passes its historical digest.
        f104_paths = {
            'Sources/ReleaseCandidateSecurityManager.swift',
            'Sources/TorBoxUsenetClient.swift',
            'Sources/SignalPortableSettings.swift',
            'Sources/CatalogStore.swift',
            'Sources/DebridChannelsTVOSApp.swift',
            'Sources/LiveTVGuideCacheManager.swift',
            'Sources/SignalIPTVImport.swift',
        }
        if path in f104_paths:
            current_hashes = read_manifest(ROOT/'Tests/F104ApprovedSourceHashes.json')
        assert path in current_hashes, 'Unpinned post-F87 source: '+path
        assert hashlib.sha256(source.encode()).hexdigest()==current_hashes[path], 'Unreviewed post-F87 source: '+path
        record=read_manifest(ROOT/'Tests/F87ApprovedSourceDeltas.json').get(path)
        additions=read_manifest(ROOT/'Tests/F87NewSourceHashes.json')
        expected=record['after_sha256'] if record is not None else additions.get(path)
        if expected is None:
            expected=read_manifest(ROOT/'Tests/F87UnchangedSourceHashes.json').get(path)
        assert expected is not None, 'Untracked F87 snapshot: '+path
        assert hashlib.sha256(snapshot.read_bytes()).hexdigest()==expected, 'Altered F87 snapshot: '+path
        source=snapshot.read_text()
    added=read_manifest(ROOT/'Tests/F87NewSourceHashes.json')
    if path in added:
        data=(snapshot if snapshot.is_file() else ROOT/path).read_bytes() if source=='' else source.encode()
        assert hashlib.sha256(data).hexdigest()==added[path],'Unreviewed F87 addition: '+path
        return ''
    record=read_manifest(ROOT/'Tests/F87ApprovedSourceDeltas.json').get(path)
    if record is None:return source
    if source=='' and path in read_manifest(ROOT/'Tests/F85NewSourceHashes.json'):
        historical = snapshot if snapshot.is_file() else ROOT/path
        assert hashlib.sha256(historical.read_bytes()).hexdigest()==record['after_sha256'],path
        return ''
    digest=hashlib.sha256(source.encode()).hexdigest()
    accepted={record['before_sha256']}
    for p in ROOT.glob('Tests/F*ApprovedSourceDeltas.json'):
        m=re.match(r'F(\d+)',p.name)
        if not m or int(m[1])>=87:continue
        rec=read_manifest(p).get(path)
        if rec:accepted.update((rec['before_sha256'],rec['after_sha256']))
    # New F85 files may already have been omitted by a repeated older history pass.
    if digest in accepted:return source
    assert digest==record['after_sha256'],'Unreviewed F87 source: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1,path
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256'],path
    return source

def f103_approved_guide_history(path):
    """Return the independently pinned F87 Guide for historical F45-F86 checks.

    Never normalize an unapproved current Guide mutation.
    """
    name=path.relative_to(ROOT).as_posix()
    if name != 'Sources/SignalGuideNavigation.swift':
        return None
    approved=read_manifest(ROOT/'Tests/F103ApprovedGuideNavigationHashes.json')
    assert set(approved)=={name}, 'Unexpected F103 exception'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==approved[name], 'Unapproved F103 Guide source'
    snapshot=ROOT/'Tests/F103HistoricalGuideNavigation.swift'
    baseline=read_manifest(ROOT/'Tests/F87UnchangedSourceHashes.json')
    assert name in baseline and hashlib.sha256(snapshot.read_bytes()).hexdigest()==baseline[name], 'Unapproved F87 Guide history'
    return snapshot.read_text()

def historical_source(path):
    name=path.relative_to(ROOT).as_posix()
    guide=f103_approved_guide_history(path)
    if guide is not None:return previous_source(guide,name)
    if name in {'Sources/LiveTVGuideCacheManager.swift', 'Sources/SignalIPTVImport.swift'}:
        return previous_source(path.read_text(),name)
    snapshot=ROOT/'Tests/F91InheritedF87Baseline'/name
    # Post-F87 edits are validated separately by check_f91_inherited_f87.py.
    # Reconstruct F86 history from the original, SHA-verified F87 source.
    return previous_source(snapshot.read_text() if snapshot.is_file() else path.read_text(),name)
