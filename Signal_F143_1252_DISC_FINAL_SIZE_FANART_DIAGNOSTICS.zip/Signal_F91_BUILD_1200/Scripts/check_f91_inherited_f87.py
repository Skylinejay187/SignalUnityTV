"""Verify preserved F87 snapshots and explicitly pinned post-F87 F91 sources.
This supplements, rather than rewrites, the original F87 manifests.
"""
from pathlib import Path
import json,hashlib
from source_hash_integrity import ENGINE_PLACEHOLDERS, verify_unchanged_sources
from f122_prior_source import before_f122
ROOT=Path(__file__).resolve().parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def check():
    later=json.loads((ROOT/'Tests/F114ApprovedSourceDeltas.json').read_text())
    assert set(later)=={'Sources/SportsScoresScheduleProvider.swift'}, 'Unexpected F114 exception set'
    for path,record in later.items():
        source=before_f122(ROOT,path,(ROOT/path).read_text())
        assert hashlib.sha256(source.encode()).hexdigest()==record['after_sha256'], 'Unreviewed F114 source: '+path
    current=json.loads((ROOT/'Tests/F91ApprovedPostF87Hashes.json').read_text())
    assert len(current)==14, 'Expected fourteen reviewed post-F87 paths'
    f87={}
    for name in ('F87ApprovedSourceDeltas','F87NewSourceHashes','F87UnchangedSourceHashes'):
        data=json.loads((ROOT/'Tests'/ (name+'.json')).read_text())
        for path,rec in data.items():f87[path]=rec['after_sha256'] if isinstance(rec,dict) else rec
    # The AetherEngine placeholders are intentionally replaced by the pinned
    # 7.44.0 checkout during the workflow's engine-install step. Reuse the
    # existing F80 lifecycle verifier; it checks the precise packaged hashes
    # OR the pinned Git tag, marker, removed placeholder and integration patches.
    # Explicit F103 Guide rewrite exception: validate exact approved bytes,
    # while retaining every other inherited F87/F91 integrity assertion.
    f104_approved=json.loads((ROOT/'Tests/F104ApprovedSourceHashes.json').read_text())
    assert set(f104_approved)=={'Sources/ReleaseCandidateSecurityManager.swift','Sources/TorBoxUsenetClient.swift','Sources/DebridChannelsTVOSApp.swift','Sources/SignalGuideNavigation.swift','Sources/CatalogStore.swift','Sources/SignalPortableSettings.swift','Sources/LiveTVGuideCacheManager.swift','Sources/SignalIPTVImport.swift','Sources/RemoteImageFit.swift'}, 'Unexpected F104 exception set'
    # F143 reviewed source deltas replace hashes only for expressly approved paths;
    # all remaining F104 hashes and historical F87/F91 contract checks stay pinned.
    f143_approved=json.loads((ROOT/'Tests/F143ApprovedPostF104Hashes.json').read_text())
    assert set(f143_approved)=={'Sources/DebridChannelsTVOSApp.swift','Sources/CatalogStore.swift','Sources/RemoteImageFit.swift','Sources/TorBoxUsenetClient.swift'}, 'Unexpected F143 exception set'
    assert set(f143_approved).issubset(f104_approved), 'F143 exceptions must originate in F104 reviewed set'
    for path,digest in f104_approved.items():
        approved=f143_approved.get(path,digest)
        assert (ROOT/path).is_file() and sha(ROOT/path)==approved, 'Unreviewed F104/F143 change: '+path
    guide_approved=json.loads((ROOT/'Tests/F103ApprovedGuideNavigationHashes.json').read_text())
    assert set(guide_approved)=={'Sources/SignalGuideNavigation.swift'}, 'Unexpected F103 Guide exception'
    engine_hashes={p:d for p,d in f87.items() if p in ENGINE_PLACEHOLDERS}
    verify_unchanged_sources(ROOT,engine_hashes)
    # Additional reviewed F143 adjustments to historically pinned components.
    f143_legacy=json.loads((ROOT/'Tests/F143ReviewedLegacyDriftHashes.json').read_text())
    assert set(f143_legacy)=={'Sources/PerTitlePlaybackMemory.swift','Sources/TraktSyncManager.swift','Sources/PlaybackResumeCache.swift'}
    for path,digest in f143_legacy.items():
        assert sha(ROOT/path)==digest, 'Unreviewed F143 historical drift: '+path
    for path,digest in f87.items():
        if path in f143_legacy:
            continue
        if path in ENGINE_PLACEHOLDERS:
            continue  # Already validated in its correct lifecycle state.
        if path in f104_approved:
            continue  # Reviewed F104 source bytes pinned above.
        if path in guide_approved:
            assert (ROOT/path).is_file() and sha(ROOT/path)==guide_approved[path], 'Unapproved F103 Guide change: '+path
            continue
        if path in later:
            assert later[path]['before_sha256']==digest, 'Changed F87 baseline: '+path
            assert hashlib.sha256(later[path]['hunks'][0]['before'].encode()).hexdigest()==digest
            continue
        original=ROOT/'Tests/F91InheritedF87Baseline'/path if path in current else ROOT/path
        source=before_f122(ROOT,path,original.read_text()) if path in {'Sources/SignalSportsScoreboard.swift','Sources/MediaFlowProxyRouter.swift','EnginePatches/AetherEngine+SignalCacheFrontier.swift'} else None
        actual=hashlib.sha256(source.encode()).hexdigest() if source is not None else sha(original)
        assert original.is_file() and actual==digest, 'F87 baseline changed: '+path
    for path,digest in current.items():
        if path in f104_approved:
            continue  # Reviewed F104 source bytes pinned above.
        assert (ROOT/path).is_file() and sha(ROOT/path)==digest, 'Unreviewed post-F87 source change: '+path
    player=(ROOT/'Sources/SignalSportsOnlinePlayer.swift').read_text()
    for token in ('store.startPlayback(item: live, url: resolved.url','headers: resolved.headers','handedOff = true; resourceClaimed = false'):
        assert token in player, 'Sports handoff missing: '+token
    for token in ('PlaybackKitAetherHost(', 'AVPlayer('):
        assert token not in player, 'Unexpected secondary sports player: '+token
    app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    for token in ('struct SportsFoundationQuickPanelSurface: View','struct GridOSCatalogOverlay: View','struct VODPlayerScreen: View'):
        assert token in app, 'Required surface missing: '+token
    print('F91 inherited F87 historical hashes + 14 pinned post-F87 sources + sports contracts PASS')
if __name__=='__main__':check()
