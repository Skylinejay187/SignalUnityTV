# F143 / build 1252 — provider credential routing audit

Source audited: F143_1252_FANART_DISC_KEY_WIRING_FIXED, with this patch applied.

## Verified source wiring

- Metadata key entry and backup/restore use `tmdbApiKey`, `omdbApiKey`, `fanartTvApiKey`, and `tvdbApiToken` consistently in the main settings view.
- VOD production metadata and Up Next pass the configured TMDB and Fanart.tv keys. Fanart.tv `moviedisc` is fetched by TMDB movie ID and published into `discArtURLs`; live artwork delivery requires runtime testing.
- `CatalogStore` reads TMDB and Fanart.tv keys for catalog enrichment. Separate TMDB lookups cover information headers and selected episode metadata.
- Real-Debrid, TorBox, Premiumize, AllDebrid, Debrid-Link, EasyDebrid, Offcloud and Put.io have a common credential bridge and existing service health checks. These are not necessarily proof that every addon and media link can play.
- NZBGeek has a dedicated secure credential store and connection test. TorBox's account/Usenet processing verification does not validate search discovery or progressive playback.
- IntroDB key is read by intro submission. Trakt uses OAuth tokens instead of the metadata/debrid key fields. MediaFlow and FebBox have separate credential stores.
- TVDB bearer token is configured in settings and forwarded by `saveArtworkKeysToBackend`; its use by the separately deployed backend is not established from this tvOS archive.

## Additional correction: expanded Verify Connections

`ConnectedServicesHealthClient.verifyAll` now includes four separate metadata provider checks:
- TMDB configuration endpoint using the saved v3 key.
- Fanart.tv sample-movie artwork endpoint using the saved Fanart.tv key.
- OMDb sample IMDb lookup, with explicit handling of an HTTP-200 `Response: False` authentication error.
- TVDB v4 search using the saved bearer JWT; a bare TVDB project API key may first need the TVDB `/login` exchange.

All four return `ConnectedServiceHealth` results in the existing settings UI. Keys are not printed in result details. Only manual verification contacts these endpoints. Provider network failures, rate limiting, missing artwork for a title, backend credentials, and feature-level usage may still require diagnosis separately.

## Limits and follow-ups

- Static source analysis cannot establish whether a device is configured with valid credentials, whether a backend received credentials, or whether an authenticated provider supplies disc artwork for a given title.
- The current phone-setup/settings backup includes secret fields; verify how backups are protected before sharing exports or distributing logs.
- Fanart.tv tests only authentication and sample movie data. Missing `moviedisc` on a specific movie is not a key failure. The fallback to alternate same-title artwork remains necessary.
- Legacy validation scripts may assert historical baselines not current in F143; this patch updates only the current reviewed-source manifest, not historical protections.
- No API key values were read or stored during this audit.
