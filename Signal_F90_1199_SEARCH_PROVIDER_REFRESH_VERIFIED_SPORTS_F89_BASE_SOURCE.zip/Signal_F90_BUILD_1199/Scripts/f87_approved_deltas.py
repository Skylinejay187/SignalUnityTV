"""Reconstruct exact pre-F87 source without masking current source changes."""
from pathlib import Path
import hashlib,re
from regression_manifest_cache import read_manifest
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    added=read_manifest(ROOT/'Tests/F87NewSourceHashes.json')
    if path in added:
        data=(ROOT/path).read_bytes() if source=='' else source.encode()
        assert hashlib.sha256(data).hexdigest()==added[path],'Unreviewed F87 addition: '+path
        return ''
    record=read_manifest(ROOT/'Tests/F87ApprovedSourceDeltas.json').get(path)
    if record is None:return source
    if source=='' and path in read_manifest(ROOT/'Tests/F85NewSourceHashes.json'):
        assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==record['after_sha256'],path
        return ''
    digest=hashlib.sha256(source.encode()).hexdigest()
    accepted={record['before_sha256']}
    for p in ROOT.glob('Tests/F*ApprovedSourceDeltas.json'):
        m=re.match(r'F(\d+)',p.name)
        if not m or int(m[1])>=87:continue
        rec=read_manifest(p).get(path)
        if rec:accepted.update((rec['before_sha256'],rec['after_sha256']))
    # New F85 files may already have been omitted by a repeated older history pass.
    if digest in accepted:return source
    assert digest==record['after_sha256'],'Unreviewed F87 source: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1,path
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256'],path
    return source

def historical_source(path):return previous_source(path.read_text(),path.relative_to(ROOT).as_posix())
