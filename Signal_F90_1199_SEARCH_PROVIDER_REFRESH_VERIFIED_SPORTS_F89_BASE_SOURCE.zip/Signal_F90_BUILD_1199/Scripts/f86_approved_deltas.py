"""Reverse only exact reviewed F86 bytes; retain all older source and mutation locks."""
from pathlib import Path
import hashlib, re
from regression_manifest_cache import read_manifest
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    from f87_approved_deltas import previous_source as previous_f87
    source=previous_f87(source,path)
    records=read_manifest(ROOT/'Tests/F86ApprovedSourceDeltas.json')
    record=records.get(path)
    if record is None:return source
    digest=hashlib.sha256(source.encode()).hexdigest()
    # Older adapters may call the chain on an already reconstructed source.
    accepted={record['before_sha256']}
    for manifest in ROOT.glob('Tests/F*ApprovedSourceDeltas.json'):
        release=re.match(r'F(\d+)',manifest.name)
        if not release or int(release[1])>=86:continue
        older=read_manifest(manifest).get(path)
        if older:accepted.update((older['before_sha256'],older['after_sha256']))
    if digest in accepted:return source
    assert digest==record['after_sha256'],'Unreviewed F86 source: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1,path
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256'],path
    return source

def historical_source(path):return previous_source(path.read_text(),path.relative_to(ROOT).as_posix())
