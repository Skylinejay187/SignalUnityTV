#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
# F67: reject unlisted app Swift files before dependency downloads or compilation.
python3 Scripts/check_app_source_membership.py
python3 Scripts/check_f87_unity_sports.py
python3 Scripts/check_f87_native_unity_sports.py
python3 Scripts/check_f86_search_build.py
python3 Scripts/check_f86_native_search.py
python3 Scripts/check_f85_sports.py
python3 Scripts/check_f85_native_sports.py
python3 Scripts/check_f84_settings_history.py
echo 'F28 preflight: all app and packaged bridge Swift syntax'
# macOS ships Bash 3.2, which does not support mapfile/readarray.
# Use portable Bash arrays and NUL-delimited paths to preserve filenames.
SWIFT_FILES=()
while IFS= read -r -d '' file; do
  SWIFT_FILES+=("$file")
done < <(find Sources TopShelfExtension Vendor/AetherPlaybackKit/Sources -name '*.swift' -type f -print0)
if (( ${#SWIFT_FILES[@]} == 0 )); then echo 'No Swift sources found' >&2; exit 1; fi
swiftc -frontend -parse "${SWIFT_FILES[@]}"
# F45: syntax parsing cannot catch escaping-closure explicit-self errors.
python3 Scripts/check_f45_quick_guide_compile.py
python3 Scripts/check_f45_regression.py
echo 'F28 preflight: bridge parity and installer checks'
cmp Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift
bash -n Scripts/check_f28_source_preflight.sh Scripts/fetch_aether_f28_744.sh Scripts/prepare_build_deps_vBRDC280.sh
python3 -m py_compile Scripts/verify_f28_aether_integration.py Scripts/verify_f28_fastzap_wiring.py
python3 Scripts/verify_f28_fastzap_wiring.py
grep -q '7.44.0' Scripts/fetch_aether_f28_744.sh
# Both direct bridge callers and the SwiftUI surface must sanitize resume time.
python3 - <<'PY_RESUME_TIME'
from pathlib import Path
bridge = Path('Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
surface = Path('Sources/PlaybackKit/PlaybackKitAetherSurface.swift').read_text()
assert 'startTimeSeconds.isFinite ? max(0, startTimeSeconds) : 0' in bridge
assert 'startTimeSeconds.isFinite ? max(0, startTimeSeconds) : 0' in surface
print('F28 bridge and surface resume timestamp guards verified')
PY_RESUME_TIME
# The engine installer must reject overlapping builds before touching the
# existing vendor checkout. Exercise the real script with a held lock.
python3 - <<'PY_INSTALL_LOCK'
from pathlib import Path
import subprocess
root = Path.cwd()
lock = root / '.build-cache' / 'aether-f28-install.lock'
lock.parent.mkdir(parents=True, exist_ok=True)
if lock.exists():
    raise SystemExit(f'Cannot test install lock: existing lock requires inspection: {lock}')
lock.mkdir()
try:
    result = subprocess.run(['bash', 'Scripts/fetch_aether_f28_744.sh'],
                            capture_output=True, text=True, timeout=10)
    if result.returncode == 0 or 'Another F28 AetherEngine installation is active' not in result.stderr:
        raise SystemExit('Concurrent engine installation was not rejected')
    if not lock.is_dir():
        raise SystemExit('Rejected installer removed a lock it did not own')
finally:
    lock.rmdir()
print('F28 concurrent AetherEngine installer lock verified')
PY_INSTALL_LOCK
# The rollback handler must retain the lock until recovery is complete.
python3 - <<'PY_ROLLBACK_LOCK'
from pathlib import Path
s = Path('Scripts/fetch_aether_f28_744.sh').read_text()
start = s.index('restore_previous() {')
end = s.index('\ntrap restore_previous EXIT', start)
handler = s[start:end]
assert handler.index('rm -rf "$TMP"') < handler.index('release_install_lock'), \
    'Installer unlocks before failed-install cleanup finishes'
assert handler.index('mv "$PREVIOUS" "$DEST"') < handler.index('release_install_lock'), \
    'Installer unlocks before restoring the previous engine'
print('F28 installer rollback lock ordering verified')
PY_ROLLBACK_LOCK
# Verify the staged-engine patch keeps finite-value guards at every gain entry.
python3 - <<'PY_GAIN_GUARDS'
from pathlib import Path
source = Path('Scripts/fetch_aether_f28_744.sh').read_text()
required = (
    'let clamped = db.isFinite ? max(0, min(12, db)) : 0',
    'signalAudioGainDB = db.isFinite ? max(0, min(12, db)) : 0',
    'softwareHost?.setAudioGainDB(db.isFinite ? max(0, min(12, db)) : 0)',
)
for guard in required:
    if guard not in source:
        raise SystemExit(f'Missing engine audio-gain finite guard: {guard}')
print('F28 staged Aether audio-gain finite guards verified (3)')
PY_GAIN_GUARDS
# A checkout whose pinned-version marker is intact but whose Git tag drifted
# must enter the rollback path rather than being accepted as a valid engine.
python3 - <<'PY_TAG_ROLLBACK'
from pathlib import Path
source = Path('Scripts/fetch_aether_f28_744.sh').read_text()
recovery = source.split('if [[ -e "$PREVIOUS" && -e "$DEST"', 1)[1].split('if [[ -f "$DEST/.signal-f28-version"', 1)[0]
assert 'git -C "$DEST" describe --tags --exact-match' in recovery
assert 'mv "$PREVIOUS" "$DEST"' in recovery
print('F28 pinned-tag drift recovery path verified')
PY_TAG_ROLLBACK
# A remote/foreground Play assertion must not resurrect the previous episode
# after the terminal event has been delivered to Up Next.
python3 - <<'PY_UPNEXT_END_ASSERTION'
from pathlib import Path
source = Path('Sources/PlaybackKit/PlaybackKitAetherSurface.swift').read_text()
assert 'shouldPlay == coordinator.lastShouldPlay && !coordinator.didReachNaturalEnd' in source
assert 'coordinator.didReachNaturalEnd = false\n                Self.performNoArgumentSelector("aetherPlay"' not in source
print('F28 Up Next natural-end assertion guard verified')
PY_UPNEXT_END_ASSERTION
# F40: parsing alone did not catch the inherited UIKit 'focused' collision.
# Type-check the complete standalone Search view against the real tvOS SDK before
# any engine install/build. Universal ZIP workflows already call this preflight.
echo 'F40 preflight: native Search UIKit/SwiftUI type check'
F40_TVOS_SDK="$(xcrun --sdk appletvos --show-sdk-path)"
xcrun --sdk appletvos swiftc -typecheck -swift-version 5 \
  -target arm64-apple-tvos18.0 -sdk "$F40_TVOS_SDK" \
  Sources/SignalVisualOptions.swift Sources/SignalSearchGlyph.swift \
  Sources/SignalLiveTVCardEffect.swift Sources/SignalLiveTVCardAlignment.swift \
  Sources/SignalLiveTVCardAlignmentVisuals.swift
python3 Scripts/check_f40_regression.py
python3 - <<'PY_F40_DISMISSAL'
from pathlib import Path
import subprocess,tempfile
with tempfile.TemporaryDirectory(prefix='signal-f40-policy-') as directory:
    executable=Path(directory)/'upnext-tests'
    subprocess.run(['swiftc','Sources/SignalUpNextDismissalState.swift',
                    'Tests/SignalF40UpNextDismissalTests.swift','-o',str(executable)],check=True)
    subprocess.run([str(executable)],check=True)
PY_F40_DISMISSAL
python3 Scripts/check_f41_regression.py
python3 Scripts/check_f41_geometry_math.py
python3 -m unittest discover -s Tests -p test_f53_geometry_audit.py
python3 - <<'PY_F41_GEOMETRY'
from pathlib import Path
import subprocess,tempfile
with tempfile.TemporaryDirectory(prefix='signal-f41-geometry-') as directory:
    executable=Path(directory)/'grid-tests'
    subprocess.run(['swiftc','Sources/SignalLiveTVCardEffect.swift','Sources/SignalLiveTVCardAlignment.swift',
                    'Tests/SignalF41GridAlignmentTests.swift','-o',str(executable)],check=True)
    subprocess.run([str(executable)],check=True)
PY_F41_GEOMETRY
python3 Scripts/check_f42_regression.py
python3 - <<'PY_F42_TESTS'
from pathlib import Path
import subprocess,tempfile
with tempfile.TemporaryDirectory(prefix='signal-f42-') as directory:
    for label,sources in [
        ('settings',['Sources/SignalPortableSettings.swift','Sources/ReleaseCandidateSecurityManager.swift','Sources/SignalLiveTVCardEffect.swift','Tests/SignalF42SettingsTests.swift']),
        ('cache',['EnginePatches/AetherEngine+SignalCacheFrontier.swift','Tests/SignalF42CacheFrontierTests.swift'])]:
        executable=Path(directory)/label
        subprocess.run(['swiftc','-swift-version','5',*sources,'-o',str(executable)],check=True)
        subprocess.run([str(executable)],check=True)
PY_F42_TESTS
# F43: type-check native renderer and actual host teardown against the tvOS SDK.
xcrun --sdk appletvos swiftc -typecheck -swift-version 5 \
  -target arm64-apple-tvos18.0 -sdk "$F40_TVOS_SDK" \
  Sources/SignalLiveTVResourcePolicy.swift Sources/SignalLiveTVVisualWork.swift \
  Sources/SignalVisualOptions.swift Sources/SignalGlassAtmosphereVisuals.swift \
  Sources/AuxiliaryVideoPlaybackCoordinator.swift Sources/LiveTVMemoryAuditManager.swift \
  Sources/PlaybackKit/PlaybackKitAetherSurface.swift
xcrun --sdk appletvos swiftc -typecheck -swift-version 5 \
  -target arm64-apple-tvos18.0 -sdk "$F40_TVOS_SDK" \
  Sources/SignalLiveTVResourcePolicy.swift Sources/SignalDashboardBackdrop.swift \
  Tests/F43BackdropTypecheckStubs.swift
python3 Scripts/check_f43_regression.py
python3 Scripts/check_f43_resource_math.py
python3 - <<'PY_F43_TESTS'
from pathlib import Path
import subprocess,tempfile
with tempfile.TemporaryDirectory(prefix='signal-f43-') as directory:
    executable=Path(directory)/'resource-tests'
    subprocess.run(['swiftc','-swift-version','5','Sources/SignalLiveTVResourcePolicy.swift',
                    'Sources/AuxiliaryVideoPlaybackCoordinator.swift','Tests/SignalF43ResourcePolicyTests.swift',
                    '-o',str(executable)],check=True)
    subprocess.run([str(executable)],check=True)
PY_F43_TESTS
# F44: visible native buttons/shared translucent guide styling and real-time axis.
xcrun --sdk appletvos swiftc -typecheck -swift-version 5 \
  -target arm64-apple-tvos18.0 -sdk "$F40_TVOS_SDK" \
  Sources/SignalGuideChrome.swift Sources/SignalGuideTimeline.swift Sources/SignalUpNextAutoplayPolicy.swift
python3 Scripts/check_f44_regression.py
python3 - <<'PY_F44_TESTS'
from pathlib import Path
import subprocess,tempfile
with tempfile.TemporaryDirectory(prefix='signal-f44-') as directory:
    executable=Path(directory)/'upnext-guide-tests'
    subprocess.run(['swiftc','-swift-version','5','Sources/SignalUpNextDismissalState.swift',
                    'Sources/SignalUpNextAutoplayPolicy.swift','Sources/SignalGuideTimeline.swift',
                    'Tests/SignalF44UpNextGuideTests.swift','-o',str(executable)],check=True)
    subprocess.run([str(executable)],check=True)
PY_F44_TESTS
# F46: duplicate EPG revisions must never render overlapping text rectangles.
python3 Scripts/check_f46_regression.py
python3 - <<'PY_F46_TESTS'
from pathlib import Path
import subprocess,tempfile
with tempfile.TemporaryDirectory(prefix='signal-f46-') as directory:
    executable=Path(directory)/'guide-tests'
    subprocess.run(['swiftc','-swift-version','5','Sources/SignalGuideTimeline.swift',
                    'Sources/SignalGuideNavigation.swift','Tests/SignalF46GuideTests.swift',
                    '-o',str(executable)],check=True)
    subprocess.run([str(executable)],check=True)
PY_F46_TESTS
# F47: scoped in-player Search/TV, single-dashboard migration, shared Sports/Search rail.
python3 Scripts/check_f47_regression.py
python3 Scripts/check_f47_native_browse.py
echo "F28 preflight passed (${#SWIFT_FILES[@]} Swift files)."

# F48: real router safety checks and original/aligned card pose/motion contracts.
python3 Scripts/check_f48_regression.py
python3 Scripts/check_f48_native_safety.py

# F49: compile the complete health client, exercise safe routing and ensure the
# supplied F48 misplaced-throw bug is caught by a negative compiler control.
python3 Scripts/check_f49_regression.py
python3 Scripts/check_f49_native_health.py

# F50: stronger preview lift with unchanged reveal/transition, geometry and safety.
python3 Scripts/check_f50_regression.py

# F51: per-device home/away routing and actual uniformly aligned card renderer.
python3 Scripts/check_f51_regression.py
python3 Scripts/check_f51_native_routing.py

# F55: compact v228-style Search cards with current async/playback safeguards.
python3 Scripts/check_f55_search_regression.py
python3 Scripts/check_f55_native_search.py

# F56: network-scoped home proof and session-owned playback routing.
python3 Scripts/check_f56_home_regression.py
python3 Scripts/check_f56_native_home.py

# F57: same-player revalidation; reject automatic decoder restart loops.
python3 Scripts/check_f57_no_restart.py
python3 Scripts/check_f57_native_continuity.py

# F58: native Search focus entry and deterministic lazy-row D-pad fallback.
python3 Scripts/check_f58_search_focus.py
python3 Scripts/check_f58_native_navigation.py

# F59: atomic Search focus ownership and no native result platter.
python3 Scripts/check_f59_search_focus.py

# F60: foreground-only timed phone setup, bounded/authenticated protocol and exact Settings actions.
python3 Scripts/check_f60_phone_setup.py
python3 Scripts/check_f60_native_phone_setup.py

if command -v node >/dev/null 2>&1; then node Scripts/check_f60_web_page.cjs; fi

# F61: cancellable notification display leases and actual Root lifecycle SDK checks.
python3 Scripts/check_f61_alert_delivery.py
python3 Scripts/check_f61_native_alert_delivery.py

# F62: actual recovery/gain/EPG ownership and executable orchestration fixtures.
python3 Scripts/check_f62_playback_guide.py
python3 Scripts/check_f62_native_playback_guide.py

# F63: cancellation-safe delayed pause information; production policy and actual VOD mapping.
python3 Scripts/check_f63_pause_info.py
python3 Scripts/check_f63_native_pause_info.py

# F64: metadata caching, current provider contracts, skips, modes, prompts and native UI.
python3 Scripts/check_f64_episode_experience.py
python3 Scripts/check_f64_native_episode_experience.py

# F65: actual mounted recap action and force-EPG source checks.
python3 Scripts/check_f65_recap_guide.py

# F66: real decoder-clock orchestration and episode-scoped diagnostics.
python3 Scripts/check_f66_episode_clock.py
python3 Scripts/check_f66_native_clock.py

# F68: branded pause title, precise recap presentation and derived EPG metadata.
python3 Scripts/check_f68_pause_recap_guide.py
python3 Scripts/check_f68_native_guide.py
