from regression_manifest_cache import read_manifest
"""Precisely reconstruct pre-F85 source for existing regression locks."""
from pathlib import Path
from functools import lru_cache
import hashlib, json, re
ROOT = Path(__file__).resolve().parents[1]
@lru_cache(maxsize=1)
def records(): return read_manifest(ROOT/'Tests/F85ApprovedSourceDeltas.json')
@lru_cache(maxsize=1)
def additions(): return read_manifest(ROOT/'Tests/F85NewSourceHashes.json')
def previous_source(source, path):
    from f86_approved_deltas import previous_source as previous_f86
    source = previous_f86(source, path)
    digest = hashlib.sha256(source.encode()).hexdigest()
    if path in additions():
        actual = previous_f86((ROOT/path).read_text(),path).encode() if source == '' else source.encode()
        assert hashlib.sha256(actual).hexdigest() == additions()[path], 'Unreviewed F85 new source: '+path
        return ''
    record = records().get(path)
    if record is None: return source
    if source == '' and path in read_manifest(ROOT/'Tests/F83NewSourceHashes.json'):
        assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest() in {record['before_sha256'],record['after_sha256']}, path
        return ''
    accepted = {record['before_sha256']}
    for manifest in ROOT.glob('Tests/F*ApprovedSourceDeltas.json'):
        version = re.match(r'F(\d+)',manifest.name)
        if not version or int(version[1]) >= 85: continue
        old = read_manifest(manifest).get(path)
        if old: accepted.update([old['before_sha256'],old['after_sha256']])
    if digest in accepted: return source
    assert digest == record['after_sha256'], 'Unreviewed F85 source: '+path
    for hunk in reversed(record['hunks']):
        assert source.count(hunk['after']) == 1, path
        source = source.replace(hunk['after'],hunk['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest() == record['before_sha256'], path
    return source
def historical_source(path): return previous_source(path.read_text(),path.relative_to(ROOT).as_posix())
