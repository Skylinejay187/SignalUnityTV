# Signal F31R1 — build 1137

The supplied log stopped during source checks, before Xcode compilation. The
universal ZIP workflow called Scripts/check_f29_build_identity.py, whose old
assertions still required F29 / build 1135. Both that historical entry point and
check_f31_build_identity.py now call check_build_identity.py. The shared validator
checks the current app, Top Shelf and every project version setting for agreement,
with readable mismatch diagnostics and no historical build pin. Six regression
tests exercise both script names, a future consistent version, and mismatched
app/extension/project metadata.

In the VOD Spotlight Hub Related on Trakt strip, poster cards no longer draw an
additional themed title logo or text title over poster artwork. The original
poster already contains its title. A plain title placeholder is retained only
when the poster is missing. Five-poster layout, sizes, accessibility labels, and
other VOD/media logos are preserved.

App and Top Shelf are both 1.0.1137 / 1137 / Signal-F31R1. This is complete source.
Use it in the same ZIP build workflow as before; its legacy checker call is now
compatible. Full Xcode compilation and Apple TV runtime testing remain pending.

Local checks:

    python3 Scripts/check_f29_build_identity.py
    python3 Scripts/check_f31_build_identity.py
    python3 -m unittest discover -s Tests -p test_build_identity.py -v
    python3 Scripts/check_f31_top_menu_regression.py
