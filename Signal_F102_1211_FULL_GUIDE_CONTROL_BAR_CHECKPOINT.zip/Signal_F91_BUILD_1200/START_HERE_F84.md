# F84 / build 1193

Repairs the failure in the uploaded F83 Actions log: `check_f42_regression.py` rejected `sportsWidgetStyleV1` during the settings coverage assertion. The old settings audit reconstructed the older registry and main app, but read the new F83 scoreboard file as though it had existed in that older build.

The F83 history adapter now checks the exact SHA256 of each F83-added file before presenting it as absent to pre-F83 checks. Repeated historical reconstruction is supported only while the real current file still matches its approved hash. Modified or unregistered files are not silently hidden. Existing source locks remain enforced. A new current-source settings audit separately checks all 221 AppStorage keys against the actual portable/default and excluded settings lists. Negative controls confirm that deleting the Sports backup mapping or modifying the scoreboard source is rejected.

App and widget Swift sources are byte-for-byte unchanged from F83. This update does not change playback, Sports widgets, their styles, IPTV import behavior, images, or any UI. App and Top Shelf build identities advance together to 1193.

The attached log stopped before F83 native widget tests, the repaired organizer SDK check and the full app compilation. No Swift compiler, Apple SDK or device is available here. Local source audits and Python regression results are recorded in F84_VALIDATION.json; the next macOS/Xcode build must still verify native compilation and runtime behavior. This source ZIP is not an IPA or a claim of a successful Xcode build.
