# Stage 28 — Final integration audit (source-only)

- Fixed cold-launch false-first-run routing when a custom Stremio primary manifest is persisted but `store.manifestURLs` has not hydrated yet.
- Matched Settings eligibility with the persisted primary manifest to prevent presenting the wizard to existing custom-Stremio users.
- Removed unused entitlement-key preflight declaration; the restore apply path continues to exclude membership and invitation state.
- Preserved Settings-owned sheet, membership checks, first-run dismissal, playback protection and existing onboarding.
- Not a full tvOS compile or runtime validation. Requires GitHub Actions on the exact source and Apple TV functional tests.
- No website or domain changes.
