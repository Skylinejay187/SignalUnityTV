# Signal F72 / build 1181

Based on verified F71/build1180 ZIP, SHA256 e946719969e2615ea3e359601c2e457997b9aea02787d88e004a5d692553f86b, current version36.

- The selected/focused season chip in Media Information now uses a solid deep red fill and white text. The screenshot's white interior with red outline is removed.
- Pause information defaults to a 1.5-second reveal delay and an independent 1.5-second dismissal delay after resume. Playback transport resumes immediately. The passive card switches from PAUSED to NOW PLAYING during its dismissal hold, then fades/slides/scales away over 0.65 seconds. Re-pausing cancels pending dismissal without flashing. A different source/presentation, ineligible modal/scene or view exit clears immediately. Delayed tasks use cancellation and request leases; the card sends no player commands.
- Settings -> Episode behavior & metadata -> Paused playback card has separate show/hide delay pickers and Signal Glass, Cinema and Minimal card themes. Signal Glass uses a dark gradient panel, slim accent rail, branded title artwork, compact status row and end-time capsule. Cinema uses serif episode/fallback title typography and sharper corners; Minimal removes the panel. Catalog title branding and the no-plot policy remain. There is no live blur or persistent animation timeline. The existing 30-second end-time clock is mounted only while the card is visible.
- All three new preference keys are in SignalPortableSettings, so the normal portable Backup/Restore snapshot includes them.

## Main-surface metadata audit

No second playback-only cache was introduced. The main Unity catalog paths use the shared CatalogStore/SignalMetadataResponseCache and the main catalog hero requests use CatalogHeroMetadataCache. The main LiveTVScreen liveTile reads liveModel.currentProgram(for:), which uses currentProgramCache and programs(for:); programs(for:) uses the bounded 192-entry resolvedGuideRows cache. The same model also retains the lineup browse snapshot and the separate bounded Guide timeline cache. These paths were present and remain unchanged; the new F72 audit follows the main-surface entry points explicitly. The metadata switch description now names main Unity catalogs, main Live TV grid and Guide. This is verified wiring, not a measured FPS improvement.

## Validation

F72_VALIDATION.json records local checks. Existing historical audits reconstruct exact reviewed earlier source; F72 separately checks actual current source, new settings coverage, season fill, pause transitions and main metadata call paths. The pause policy executable tests now include the 1.5-second default, finite delay bounds, same-owner identity and stale/re-paused dismissal rejection. Normal macOS build preparation now also runs the existing native pause policy and actual SwiftUI card/mapping type-check against the tvOS SDK.

Local Swift grammar checking matches the baseline (two pre-existing min parser diagnostics in the large app, none added). No local Swift compiler/Apple SDK/Xcode/Apple TV is available. Native executable tests, full compilation, on-screen typography/transitions, actual remote focus and performance have not been validated here.

## Apple TV checks

Move through seasons and verify red fill/white text. Pause for less than 1.5 seconds: no card should flash. Pause longer, resume and verify immediate playback with delayed smooth card dismissal. Re-pause during the hold and switch source/open settings/background during pending reveal/hide; no stale card should appear. Test each theme and each delay setting, then Backup/Restore the preferences. Check metadata scrolling in main Unity catalogs, main Live TV grid, Guide, and VOD browsing independently.
