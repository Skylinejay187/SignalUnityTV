# Signal F81 / build 1190 — isolate build-test fixtures

Use this package instead of F80. It fixes the five missing-placeholder errors shown in logs_112161670109.zip and Signal_tvOS_build_logs (16).zip. The failure was in F80's new test setup, not application Swift code.

F80's engine lifecycle validation remains intact. All 171 existing Swift files are byte-identical to F80, preserving the F78 artwork cache work and F79 guide/artwork/preview/pause-dimmer changes.

See F81_BUILD_FIX_REPORT.md and F81_VALIDATION.json for the reproduced failure, corrections and validation limits. This is source; full Xcode compilation remains to be run on a macOS runner.
