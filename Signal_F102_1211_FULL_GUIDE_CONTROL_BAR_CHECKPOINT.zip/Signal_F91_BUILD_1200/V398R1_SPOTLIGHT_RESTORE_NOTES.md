# vBRDC398R1 — Spotlight regression rollback and Resume actions

- Restored the original `VBRDC193SpotlightHubPanel` in the media information right-hand surface. Removed the new placeholder-only 12-panel vertical stack that overlaid the movie artwork.
- Preserved the existing Related on Trakt poster strip (74 × 111 points, portrait 2:3) and its real metadata loader. Original Spotlight styling/layout restored.
- Expanded Resume/Continue Watching recognition in focused-poster long-press and context menu to handle row title and alternate row IDs; Trakt history deletion remains a separate confirmed action.
- **Not implemented:** 12 real data-backed, auto-rotating Spotlight themes. No fabricated metadata or placeholder panels are presented as finished.
- Swift syntax parse only; full tvOS build and remote/device test unavailable here.
