# Signal F60 — build 1169

Forward from F59 / build 1168. Adds an optional phone setup page at the beginning of About, now the first card in Settings → General.

## Use

1. Connect Apple TV and your phone to the same trusted home network.
2. Open Settings → General → About → Enable Phone Setup — 10 Minutes.
3. Scan the QR code. Alternatively, open the displayed HTTP address and enter the six-digit pairing code.
4. Paste the entries you want to change, then choose Save entered settings. Blank inputs preserve their current values. A Clear checkbox explicitly clears that entry. Entering an M3U/XMLTV list replaces the entire saved list.
5. After editing sources, choose Import / refresh Live TV. Choose Finish & close connection when done, or disable setup on the TV.

The page supports M3U playlists, XMLTV guides, Channels DVR, HDHomeRun, current Xtream details, metadata/artwork API keys, provider API credentials, addon manifest links, existing restore-code entry, and creating/refreshing/copying a backup code. Saved Xtream accounts remain managed on the TV; a complete edited current connection updates its matching saved account. Connection validity is not implied by saving a field. Provider attachments and playback protection are not enabled or disabled by these fields. Artwork keys are saved to the same local settings; the existing TV action for sending artwork keys to the backend remains available.

Restore and backup use the existing TV functions unchanged. The same restore preflight, portable-setting filters, credential-vault restore and playback-history refresh remain in effect. The phone page displays actual backup/restore messages and busy state; it does not invent progress or claim source connectivity. Restoring deliberately applies the complete saved profile, including its presentation settings. A restore/import accepted before shutdown can finish on the TV after the web session closes. Provider verification is still separate from applying settings.

## Session behavior

The listener is disabled by default and never persists its enabled state, token or PIN. Each activation creates new random credentials and a random local port. A QR fragment carries the session token; the browser removes it from its address and sends it only in authenticated request headers. Manual pairing is limited to eight failed PIN attempts. Stored credentials and source URLs are not read back to the phone; only configured/not-configured indicators are returned, plus the paired backup code needed for copying.

This is local HTTP, not HTTPS. It is intended for a trusted home LAN, not public Wi-Fi. The interface says the connection is not encrypted. It binds a physical Ethernet/Wi-Fi private IPv4 address, rejects public peers, checks Host and Origin, exposes no arbitrary files/defaults, provides no CORS access, uses no external web assets and sends no-store/referrer/CSP headers. IPv6-only LANs are not supported by this first implementation. No Bonjour service, router forwarding, new backend service or web theme/icon controls are added.

The fixed deadline is 600 seconds from activation, measured with system uptime. Pairing, polling and saving never extend it. Request admission and execution check that deadline independently of the countdown. The listener, connections, receive deadlines, countdown and handlers are released on expiry, Disable, Finish, leaving About or leaving the foreground. Maximum six concurrent connections, an eight-second connection deadline, 16 KiB headers, 128 KiB bodies and 1,200 requests per session bound resource use. Only the small section observes the one-second countdown; its QR rendering is cached through an Equatable child. No player, preview decoder or always-running service is created.

## Validation

Executed here: 21 Python source/regression checks, six build-identity tests, actual bundled JavaScript flow tests with a simulated DOM/HTTP transport, script/shell syntax, Swift grammar comparisons, exact source-delta/unchanged-file checks, ZIP CRC and every-entry/source byte verification. The JS tests cover QR/manual pairing, wrong PIN, scoped saves, explicit clearing, blank secret inputs, addon entry, HTTP clipboard fallback, restore busy state, Finish and lost connection.

Production changes in the existing App file are confined to SettingsScreen. All other 141 prior Swift files are byte-identical. Entire Search, VOD player/F57 continuity fix, Live TV, Guide, media information, network/proxy policy and original backup/restore implementations are unchanged. AetherEngine 7.44.0 and Kingfisher 8.11.0 remain pinned. Five new source files implement the schema, protocol, page, server and About section.

Pending: actual Swift protocol test execution, native tvOS SDK type-check, full Xcode build, real LAN connections, physical QR scanning/copy behavior, visual browser rendering and Apple TV navigation/lifecycle tests. This environment has no Swift compiler, Apple SDK or installed browser executable. The supplied macOS preflight compiles production parser/schema tests and type-checks the actual server, section and extracted Settings action handler against the tvOS SDK. The JavaScript fixture is not a real browser or native transport test.

Device checks: enable and scan from iPhone and Android; use manual PIN; save a playlist/key and verify immediate TV/backup consistency; blank-save preservation and explicit Clear; addon entry; backup creation/copy; restore success and invalid-code rejection; source import; disable and immediate reconnect with a new token; expiry while idle and while sending requests; leave About and background the app; confirm no listener after relaunch and no effect on normal playback.
