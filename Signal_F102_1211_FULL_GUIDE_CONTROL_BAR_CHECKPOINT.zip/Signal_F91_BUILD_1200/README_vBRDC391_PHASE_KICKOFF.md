# vBRDC391 — Phase kickoff / foreground popup depth checkpoint (NOT FINAL)

Base: vBRDC390 MEDIA_LAYER_DEPTH_CHECKPOINT_NOT_FINAL. No older build substituted.

## Implemented in this checkpoint
- Media Information now has a bounded dark foreground surface rather than a fully transparent/dissolving panel; previously shadows alone could not convey a separate layer.
- More distinct foreground edge and stronger catalog dimming.
- More pronounced entrance scale and small depth translation, while retaining the panel dimensions, connector coordinates, raised header layout, focus, playback behavior, and existing popup content.
- Previous connector shadow/glow treatment carried forward.

## Phase v391 — pending implementation and verification
- Universal Up Next: robust Aether end-of-file, near-end, seek, resume, buffering and next-episode handoff; no dependency on skip databases; no double-launch.
- Skip Intro/Recap/Credits: audit existing LocalIntroDetectionEngine and provider clients, verify public API terms, stream-duration validation, cached markers, conflict handling, fallback for missing markers.
- Carry forward unfinished v390 stabilization: first-load themed logos, Kingfisher request ownership, Spotlight artwork, resume show-level deduplication, Trakt long-press removal + remote synchronization, full Normal/Performance/Turbo wiring, catalog endpoint privacy and customer-facing build-history cleanup.
- Preserve Aether, timeshift, trailers, Live TV, top menu focus and ambient suspension regression locks.

## Validation
Swift frontend parse succeeded. Full Xcode build, runtime screenshot/visual test and hardware performance measurements NOT performed. Popup effect is a stronger visual candidate, not a verified visionOS-equivalent spatial window. This is NOT the completed v391 phase.
