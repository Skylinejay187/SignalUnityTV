# vBRDC392 — Phase 1, Step 3: VOD artwork reveal recovery

Base: vBRDC392_UPNEXT_HANDOFF_GUARD_INTERMEDIATE.zip (includes v392 artwork lifecycle and v391 carryovers).

Source changes:
- On showing the foreground VOD controls with the first frame ready, post a scoped artwork reveal notification.
- Mounted `RemoteImageFit` views explicitly marked for foreground playback retry only if their bitmap is missing and they have a valid URL.
- Do not reload existing artwork, restart the overlay, reset focus, or flush global caches.

Verification: Swift syntax parse passed. Full tvOS/Xcode typecheck and physical Apple TV long-session test NOT performed. Step 3 is source-patched, not device-verified.

Phase 1 status: Step 1 source-patched/device test pending; Step 2 source-patched/device test pending; Step 3 source-patched/device test pending; Steps 4–8 pending.
