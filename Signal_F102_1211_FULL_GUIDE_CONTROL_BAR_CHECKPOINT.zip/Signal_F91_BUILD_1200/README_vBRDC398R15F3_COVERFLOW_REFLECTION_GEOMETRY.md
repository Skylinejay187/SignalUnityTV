# vBRDC398R15F3 — Cover Flow reflection and symmetry patch
Base: vBRDC398R15F2. App/TopShelf/project version 1.0.1118 (1118).
- Removed full-width black floor gradient which appeared as a rectangular slab beneath cards.
- Clip each reflected poster to its own rounded card outline before/after mirroring, retaining vertical fade.
- Use mirrored side slot geometry and symmetric visible-neighbor count; even catalog counts omit the antipodal duplicate.
- Removed explicit image view `.id` on side posters to reduce unnecessary image view teardown during row changes.
- Preserve catalog ownership, focused preview player, Media Information clearance, circular index navigation and Classic Rows.
Validation: Swift frontend parse passed; XML plist checks and ZIP integrity performed. No Xcode compilation or Apple TV visual testing. Flashing from uncached artwork cannot be conclusively fixed without device/cache profiling.
