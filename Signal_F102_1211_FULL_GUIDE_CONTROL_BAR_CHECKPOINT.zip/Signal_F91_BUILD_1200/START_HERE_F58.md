# Signal F58 — build 1167

Forward from F57/build 1166. Addresses Search results that could not be reached/scrolled downward after a successful query.

## Focus and scrolling correction

Search result cards are now native plain Buttons with a bounded focus section. The old generic focusable card/tap-gesture combination is removed. The compact landscape artwork, sideways focus effect, dark surface and lazy rendering remain unchanged.

The filter chips explicitly hand Down to results and Up to the query. Left/Right retain focus-only filter navigation until Select activates a filter. Done/Down before remote results finish now retains its intent; when results publish, the handoff proceeds instead of remaining at the header.

The grid has an explicit D-pad fallback for all four directions, using the ID of the card that received the command. It computes one legal row/column step and scrolls an offscreen target into the lazy viewport. The scroll task no longer guesses that a destination has mounted after two yields. Instead, the target Button's own scoped lifecycle task assigns focus once it is mounted, checking request generation, target identity, cancellation, active scene/surface, current detail and query ownership. A superseded request cannot steal focus. Partial last rows clamp to an actual item; boundaries do not wrap. Up from the first row returns to the filter chips. Query changes, closing Search and backgrounding cancel pending handoffs. Returning from Media Information explicitly restores the selected result after checking current ownership.

Offscreen fallback scrolling uses a short 180 ms ease-out; Reduce Motion disables that animation. Native focus scrolling still handles ordinary available neighbors. No extra player, polling loop, image decode size or new preference is added. Cards remain 16:9, capped at 360 × 202.5 points with a 768-pixel artwork request.

## Preserved scope and validation

Only GlobalSearchScreen and the pure Search layout/navigation helper change in production Swift. The other 139 prior Swift files are byte-identical. The entire VOD player, F57 no-restart protection logic, network/router/engine/bridge code, Guide, red season outlines and Search result-card styling are preserved. Async query/debounce/cancellation, selected-source hydration and settled-focus prefetch functions remain unchanged. AetherEngine 7.44.0 and Kingfisher 8.11.0 remain pinned.

Executed locally: all available Python preflight checks; a new current Search focus guard which rejects the previous F57 Search as a negative control; exact source-delta/unchanged-file verification; six build-identity tests; no new Swift grammar errors; current UI fixture/native test grammar; script/shell syntax and complete ZIP/source integrity. See F58_VALIDATION.json.

The macOS preflight adds actual navigation-helper tests over complete/partial grids, boundaries and long-list traversal. The existing tvOS SDK fixture now type-checks the actual native-Button grid and all new focus/scroll/helper methods. These native tests, SDK checks and full Xcode build have not run here: this environment has no Swift compiler or Apple SDK. Physical Apple TV focus behavior remains unverified.

Device checks: search for a title with many results; press Done both before/after completion; Down from the query and each filter; navigate through offscreen rows to the partial last row; Up to filters/query; change filters and query during a pending move; open/close Media Information; test Reduce Motion; repeat Search over VOD/Live playback. Confirm F57 playback behavior remains stable.
