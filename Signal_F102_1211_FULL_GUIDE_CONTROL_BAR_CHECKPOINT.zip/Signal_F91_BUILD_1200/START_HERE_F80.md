# Signal F80 / build 1189 — engine lifecycle build-check fix

Use this package instead of F79. It fixes the pre-generation Python assertion shown in logs_112132395209.zip and Signal_tvOS_build_logs (15).zip. All 171 existing Swift files are byte-identical to F79, preserving the recent Gracenote disk restore, VOD Quick Guide timeout exclusions, 1.5-second VOD focus dwell, optional pause dimmer and F78 Kingfisher work.

Read F80_BUILD_FIX_REPORT.md and F80_VALIDATION.json for the exact fix and results. This is source, not a compiled tvOS app; full Xcode compilation still needs a macOS build runner.
