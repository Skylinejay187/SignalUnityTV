# vBRDC393 — Up Next 30-second cinematic follow-up

- At approximately 240 seconds remaining, the original Up Next choice appears.
- 30 seconds of actual playback progress after its first appearance, a second-stage cinematic reminder displays even if Back dismissed the first popup.
- Second-stage artwork, heading, 10-second countdown, progress bar, Play Now and Cancel Auto Next follow the supplied reference layout.
- When Auto Next is disabled or explicitly cancelled, the cinematic reminder does not arm.
- The 10-second countdown can intentionally skip the remainder of the episode. If a source is not ready, the app must wait and show a preparing state rather than start an invalid URL.
- Provider resolution is intentionally held until playback is paused/stopped to preserve decoder smoothness. If source is not ready at the end of the 10-second countdown, playback pauses while preparing. Test this transition on actual Apple TV hardware.

## Device tests
1. Regular 40–60 minute episode: first popup around 4:00 left; second reminder around 3:30 left.
2. Dismiss first popup with Back: second reminder still appears.
3. Cancel Auto Next: no automatic handoff; current episode remains available.
4. Play Now starts the correct next episode only when source is ready.
5. Let the 10-second timer expire: next episode starts if prepared, otherwise shows Preparing and waits for a valid source.
6. Disable Auto Next: no second reminder.
7. Test remote focus, playback continuity, source failures, and repeated episodes.
8. Verify the existing v393 Resume/Trakt and Unity transparency features remain intact.

Swift syntax parsing is not a full tvOS build. Xcode compilation and physical Apple TV verification remain required.
