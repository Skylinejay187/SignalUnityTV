# Signal F53 — build 1162

Forward from F52/build 1161. Fixes the build failure in the supplied `logs_109408487221.zip`.

## Failure and correction

The F52 workflow stopped during `Scripts/check_f41_geometry_math.py`, before the full Xcode build. That Python audit still expected the earlier independent-axis fitting expressions. F51 introduced a shared fitting helper with Swift `uniform ? ... : ...` expressions, separate fit scales and centering offsets. The old audit sent the Swift ternary directly into Python's expression parser and failed with `SyntaxError`.

The audit now translates the current uniform-selection expression within its restricted numeric evaluator, evaluates the production fit scales and centering offsets in dependency order, and independently checks both fitting paths. It compares all four projected corners against a separate rotation/perspective calculation, checks finite positive projection, bounded centered geometry and repeated row gutters. All 28 themes, four columns, focused/unfocused poses, three sizes and both fits are covered: 1,344 cases.

Three regression tests run in the normal macOS preflight. They accept the current production coefficients and deliberately mutate the Swift source to confirm that a stretched uniform fit and a misplaced centering offset each fail. No check is skipped or weakened to pass the build.

All 137 Swift files are byte-identical to F52. F52's smooth Guide/header blend, F51's home/away routing and aligned renderer, F50 popup strength, VOD cache updates, Up Next and playback behavior remain unchanged. AetherEngine stays 7.44.0; Kingfisher stays 8.11.0.

## Verification

Local validation includes the real-source geometry audit, its three positive/negative regression tests, available Python preflight checks, six build-identity tests, shell/Python syntax, exact Swift-source preservation and ZIP integrity. See F53_VALIDATION.json.

The supplied macOS log confirms F52 passed its initial Swift syntax stage, the quick-guide semantic check, Search native type-check and Up Next dismissal executable before this audit failure. It does not establish that the later routing/alignment native checks or full Xcode build passed. No Swift compiler/Apple SDK is installed in this environment, so F53's complete macOS preflight, full Xcode build and physical Apple TV verification remain pending.
