# vBRDC398R4 Cover Flow visual refinement
- Source base: vBRDC398R3F1.
- Cover Flow focused card uses landscape art (poster fallback); surrounding cards use portrait art (landscape fallback).
- Softer 15-degree side-card rotation, tighter spacing, 11 visible cards, subtle reflection on black-glass floor.
- Removed the Cover Flow portrait/landscape setting control. Classic Rows remains available.
- The row's selected index remains the centered item; existing selection/focus behavior preserved.
- Scope: shared VOD catalog rail only. Live TV grid and Spotlight untouched.
- Validation: Swift syntax parser only, no Xcode typecheck/device test.
