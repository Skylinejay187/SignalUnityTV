# Signal F40 — Build 1149

Version **1.0.1149**, patched forward from F39 / 1148. This source package fixes the two fatal compiler diagnostics in the supplied logs and makes Up Next dismissible in every rendered state. Build it with the existing ZIP workflow.

## Logged build failure

Both errors came from `SignalSearchGlyph.swift`: the new UIView subclass declared a private stored property named `focused`, colliding with UIKit's inherited focus property. Its stored state is now named `glyphHasFocus`, with all reads/writes updated. The Search renderer otherwise remains unchanged.

The existing `Scripts/check_f28_source_preflight.sh` is called by the universal ZIP workflow shown in the supplied Actions logs. It now also type-checks the standalone Search view against the real tvOS SDK, then runs the F40 source contracts and executable dismissal-state tests. This catches UIKit inheritance/type errors before engine installation and the long full-app build. Syntax parsing alone did not catch the original collision.

## Up Next can be closed

- Normal and cinematic Up Next use the same always-enabled **Dismiss** button. The label does not disappear or change to Cancel Countdown. Missing episode/preparation metadata renders a fallback panel containing that same button.
- Back/Menu on either panel calls the same dismissal handler as the button. Left/Right and Up/Down can reach Play and Dismiss. Dismiss remains available while Play is disabled or a source is loading/unavailable, including season boundaries.
- The invisible player canvas is excluded while Up Next owns focus. Source readiness cannot force focus from Dismiss back to Play. Panel focus work belongs to a cancellable view task, replacing the old unguarded delayed callback.
- Closing an early reminder hides it for the rest of the playing episode and preserves the existing automatic-next preference at natural EOF.
- Closing the end-of-episode panel stops its countdown, cancels pending source/retry/decorative work and prevents delayed callbacks from reopening it or replacing the player. Further EOF callbacks cannot reset that choice. The underlying player controls regain focus so Back can leave normally.
- If no next episode exists, stale panels/countdowns are released and ordinary player controls are shown. Dismissal does not depend on having a successor episode, a playable URL or complete season metadata.
- Natural-end watched-history bookkeeping still finishes after its decoder-settle window, even if the EOF panel was closed. A completion flag prevents duplicate EOF events from running this bookkeeping again.

The existing >1 GB source rule, source mixing, Aether engine/bridge/host, Live TV/timeshift behavior and the F39 smoke/catalog/Search/2.0-second preview changes are retained.

## Verification

Local checks passed: current F40 contracts, exact historical F31–F39 projections, 107 unchanged Swift-file hashes, six build-identity tests, seven redaction cases, remote-thumbnail safety, 22 FastZap wiring checks, workflow YAML and preflight shell syntax. Of the 220 tracked VOD functions, 206 are byte-identical to F39; the 14 changes are scoped to Up Next presentation, dismissal, focus and callback ownership. Reviewed deltas preserve the original historical fixtures.

**Not run locally:** Swift compiler/type checking, the executable Swift dismissal tests, full Xcode compilation or physical Apple TV testing. This workspace has no Swift/Xcode/Apple SDK. The enhanced macOS preflight performs the real type check and executable tests before the full build. The included validation record distinguishes local source checks from build/runtime verification.

After a successful build, test Dismiss and Back with ready sources, loading/no sources, the last episode of a season, no successor episode, and both panel layouts. Also close while a provider response is pending, wait past the former countdown, and confirm no reopening or automatic handoff. Verify that dismissing only the early reminder still allows the configured EOF autoplay behavior. Previous F39 visual/focus changes still need physical-device verification.
