# Signal F54 — build 1163

Forward from F53/build 1162.

The Guide hero's extra dark scrim now starts transparent beside the category rail and fades gradually into the existing black surface. This removes the abrupt vertical dark boundary indicated in the screenshot, using the same static gradient already present. F52's top fade remains. Labels, category chips and timeline cells are not masked; layout, focus, rail collapse and video ownership are unchanged. No additional blur, mask, timer, animation or decoder is added.

The season focus outline changes from cyan/blue to red in both the compact Media Information episode section and the shared full season row. Existing selected-season fill, text contrast, focus movement, scrolling and episode filtering stay unchanged.

Only these three decoration changes affect production Swift. The F53 geometry-preflight repair, F51 home/away routing and aligned renderer, popup strength, cache updates and Up Next behavior remain intact. AetherEngine 7.44.0 and Kingfisher 8.11.0 stay pinned.

Local verification: exact source-delta and unchanged Swift comparisons, no new Swift grammar errors versus F53, relevant Guide/browsing/routing regression checks, geometry audit and its negative controls, build identity and ZIP integrity. See F54_VALIDATION.json. Native compilation and physical Apple TV visual verification remain pending; no Swift compiler or Apple SDK is available here.
