# Signal tvOS vBRDC398R12 — Cover Flow placement and black-glass reflection

Base: vBRDC398R11 measured Dexter Cover Flow.

Changes:
- Move the whole Cover Flow quick-panel group down 34 tvOS points, including current row header, cards and next-row header. Classic layout unaffected.
- Strengthen the lightweight, image-only Cover Flow mirrors (gradient alpha 0.67 -> 0, 60 reference-pixel fade length), including the focused backdrop mirror, without spawning a second player.
- Increase the black-glass floor under the reflection while keeping the floor transparent and avoiding an opaque slab.
- Preserve 1.5 degree focused-card perspective, original focus card/player, logo and Siri Remote interactions.
- No changes to Up Next, Live TV or Classic row reflections.

Validation: Swift syntax parse only on Linux; Xcode build, runtime geometry and Apple TV screenshots still required.
