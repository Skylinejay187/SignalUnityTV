# F85 / build 1194 — iSportsurge on-device playback test

This is the next device-test source build after F84. A video filename is not used to identify an event. The adapter reads the event title, teams, league and dated Eastern Time kickoff from the event page. Scores attach only when both full team names, the supported league and a kickoff within 15 minutes match exactly and uniquely. Uncertain matches remain named events without an attached score. Women's college basketball has been added to the ESPN feed list.

## Try it

1. Build and install using the existing macOS/Xcode workflow.
2. Open Sports. Online Sports rows populate from the iSportsurge catalog without an IPTV subscription. Existing IPTV/Sports rows remain below them.
3. For the supplied sample, choose Sports Playback Test → UNLV Rebels vs USC Trojans. The event may have ended by installation time; also try a current event in Online Sports → Live Now or its league row.
4. The full-screen Sports view resolves the page's current supported embedded player and current signed HLS URL on the device, then passes it and the observed request headers directly to PlaybackKitAetherHost. No central backend or MediaFlow route participates in this new Sports path.
5. Check first picture and audio, Pause/Play, Retry, Next Source when multiple player IDs exist, Menu/Back and Close. Move the remote to reveal controls after they hide. Retry obtains a new source rather than replaying a stored URL. Verify return to the same Sports row/card and that the dashboard preview resumes cleanly.
6. Background/foreground the app. This Sports view releases its player while inactive and obtains a fresh source on return, retaining the user's Play/Pause intention.

Existing membership eligibility is checked before resolution and again before native playback. Leaving the Sports owner or losing membership dismisses this player. Signed playback URLs are in-memory only, per attempt. Catalog metadata is cached for 60 seconds and bounded to 120 events, paginated into rows of 48. Only selection resolves playback; scrolling does not start hidden player sessions. Resolution uses an ephemeral session with a 25-second budget, bounded response sizes, known provider/CDN host checks and cancellation. HTTP 429 stops fallback attempts immediately. The player has a 20-second first-frame timeout, followed by manual Retry/Close; it does not automatically restart a stream in a loop.

The existing Glass scoreboard style now has a more transparent background and a light edge. No new blur/timeline/GPU animation was added. The player score overlay refreshes only its supported league while controls are visible and the scene is active. Existing user settings/Backup & Restore and the rest of the artwork pipeline are unchanged.

## Verification and limits

The preceding Linux HTTP test freshly discovered the supplied event, fetched both playlists and a real video segment, and decoded three seconds with FFmpeg without errors: H.264 1280×720 at 30 fps; AAC stereo at 48 kHz. That established source-format viability at that moment, not native AetherEngine or Apple TV compatibility.

F85_VALIDATION.json records local checks; F85_GRAMMAR_CHECKS.json distinguishes tree-sitter grammar checks from compilation. Swift/Xcode/Apple SDK and an Apple device are unavailable locally. Full app compilation, the new native production parser/URLProtocol transport tests, isolated tvOS UI typechecking and actual device playback have NOT been run here. The native checks are required early in both preflight entry points, not silently skipped on the runner.

This test build supports the observed iSportsurge → gooz.aapmains.net public-player path. It does not execute site JavaScript, request popup ads, refresh hidden ad impressions, or remove ads inserted into video. New upstream/CDN domains, authentication challenges or changed player markup may require an adapter update. The source's text/plain segment response is passed to the unchanged Aether transport; native handling still needs a device test.

CrackStreams/MethStreams provider fallback adapters and KSPlayer have not been added in this test build. Multiple player IDs on one event do not establish independent providers. Online Sports launch is currently limited to the main Sports section; opening another primary player over existing VOD playback is blocked to prevent double audio. Existing VOD, Live TV, shared catalog rail, Aether bridge/engine, timeshift, amplification, trailers and caching code are preserved byte-for-byte.

The viewer's current network is used. A home IP is used while at home; cellular, hotel or VPN egress is used on those connections. There is no mechanism that forces someone away from home through your NAS.
