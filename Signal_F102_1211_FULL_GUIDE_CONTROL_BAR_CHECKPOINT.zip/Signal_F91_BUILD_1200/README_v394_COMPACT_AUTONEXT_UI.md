# v394 compact Auto Next UI checkpoint

- Replaced large centered Auto Next modal with compact bottom-left 700pt indication.
- Retains next-episode artwork, title, season/episode, countdown, Play and Cancel.
- Does not change the source handoff: `playPreparedUpNextEpisode()` consumes the same `upNextPreparation.primaryURL`, ranked links and HTTP headers already resolved by Up Next, without a fresh lookup when sourceReady.
- Important limitation: if `upNextPreparation.sourceReady` is false, the source has NOT actually been resolved/cached; current source resolution defers provider work during active video decoding. This is not yet a full solution to missing prepared links. Do not treat this as complete Phase 3.
- Swift parser check only; no Xcode compile or Apple TV testing.
