# vBRDC392 — Aether migration / long-playback VOD overlay kickoff (INTERMEDIATE)

Base: vBRDC391_SKIP_LOOKUP_LIFECYCLE_INTERMEDIATE.zip.

Implemented in this checkpoint:
- Removed hidden-VOD-chrome per-auto-hide image-request cancellation in DebridChannelsTVOSApp.swift. SwiftUI may keep VOD chrome mounted for hours, so cancelling network image work without remount/retry could strand images blank on reveal. Existing bounded image cache and playback teardown remain.
- Preserved v391 skip duration lookup patch and existing Unity glass changes from source.

NOT implemented / NOT verified:
- Full Aether-only conversion, removal of KSPlayer, duplicate FFmpeg dependencies.
- Up Next / Auto Next end-to-end reliability, Skip Intro/Recap/Credits validation, Trakt and Resume fixes.
- Apple TV hardware visual test or complete Xcode/tvOS typecheck/build. Swift syntax parse only.

Regression locks: retain catalog row position, popup translucency, Media Connector placement, playback state and Live TV/timeshift.
