# vBRDC393 Up Next early presentation adjustment

- Show Up Next when approximately 240 seconds remain in normal episodes, with a 30% duration cap for short episodes.
- Start next-episode metadata identity resolution at 300 seconds remaining instead of 180, to improve readiness before the display window.
- Evaluate presentation during playback from 240 seconds remaining instead of 120.
- Preserve the existing behavior of delaying provider source resolution until the player is paused or has finished, to avoid decoder starvation.
- Preserve automatic handoff timing at the last 15 seconds/EOF, not at four minutes.
- When identity lookup fails or no next episode exists, no Up Next is displayed. User device verification required.

Validation: Swift syntax parse only, not an Xcode build or Apple TV playback test.
