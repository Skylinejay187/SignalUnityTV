# F78 / build 1187 — Kingfisher artwork cache optimization

Based on the attached, verified F77/build1186 archive (SHA256 `7cf508ecddc2deacf8da3494376e4a4e49af970bac16ff7e10c77bbc7ad29e4a`). Kingfisher remains pinned to 8.11.0. The NAS WebP assets, content-hashed URLs, Cloudflare routing and immutable delivery headers are unchanged. No CatalogServer work or backend deployment is included.

## Actual causes found in F77

1. Visible images used KingfisherManager; speculative prefetch and detail prewarm used a different URLSession. Their source bytes were written into a 768 MiB .art store and/or a separate 1 GiB HTTP cache. The visible Kingfisher path never read those originals. Prefetch could therefore download a poster and the later visible request could download it again.
2. The Kingfisher resource key included the URL, decode bucket and surface domain. No cacheOriginalImage/originalCache was configured. Later size/domain presentations could miss their separate processed entries and fetch the same source again. Simultaneous visible requests could still be coalesced by Kingfisher's existing downloader; the problem was not a guaranteed duplicate for every concurrent request.
3. The 15-second Kingfisher memory expiry increased disk work after short gaps. It did NOT alone imply a CDN download: a valid exact processed disk entry could still satisfy the request.
4. Original-byte prefetch allowed six speculative HTTP tasks. Its proxy-origin fallback kept a completed fallback task in the active map and wrote origin bytes under the failed proxy URL. Detail prewarm callbacks also lacked the visible loader's request-token checks.
5. Additional safeguard while enabling original reuse (not an already-active F77 original-cache path): inspection of pinned Kingfisher 8.11 found its standard original-cache .image downsampling path re-encodes the full source image before resizing. F78 supplies cached original bytes to the SAME Kingfisher downsampler on the utility queue, retaining its exact processor identifier and output sizing. This avoids that unnecessary full-size re-encoding when encoded bytes remain available; fallback processing is preserved.
6. CatalogArtworkCacheManager.swift only selects URLs/themes. It contains no download transport and does not need modification.

## Exact changes

Only the existing production file Sources/RemoteImageFit.swift changed. Its PremiumArtworkURL enum, RemoteImageFit view and aspect modifier are byte-for-byte preserved. All 168 other pre-existing Swift files, including the main app, all player/engine/preview code and CatalogArtworkCacheManager.swift, are unchanged.

| Item | F77 verified configuration | F78 |
|---|---|---|
| Visible / prefetch / detail prewarm | Separate transport/cache paths | Same pinned Kingfisher downloader, original store and request helper |
| Encoded original identity | Prefetch .art store, not consumed by visible path | Exact absolute URL; no added parameters or query stripping |
| Processed identity | URL + size + domain + processor | URL + Kingfisher processor identifier; app's decoded domain isolation retained |
| Kingfisher processed disk | 256 MiB; default 7-day sliding expiry | Same existing cache name, 256 MiB; 30 days normally, 365 days for query-free hashed /assets objects |
| Kingfisher originals | Not retained by visible requests | Shared 384 MiB disk cache with the same expiry policy; cacheOriginalImage + originalCache |
| Kingfisher processed memory | 8 MiB / 24 entries, 15-second visible expiry | Same 8 MiB / 24 entries, 60-second expiry |
| Original decoded retention | No common original cache | Original cache memory cost ceiling 1 byte / 1 entry; no extra full-size bitmap reservoir |
| App decoded caches | Persistent 96 MiB; sports/favorites/return 16 MiB each; VOD ceiling 32 MiB | Existing limits retained; eviction diagnostics added |
| Speculative prefetch | Six URLSession jobs / up to 24 ordered URLs | Two lower-priority 320px jobs / same ordered 24-URL bound; respects existing background-prefetch lane |
| Catalog HTTP cache | Separate 16 MiB RAM / 1 GiB disk URLCache | Retired from this loader; Kingfisher original disk is authoritative; downloader URLCache disabled |
| Disk lookups | Default cache-type checks | asyncCacheTypeCheck: no caller-thread disk stat; existing utility processing queue retained |
| Cache write race | Different sizes could miss original bytes | waitForCache completes after Kingfisher cache writes |

The existing source-byte API used by Live TV now reads/writes Kingfisher's original store, while its Live TV-specific decoding, playback and fetch registry remain intact. Existing .art originals migrate on access; valid old processed entries migrate at their exact requested size. F77 entries cannot supply original pixels they never retained: an uncached new size can still need one first download when only a smaller legacy processed entry exists.

The new full-size identity processor performs DefaultImageProcessor processing without resizing; its non-default identifier lets Kingfisher retain original bytes even for callers without a size cap. All existing card/search/Cover Flow/Spotlight/Media Information decode budgets are retained.

Cancellation covers async cache lookup shells and downloads, prefetch ownership, detail prewarm promotion, background/playback boundaries and stale completions. Proxy-origin fallback keeps the origin's own identity. Corrupt/raced cache reads get bounded repair; HTTP 404/410 results have a bounded 60-second negative cache. Other transport failures remain eligible for the existing view-owned retry policy. Memory pressure clears decoded caches and speculative work, not original disk bytes.

## Diagnostics

`PremiumRemoteImageLoader.artworkCacheDiagnostics()` / `SignalArtworkDiagnostics.shared.snapshot()` returns numeric, process-local counters. Summaries are logged as `[ArtworkCache][F78]` on background/memory-pressure events. There are no poster URLs, account credentials, polling timers, new settings, SwiftUI publishers or diagnostic overlays.

- decodedMemoryHits, mountedImageReuses: app-side immediate reuse.
- kingfisherMemoryHits / kingfisherDiskHits: actual cache retrieval events, including originals.
- sourceDiskHits, legacySourceHits, sourceByteReuses, legacyProcessedReuses, rawDownsampleReuses.
- networkTransfers / networkBytes: successful underlying downloader data transfers, counted once per URLSession transfer, not once per view or decoded size. Failed HTTP requests are NOT included in these successful-transfer counters; the native HTTP fixture separately counts every request.
- cloudflareHits / cloudflareMisses: only when the actual response provides CF-Cache-Status. HIT still means bytes were downloaded from Cloudflare; it is not a local cache hit.
- prefetchReuses: a later visible request reuses a URL successfully handled speculatively; this is not an independently measured bandwidth-saving figure.
- decodedEvictions: NSCache delegate events from app decoded caches; diskEvictions: Kingfisher cleanup notifications. Explicit memory clearing and OS deletion of files cannot be inferred as exact eviction counts.
- requestCancellations, cacheRepairs, negativeCacheHits, memoryPressureEvents, loadFailures.
- meanLoadMilliseconds, loadMaxMilliseconds, four latency buckets, localLoadHitRatio. The ratio covers completed ordinary helper requests (early negative-cache responses are counted separately), not all app image presentations; immediate app decoded hits are separately counted.

## Verification actually performed here

- 34 source checks passed (F78_SOURCE_CHECK_RESULTS.json), plus separate F43 and F73 historical contract checks.
- Current F78 checks inspect CURRENT production wiring and reject four bad mutations. Historical checks reconstruct exact prior reviewed source; their old configuration descriptions are not F78 performance claims.
- All 168 other pre-existing Swift files match F77 hashes. The complete image view and URL-routing blocks match F77 exactly.
- Source-target membership and bridge parity passed; build identity matches app/Top Shelf/project. Five prior F75/F76 regression tests and six build-identity unit tests passed.
- Swift grammar parsing: no errors in the changed artwork file, generated actual-method fixture and both new Swift test files. Python and shell syntax checks passed.
- Final archive is checked entry-for-entry against the source tree, CRC-tested and SHA256-recorded.

## Native checks supplied, NOT executed here

No Swift compiler, Xcode or Apple SDK is installed in this environment. Full Xcode compilation, real Kingfisher transport execution, Apple TV/iOS visual testing, FPS/hitches, CPU and RAM profiling have NOT been performed. No before/after device measurements or percentage improvement are claimed.

Normal macOS build preparation now runs `python3 Scripts/check_f78_native_artwork.py`. It compiles the production shared transport + source-cache methods against real Kingfisher 8.11.0, serves a synthetic WebP over a loopback HTTP server, and runs separate processes:

| Test | Assertion / expected result — NOT a measured result from this environment |
|---|---|
| Prefetch then 320/384/640/1024/full-size presentations | One successful source transfer |
| Two simultaneous new sizes of a second URL | One shared transfer; independently sized images |
| New process, existing disk files, server refuses all requests | Zero HTTP requests, including a new decode size |
| Corrupt processed entry | Repair from original bytes, zero downloads |
| Legacy .art and exact-size processed migration | Zero downloads while valid legacy bytes exist |
| Missing image requested twice | One HTTP request, second request negative-cache hit |
| Slow cancelled request | No callback publication after cancellation |
| Corrupt original with no processed copy | One successful replacement transfer |
| Disk size eviction | Actual Kingfisher cleanup notification observed |

The same script builds the FULL actual RemoteImageFit.swift as temporary tvOS 18 and iOS 17 frameworks with the real pinned dependency; only unrelated app-global frame/playback gates are stubbed. Output is saved to `.build-cache/F78_NATIVE_ARTWORK_RESULTS.json` and printed in build logs. These are transport/API integration checks, not visual focus or playback tests. The deliverable remains the existing tvOS project, not a new complete iOS application.

## F77 versus F78 device test plan

Use the same Apple TV, Release settings, account, catalog and network. Profile F77 first, then F78; retain native logs and Instruments traces. Distinguish a first cold cache from subsequent warm visits. Do not infer actual RAM from configured NSCache cost limits.

1. First catalog opening: time to visible posters, successful HTTP transfers/bytes, CPU, peak memory.
2. Revisit the same catalog and switch Home/Movies/TV Shows: cached unchanged posters should require no extra CDN transfer while originals/processed files are available.
3. Fast-scroll multiple rows: measure hitches/long frame intervals and observe that obsolete prefetch stops; check focus and appearance are identical.
4. Open/close Media Information repeatedly: measure original reuse across different decode sizes, retained-image continuity and memory plateau.
5. Navigate Cover Flow and Spotlight: verify size, sharpness, reflections, logos and animation remain unchanged.
6. Relaunch and revisit: measure disk hits and network requests; compare the same source's other size variants.
7. Memory pressure: simulate warnings, then verify decoded caches can repopulate from disk without unnecessary downloads. Real tvOS disk eviction is a distinct test.
8. Slow/offline internet: cached posters remain available; uncached posters fail/retry gracefully; restore connectivity and retry.
9. Regression smoke: Live TV preview/playback entry/exit, VOD/trailer return, subtitles, gain, seek, Up Next, themes and restore behavior. Their implementation is hash-identical, but device integration still needs confirmation.

## Remaining limits

- tvOS/iOS can purge Caches storage; finite disk caps/expiration also evict entries. Local caching cannot promise permanent retention or zero lifetime downloads.
- Each new device needs its own first download. CDN HIT traffic still transfers bytes; this patch does not make all users share one device cache.
- The Live TV-specific fetch registry remains separate. Committed original bytes are shared, but an exactly simultaneous cold miss in that separate URLSession path and the catalog downloader can still race. No cross-engine/player rewrite is introduced.
- No server, Cloudflare, content-hash scheme or app presentation was changed. No measured user-scale throughput, monthly bandwidth, CPU reduction or frame-rate improvement is asserted.
