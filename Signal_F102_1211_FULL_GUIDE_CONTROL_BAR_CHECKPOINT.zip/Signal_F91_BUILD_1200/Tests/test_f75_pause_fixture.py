#!/usr/bin/env python3
"""Regression for the missing Quick Guide state in the real pause mapping fixture."""
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'Scripts'))
from check_f63_native_pause_info import fixture, validate_fixture


class PauseMappingFixtureTests(unittest.TestCase):
    def test_current_production_mapping_has_declared_gate_state(self):
        source = fixture()
        self.assertIn('&& !liveQuickGuideVisible', source)
        self.assertIn('var liveQuickGuideVisible = false', source)

    def test_original_build_failure_is_rejected(self):
        broken = fixture().replace('    var liveQuickGuideVisible = false\n', '')
        with self.assertRaisesRegex(ValueError, 'liveQuickGuideVisible'):
            validate_fixture(broken)

    def test_future_positive_gate_without_fixture_state_is_rejected(self):
        broken = fixture().replace('&& isFirstFrameReady', '&& futureReady && isFirstFrameReady')
        with self.assertRaisesRegex(ValueError, 'futureReady'):
            validate_fixture(broken)


if __name__ == '__main__':
    unittest.main()
