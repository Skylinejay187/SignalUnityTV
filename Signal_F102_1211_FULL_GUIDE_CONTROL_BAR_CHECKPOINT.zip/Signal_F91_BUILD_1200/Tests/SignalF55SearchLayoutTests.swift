import Foundation

@main
enum SignalF55SearchLayoutTests {
    static func main() {
        for width in stride(from: 320.0, through: 3840.0, by: 7.0) {
            let layout = SignalSearchResultsLayout.make(width: width)
            precondition((1...4).contains(layout.columnCount))
            precondition(layout.cardWidth > 0 && layout.cardWidth <= 360)
            precondition(layout.cardHeight <= 202.5)
            precondition(abs(layout.cardWidth / layout.cardHeight - 16.0 / 9.0) < 0.000001)
            precondition(layout.cardWidth <= layout.columnWidth)
            let occupied = Double(layout.columnCount) * layout.columnWidth
                + Double(layout.columnCount - 1) * SignalSearchResultsLayout.columnSpacing
                + 2 * SignalSearchResultsLayout.horizontalInset
            precondition(occupied <= width + 0.000001)
            // Native focus's 2% lift/tilt has room within separate slots and row gutters.
            precondition(layout.cardWidth * 0.02 < SignalSearchResultsLayout.columnSpacing)
        }
        let tv = SignalSearchResultsLayout.make(width: 1920 - 128)
        precondition(tv.columnCount == 4 && tv.cardWidth == 360 && tv.cardHeight == 202.5)
        for width in [Double.nan, .infinity, -.infinity, -1, 0] {
            let result = SignalSearchResultsLayout.make(width: width)
            precondition(result.cardWidth.isFinite && result.cardWidth > 0)
        }
        precondition(SignalSearchResultsLayout.targetIndex(ids: [], rememberedID: "A", fallback: 8) == nil)
        precondition(SignalSearchResultsLayout.targetIndex(ids: ["A", "B", "C"], rememberedID: "B", fallback: 0) == 1)
        precondition(SignalSearchResultsLayout.targetIndex(ids: ["C", "A", "B"], rememberedID: "B", fallback: 0) == 2)
        precondition(SignalSearchResultsLayout.targetIndex(ids: ["C"], rememberedID: "B", fallback: 9) == 0)
        precondition(SignalSearchResultsLayout.targetIndex(ids: ["A", "B"], rememberedID: nil, fallback: -1) == 0)
        print("F55 native Search layout and focus identity tests passed")
    }
}
