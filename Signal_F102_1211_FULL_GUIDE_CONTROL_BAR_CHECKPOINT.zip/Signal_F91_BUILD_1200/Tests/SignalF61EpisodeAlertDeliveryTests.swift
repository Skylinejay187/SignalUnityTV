import Foundation

@main
struct SignalF61EpisodeAlertDeliveryTests {
    static func main() async {
        typealias Policy = SignalEpisodeAlertDeliveryPolicy
        let receipt = Policy.Receipt(alertID: "show:S01E02", surfaceID: "playback:A")
        let old = Policy.Lease(receipt: receipt)
        let renewed = Policy.Lease(receipt: receipt)
        precondition(old != renewed)
        precondition(Policy.mayDismiss(renewed, currentLease: renewed, activeAlertID: receipt.alertID, visibleSurfaceID: receipt.surfaceID))
        // Renewing the same alert on the same player must revoke the old timer, even
        // though its alert ID is identical. This was the F60 cancellation failure.
        precondition(!Policy.mayDismiss(old, currentLease: renewed, activeAlertID: receipt.alertID, visibleSurfaceID: receipt.surfaceID))
        precondition(!Policy.mayDismiss(old, currentLease: nil, activeAlertID: receipt.alertID, visibleSurfaceID: receipt.surfaceID))
        for surface in [nil, "main", "playback:B"] as [String?] {
            precondition(!Policy.mayDismiss(renewed, currentLease: renewed, activeAlertID: receipt.alertID, visibleSurfaceID: surface))
        }
        for active in [nil, "different-episode"] as [String?] {
            precondition(!Policy.mayDismiss(renewed, currentLease: renewed, activeAlertID: active, visibleSurfaceID: receipt.surfaceID))
        }
        let cancelled = Task { await Policy.waitForDisplayDuration(nanoseconds: 30_000_000_000) }
        cancelled.cancel()
        let cancelledExpired = await cancelled.value
        precondition(!cancelledExpired, "A cancelled sleep must never authorize dismissal")
        let completed = await Policy.waitForDisplayDuration(nanoseconds: 0)
        precondition(completed)
        let alreadyCancelled = Task {
            while !Task.isCancelled { await Task.yield() }
            return await Policy.waitForDisplayDuration(nanoseconds: 0)
        }
        alreadyCancelled.cancel()
        let zeroExpired = await alreadyCancelled.value
        precondition(!zeroExpired)
        print("F61 production alert policy passed: same-ID timer renewal, stale player/main surface, inactive/covered surface, cancelled sleeps and completed display duration")
    }
}
