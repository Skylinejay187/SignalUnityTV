import Foundation
enum SignalIntroDBCredential { static func save(_ value: String) -> Bool { true } }
// Isolated credential-boundary dependencies; these tests never call migration or Keychain.
enum BackupStreamingCredentialStore { static func purgeForFreshInstall() -> Bool { true } }
enum MediaFlowCredentialStore { static func purgeForFreshInstall() -> Bool { true } }
enum NuvioPluginPreferences { static func purgeForFreshInstall(defaults: UserDefaults) -> Bool { true } }

@main struct SignalF42SettingsTests {
    static func main() throws {
        let sourceName = "Signal.F42.Source." + UUID().uuidString
        let targetName = "Signal.F42.Target." + UUID().uuidString
        let source = UserDefaults(suiteName: sourceName)!, target = UserDefaults(suiteName: targetName)!
        defer { source.removePersistentDomain(forName: sourceName); target.removePersistentDomain(forName: targetName) }
        // Test the important replacement-device case: untouched source defaults must
        // overwrite different saved destination values too, not disappear from backup.
        target.set("unlimited", forKey: "vodDiskCachePolicyV1")
        target.set(false, forKey: "signalAutoNextEnabledV393")
        let initial = SignalPortableSettings.snapshot(source)
        precondition(initial["vodDiskCachePolicyV1"] as? String == "auto")
        precondition(initial["signalAutoNextEnabledV393"] as? Bool == true)
        source.set("3gb", forKey: "vodDiskCachePolicyV1")
        source.set(false, forKey: "signalAutoNextEnabledV393")
        source.set(8, forKey: "vodAudioAmplificationDBV1")
        source.set("cyan", forKey: "vodSubtitleTextColorV1")
        source.set("fill", forKey: "vodVideoFitModeV1")
        source.set(false, forKey: "traktResumeSyncEnabledV1")
        source.set(true, forKey: "membershipActive")
        source.set("DO-NOT-COPY", forKey: "backendProfileBackupCode")
        let settings = ReleaseCandidateSecurityManager.sanitizedRestoredSettings(SignalPortableSettings.snapshot(source))
        precondition(settings.count == SignalPortableSettings.defaults.count)
        let wire = try JSONSerialization.data(withJSONObject: ["settings": settings], options: [.sortedKeys])
        let envelope = try JSONSerialization.jsonObject(with: wire) as! [String: Any]
        let restored = ReleaseCandidateSecurityManager.sanitizedRestoredSettings(envelope["settings"] as! [String: Any])
        for (key, value) in restored { target.set(value, forKey: key) }
        precondition(target.string(forKey: "vodDiskCachePolicyV1") == "3gb")
        precondition(!target.bool(forKey: "signalAutoNextEnabledV393"))
        precondition(target.integer(forKey: "vodAudioAmplificationDBV1") == 8)
        precondition(target.string(forKey: "vodSubtitleTextColorV1") == "cyan")
        precondition(target.string(forKey: "vodVideoFitModeV1") == "fill")
        precondition(!target.bool(forKey: "traktResumeSyncEnabledV1"))
        precondition(target.object(forKey: "membershipActive") == nil)
        precondition(target.object(forKey: "backendProfileBackupCode") == nil)
        let rejected = ReleaseCandidateSecurityManager.sanitizedRestoredSettings([
            "membershipActive": true, "unknownFutureKey": true, "vodDiskCachePolicyV1": "2gb"])
        precondition(rejected.count == 1)
        let vault = ReleaseCandidateSecurityManager.sanitizedCredentialVault([
            "mediaFlowAPIPassword": "primary", "mediaFlowLightAPIPassword": "light", "unknownSecret": "reject"])
        precondition(vault.count == 2 && vault["mediaFlowLightAPIPassword"] == "light")
        precondition(SignalLiveTVCardTheme.names.count == 22)
        for shape in SignalLiveTVCardTheme.names {
            precondition(SignalLiveTVCardTheme.normalized(shape) == shape)
            precondition((3...72).contains(SignalLiveTVCardTheme.radius(shape)))
        }
        for effect in SignalLiveTVCardEffect.baseNames {
            for column in 0..<4 {
                let aligned = SignalLiveTVCardEffect.pose(effect + SignalLiveTVCardEffect.alignedSuffix, column: column, focused: true)
                // F48: every aligned card keeps the selected style's full pose,
                // matching the all-card editor. Only lattice offsets are removed.
                var original = SignalLiveTVCardEffect.pose(effect, column: column, focused: true)
                original.x = 0; original.y = 0
                precondition(aligned == original)
            }
        }
        print("F42 real JSON/UserDefaults round trip passed; VOD settings/defaults; protected keys; both MediaFlow profiles; 22 shapes; unstretched paired poses")
    }
}
