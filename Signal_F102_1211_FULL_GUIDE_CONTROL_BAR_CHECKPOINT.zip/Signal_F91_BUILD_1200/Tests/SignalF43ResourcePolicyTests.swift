import Foundation

@main struct SignalF43ResourcePolicyTests {
    @MainActor static func main() {
        for raw in [-1, 0, 2, 3, 4, 5, 999] {
            let rows = SignalLiveTVResourcePolicy.rows(raw)
            precondition(rows == (raw == 4 ? 4 : 3))
            precondition(SignalLiveTVResourcePolicy.pageSize(rows: raw) == rows * 4)
        }
        for count in [0, 1, 12, 16, 47, 48, 49, 1_000, 30_000] {
            for anchor in [-50, 0, 3, count/2, count-1, count+50] {
                let window = SignalLiveTVResourcePolicy.window(count: count, anchor: anchor)
                precondition(window.lowerBound >= 0 && window.upperBound <= count)
                precondition(window.count == min(count, 48))
                if count > 0 { precondition(window.contains(min(count-1, max(0, anchor)))) }
            }
        }
        for (width,height) in [(1280.0,720.0),(1920,1080),(3840,2160)] {
            for rows in [3,4] {
                for mirror in [false,true] {
                    for spread in [false,true] {
                        for expanded in [false,true] {
                            for split in [false,true] {
                                let h = SignalLiveTVResourcePolicy.cardHeight(width:width,height:height,rows:rows,mirror:mirror,spread:spread,expanded:expanded,split:split)
                                let gap = mirror ? 23.0 : (spread ? 30.0 : 25.0)
                                let reserved = mirror ? 305.0 : (expanded ? 246.0 : 274.0)
                                precondition(h.isFinite && h > 0)
                                precondition(Double(rows) * h + Double(rows-1) * gap + reserved <= height + 0.000001)
                                if rows == 4 {
                                    let w = h * 16 / 9
                                    let horizontal = mirror ? 80.0 : (expanded ? 98.0 : 148.0)
                                    let gridWidth = 4*w + (split ? 4.0 : 3.0)*(mirror ? 29.0 : 28.0) + (split ? 46 : 0)
                                    precondition(gridWidth + horizontal <= width + 0.000001)
                                }
                            }
                        }
                    }
                }
            }
        }
        let coordinator = AuxiliaryVideoPlaybackCoordinator.shared
        var releases = 0
        let a = coordinator.registerReleaseHandler { releases += 1 }
        let b = coordinator.registerReleaseHandler { releases += 1 }
        coordinator.releaseRegisteredPlayers()
        precondition(releases == 2 && !coordinator.isAuxiliaryPlaybackSuppressed())
        coordinator.releaseRegisteredPlayers(); precondition(releases == 2)
        coordinator.unregisterReleaseHandler(a); coordinator.unregisterReleaseHandler(b)
        let id = SignalLiveTVResourceLedger.beginHost(auxiliary:true)
        precondition(SignalLiveTVResourceLedger.summary.contains("hosts=1 auxiliary=1"))
        SignalLiveTVResourceLedger.endHost(id); SignalLiveTVResourceLedger.endHost(id)
        precondition(SignalLiveTVResourceLedger.summary.contains("hosts=0 auxiliary=0"))
        let smoke = UUID(), backdrop = UUID()
        SignalLiveTVResourceLedger.smoke(smoke,active:true); SignalLiveTVResourceLedger.smoke(smoke,active:true)
        SignalLiveTVResourceLedger.backdrop(backdrop,active:true)
        precondition(SignalLiveTVResourceLedger.summary.contains("smoke=1 backdrops=1"))
        SignalLiveTVResourceLedger.smoke(smoke,active:false); SignalLiveTVResourceLedger.backdrop(backdrop,active:false)
        precondition(SignalLiveTVResourceLedger.summary.contains("smoke=0 backdrops=0"))
        print("F43 policy tests passed: 3/4-row geometry, 48-channel bounds, immediate idempotent release, no extra cooldown, balanced render owners")
    }
}
