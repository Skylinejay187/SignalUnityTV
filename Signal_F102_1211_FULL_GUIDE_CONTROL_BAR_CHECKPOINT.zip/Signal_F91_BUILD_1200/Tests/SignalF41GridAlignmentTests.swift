import Foundation

@main struct SignalF41GridAlignmentTests {
    static func near(_ a: Double, _ b: Double, _ message: String = "Geometry mismatch") {
        precondition(abs(a - b) < 0.000001, message)
    }
    static func main() {
        precondition(SignalLiveTVCardEffect.baseNames.count == 28)
        precondition(SignalLiveTVCardEffect.names.count == 56)
        precondition(Set(SignalLiveTVCardEffect.names).count == 56)
        // Existing canonical identities remain in their original order and are never migrated away.
        let legacy = ["Original", "Tilt Left", "Tilt Right", "Dual Inward", "Split Inward",
            "Dual Inward Strong", "Split Inward Strong", "Dual Inward Max", "Split Inward Max",
            "Dual Outward", "Raised Glass", "Deep Float", "Beveled Cinema", "Layered Slate",
            "Curved Wall", "Tilted Pedestal", "Inset Lens", "Gallery Lift", "Prism Bevel",
            "Curved Wall Soft", "Curved Wall Strong", "Curved Wall Deep", "Curved Wall Max"]
        precondition(Array(SignalLiveTVCardEffect.names.prefix(23)) == legacy)
        for base in SignalLiveTVCardEffect.baseNames {
            let aligned = SignalLiveTVCardEffect.togglingAlignment(base)
            precondition(SignalLiveTVCardEffect.isAligned(aligned))
            precondition(SignalLiveTVCardEffect.baseName(aligned) == base)
            precondition(SignalLiveTVCardEffect.togglingAlignment(aligned) == base)
            precondition(SignalLiveTVCardEffect.normalized(aligned) == aligned)
            precondition(SignalLiveTVCardEffect.usesCenterGutter(aligned) == base.hasPrefix("Split "))
            for column in 0..<4 {
                let pose = SignalLiveTVCardEffect.pose(aligned, column: column, focused: false)
                precondition(pose == SignalLiveTVCardEffect.pose(aligned, column: column, focused: true))
                precondition(pose.x == 0 && pose.y == 0)
                for (width, height) in [(480.0, 270.0), (320, 183), (360, 210)] {
                    let m = SignalLiveTVCardProjection.fitted(pose: pose, width: width, height: height)
                    let corners = [(0.0,0.0), (width,0), (0,height), (width,height)].map { m.project(x: $0.0, y: $0.1) }
                    near(corners.map(\.x).min()!, 0)
                    near(corners.map(\.x).max()!, width)
                    near(corners.map(\.y).min()!, 0)
                    near(corners.map(\.y).max()!, height)
                    // In the fixed 4x3 lattice, every row uses this exact same local quad.
                    // Verify its translated bounds keep identical row/column gutters.
                    for row in 0..<3 {
                        let x = Double(column) * (width + 29)
                        let y = Double(row) * (height + 23)
                        near(corners.map { $0.x + x }.min()!, x)
                        near(corners.map { $0.y + y }.min()!, y)
                        near(corners.map { $0.x + x }.max()!, x + width)
                        near(corners.map { $0.y + y }.max()!, y + height)
                    }
                }
            }
        }
        for prefix in ["Dual Outward", "Split Outward"] {
            var previous = 0.0
            for suffix in ["", " Strong", " Max"] {
                let name = prefix + suffix
                let left = SignalLiveTVCardEffect.pose(name, column: 0, focused: true)
                let right = SignalLiveTVCardEffect.pose(name, column: 3, focused: true)
                precondition(left.yaw < 0 && right.yaw > 0)
                near(left.yaw, -right.yaw)
                precondition(abs(left.yaw) > previous)
                previous = abs(left.yaw)
            }
        }
        precondition(SignalLiveTVCardEffect.normalized("Dual Outward Split Max") == "Split Outward Max")
        // Corresponding left/right quads mirror exactly around their cell center.
        for suffix in ["", " Strong", " Max"] {
            let left = SignalLiveTVCardProjection.fitted(pose: SignalLiveTVCardEffect.pose("Dual Outward" + suffix + " · Aligned", column: 0, focused: false), width: 480, height: 270)
            let right = SignalLiveTVCardProjection.fitted(pose: SignalLiveTVCardEffect.pose("Dual Outward" + suffix + " · Aligned", column: 3, focused: false), width: 480, height: 270)
            for (x,y) in [(0.0,0.0),(480,0),(0,270),(480,270),(240,135)] {
                let a = left.project(x:x,y:y), b = right.project(x:480-x,y:y)
                near(a.x,480-b.x); near(a.y,b.y)
            }
        }
        precondition(SignalLiveTVCardProjection.fitted(pose: .init(), width: 0, height: 200) == .identity)
        precondition(SignalLiveTVCardProjection.fitted(pose: .init(), width: .nan, height: 200) == .identity)
        let center = SignalMirrorSearchLayout.centerY(headingTop: 50 + SignalMirrorSearchLayout.headingTopPadding)
        near(center - SignalMirrorSearchLayout.iconDiameter / 2, 34)
        near(88 - (center + SignalMirrorSearchLayout.iconDiameter / 2), SignalMirrorSearchLayout.headingGap)
        precondition(SignalMirrorSearchLayout.centerY(headingTop:nil) == 48)
        precondition(SignalMirrorSearchLayout.centerY(headingTop:0) == 48)
        precondition(SignalMirrorSearchLayout.centerY(headingTop:.nan) == 48)
        print("F41 geometry tests passed: 28 paired styles; fixed 4x3 row bounds; focus invariance; outward strengths/mirroring; safe Search inset")
    }
}
