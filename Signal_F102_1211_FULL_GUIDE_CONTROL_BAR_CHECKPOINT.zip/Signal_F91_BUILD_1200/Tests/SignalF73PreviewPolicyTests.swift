import Foundation
@main struct SignalF73PreviewPolicyTests {
    static func main() {
        typealias M = SignalQuickGuidePreviewMode
        precondition(M.allCases.count == 3 && M.resolved("invalid") == .pauseMain)
        precondition(M.pauseMain.pausesMain && !M.pauseMain.mutesPreview && !M.pauseMain.mutesMain)
        precondition(!M.silentPreview.pausesMain && M.silentPreview.mutesPreview && !M.silentPreview.mutesMain)
        precondition(!M.previewAudio.pausesMain && !M.previewAudio.mutesPreview && M.previewAudio.mutesMain)
        for mode in M.allCases {
            precondition(mode.pausesMain || mode.mutesMain || mode.mutesPreview, "Never two audible lanes")
        }
        print("F73 all preview policies have one audible lane; invalid preference fails to pause-main mode")
    }
}
