import Foundation

@main struct SignalF46GuideTests {
    static func main() {
        precondition(SignalGuideNavigation.targetIndex(ids: [], selectedID: 1) == nil)
        for count in 1...120 {
            let ids = Array(500..<(500 + count))
            precondition(SignalGuideNavigation.targetIndex(ids: ids, selectedID: -1) == 0)
            for index in ids.indices {
                precondition(SignalGuideNavigation.targetIndex(ids: ids, selectedID: ids[index]) == index)
            }
        }
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        for width in [1280.0, 1536, 1920, 3840] {
            let axis = SignalGuideTimeline(now: now, width: width)
            func entry(_ id: UInt64, _ start: Double, _ end: Double) -> SignalGuideTimeline.Entry {
                .init(id: id, start: axis.start.addingTimeInterval(start * 60), end: axis.start.addingTimeInterval(end * 60))
            }
            let entries = [entry(1,-30,60),entry(1,-30,60),entry(2,0,30),entry(3,0,20),
                           entry(4,25,60),entry(5,60,90),entry(6,90,140),entry(7,75,75),entry(8,150,180)]
            let slots = axis.slots(entries)
            precondition(!slots.isEmpty)
            precondition(Set(slots.map(\.id)).count == slots.count)
            for slot in slots { precondition(slot.x >= 0 && slot.width > 0 && slot.x + slot.width <= axis.scheduleWidth + 0.0001) }
            for pair in zip(slots, slots.dropFirst()) { precondition(pair.0.x + pair.0.width <= pair.1.x + 0.0001) }
            // Reordering a provider response must not change selected EPG revisions.
            precondition(axis.slots(Array(entries.reversed())) == slots)
            precondition(axis.slots([]).isEmpty)
        }
        print("F46 Guide navigation and duplicate/overlap geometry passed")
    }
}
