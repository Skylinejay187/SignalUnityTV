import SwiftUI

struct MediaItem: Identifiable {
    let id: String
    let title: String
    let year: String
    let type: String
    let catalog: String
    let description: String
    let genres: [String]
    let rating: String
    let posterURL: String?
    let landscapeURL: String?
    let logoURL: String?
    let previewURL: String?
    let addonName: String?
    let addonIconURL: String?
}
struct MediaRow { let id: String; let title: String; let items: [MediaItem] }
@MainActor final class CatalogStore: ObservableObject {
    var playbackURL: URL? = nil
    var playbackPresentationID = UUID()
    func startPlayback(item: MediaItem, url: URL, alternates: [URL], subtitles: [URL], headers: [String: String], label: String) {
        playbackPresentationID = UUID(); playbackURL = url
    }
    func setFullScreenPlaybackResourceSuspended(_ flag: Bool, reason: String) {}
}
final class AuxiliaryVideoPlaybackCoordinator {
    static let shared = AuxiliaryVideoPlaybackCoordinator()
    func beginExclusivePlayback(reason: String) -> UUID { UUID() }
    func endExclusivePlayback(_ id: UUID?) {}
    func requiresDecoderHandoffCooldown() -> Bool { false }
}
struct RemoteImageFit: View {
    enum Mode { case fit }
    let url: String?
    var mode: Mode = .fit
    var maxPixelSize: Int = 96
    var body: some View { Color.clear }
}
struct PlaybackKitAetherHost: View {
    let url: URL
    let shouldPlay: Bool
    let playAssertionSerial: Int
    let seekSerial: Int
    let seekSeconds: Double
    let seekIsAbsolute: Bool
    let reloadToken: Int
    let startTimeSeconds: Double
    var isLiveStream: Bool = false
    var sourceHint = ""
    var httpHeaders: [String:String] = [:]
    var onFirstFrameReady: (() -> Void)?
    var onPlaybackFailure: ((String) -> Void)?
    var body: some View { Color.black }
}

struct SportsLiveEvent: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let league: String
    let status: String
    let artworkURL: String?
    let accent: Color
    var streamURL: String? = nil
    var webURL: String? = nil
    var scoreboard: SignalSportsGame? = nil
}
enum VODExclusivePlaybackGate { static var isActive: Bool { false } }

@MainActor final class UnityAppCore: ObservableObject {
    enum Surface { case sports, membership }
    @Published var effectiveSurface: Surface = .sports
}
enum MembershipEntitlementManager { static func isCurrentDeviceLocked() -> Bool { false } }
