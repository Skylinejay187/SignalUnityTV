import SwiftUI

/// Only two identifiers survive the standard player's root unmount; no images/URLs.
@MainActor enum SignalSportsBrowseMemory {
    static var rowID: String?
    static var itemID: String?
}

@MainActor
final class SignalSportsOnlineCatalog: ObservableObject {
    @Published var events: [SignalSportsWebEvent] = []
    @Published var status = "Loading online sports…"
    private var generation: UInt64 = 0
    func load() async {
        generation &+= 1
        let owner = generation
        do {
            let fresh = try await SignalSportsWebSource.shared.catalog()
            guard !Task.isCancelled, owner == generation else { return }
            events = fresh; status = "\(fresh.count) online events • resolve on selection"
        } catch {
            guard !Task.isCancelled, owner == generation else { return }
            status = "Online source unavailable. Existing sports channels remain available."
        }
    }
    func cancelPublication() { generation &+= 1 }
    func release() { generation &+= 1; events.removeAll() }
    var rows: [MediaRow] {
        let test = MediaRow(id: "sports-web-test", title: "Sports Playback Test", items: [item(.test)])
        let grouped = Dictionary(grouping: events, by: \.league)
        let live = events.filter { $0.status.lowercased().contains("progress") || $0.status.lowercased() == "live" }
        var result: [MediaRow] = []
        if !live.isEmpty { result.append(MediaRow(id: "sports-web-live", title: "Online Sports • Live Now", items: live.prefix(48).map(item))) }
        for league in grouped.keys.sorted() {
            let list = grouped[league] ?? []
            for start in stride(from: 0, to: list.count, by: 48) {
                result.append(MediaRow(id: "sports-web-league-" + league + "-\(start)", title: "Online Sports • " + league, items: list.dropFirst(start).prefix(48).map(item)))
            }
        }
        result.append(test)
        return result
    }
    private func item(_ event: SignalSportsWebEvent) -> MediaItem {
        MediaItem(id: "sports-web:" + event.id, title: event.title, year: event.status,
            type: "sports-web", catalog: "Sports", description: event.league + " • iSportsurge",
            genres: ["Sports", event.league], rating: event.status, posterURL: event.artwork,
            landscapeURL: event.artwork, logoURL: nil, previewURL: event.pageURL.absoluteString,
            addonName: "iSportsurge", addonIconURL: nil)
    }
}

/// Resolve once on the viewer's network, then hand off to Signal's established
/// Live TV playback root. This cover never creates its own decoder or playback UI.
struct SignalSportsOnlinePlayer: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    let item: MediaItem
    let games: [SignalSportsGame]
    @State private var message = "Resolving sports source on this device…"
    @State private var attempt = 0
    @State private var loading = true
    @State private var closing = false
    @State private var handedOff = false
    @State private var exclusiveID: UUID?
    @State private var resourceClaimed = false
    @FocusState private var focusedControl: Int?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 20) {
                if loading { ProgressView() }
                Text(item.title).font(.title2.bold()).lineLimit(2)
                Text(message).font(.headline).multilineTextAlignment(.center)
                    .foregroundStyle(.white.opacity(0.75))
                HStack(spacing: 20) {
                    if !loading {
                        Button("Retry") { attempt &+= 1 }.focused($focusedControl, equals: 0)
                    }
                    Button("Cancel") { close() }.focused($focusedControl, equals: 1)
                }.buttonStyle(.bordered)
            }.padding(36).frame(maxWidth: 1000)
        }
        .task(id: "\(attempt)-\(scenePhase == .active)") {
            guard !closing, !handedOff, scenePhase == .active else { return }
            await resolveAndLaunch()
        }
        .onAppear {
            exclusiveID = AuxiliaryVideoPlaybackCoordinator.shared.beginExclusivePlayback(reason: "Online Sports resolution")
            store.setFullScreenPlaybackResourceSuspended(true, reason: "Online Sports resolution")
            resourceClaimed = true
            focusedControl = 1
        }
        .onDisappear {
            closing = true
            AuxiliaryVideoPlaybackCoordinator.shared.endExclusivePlayback(exclusiveID)
            exclusiveID = nil
            // A successful launch transfers suspension ownership to the root player.
            // Never resume the dashboard under its active full-screen decoder.
            if resourceClaimed && !handedOff {
                store.setFullScreenPlaybackResourceSuspended(false, reason: "Online Sports cancelled")
            }
            resourceClaimed = false
        }
        .onChange(of: unityCore.effectiveSurface) { _, surface in
            if surface != .sports && !handedOff { close() }
        }
        .onReceive(NotificationCenter.default.publisher(for: UserDefaults.didChangeNotification).receive(on: RunLoop.main)) { _ in
            if MembershipEntitlementManager.isCurrentDeviceLocked() && !handedOff { close() }
        }
        .onExitCommand { close() }
    }

    @MainActor private func resolveAndLaunch() async {
        loading = true; message = "Resolving sports source on this device…"
        guard !MembershipEntitlementManager.isCurrentDeviceLocked(), unityCore.effectiveSurface == .sports,
              store.playbackURL == nil else { fail("Sports playback is unavailable for the current app session."); return }
        guard let raw = item.previewURL, let page = URL(string: raw), SignalSportsWebParser.eventURL(page) else {
            fail("Unsupported sports event URL."); return
        }
        let seed = SignalSportsWebEvent(pageURL: page, title: item.title,
            league: item.genres.last ?? item.description, status: item.year, artwork: item.posterURL)
        do {
            let resolved = try await SignalSportsWebSource.shared.resolve(seed)
            if AuxiliaryVideoPlaybackCoordinator.shared.requiresDecoderHandoffCooldown() {
                try await Task.sleep(nanoseconds: 400_000_000)
            }
            guard !Task.isCancelled, !closing, !handedOff, scenePhase == .active,
                  unityCore.effectiveSurface == .sports, store.playbackURL == nil,
                  !MembershipEntitlementManager.isCurrentDeviceLocked() else { return }
            let live = liveItem(for: resolved.event)
            let previousSession = store.playbackPresentationID
            store.startPlayback(item: live, url: resolved.url, alternates: [], subtitles: [],
                headers: resolved.headers, label: "Live TV • iSportsurge • " + resolved.event.title)
            guard store.playbackURL == resolved.url, store.playbackPresentationID != previousSession else {
                fail("The sports session could not be opened. Try again."); return
            }
            handedOff = true; resourceClaimed = false
            dismiss()
        } catch {
            guard !Task.isCancelled, !closing, !handedOff else { return }
            fail((error as? SignalSportsWebError)?.errorDescription ?? "Sports source could not be resolved. Try again.")
        }
    }

    private func liveItem(for event: SignalSportsWebEvent) -> MediaItem {
        let matches = games.filter { game in
            SignalSportsWebParser.identityMatches(event: event, league: game.league,
                teams: [game.away.fullName ?? game.away.name, game.home.fullName ?? game.home.name], start: game.start)
        }
        let artwork = event.artwork ?? item.posterURL ?? (matches.count == 1 ? matches.first?.home.logo : nil)
        return MediaItem(id: "live-sports-web:" + event.id, title: event.title, year: event.status,
            type: "live", catalog: "iSportsurge", description: event.league + " • " + event.status,
            genres: ["Sports", event.league], rating: event.status, posterURL: artwork,
            landscapeURL: artwork, logoURL: artwork, previewURL: event.pageURL.absoluteString,
            addonName: "iSportsurge", addonIconURL: artwork)
    }
    private func fail(_ text: String) { loading = false; message = text; focusedControl = 0 }
    private func close() { closing = true; dismiss() }
}
