import Foundation

/// Static compositing only: keep the shared shell's header clear, shade the content.
enum SignalUnityDashboardShadePolicy {
    static func headerStops(height: Double) -> (clear: Double, opaque: Double) {
        let height = height.isFinite ? max(1, height) : 1080
        return (min(0.28, 112 / height), min(0.42, 184 / height))
    }
    static func normalizedSportsStyle(_ value: String) -> String {
        ["Dimmed Dashboard", "Artwork 3 Hero", "Clear Dashboard"].contains(value) ? value : "Dimmed Dashboard"
    }
}

#if canImport(SwiftUI)
import SwiftUI
struct SignalUnityDashboardHeaderMask: View {
    let height: CGFloat
    var body: some View {
        let stops = SignalUnityDashboardShadePolicy.headerStops(height: Double(height))
        LinearGradient(stops: [.init(color: .clear, location: 0),
            .init(color: .clear, location: CGFloat(stops.clear)),
            .init(color: .white, location: CGFloat(stops.opaque)), .init(color: .white, location: 1)],
            startPoint: .top, endPoint: .bottom)
    }
}
struct SignalUnityDashboardShade: View {
    var hero: Bool = false
    var body: some View {
        ZStack {
            Color.black.opacity(hero ? 0.04 : 0.32)
            LinearGradient(colors: [Color.black.opacity(hero ? 0.48 : 0.14),
                Color.black.opacity(hero ? 0.32 : 0.08), Color.black.opacity(0.16),
                Color.black.opacity(0.04)], startPoint: .leading, endPoint: .trailing)
            LinearGradient(colors: [.black.opacity(0.10), .clear, .black.opacity(0.16)],
                startPoint: .top, endPoint: .bottom)
        }.allowsHitTesting(false)
    }
}
#endif
