import Foundation

struct SignalSportsWebEvent: Identifiable, Equatable, Sendable {
    let pageURL: URL
    var title: String
    var league: String
    var status: String
    var teams: [String] = []
    var artwork: String? = nil
    var start: Date? = nil
    var id: String { pageURL.path }
    static let test = Self(pageURL: URL(string: "https://isportsurge.ws/watch/regular-season/unlv-rebels-usc-trojans/455023308")!,
        title: "UNLV Rebels vs USC Trojans", league: "Playback Test", status: "Resolve current source • event may have ended")
}

enum SignalSportsWebError: LocalizedError {
    case unsupportedURL, invalidResponse, oversized, noPlayer, noMedia, timeout, http(Int)
    var errorDescription: String? {
        switch self {
        case .unsupportedURL: return "This sports source or redirect is not supported."
        case .invalidResponse: return "The source did not return a valid playlist."
        case .oversized: return "The source response exceeded the size limit."
        case .noPlayer: return "No supported player was found for this event."
        case .noMedia: return "No playable source is available. The event may not have started or may have ended."
        case .timeout: return "Sports source resolution timed out. Try again."
        case .http(let code): return "The sports source returned HTTP \(code). Try resolving again or choose another event."
        }
    }
}

/// Public metadata and page parsing only. No JavaScript, webviews, ad requests,
/// backend forwarding, shared tokens, or stored signed media URLs.
enum SignalSportsWebParser {
    static func matches(_ pattern: String, _ text: String) -> [[String]] {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return [] }
        let range = NSRange(text.startIndex..., in: text)
        return regex.matches(in: text, range: range).map { match in
            (0..<match.numberOfRanges).map { i in
                Range(match.range(at: i), in: text).map { String(text[$0]) } ?? ""
            }
        }
    }
    static func plain(_ input: String) -> String {
        var result = input.replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
        for item in matches("&#(x[0-9a-f]+|[0-9]+);", result).reversed() {
            let raw = item[1]; let hex = raw.lowercased().hasPrefix("x")
            if let n = UInt32(hex ? String(raw.dropFirst()) : raw, radix: hex ? 16 : 10), let scalar = UnicodeScalar(n) {
                result = result.replacingOccurrences(of: item[0], with: String(scalar))
            }
        }
        for (entity, value) in [("&quot;", "\""), ("&apos;", "'"), ("&nbsp;", " "), ("&lt;", "<"), ("&gt;", ">"), ("&amp;", "&")] {
            result = result.replacingOccurrences(of: entity, with: value)
        }
        return result.replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression).trimmingCharacters(in: .whitespacesAndNewlines)
    }
    static func attribute(_ name: String, in tag: String) -> String? {
        matches("\\b" + name + "\\s*=\\s*[\"']([^\"']*)[\"']", tag).first.map { plain($0[1]) }
    }
    static func eventURL(_ url: URL) -> Bool {
        url.scheme == "https" && url.host?.lowercased() == "isportsurge.ws" && url.user == nil && url.password == nil && url.port == nil && url.path.hasPrefix("/watch/")
    }
    static func catalog(_ html: String) -> [SignalSportsWebEvent] {
        var seen = Set<String>(); var events: [SignalSportsWebEvent] = []
        for link in matches("<a\\b([^>]*href=[\"']https://isportsurge\\.ws/watch/[^>]+)>(.*?)</a>", html) {
            guard let raw = attribute("href", in: link[1]), let url = URL(string: raw), eventURL(url), seen.insert(url.path).inserted else { continue }
            let body = link[2]
            let images = matches("<img\\b[^>]+>", body).map { $0[0] }
            let teams = images.compactMap { attribute("alt", in: $0) }.filter { !$0.hasPrefix("Watch ") }
            guard teams.count == 2 else { continue }
            let league = matches("<div[^>]*class=[\"'][^\"']*col-md-2[^\"']*[\"'][^>]*>(.*?)</div>", body).first.map { plain($0[1]) } ?? "Sports"
            let status = matches("<span[^>]*class=[\"'][^\"']*time-badge[^\"']*[\"'][^>]*>(.*?)</span>", body).first.map { plain($0[1]) } ?? "Scheduled"
            let rawArtwork = images.first.flatMap { attribute("src", in: $0) }
            let artURL = rawArtwork.flatMap(URL.init(string:))
            let artwork = artURL.flatMap { url -> String? in
                guard url.scheme == "https", url.host == "scdnmain.net", url.user == nil, url.password == nil, url.port == nil else { return nil }
                return url.absoluteString
            }
            events.append(.init(pageURL: url, title: teams.joined(separator: " vs "), league: league, status: status, teams: teams, artwork: artwork))
            if events.count >= 120 { break }
        }
        return events
    }
    static func detail(_ html: String, seed: SignalSportsWebEvent) -> SignalSportsWebEvent {
        var result = seed
        if let h1 = matches("<h1\\b[^>]*>(.*?)</h1>", html).first {
            let title = plain(h1[1]); if !title.isEmpty { result.title = title }
        }
        let teams = result.title.components(separatedBy: " vs ")
        if teams.count == 2 { result.teams = teams }
        for pair in matches("<dt[^>]*>(.*?)</dt>\\s*<dd[^>]*>(.*?)</dd>", html) {
            let key = plain(pair[1]); let value = plain(pair[2])
            if key == "League:" { result.league = value }
            if key == "Date:" {
                let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = TimeZone(identifier: "America/New_York")
                f.dateFormat = "yyyy-MM-dd HH:mm'ET'"; result.start = f.date(from: value)
            }
        }
        if let status = matches("Start Time:.*?<span[^>]*>(.*?)</span>", html).first { result.status = plain(status[1]) }
        return result
    }
    static func players(_ html: String) -> [URL] {
        var output: [URL] = []; var seen = Set<String>()
        for frame in matches("<iframe\\b[^>]*>", html) {
            guard attribute("id", in: frame[0]) == "cx-iframe", let raw = attribute("src", in: frame[0]), let url = URL(string: raw), playerURL(url) else { continue }
            if seen.insert(url.absoluteString).inserted { output.append(url) }
        }
        for item in matches("changeStream\\(\\s*['\"]?([0-9]+)['\"]?\\s*\\)", html) {
            let raw = "https://gooz.aapmains.net/new-stream-embed/" + item[1]
            if seen.insert(raw).inserted, let url = URL(string: raw) { output.append(url) }
        }
        return Array(output.prefix(6))
    }
    static func playerURL(_ url: URL) -> Bool {
        url.scheme == "https" && url.host == "gooz.aapmains.net" && url.port == nil && url.user == nil && url.password == nil && url.path.hasPrefix("/new-stream-embed/")
    }
    static func media(_ html: String) -> URL? {
        if let literal = matches("\\bconst\\s+source\\s*=\\s*[\"'](https://[^\"']+)[\"']", html).first, let url = URL(string: plain(literal[1])), mediaURL(url) { return url }
        if let encoded = matches("\\bsource\\s*:\\s*(?:window\\.)?atob\\(['\"]([A-Za-z0-9+/=]+)['\"]\\)", html).first,
           let bytes = Data(base64Encoded: encoded[1]), let raw = String(data: bytes, encoding: .utf8), let url = URL(string: raw), mediaURL(url) { return url }
        return nil
    }
    static func mediaURL(_ url: URL) -> Bool {
        guard url.scheme == "https", url.user == nil, url.password == nil, url.port == nil, let host = url.host?.lowercased() else { return false }
        // Explicitly observed provider/CDN domains, not an arbitrary URL fetcher.
        return ["hereisman.net", "malek5.space", "playlist5.space", "whywelove1.space", "newvegan3.space"].contains { host == $0 || host.hasSuffix("." + $0) }
    }
    static func normalized(_ value: String) -> String {
        value.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "en_US_POSIX"))
            .components(separatedBy: CharacterSet.alphanumerics.inverted).filter { !$0.isEmpty }.joined(separator: " ")
    }
    static func leagueKey(_ value: String) -> String? {
        let v = normalized(value)
        if v.contains("ncaa") && v.contains("women") { return "NCAAW" }
        if v.contains("ncaa") && v.contains("men") { return "NCAAM" }
        return ["NBA", "WNBA", "NFL", "NHL", "MLB", "NCAAM", "NCAAW"].first { normalized($0) == v }
    }
    static func identityMatches(event: SignalSportsWebEvent, league: String, teams: [String], start: Date?) -> Bool {
        guard event.teams.count == 2, teams.count == 2, let a = event.start, let b = start,
              abs(a.timeIntervalSince(b)) <= 900, let key = leagueKey(event.league), key == league else { return false }
        let left = Set(event.teams.map(normalized)); let right = Set(teams.map(normalized))
        return left.count == 2 && !left.contains("") && left == right
    }
}

struct SignalSportsWebPlayback: Sendable {
    let event: SignalSportsWebEvent
    let url: URL
    let headers: [String: String]
    let playerCount: Int
    let playerIndex: Int
}

private final class SignalSportsWebRedirectPolicy: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        guard let url = request.url, SignalSportsWebParser.eventURL(url) || SignalSportsWebParser.playerURL(url) || SignalSportsWebParser.mediaURL(url) || (url.scheme == "https" && url.host == "isportsurge.ws" && url.path == "/index10" && url.port == nil && url.user == nil && url.password == nil) else { completionHandler(nil); return }
        completionHandler(request)
    }
}

actor SignalSportsWebSource {
    static let shared = SignalSportsWebSource()
    private var cachedCatalog: (Date, [SignalSportsWebEvent])?
    private let redirectPolicy = SignalSportsWebRedirectPolicy()
    private let protocolClasses: [AnyClass]?
    init(protocolClasses: [AnyClass]? = nil) { self.protocolClasses = protocolClasses }
    private func session() -> URLSession {
        let config = URLSessionConfiguration.ephemeral
        if let protocolClasses { config.protocolClasses = protocolClasses }
        config.urlCache = nil; config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.timeoutIntervalForRequest = 10; config.timeoutIntervalForResource = 25
        config.httpMaximumConnectionsPerHost = 2
        return URLSession(configuration: config, delegate: redirectPolicy, delegateQueue: nil)
    }
    private func text(_ url: URL, parent: URL?, session: URLSession, limit: Int, deadline: Date) async throws -> (String, URL) {
        try Task.checkCancellation()
        guard deadline > Date() else { throw SignalSportsWebError.timeout }
        guard SignalSportsWebParser.eventURL(url) || SignalSportsWebParser.playerURL(url) || SignalSportsWebParser.mediaURL(url) || url.absoluteString == "https://isportsurge.ws/index10" else { throw SignalSportsWebError.unsupportedURL }
        var request = URLRequest(url: url, timeoutInterval: min(10, deadline.timeIntervalSinceNow))
        request.setValue("SignalSportsProbe/0.1", forHTTPHeaderField: "User-Agent")
        request.setValue("*/*", forHTTPHeaderField: "Accept")
        if let parent {
            request.setValue(parent.absoluteString, forHTTPHeaderField: "Referer")
            request.setValue("https://" + (parent.host ?? ""), forHTTPHeaderField: "Origin")
        }
        let (bytes, response) = try await session.bytes(for: request)
        defer { bytes.task.cancel() }
        guard let http = response as? HTTPURLResponse else { throw SignalSportsWebError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw SignalSportsWebError.http(http.statusCode) }
        guard http.expectedContentLength <= Int64(limit) else { throw SignalSportsWebError.oversized }
        var data = Data(); data.reserveCapacity(min(limit, 128_000))
        for try await byte in bytes {
            if data.count % 4096 == 0 { try Task.checkCancellation(); if deadline <= Date() { throw SignalSportsWebError.timeout } }
            guard data.count < limit else { throw SignalSportsWebError.oversized }
            data.append(byte)
        }
        try Task.checkCancellation()
        guard let result = String(data: data, encoding: .utf8) else { throw SignalSportsWebError.invalidResponse }
        return (result, response.url ?? url)
    }
    func catalog() async throws -> [SignalSportsWebEvent] {
        if let (date, events) = cachedCatalog, Date().timeIntervalSince(date) < 60 { return events }
        let client = session(); defer { client.invalidateAndCancel() }
        let (html, _) = try await text(URL(string: "https://isportsurge.ws/index10")!, parent: nil, session: client, limit: 2_000_000, deadline: Date().addingTimeInterval(15))
        let events = SignalSportsWebParser.catalog(html)
        guard !events.isEmpty else { throw SignalSportsWebError.noPlayer }
        cachedCatalog = (Date(), events)
        return events
    }
    func resolve(_ event: SignalSportsWebEvent, preferredPlayer: Int = 0) async throws -> SignalSportsWebPlayback {
        guard SignalSportsWebParser.eventURL(event.pageURL) else { throw SignalSportsWebError.unsupportedURL }
        // Each selection creates its own ephemeral cookie jar on this device. Only
        // unsigned public catalog data is cached; session/media URLs are never shared.
        let client = session(); defer { client.invalidateAndCancel() }
        let deadline = Date().addingTimeInterval(25)
        let (html, final) = try await text(event.pageURL, parent: nil, session: client, limit: 2_000_000, deadline: deadline)
        let detail = SignalSportsWebParser.detail(html, seed: event)
        let players = SignalSportsWebParser.players(html)
        guard !players.isEmpty else { throw SignalSportsWebError.noPlayer }
        let first = min(max(0, preferredPlayer), players.count - 1)
        let order = [first] + players.indices.filter { $0 != first }
        var last: Error = SignalSportsWebError.noMedia
        for index in order.prefix(5) {
            try Task.checkCancellation()
            do {
                let (player, parent) = try await text(players[index], parent: final, session: client, limit: 500_000, deadline: deadline)
                guard let media = SignalSportsWebParser.media(player) else { throw SignalSportsWebError.noMedia }
                let (manifest, mediaFinal) = try await text(media, parent: parent, session: client, limit: 128_000, deadline: deadline)
                guard manifest.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("#EXTM3U"), manifest.contains("#EXT-X-STREAM-INF") || manifest.contains("#EXTINF:") else { throw SignalSportsWebError.invalidResponse }
                let headers = ["Referer": parent.absoluteString, "Origin": "https://" + (parent.host ?? ""), "User-Agent": "SignalSportsProbe/0.1"]
                return SignalSportsWebPlayback(event: detail, url: mediaFinal, headers: headers, playerCount: players.count, playerIndex: index)
            } catch is CancellationError { throw CancellationError() }
            catch {
                if let providerError = error as? SignalSportsWebError, case .http(429) = providerError { throw providerError }
                last = error
            }
        }
        throw last
    }
}
