import SwiftUI
import UIKit

// Presentation-only. Destinations, focus bindings, entitlement checks and command
// handlers remain owned by TopMenuBar. Every canonical theme has its own renderer.
extension TopMenuThemeStyle {
    var spacing: CGFloat {
        switch self {
        case .signalOriginal: return 0
        case .floatingLens: return 5
        case .graphiteCapsule: return 1
        case .cinemaRail: return 14
        case .crystalOutline: return 7
        case .slimDock: return 5
        case .liquidGlassIsland: return 4
        case .cinemaSegmented: return 2
        case .studioMinimal: return 22
        case .obsidianFloating: return 10
        case .titaniumToolbar: return 0
        case .iconDock: return 14
        case .spotlightRibbon: return 8
        case .neonOutline: return 8
        case .broadcastDeck: return 6
        case .classicMediaBar: return 16
        case .crystalSlabs: return 8
        case .orbitRail: return 10
        case .cinemaTicket: return 8
        case .stackedCards: return 12
        case .signalTerminal: return 10
        case .galleryTabs: return 3
        case .beaconRail: return 23
        case .haloDock: return 18
        case .auroraReborn: return 8
        case .marqueeReborn: return 7
        case .retroReborn: return 5
        case .graphiteReborn: return 5
        case .copperReborn: return 12
        case .polarReborn: return 6
        }
    }
    func itemWidth(for tab: AppTab) -> CGFloat {
        if self == .iconDock || self == .haloDock { return 92 }
        switch tab {
        case .home: return 110
        case .movies: return 126
        case .shows: return 151
        case .sports: return 120
        case .favorites: return 150
        case .live: return 136
        case .settings: return 145
        case .membership: return 180
        }
    }
    var itemHeight: CGFloat { self == .signalOriginal ? 42 : 60 }
    var separatesUtilities: Bool { self == .studioMinimal || self == .titaniumToolbar }
    var horizontalInset: CGFloat {
        switch self {
        case .signalOriginal, .graphiteCapsule: return 5
        case .floatingLens, .crystalOutline, .slimDock: return 9
        case .cinemaRail: return 12
        case .liquidGlassIsland, .iconDock: return 10
        case .cinemaSegmented: return 5
        case .titaniumToolbar, .spotlightRibbon: return 12
        case .classicMediaBar: return 18
        default: return 0
        }
    }
    var verticalInset: CGFloat { self == .signalOriginal ? 2 : (self == .iconDock || self == .haloDock ? 7 : 6) }
    var accent: Color {
        switch self {
        case .signalOriginal: return Color(red: 0.92, green: 0.27, blue: 0.34)
        case .floatingLens, .crystalOutline: return Color(red: 0.65, green: 0.86, blue: 1)
        case .graphiteCapsule, .slimDock: return Color(red: 0.76, green: 0.84, blue: 0.94)
        case .cinemaRail: return Color(red: 0.95, green: 0.73, blue: 0.49)
        case .liquidGlassIsland: return Color(red: 0.65, green: 0.86, blue: 1)
        case .cinemaSegmented, .obsidianFloating: return Color(red: 0.86, green: 0.73, blue: 0.54)
        case .studioMinimal, .titaniumToolbar: return Color(red: 0.76, green: 0.84, blue: 0.94)
        case .iconDock, .neonOutline: return Color(red: 0.28, green: 0.88, blue: 0.95)
        case .spotlightRibbon: return Color(red: 0.93, green: 0.69, blue: 0.40)
        case .broadcastDeck: return Color(red: 0.30, green: 0.80, blue: 1)
        case .classicMediaBar: return Color(red: 1, green: 0.55, blue: 0.25)
        case .crystalSlabs: return Color(red: 0.72, green: 0.90, blue: 1)
        case .orbitRail: return Color(red: 0.55, green: 0.82, blue: 0.96)
        case .cinemaTicket: return Color(red: 1, green: 0.79, blue: 0.53)
        case .stackedCards: return Color(red: 0.75, green: 0.68, blue: 1)
        case .signalTerminal: return Color(red: 0.52, green: 1, blue: 0.76)
        case .galleryTabs: return Color(red: 0.97, green: 0.87, blue: 0.73)
        case .beaconRail: return Color(red: 0.50, green: 0.86, blue: 1)
        case .haloDock: return Color(red: 0.93, green: 0.72, blue: 0.99)
        case .auroraReborn: return Color(red: 0.40, green: 0.85, blue: 0.80)
        case .marqueeReborn: return Color(red: 1, green: 0.78, blue: 0.44)
        case .retroReborn: return Color(red: 0.94, green: 0.43, blue: 0.78)
        case .graphiteReborn: return Color(red: 0.66, green: 0.78, blue: 0.88)
        case .copperReborn: return Color(red: 0.92, green: 0.60, blue: 0.40)
        case .polarReborn: return Color(red: 0.74, green: 0.91, blue: 1)
        }
    }
}

struct TopMenuThemeChrome: ViewModifier {
    let theme: TopMenuThemeStyle
    let accent: Color
    func body(content: Content) -> some View {
        // Keep this content subtree stable across theme changes: only presentation
        // properties/backgrounds change, so Settings and tvOS focus are not remounted.
        content
            .padding(.horizontal, theme.horizontalInset)
            .padding(.vertical, theme.verticalInset)
            .background(TopMenuChromeBackground(theme: theme, accent: accent))
    }
}

private struct TopMenuChromeBackground: View {
    let theme: TopMenuThemeStyle
    let accent: Color
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency

    private var barFill: LinearGradient {
        LinearGradient(colors: [Color(white: 0.19), Color(white: 0.055), accent.opacity(0.09), Color(white: 0.075)], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
    @ViewBuilder var body: some View {
        switch theme {
        case .signalOriginal:
            Capsule().fill(Color.black.opacity(reduceTransparency ? 0.96 : 0.62))
                .overlay(Capsule().fill(LinearGradient(colors: [.white.opacity(0.11), .clear, .white.opacity(0.035)], startPoint: .top, endPoint: .bottom)))
                .overlay(Capsule().stroke(Color.white.opacity(0.24), lineWidth: 1))
        case .floatingLens:
            Capsule().fill(barFill).padding(.vertical, 10)
                .overlay(Capsule().stroke(accent.opacity(0.13), lineWidth: 1).padding(.vertical, 10))
        case .graphiteCapsule:
            Capsule().fill(barFill).overlay(Capsule().stroke(Color.white.opacity(0.18), lineWidth: 1))
        case .cinemaRail:
            RoundedRectangle(cornerRadius: 7).fill(Color.black.opacity(0.22))
                .overlay(alignment: .bottom) { Rectangle().fill(Color.white.opacity(0.20)).frame(height: 1) }
        case .crystalOutline:
            RoundedRectangle(cornerRadius: 17).fill(Color.black.opacity(0.18))
                .overlay(RoundedRectangle(cornerRadius: 17).stroke(LinearGradient(colors: [.white.opacity(0.38), accent.opacity(0.18), .white.opacity(0.07)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
        case .slimDock:
            RoundedRectangle(cornerRadius: 13).fill(barFill).padding(.vertical, 7)
        case .liquidGlassIsland:
            Capsule().fill(reduceTransparency ? AnyShapeStyle(Color.black.opacity(0.96)) : AnyShapeStyle(Material.ultraThin))
                .overlay(Capsule().fill(LinearGradient(colors: [Color.white.opacity(0.08), accent.opacity(0.07), .clear], startPoint: .topLeading, endPoint: .bottomTrailing)))
                .overlay(Capsule().stroke(accent.opacity(0.24), lineWidth: 1))
                .shadow(color: .black.opacity(0.35), radius: 14, y: 7)
        case .cinemaSegmented:
            RoundedRectangle(cornerRadius: 14).fill(barFill)
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.12), lineWidth: 1))
        case .titaniumToolbar:
            RoundedRectangle(cornerRadius: 8)
                .fill(barFill)
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.24), lineWidth: 1))
        case .iconDock:
            RoundedRectangle(cornerRadius: 24).fill(barFill)
                .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.12), lineWidth: 1))
        case .spotlightRibbon:
            RoundedRectangle(cornerRadius: 5).fill(barFill)
                .overlay(alignment: .bottom) { Rectangle().fill(accent.opacity(0.65)).frame(height: 2) }
        case .classicMediaBar:
            RoundedRectangle(cornerRadius: 7).fill(barFill)
                .overlay(alignment: .bottom) { Rectangle().fill(Color.white.opacity(0.18)).frame(height: 1) }
        case .orbitRail:
            Capsule().fill(barFill)
                .overlay(alignment: .center) { Rectangle().fill(Color.white.opacity(0.09)).frame(height: 1) }
        case .signalTerminal:
            RoundedRectangle(cornerRadius: 3).fill(barFill)
                .overlay(RoundedRectangle(cornerRadius: 3).stroke(accent.opacity(0.28), lineWidth: 1))
        case .galleryTabs:
            Color.clear.overlay(alignment: .bottom) { Rectangle().fill(Color.white.opacity(0.36)).frame(height: 2) }
        case .haloDock:
            Capsule().fill(barFill)
                .overlay(Capsule().stroke(Color.white.opacity(0.11), lineWidth: 1))
        case .studioMinimal, .obsidianFloating, .neonOutline, .broadcastDeck,
             .crystalSlabs, .cinemaTicket, .stackedCards, .beaconRail,
             .auroraReborn, .marqueeReborn, .retroReborn, .graphiteReborn, .copperReborn, .polarReborn:
            Color.clear
        }
    }
}

struct TopMenuTabVisual: View {
    let tab: AppTab
    let theme: TopMenuThemeStyle
    let fontPreset: String
    let accent: Color
    let isFocused: Bool
    let isSelected: Bool
    var selectionNamespace: Namespace.ID? = nil
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    private var active: Bool { isFocused || isSelected }
    private var label: String { tab == .shows ? "TV Shows" : tab.rawValue }
    private var ink: Color { active ? .white : .white.opacity(0.66) }
    private var selectionInk: Color { .white }
    private var surfaceTint: LinearGradient {
        LinearGradient(colors: [Color(white: active ? 0.19 : 0.08), accent.opacity(active ? 0.16 : 0.035), Color.black.opacity(0.72)], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
    private var font: Font {
        PopupTypography.font(fontPreset, size: theme == .iconDock || theme == .haloDock ? 14 : 18, weight: .semibold)
    }
    private var icon: String {
        switch tab {
        case .home: return "house.fill"
        case .movies: return "film.fill"
        case .shows: return "tv.fill"
        case .sports: return "sportscourt.fill"
        case .favorites: return "heart.fill"
        case .live: return "dot.radiowaves.left.and.right"
        case .membership: return "person.crop.circle.badge.checkmark"
        case .settings: return "gearshape.fill"
        }
    }
    private var context: String {
        switch tab {
        case .home: return "DISCOVER"
        case .movies: return "FILMS"
        case .shows: return "SERIES"
        case .sports: return "SPORTS"
        case .favorites: return "SAVED"
        case .live: return "ON AIR"
        case .membership: return "ACCOUNT"
        case .settings: return "SYSTEM"
        }
    }
    private var iconAndTitle: some View {
        HStack(spacing: 7) {
            Image(systemName: icon).font(.system(size: 14, weight: .semibold))
            Text(label).font(font).fixedSize()
        }
    }
    @ViewBuilder private var lens: some View {
        if active {
            Capsule().fill(LinearGradient(colors: [Color.white.opacity(0.20), accent.opacity(isFocused ? 0.25 : 0.14), Color.white.opacity(0.06)], startPoint: .topLeading, endPoint: .bottomTrailing))
                .overlay(Capsule().stroke(LinearGradient(colors: [Color.white.opacity(0.65), accent.opacity(0.45), .clear], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
        }
    }

    @ViewBuilder var body: some View {
        switch theme {
        case .signalOriginal: signalOriginal
        case .floatingLens: floatingLens
        case .graphiteCapsule: graphiteCapsule
        case .cinemaRail: cinemaRail
        case .crystalOutline: crystalOutline
        case .slimDock: slimDock
        case .liquidGlassIsland: liquidIsland
        case .cinemaSegmented: segmented
        case .studioMinimal: minimal
        case .obsidianFloating: obsidian
        case .titaniumToolbar: titanium
        case .iconDock: dock
        case .spotlightRibbon: ribbon
        case .neonOutline: neon
        case .broadcastDeck: broadcast
        case .classicMediaBar: classic
        case .crystalSlabs: crystal
        case .orbitRail: orbit
        case .cinemaTicket: ticket
        case .stackedCards: stacked
        case .signalTerminal: terminal
        case .galleryTabs: gallery
        case .beaconRail: beacon
        case .haloDock: halo
        case .auroraReborn: aurora
        case .marqueeReborn: marquee
        case .retroReborn: retro
        case .graphiteReborn: graphite
        case .copperReborn: copper
        case .polarReborn: polar
        }
    }

    private var signalOriginal: some View {
        HStack(spacing: 7) {
            Image(systemName: icon).font(.system(size: 12, weight: .semibold))
            Text(label).font(PopupTypography.font(fontPreset, size: 16, weight: .semibold)).fixedSize()
        }
        .padding(.horizontal, 10).frame(height: 31)
        .foregroundStyle(active ? Color.white : Color.white.opacity(0.72))
        .background(Capsule().fill(active ? accent.opacity(0.16) : Color.clear))
        .overlay(Capsule().stroke(active ? accent.opacity(0.42) : Color.clear, lineWidth: 1))
    }
    private var floatingLens: some View {
        iconAndTitle.padding(.horizontal, 13).frame(height: 43).foregroundStyle(ink)
            .background(Capsule().fill(active ? Color.white.opacity(0.13) : .clear))
            .overlay(Capsule().stroke(active ? accent.opacity(0.68) : .clear, lineWidth: 1))
            .shadow(color: active ? .black.opacity(0.35) : .clear, radius: 5, y: 4)
    }
    private var graphiteCapsule: some View {
        iconAndTitle.padding(.horizontal, 12).frame(height: 39).foregroundStyle(ink)
            .background(RoundedRectangle(cornerRadius: 12).fill(active ? Color.white.opacity(0.075) : .clear))
            .overlay(alignment: .leading) { Capsule().fill(active ? accent : .clear).frame(width: 2, height: 17) }
            .overlay(alignment: .trailing) { Capsule().fill(active ? accent.opacity(0.5) : .clear).frame(width: 2, height: 17) }
    }
    private var cinemaRail: some View {
        iconAndTitle.padding(.horizontal, 9).frame(height: 44).foregroundStyle(ink)
            .overlay(alignment: .bottom) { Capsule().fill(active ? accent : .clear).frame(height: 2) }
    }
    private var crystalOutline: some View {
        iconAndTitle.padding(.horizontal, 12).frame(height: 41).foregroundStyle(ink)
            .background(RoundedRectangle(cornerRadius: 11).fill(active ? accent.opacity(0.08) : .clear))
            .overlay(RoundedRectangle(cornerRadius: 11).stroke(active ? .white.opacity(0.65) : .clear, lineWidth: 1))
            .overlay(alignment: .top) { Capsule().fill(active ? accent.opacity(0.8) : .clear).frame(width: 32, height: 2) }
    }
    private var slimDock: some View {
        HStack(spacing: 8) {
            Image(systemName: icon).font(.system(size: 16, weight: .medium)).foregroundStyle(active ? accent : ink)
            Text(label).font(PopupTypography.font(fontPreset, size: 15, weight: .semibold)).fixedSize()
        }
        .padding(.horizontal, 12).frame(height: 38).foregroundStyle(ink)
        .background(RoundedRectangle(cornerRadius: 8).fill(active ? Color.white.opacity(0.10) : .clear))
        .overlay(alignment: .bottom) { Capsule().fill(active ? accent.opacity(0.5) : .clear).frame(width: 24, height: 2) }
    }

    private var liquidIsland: some View {
        iconAndTitle.padding(.horizontal, 13).frame(height: 42)
            .foregroundStyle(active ? selectionInk : ink)
            .background { lens }
    }
    private var segmented: some View {
        Text(label).font(font).fixedSize().padding(.horizontal, 16).frame(height: 36)
            .foregroundStyle(active ? selectionInk : ink)
            .background(RoundedRectangle(cornerRadius: 10).fill(active ? AnyShapeStyle(surfaceTint) : AnyShapeStyle(Color.clear)))
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(isFocused ? Color.white.opacity(0.7) : Color.clear, lineWidth: 1))
    }
    @ViewBuilder private var minimal: some View {
        if tab == .settings {
            Image(systemName: icon).font(.system(size: 21, weight: .medium))
                .frame(width: 42, height: 42).foregroundStyle(active ? accent : ink)
                .background(Circle().fill(isFocused ? Color.white.opacity(0.12) : Color.clear))
                .accessibilityLabel(label)
        } else {
            Text(label).font(font).fixedSize().foregroundStyle(active ? Color.white : ink)
                .padding(.vertical, 10)
                .overlay(alignment: .bottom) {
                    Capsule().fill(active ? AnyShapeStyle(surfaceTint) : AnyShapeStyle(Color.clear)).frame(width: 30, height: 3)
                }
        }
    }
    private var obsidian: some View {
        iconAndTitle.padding(.horizontal, 15).frame(height: 46).foregroundStyle(ink)
            .background(RoundedRectangle(cornerRadius: 14)
                .fill(surfaceTint))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(active ? accent.opacity(0.85) : Color.white.opacity(0.15), lineWidth: 1))
            .shadow(color: isFocused ? accent.opacity(0.22) : .black.opacity(0.45), radius: isFocused ? 9 : 5, y: 5)
    }
    private var titanium: some View {
        iconAndTitle.padding(.horizontal, 14).frame(height: 38).foregroundStyle(ink)
            .background(Rectangle().fill(active ? Color.white.opacity(0.10) : Color.clear))
            .overlay(alignment: .trailing) { Rectangle().fill(Color.white.opacity(0.14)).frame(width: 1, height: 20) }
            .overlay(alignment: .top) { Rectangle().fill(active ? AnyShapeStyle(surfaceTint) : AnyShapeStyle(Color.clear)).frame(height: 2) }
    }
    private var dock: some View {
        VStack(spacing: 5) {
            Image(systemName: icon).font(.system(size: 22, weight: .semibold))
                .frame(width: 44, height: 38)
                .foregroundStyle(active ? selectionInk : Color.white)
                .background(RoundedRectangle(cornerRadius: 13).fill(active ? AnyShapeStyle(surfaceTint) : AnyShapeStyle(Color.white.opacity(0.09))))
            Text(label).font(font).foregroundStyle(ink).fixedSize()
        }.frame(minWidth: 66)
    }
    private var ribbon: some View {
        HStack(spacing: 9) {
            RoundedRectangle(cornerRadius: 2).fill(active ? accent : Color.white.opacity(0.12)).frame(width: 3, height: 24)
            Text(label.uppercased()).font(font).tracking(1).fixedSize()
        }.padding(.horizontal, 11).frame(height: 40).foregroundStyle(ink)
            .background(Rectangle().fill(isFocused ? accent.opacity(0.14) : Color.clear))
    }
    private var neon: some View {
        iconAndTitle.padding(.horizontal, 14).frame(height: 40)
            .foregroundStyle(active ? accent : ink)
            .background(Capsule().fill(surfaceTint))
            .overlay(Capsule().stroke(active ? accent : Color.white.opacity(0.20), lineWidth: active ? 2 : 1))
            .shadow(color: isFocused ? accent.opacity(0.32) : .clear, radius: 8)
    }
    private var broadcast: some View {
        HStack(spacing: 8) {
            Image(systemName: icon).font(.system(size: 16, weight: .bold)).foregroundStyle(active ? accent : ink)
            VStack(alignment: .leading, spacing: 3) {
                Text(context).font(.system(size: 8, weight: .black)).tracking(1.1).foregroundStyle(accent.opacity(active ? 1 : 0.55))
                Text(label).font(font).fixedSize().foregroundStyle(ink)
            }
        }.padding(.horizontal, 12).frame(height: 48)
            .background(RoundedRectangle(cornerRadius: 6).fill(surfaceTint))
            .overlay(alignment: .bottom) { Rectangle().fill(active ? accent : Color.white.opacity(0.08)).frame(height: 3) }
    }
    private var classic: some View {
        Text(label).font(font).fixedSize().padding(.horizontal, 8).frame(height: 40)
            .foregroundStyle(isFocused ? accent : ink)
            .overlay(alignment: .bottom) { Rectangle().fill(active ? AnyShapeStyle(surfaceTint) : AnyShapeStyle(Color.clear)).frame(width: 36, height: 2) }
    }
    private var crystal: some View {
        iconAndTitle.padding(.horizontal, 14).frame(height: 44).foregroundStyle(ink)
            .background(RoundedRectangle(cornerRadius: 9).fill(reduceTransparency
                ? AnyShapeStyle(Color(white: 0.12)) : AnyShapeStyle(Material.ultraThin)))
            .overlay(RoundedRectangle(cornerRadius: 9).fill(accent.opacity(active ? 0.32 : 0.16)))
            .overlay(RoundedRectangle(cornerRadius: 9).fill(LinearGradient(
                colors: [Color.white.opacity(active ? 0.24 : 0.08), .clear], startPoint: .topLeading, endPoint: .bottomTrailing)))
            .overlay(RoundedRectangle(cornerRadius: 9).stroke(active ? accent.opacity(0.9) : Color.white.opacity(0.23), lineWidth: 1))
            .overlay(alignment: .top) { Capsule().fill(active ? Color.white.opacity(0.8) : Color.clear).frame(width: 38, height: 2) }
    }
    private var orbit: some View {
        HStack(spacing: 8) {
            Image(systemName: icon).font(.system(size: 14, weight: .semibold))
                .frame(width: 32, height: 32)
                .background(Circle().fill(surfaceTint))
                .foregroundStyle(active ? selectionInk : ink)
                .overlay(Circle().stroke(active ? Color.white.opacity(0.9) : Color.white.opacity(0.2), lineWidth: 1))
            Text(label).font(font).fixedSize().foregroundStyle(ink)
        }.padding(.horizontal, 8).frame(height: 46)
            .background(Capsule().fill(surfaceTint))
    }
    private var ticket: some View {
        HStack(spacing: 9) {
            Image(systemName: icon).font(.system(size: 13, weight: .bold)).frame(width: 19)
            Rectangle().fill(active ? Color.black.opacity(0.3) : Color.white.opacity(0.25)).frame(width: 1, height: 22)
            Text(label).font(font).fixedSize()
        }.padding(.horizontal, 13).frame(height: 42)
            .foregroundStyle(active ? selectionInk : ink)
            .background(SignalTicketShape().fill(AnyShapeStyle(surfaceTint)))
            .overlay(SignalTicketShape().stroke(active ? Color.white.opacity(0.75) : Color.white.opacity(0.21), lineWidth: 1))
    }
    private var stacked: some View {
        iconAndTitle.padding(.horizontal, 13).frame(height: 43).foregroundStyle(ink)
            .background(RoundedRectangle(cornerRadius: 10).fill(surfaceTint))
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(active ? accent : Color.white.opacity(0.16), lineWidth: 1))
            .background(RoundedRectangle(cornerRadius: 10).fill(accent.opacity(active ? 0.28 : 0.08)).offset(x: 3, y: 5))
            .padding(.bottom, 5)
    }
    private var terminal: some View {
        HStack(spacing: 6) {
            Text(active ? "[" : " ").foregroundStyle(accent)
            VStack(alignment: .leading, spacing: 2) {
                Text(stationNumber).font(.system(size: 8, weight: .medium, design: .monospaced)).foregroundStyle(accent.opacity(0.7))
                Text(label.uppercased()).font(.system(size: 13, weight: .semibold, design: .monospaced)).fixedSize().foregroundStyle(ink)
            }
            Text(active ? "]" : " ").foregroundStyle(accent)
        }.font(.system(size: 18, weight: .light, design: .monospaced))
            .padding(.horizontal, 7).frame(height: 43)
    }
    private var stationNumber: String {
        switch tab {
        case .home: return "01 / DISCOVER"
        case .movies: return "02 / FILMS"
        case .shows: return "03 / SERIES"
        case .sports: return "04 / SPORTS"
        case .favorites: return "05 / SAVED"
        case .live: return "06 / ON AIR"
        case .membership: return "07 / ACCOUNT"
        case .settings: return "08 / SYSTEM"
        }
    }
    private var gallery: some View {
        Text(label).font(font).fixedSize().padding(.horizontal, 19).frame(height: 43)
            .foregroundStyle(active ? selectionInk : ink)
            .background(SignalGalleryTabShape().fill(AnyShapeStyle(surfaceTint)))
            .overlay(SignalGalleryTabShape().stroke(Color.white.opacity(active ? 0.6 : 0.19), lineWidth: 1))
    }
    private var beacon: some View {
        VStack(spacing: 7) {
            Text(label).font(font).fixedSize().foregroundStyle(ink)
            HStack(spacing: 3) {
                Capsule().fill(active ? accent : Color.white.opacity(0.12)).frame(width: active ? 20 : 4, height: 4)
                Circle().fill(active ? accent.opacity(0.4) : Color.clear).frame(width: 4, height: 4)
            }
        }.padding(.horizontal, 5).frame(height: 45)
    }
    private var halo: some View {
        VStack(spacing: 4) {
            Image(systemName: icon).font(.system(size: 19, weight: .semibold))
                .frame(width: 39, height: 39).foregroundStyle(active ? selectionInk : ink)
                .background(Circle().fill(surfaceTint))
                .overlay(Circle().stroke(active ? Color.white.opacity(0.85) : Color.white.opacity(0.17), lineWidth: 1))
                .shadow(color: isFocused ? accent.opacity(0.32) : .clear, radius: 8)
            Text(label).font(font).fixedSize().foregroundStyle(ink)
        }.frame(minWidth: 66)
    }

    private var aurora: some View {
        iconAndTitle.padding(.horizontal, 13).frame(height: 44).foregroundStyle(ink)
            .background(Capsule().fill(surfaceTint))
            .overlay(Capsule().stroke(LinearGradient(colors: [Color.white.opacity(active ? 0.65 : 0.24), accent.opacity(0.22), .clear], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
            .overlay(alignment: .bottom) { Capsule().fill(accent.opacity(active ? 0.65 : 0.08)).frame(width: 44, height: 2).padding(.bottom, 3) }
    }
    private var marquee: some View {
        Text(label).font(font).fixedSize().padding(.horizontal, 16).frame(height: 40).foregroundStyle(ink)
            .background(RoundedRectangle(cornerRadius: 12).fill(LinearGradient(colors: [Color.white.opacity(active ? 0.20 : 0.04), Color.white.opacity(0.03), accent.opacity(active ? 0.12 : 0.025)], startPoint: .topLeading, endPoint: .bottomTrailing)))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(active ? 0.5 : 0.08), lineWidth: 1))
    }
    private var retro: some View {
        iconAndTitle.padding(.horizontal, 13).frame(height: 44).foregroundStyle(ink)
            .background(Capsule().fill(surfaceTint))
            .overlay(Capsule().fill(LinearGradient(stops: [.init(color: .clear, location: 0.20), .init(color: Color.white.opacity(active ? 0.18 : 0.055), location: 0.46), .init(color: .clear, location: 0.58)], startPoint: .topLeading, endPoint: .bottomTrailing)))
            .overlay(Capsule().stroke(active ? accent.opacity(0.6) : Color.white.opacity(0.18), lineWidth: 1))
    }
    private var graphite: some View {
        HStack(spacing: 8) {
            Image(systemName: icon).font(.system(size: 14, weight: .semibold)).foregroundStyle(active ? accent : ink)
                .frame(width: 27, height: 27).background(RoundedRectangle(cornerRadius: 8).fill(Color.white.opacity(active ? 0.10 : 0.035)))
            Text(label).font(.system(size: 15, weight: .semibold)).fixedSize().foregroundStyle(ink)
        }.padding(.horizontal, 11).frame(height: 44)
            .background(RoundedRectangle(cornerRadius: 14).fill(surfaceTint))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(active ? 0.42 : 0.12), lineWidth: 1))
    }
    private var copper: some View {
        Text(label).font(.system(size: 17, weight: .medium)).fixedSize().padding(.horizontal, 12).frame(height: 44).foregroundStyle(ink)
            .background(Capsule().fill(Color.white.opacity(active ? 0.065 : 0)))
            .overlay(alignment: .bottom) { Capsule().fill(LinearGradient(colors: [.clear, active ? accent.opacity(0.9) : Color.white.opacity(0.12), .clear], startPoint: .leading, endPoint: .trailing)).frame(height: 2).padding(.horizontal, 14) }
    }
    private var polar: some View {
        iconAndTitle.padding(.horizontal, 13).frame(height: 44).foregroundStyle(ink)
            .background(RoundedRectangle(cornerRadius: 11).fill(LinearGradient(colors: [Color.white.opacity(active ? 0.16 : 0.055), accent.opacity(active ? 0.10 : 0.02), Color.white.opacity(0.025)], startPoint: .top, endPoint: .bottom)))
            .overlay(RoundedRectangle(cornerRadius: 11).stroke(Color.white.opacity(active ? 0.55 : 0.15), lineWidth: 1))
    }

}

// The picker thumbnails use the SAME renderer and chrome as the live menu.
// No approximate images or extra focusable destinations are introduced.
struct TopMenuThemePreview: View {
    let theme: TopMenuThemeStyle
    let accent: Color
    @Namespace private var previewSelection
    private let tabs: [AppTab] = [.home, .movies, .shows, .settings]
    var body: some View {
        HStack(spacing: theme.spacing) {
            ForEach(tabs) { tab in
                TopMenuTabVisual(tab: tab, theme: theme, fontPreset: "SF Rounded", accent: accent,
                    isFocused: false, isSelected: tab == .movies, selectionNamespace: previewSelection)
                    .frame(width: theme.itemWidth(for: tab), height: theme.itemHeight)
            }
        }
        .modifier(TopMenuThemeChrome(theme: theme, accent: accent))
        .fixedSize()
        .frame(width: 950, height: 92, alignment: .leading)
        .scaleEffect(0.35, anchor: .leading)
        .frame(width: 240, height: 38, alignment: .leading)
        .clipped()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct TopMenuThemePicker: View {
    @Binding var selectedTheme: String
    let onClose: () -> Void
    @FocusState private var focusedTheme: TopMenuThemeStyle?
    @AppStorage("topMenuAccentColor") private var accentPreference: String = "Orange"
    private let columns: [GridItem] = [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)]
    private var selected: TopMenuThemeStyle { TopMenuThemeStyle.resolve(selectedTheme) }

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("SIGNAL · \(TopMenuThemeStyle.implementedThemes.count) DISTINCT MENU LAYOUTS")
                .font(.system(size: 13, weight: .bold, design: .rounded)).foregroundStyle(Color.cyan)
            Text("Choose a layout. Accent, font and size stay independent. Press Back to close.")
                .font(.system(size: 12)).foregroundStyle(Color.white.opacity(0.6))
            ForEach(TopMenuThemeGroup.allCases) { group in
                Text(group.rawValue.uppercased()).font(.system(size: 11, weight: .bold)).foregroundStyle(Color.white.opacity(0.65))
                LazyVGrid(columns: columns, spacing: 12) {
                    ForEach(themes(in: group)) { (theme: TopMenuThemeStyle) in
                        themeButton(theme)
                    }
                }
            }
        }
        .padding(.top, 8)
        .onAppear {
            let canonical = selected
            if selectedTheme != canonical.rawValue { selectedTheme = canonical.rawValue }
        }
        .onExitCommand(perform: onClose)
    }
    private func themes(in group: TopMenuThemeGroup) -> [TopMenuThemeStyle] {
        TopMenuThemeStyle.implementedThemes.filter { $0.group == group }
    }
    private func themeButton(_ theme: TopMenuThemeStyle) -> some View {
        let isSelected = selected == theme
        let isFocused = focusedTheme == theme
        let accent = TopMenuAccentColorSystem.color(for: accentPreference, themeAccent: theme.accent)
        return Button {
            // One @AppStorage write, no duplicate defaults write, no category reset.
            selectedTheme = theme.rawValue
        } label: {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(theme.rawValue).font(.system(size: 15, weight: .bold)).lineLimit(1)
                    Spacer(minLength: 0)
                    if isSelected { Image(systemName: "checkmark.circle.fill").foregroundStyle(accent) }
                }
                TopMenuThemePreview(theme: theme, accent: accent)
                Text(theme.summary).font(.system(size: 11)).foregroundStyle(Color.white.opacity(0.62)).lineLimit(2)
            }
            .foregroundStyle(Color.white)
            .padding(13).frame(maxWidth: .infinity, minHeight: 118, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 14).fill(Color.white.opacity(isFocused ? 0.15 : 0.055)))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(isFocused ? Color.white : (isSelected ? accent : Color.white.opacity(0.12)), lineWidth: isFocused || isSelected ? 2 : 1))
            .contentShape(RoundedRectangle(cornerRadius: 14))
        }
        .modifier(SettingsRoundedFocusVisual(cornerRadius: 14))
        .focusEffectDisabled()
        .focused($focusedTheme, equals: theme)
        .accessibilityLabel(theme.rawValue + (isSelected ? ", selected" : ""))
        .accessibilityHint(theme.summary)
    }
}


private struct SignalTicketShape: Shape {
    func path(in rect: CGRect) -> Path {
        // Inward half-circle cuts identify a ticket instead of another rounded pill.
        let notch: CGFloat = 5
        var p = Path()
        p.move(to: CGPoint(x: 5, y: 0))
        p.addLine(to: CGPoint(x: rect.maxX - 5, y: 0))
        p.addQuadCurve(to: CGPoint(x: rect.maxX, y: 5), control: CGPoint(x: rect.maxX, y: 0))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.midY - notch))
        p.addQuadCurve(to: CGPoint(x: rect.maxX, y: rect.midY + notch), control: CGPoint(x: rect.maxX - notch * 2, y: rect.midY))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - 5))
        p.addQuadCurve(to: CGPoint(x: rect.maxX - 5, y: rect.maxY), control: CGPoint(x: rect.maxX, y: rect.maxY))
        p.addLine(to: CGPoint(x: 5, y: rect.maxY))
        p.addQuadCurve(to: CGPoint(x: 0, y: rect.maxY - 5), control: CGPoint(x: 0, y: rect.maxY))
        p.addLine(to: CGPoint(x: 0, y: rect.midY + notch))
        p.addQuadCurve(to: CGPoint(x: 0, y: rect.midY - notch), control: CGPoint(x: notch * 2, y: rect.midY))
        p.addLine(to: CGPoint(x: 0, y: 5))
        p.addQuadCurve(to: CGPoint(x: 5, y: 0), control: .zero)
        p.closeSubpath()
        return p
    }
}
private struct SignalGalleryTabShape: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: rect.maxY))
        p.addLine(to: CGPoint(x: 9, y: 5))
        p.addQuadCurve(to: CGPoint(x: 15, y: 0), control: CGPoint(x: 10, y: 0))
        p.addLine(to: CGPoint(x: rect.maxX - 15, y: 0))
        p.addQuadCurve(to: CGPoint(x: rect.maxX - 9, y: 5), control: CGPoint(x: rect.maxX - 10, y: 0))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
        p.closeSubpath()
        return p
    }
}


private enum SignalMenuAccentInk {
    static func color(for accent: Color) -> Color {
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0, alpha: CGFloat = 0
        guard UIColor(accent).getRed(&red, green: &green, blue: &blue, alpha: &alpha) else { return .white }
        return SignalMenuContrast.prefersDarkInk(red: Double(red), green: Double(green), blue: Double(blue)) ? .black : .white
    }
}
