import Foundation

final class SportsFixtureProtocol: URLProtocol {
    static let lock = NSLock()
    static var mode = "success"
    static var requests: [URLRequest] = []
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.lock.lock(); Self.requests.append(request); let mode = Self.mode; Self.lock.unlock()
        let url = request.url!
        var text = ""; var status = 200
        if url.host == "isportsurge.ws" {
            text = SportsTests.detail
        } else if url.host == "gooz.aapmains.net" {
            text = "const source = 'https://chatgpt.hereisman.net/playlist/fixture/load-playlist';"
        } else {
            if mode == "html" { text = "<html>not a playlist</html>" }
            else if mode == "403" { status = 403 }
            else if mode == "429" { status = 429 }
            else { text = "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000000\nhttps://pl.playlist5.space/fixture.m3u8\n" }
        }
        let response = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: ["Content-Type":"text/plain"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(text.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
    static func set(_ mode: String) { lock.lock(); self.mode = mode; requests = []; lock.unlock() }
    static func captured() -> [URLRequest] { lock.lock(); defer { lock.unlock() }; return requests }
}

@main struct SportsTests {
    static let detail = """
    <h1>UNLV Rebels vs USC Trojans</h1><div>Start Time: <span>In Progress</span></div>
    <iframe id="advertisement" src="https://invalid.example/ad"></iframe>
    <iframe id="cx-iframe" src="https://gooz.aapmains.net/new-stream-embed/123"></iframe>
    <button onclick="changeStream(123)">One</button><button onclick="changeStream(456)">Two</button>
    <dl><dt>Date:</dt><dd>2026-11-02 16:00ET</dd><dt>League:</dt><dd>NCAA Women&#039;s Division I, Regular season</dd></dl>
    """
    static let index = """
    <a class="row" href="https://isportsurge.ws/watch/regular-season/fixture/1">
    <span class="time-badge">In Progress</span>
    <img alt="UNLV Rebels" src="https://scdnmain.net/a.webp"><img alt="USC Trojans" src="https://scdnmain.net/b.webp">
    <div class="col-md-2 text-center">NCAA Women&#039;s Division I</div></a>
    <a href="https://invalid.example/watch/fixture"><img alt="Other" src="x"><img alt="Team" src="y"></a>
    """
    static func main() async throws {
        let parsed = SignalSportsWebParser.catalog(index)
        precondition(parsed.count == 1 && parsed[0].title == "UNLV Rebels vs USC Trojans")
        precondition(parsed[0].league == "NCAA Women's Division I")
        let event = SignalSportsWebParser.detail(detail, seed: .test)
        precondition(event.teams == ["UNLV Rebels", "USC Trojans"])
        let iso = ISO8601DateFormatter()
        let start = iso.date(from: "2026-11-02T21:00:00Z")!
        precondition(event.start == start)
        precondition(SignalSportsWebParser.players(detail).map(\.lastPathComponent) == ["123", "456"])
        precondition(SignalSportsWebParser.identityMatches(event: event, league: "NCAAW", teams: ["USC Trojans", "UNLV Rebels"], start: start))
        precondition(!SignalSportsWebParser.identityMatches(event: event, league: "NCAAM", teams: event.teams, start: start))
        precondition(!SignalSportsWebParser.identityMatches(event: event, league: "NCAAW", teams: event.teams, start: start.addingTimeInterval(3600)))
        precondition(!SignalSportsWebParser.identityMatches(event: event, league: "NCAAW", teams: ["USC", "UNLV"], start: start))
        precondition(!SignalSportsWebParser.identityMatches(event: parsed[0], league: "NCAAW", teams: event.teams, start: start))
        precondition(SignalSportsWebParser.media("const source = 'http://localhost/a';") == nil)
        precondition(SignalSportsWebParser.media("const source = 'https://hereisman.net.evil.example/a';") == nil)
        precondition(!SignalSportsWebParser.mediaURL(URL(string:"https://user:pass@chatgpt.hereisman.net/a")!))
        let encoded = Data("https://chatgpt.hereisman.net/playlist/fixture/load-playlist".utf8).base64EncodedString()
        precondition(SignalSportsWebParser.media("source: window.atob('\(encoded)')") != nil)
        SportsFixtureProtocol.set("success")
        let source = SignalSportsWebSource(protocolClasses: [SportsFixtureProtocol.self])
        let result = try await source.resolve(.test)
        precondition(result.event.title == event.title && result.playerCount == 2 && result.playerIndex == 0)
        precondition(result.headers["Referer"] == "https://gooz.aapmains.net/new-stream-embed/123")
        precondition(result.headers["Cookie"] == nil)
        let requests = SportsFixtureProtocol.captured()
        precondition(requests.count == 3 && requests[1].value(forHTTPHeaderField:"Referer") == SignalSportsWebEvent.test.pageURL.absoluteString)
        _ = try await source.resolve(.test)
        precondition(SportsFixtureProtocol.captured().count == 6, "Signed media URLs must not be cached between plays")
        for mode in ["html", "403", "429"] {
            SportsFixtureProtocol.set(mode)
            do { _ = try await source.resolve(.test); preconditionFailure("Invalid source accepted: \(mode)") }
            catch is SignalSportsWebError { }
            if mode == "429" { precondition(SportsFixtureProtocol.captured().count == 3, "Rate limit must stop fallback requests") }
        }
        SportsFixtureProtocol.set("success")
        var release: AsyncStream<Void>.Continuation!
        let gate = AsyncStream<Void> { release = $0 }
        let cancelled = Task { () throws -> SignalSportsWebPlayback in
            for await _ in gate { break }
            return try await source.resolve(.test)
        }
        cancelled.cancel(); release.finish()
        do { _ = try await cancelled.value; preconditionFailure("Cancelled launch accepted") }
        catch { precondition(error is CancellationError || (error as? URLError)?.code == .cancelled) }
        precondition(SportsFixtureProtocol.captured().isEmpty, "Cancelled resolution issued requests")
        print("F85 production parser/identity/transport PASS: event naming; women/men/date ambiguity; ad exclusion; host bounds; headers; fresh per-play resolution; HTML/403 rejection; cancellation")
    }
}
