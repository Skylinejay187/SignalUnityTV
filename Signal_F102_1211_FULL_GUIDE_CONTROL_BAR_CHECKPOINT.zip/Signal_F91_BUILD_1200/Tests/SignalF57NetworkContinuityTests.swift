import Foundation

@main enum SignalF57NetworkContinuityTests {
    static func main() {
        var paths = SignalProtectedPathDeduplicator<String>()
        precondition(!paths.changed("home"))
        for _ in 0..<100 { precondition(!paths.changed("home")) }
        precondition(paths.changed("different-path"))
        for _ in 0..<100 { precondition(!paths.changed("different-path")) }
        precondition(paths.changed("home"))

        let owner = UUID()
        let source = URL(string: "https://cdn.real-debrid.com/episode.mkv")!
        let headers = ["Authorization": "fixture-token"]
        var route = SignalProtectedPlaybackRoute(sessionID: owner, sourceURL: source,
            networkURL: source, headers: headers, epoch: 0, isHomeDirect: true)
        for epoch in UInt64(1)...100 {
            let checked = SignalProtectedPlaybackRoute(sessionID: owner, sourceURL: source,
                networkURL: source, headers: headers, epoch: epoch, isHomeDirect: true)
            precondition(route.requiresRecheck(eventEpoch: epoch, sessionID: owner))
            precondition(route.canContinue(with: checked))
            route = checked  // metadata only: the same URL/headers/player remain valid
            precondition(!route.requiresRecheck(eventEpoch: epoch, sessionID: owner))
        }
        let proxy = SignalProtectedPlaybackRoute(sessionID: owner, sourceURL: source,
            networkURL: URL(string: "https://home-proxy.invalid/proxy/stream")!, headers: [:], epoch: 101, isHomeDirect: false)
        precondition(!route.canContinue(with: proxy))
        let otherEpisode = SignalProtectedPlaybackRoute(sessionID: owner,
            sourceURL: URL(string: "https://cdn.real-debrid.com/another-episode.mkv")!,
            networkURL: source, headers: headers, epoch: 101, isHomeDirect: true)
        precondition(!route.canContinue(with: otherEpisode))
        let otherSession = SignalProtectedPlaybackRoute(sessionID: UUID(), sourceURL: source,
            networkURL: source, headers: headers, epoch: 101, isHomeDirect: true)
        precondition(!route.canContinue(with: otherSession))
        let differentHeaders = SignalProtectedPlaybackRoute(sessionID: owner, sourceURL: source,
            networkURL: source, headers: [:], epoch: 101, isHomeDirect: true)
        precondition(!route.canContinue(with: differentHeaders))
        print("F57 native PASS: duplicate path suppression, 100 same-player continuity checks, changed route/source/owner/header rejection")
    }
}
