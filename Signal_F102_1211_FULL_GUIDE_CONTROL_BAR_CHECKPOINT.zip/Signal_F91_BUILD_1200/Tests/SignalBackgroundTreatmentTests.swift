import Foundation

@main
struct SignalBackgroundTreatmentTests {
    static func main() {
        let limits = SignalBackgroundTreatment(blurPercent: -200, glassTransparency: 300)
        precondition(limits.blurPercent == 0 && limits.glassTransparency == 100)
        precondition(limits.blurRadius(frosted: true) == 0 && limits.glassOpacity == 0)
        let opaque = SignalBackgroundTreatment(blurPercent: 100, glassTransparency: 0)
        precondition(abs(opaque.glassOpacity - 0.68) < 0.00001)
        precondition(opaque.blurRadius(frosted: true) == 96)
        precondition(opaque.blurRadius(frosted: false) == 64)
        var previousBlur: Double = -1
        var previousTint: Double = 1
        for percent in 0...100 {
            let value = SignalBackgroundTreatment(blurPercent: percent, glassTransparency: percent)
            precondition(value.blurRadius(frosted: true) >= previousBlur)
            precondition(value.glassOpacity <= previousTint)
            previousBlur = value.blurRadius(frosted: true)
            previousTint = value.glassOpacity
            let otherTransparency = SignalBackgroundTreatment(blurPercent: percent, glassTransparency: 0)
            precondition(value.blurRadius(frosted: true) == otherTransparency.blurRadius(frosted: true))
            let otherBlur = SignalBackgroundTreatment(blurPercent: 0, glassTransparency: percent)
            precondition(value.glassOpacity == otherBlur.glassOpacity)
            precondition(value.smokeSoftness >= 4 && value.smokeSoftness <= 12)
        }
        precondition(SignalBackgroundTreatment(blurPercent: 0, glassTransparency: 35).artworkMaxPixelSize == 1920)
        precondition(SignalBackgroundTreatment(blurPercent: 20, glassTransparency: 35).artworkMaxPixelSize == 1280)
        precondition(SignalBackgroundTreatment(blurPercent: 50, glassTransparency: 35).artworkMaxPixelSize == 640)
        let suite = "SignalF32R2TreatmentTests." + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        for key in SignalBackgroundTreatment.retiredWallpaperKeys { defaults.set("retired", forKey: key) }
        defaults.set("Cinematic", forKey: "ambientClassicSmokeModeV378")
        defaults.set(20, forKey: "liveTVBackgroundBlurPercentV1")
        defaults.set(80, forKey: "liveTVBackgroundGlassTransparencyV1")
        defaults.set("Frosted Channel Artwork", forKey: "mainGridBackgroundPreset")
        SignalBackgroundTreatment.retireStandaloneWallpaper(defaults: defaults)
        SignalBackgroundTreatment.retireStandaloneWallpaper(defaults: defaults)
        for key in SignalBackgroundTreatment.retiredWallpaperKeys { precondition(defaults.object(forKey: key) == nil) }
        precondition(defaults.string(forKey: "ambientClassicSmokeModeV378") == "Cinematic")
        precondition(defaults.integer(forKey: "liveTVBackgroundBlurPercentV1") == 20)
        precondition(defaults.integer(forKey: "liveTVBackgroundGlassTransparencyV1") == 80)
        precondition(defaults.string(forKey: "mainGridBackgroundPreset") == "Frosted Channel Artwork")
        print("F32R2: bounded independent blur/transparency, 101 steps, adaptive decode budget and idempotent wallpaper retirement passed")
    }
}
