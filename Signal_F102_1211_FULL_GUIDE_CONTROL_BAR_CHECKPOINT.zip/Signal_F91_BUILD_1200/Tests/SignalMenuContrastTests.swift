import Foundation

@main
struct SignalMenuContrastTests {
    static func main() {
        precondition(SignalMenuContrast.prefersDarkInk(red: 1, green: 1, blue: 1))
        precondition(!SignalMenuContrast.prefersDarkInk(red: 0, green: 0, blue: 0))
        precondition(SignalMenuContrast.prefersDarkInk(red: 1, green: 0, blue: 0))
        precondition(SignalMenuContrast.prefersDarkInk(red: 0, green: 1, blue: 0))
        precondition(!SignalMenuContrast.prefersDarkInk(red: 0, green: 0, blue: 1))
        precondition(!SignalMenuContrast.prefersDarkInk(red: 0.38, green: 0.1, blue: 0.78))
        precondition(SignalMenuContrast.prefersDarkInk(red: 1, green: 0.94, blue: 0.84))
        precondition(!SignalMenuContrast.prefersDarkInk(red: .nan, green: -1, blue: 0))
        precondition(SignalMenuContrast.prefersDarkInk(red: 2, green: 2, blue: 2))
        precondition(TopMenuThemeStyle.implementedThemes.count == 30)
        let revived: [TopMenuThemeStyle] = [.auroraReborn, .marqueeReborn, .retroReborn, .graphiteReborn, .copperReborn, .polarReborn]
        for theme in revived {
            precondition(TopMenuThemeStyle.resolve(theme.rawValue) == theme)
            precondition(!theme.summary.isEmpty)
        }
        print("F33: readable accent ink, invalid component bounds, 30 layouts and six revived theme identities passed")
    }
}
