"""Reproduce the CI install-before-XcodeGen ordering without downloading an engine.

The installed tree is a local fixture, not a real engine compilation/playback test.
Actual installer, bridge and production Swift sources are never modified.
"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'Scripts'))
from source_hash_integrity import verify_unchanged_sources, ENGINE_PLACEHOLDERS


def write(root, name, text):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def seed_packaged_engine(root):
    # CI runs this suite after the real installer has removed these placeholders.
    # Never derive a fixture from that mutable production dependency directory.
    fixtures = json.loads((ROOT / 'Tests/F80EnginePlaceholders.json').read_text())
    manifest = json.loads((ROOT / 'Tests/F79UnchangedSourceHashes.json').read_text())
    assert set(fixtures) == ENGINE_PLACEHOLDERS
    for name, text in fixtures.items():
        assert hashlib.sha256(text.encode()).hexdigest() == manifest[name], name
        write(root, name, text)


def copy_project_fixture(root):
    def ignore(directory, names):
        skipped = set(shutil.ignore_patterns('__pycache__', '.build-cache', '*.pyc', '.git')(directory, names))
        if Path(directory).resolve() == (ROOT / 'Vendor').resolve():
            skipped.add('AetherEngine')
        return skipped
    shutil.copytree(ROOT, root, ignore=ignore)
    seed_packaged_engine(root)


def stage_fixture(root):
    engine = root / 'Vendor/AetherEngine'
    shutil.rmtree(engine)
    files = {
        'Package.swift': '// swift-tools-version: 6.1\n',
        '.signal-f28-version': '7.44.0\n',
        'Sources/AetherEngine/Audio/AudioDecoder.swift': 'func setGainDB(_ db: Double) {}\n// decodedGainLinear\n',
        'Sources/AetherEngine/Native/SoftwarePlaybackHost.swift': '// aDec.setGainDB(signalAudioGainDB)\n',
        'Sources/AetherEngine/AetherEngine+SignalAudioGain.swift': 'public func setDecodedAudioGainDB() {}\n',
        'Sources/AetherEngine/AetherEngine+SignalCacheFrontier.swift': 'public func refreshSignalBufferFrontier() {}\n',
        'Sources/AetherEngine/Native/NativeAVPlayerHost.swift': 'func signalCachedBufferEnd() -> Double { 0 }\n',
    }
    for name, text in files.items():
        write(engine, name, text)
    for args in [
        ['init', '-q'], ['add', '.'],
        ['-c', 'user.name=Signal F80 Fixture', '-c', 'user.email=fixture@example.invalid',
         '-c', 'commit.gpgsign=false', 'commit', '-qm', 'local staged lifecycle fixture'],
        ['tag', '7.44.0'],
    ]:
        subprocess.run(['git', '-C', str(engine), *args], check=True, capture_output=True)


class EngineLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='signal-f80-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        seed_packaged_engine(self.root)
        for name in ['Scripts/verify_f28_aether_integration.py',
                     'Sources/SignalPauseInfoPolicy.swift', 'Vendor/AetherPlaybackKit/Package.swift',
                     'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift',
                     'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift']:
            target = self.root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / name, target)
        self.hashes = {str(p.relative_to(self.root)): hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in self.root.rglob('*.swift')}

    def test_packaged_placeholders_keep_exact_hashes(self):
        self.assertEqual(verify_unchanged_sources(self.root, self.hashes), 'packaged-exact-hashes')

    def test_unstaged_drift_or_missing_placeholder_is_rejected(self):
        package = self.root / 'Vendor/AetherEngine/Package.swift'
        original = package.read_bytes()
        package.write_text('unauthorized replacement')
        with self.assertRaises(AssertionError):
            verify_unchanged_sources(self.root, self.hashes)
        package.write_bytes(original)
        (self.root / 'Vendor/AetherEngine/Sources/AetherEngine/Placeholder.swift').unlink()
        with self.assertRaises(AssertionError):
            verify_unchanged_sources(self.root, self.hashes)

    def test_verified_staged_engine_is_accepted(self):
        stage_fixture(self.root)
        self.assertEqual(verify_unchanged_sources(self.root, self.hashes), 'verified-installed-7.44.0')

    def test_wrong_tag_broken_hook_or_missing_checkout_is_rejected(self):
        stage_fixture(self.root)
        engine = self.root / 'Vendor/AetherEngine'
        marker = engine / '.signal-f28-version'
        marker.write_text('7.43.0')
        with self.assertRaises(AssertionError):
            verify_unchanged_sources(self.root, self.hashes)
        marker.write_text('7.44.0\n')
        subprocess.run(['git', '-C', str(engine), 'tag', '-d', '7.44.0'], check=True, capture_output=True)
        subprocess.run(['git', '-C', str(engine), 'tag', 'wrong-tag'], check=True)
        with self.assertRaises(AssertionError):
            verify_unchanged_sources(self.root, self.hashes)
        subprocess.run(['git', '-C', str(engine), 'tag', '-d', 'wrong-tag'], check=True, capture_output=True)
        subprocess.run(['git', '-C', str(engine), 'tag', '7.44.0'], check=True)
        hook = engine / 'Sources/AetherEngine/AetherEngine+SignalAudioGain.swift'
        original = hook.read_bytes()
        hook.write_text('// missing gain integration')
        with self.assertRaises(subprocess.CalledProcessError):
            verify_unchanged_sources(self.root, self.hashes)
        hook.write_bytes(original)
        shutil.rmtree(engine / '.git')
        with self.assertRaises(AssertionError):
            verify_unchanged_sources(self.root, self.hashes)

    def test_non_engine_vendor_and_app_hashes_remain_strict(self):
        stage_fixture(self.root)
        for name in ['Sources/SignalPauseInfoPolicy.swift', 'Vendor/AetherPlaybackKit/Package.swift',
                     'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift',
                     'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift']:
            path = self.root / name
            original = path.read_bytes()
            path.write_bytes(original + b'\n// unapproved edit\n')
            with self.assertRaises((AssertionError, subprocess.CalledProcessError)):
                verify_unchanged_sources(self.root, self.hashes)
            path.write_bytes(original)


class CurrentCheckerOrderingTests(unittest.TestCase):
    def test_actual_f78_f79_checkers_before_and_after_install(self):
        with tempfile.TemporaryDirectory(prefix='signal-f80-order-') as directory:
            root = Path(directory) / 'source'
            copy_project_fixture(root)
            for phase in ['packaged', 'installed']:
                if phase == 'installed':
                    stage_fixture(root)
                    # F79's old raw-hash loop rejected exactly this intended change.
                    manifest = json.loads((root / 'Tests/F79UnchangedSourceHashes.json').read_text())
                    self.assertNotEqual(hashlib.sha256((root / 'Vendor/AetherEngine/Package.swift').read_bytes()).hexdigest(),
                                        manifest['Vendor/AetherEngine/Package.swift'])
                for name in ['check_f79_playback_artwork.py', 'check_f78_artwork.py']:
                    with self.subTest(phase=phase, checker=name):
                        result = subprocess.run([sys.executable, str(root / 'Scripts' / name)],
                                                capture_output=True, text=True, timeout=90)
                        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == '__main__':
    unittest.main()
