import Foundation

@main struct SignalF36OptionsTests {
    static func main() {
        precondition(SignalLiveTVCardTheme.names.count == 22)
        precondition(SignalLiveTVCardEffect.names.count == 56)
        var combinations = 0
        for shape in SignalLiveTVCardTheme.names {
            for effect in SignalLiveTVCardEffect.names {
                for focused in [false,true] {
                    let surface = SignalLiveTVCardTheme.surface(shape, focused: focused)
                    precondition((0...18).contains(surface.depth) && (0...1).contains(surface.bevel))
                    precondition(SignalLiveTVCardTheme.radius(shape) > 0)
                    for column in 0..<4 {
                        let pose = SignalLiveTVCardEffect.pose(effect,column:column,focused:focused)
                        precondition(pose.depth == 0 && pose.bevel == 0, "Motion may not choose the physical surface")
                        precondition([pose.yaw,pose.pitch,pose.roll,pose.x,pose.y].allSatisfy { $0.isFinite })
                        precondition(abs(pose.yaw) <= 24)
                        combinations += 1
                    }
                }
            }
        }
        precondition(combinations == 22 * 56 * 2 * 4)
        let glass = SignalLiveTVCardTheme.surface("Raised Glass", focused:true)
        precondition(glass.depth == 10 && glass.bevel == 0.55)
        precondition(SignalLiveTVCardEffect.pose("Dual Inward",column:0,focused:true).yaw == 8.5)
        var prior = 0.0
        for effect in ["Curved Wall Soft","Curved Wall","Curved Wall Strong","Curved Wall Deep","Curved Wall Max"] {
            let yaw = abs(SignalLiveTVCardEffect.pose(effect,column:0,focused:true).yaw)
            precondition(yaw > prior); prior = yaw
        }
        let defaultsName = "Signal.F36.Test." + UUID().uuidString
        let defaults = UserDefaults(suiteName:defaultsName)!
        defer { defaults.removePersistentDomain(forName:defaultsName) }
        defaults.set("Original UNITY",forKey:"signalLiveTVCardThemeV342")
        defaults.set("Raised Glass",forKey:"signalLiveTVCardEffectV344")
        SignalLiveTVCardTheme.migrateSurfaceSplit(defaults:defaults)
        precondition(defaults.string(forKey:"signalLiveTVCardThemeV342") == "Raised Glass")
        defaults.set("Heavy",forKey:"ambientClassicSmokeModeV378")
        SignalGlassAtmosphereStyle.migrateRetiredSmoke(defaults:defaults)
        precondition(defaults.string(forKey:"signalGlassAtmosphereV1") == "Smoke · Cinematic")
        precondition(defaults.object(forKey:"ambientClassicSmokeModeV378") == nil)
        defaults.set("Off",forKey:"signalGlassAtmosphereV1")
        defaults.set("Orbs",forKey:"ambientClassicSmokeModeV378")
        SignalGlassAtmosphereStyle.migrateRetiredSmoke(defaults:defaults)
        precondition(defaults.string(forKey:"signalGlassAtmosphereV1") == "Off")
        precondition(SignalGlassAtmosphereStyle.allCases.count == 6)
        var style = "Off"
        for _ in SignalGlassAtmosphereStyle.allCases { style = SignalGlassAtmosphereStyle.next(style) }
        precondition(style == "Off")
        precondition(SignalSearchEffectStyle.allCases.count == 11)
        var search = "Off"
        for _ in SignalSearchEffectStyle.allCases { search = SignalSearchEffectStyle.next(search) }
        precondition(search == "Off")
        precondition(!SignalSearchEffectStyle.off.animates(focused:true))
        precondition(!SignalSearchEffectStyle.focusOnly.animates(focused:false))
        precondition(SignalSearchEffectStyle.focusOnly.animates(focused:true))
        precondition(SignalSearchEffectStyle.resolve("missing") == .orbit)
        var gate = SignalDuplicateCommandGate()
        precondition(gate.accept(identity:"A|left",now:1))
        precondition(!gate.accept(identity:"A|left",now:1.02))
        precondition(gate.accept(identity:"B|left",now:1.03))
        precondition(gate.accept(identity:"A|left",now:1.04))
        precondition(!gate.accept(identity:"A|left",now:1.05))
        precondition(gate.accept(identity:"A|right",now:1.06))
        precondition(gate.accept(identity:"A|right",now:1.30))
        precondition(!gate.accept(identity:"A|left",now:.nan))
        precondition(SignalPreviewStartupPolicy.dwellNanoseconds == 650_000_000)
        print("F36/F42: 9856 independent shape/motion combinations; five curvature levels; visual choices/migrations; duplicate delivery gate passed")
    }
}
