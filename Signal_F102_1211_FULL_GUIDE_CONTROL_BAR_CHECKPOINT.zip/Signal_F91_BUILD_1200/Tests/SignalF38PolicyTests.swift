import Foundation

@main struct SignalF38PolicyTests {
    struct Row: Equatable { let service: String; let addon: String; let rank: Int }
    static func main() {
        let input = [Row(service:"TB",addon:"Torrentio",rank:1), Row(service:"TB",addon:"Torrentio",rank:2),
                     Row(service:"TB",addon:"Comet",rank:1), Row(service:"RD",addon:"Torrentio",rank:1),
                     Row(service:"RD",addon:"Torrentio",rank:2), Row(service:"RD",addon:"Comet",rank:1)]
        let mixed = SignalSourceMixingPolicy.interleaved(input, limit:6, service:{$0.service}, addon:{$0.addon})
        precondition(mixed.map(\.service) == ["TB","RD","TB","RD","TB","RD"])
        precondition(mixed.map(\.addon) == ["Torrentio","Torrentio","Comet","Comet","Torrentio","Torrentio"])
        precondition(mixed.filter{$0.service=="TB" && $0.addon=="Torrentio"}.map(\.rank) == [1,2])
        precondition(SignalSourceMixingPolicy.interleaved(input, limit:0, service:{$0.service}, addon:{$0.addon}).isEmpty)
        let uneven = SignalSourceMixingPolicy.interleaved(Array(input.prefix(4)),limit:50,service:{$0.service},addon:{$0.addon})
        precondition(uneven.count==4 && Set(uneven.map{ $0.service+"|"+$0.addon+"|"+String($0.rank) }).count==4)
        for n in 0...6 {
            precondition(SignalSourceMixingPolicy.interleaved(input,limit:n,service:{$0.service},addon:{$0.addon}).count==n)
        }
        var gate=SignalRemoteRepeatGate()
        precondition(gate.accept(owner:"catalog",direction:"left",now:1))
        precondition(!gate.accept(owner:"catalog",direction:"left",now:1.02))
        precondition(!gate.accept(owner:"catalog",direction:"left",now:1.09))
        precondition(gate.accept(owner:"catalog",direction:"left",now:1.13))
        precondition(gate.accept(owner:"catalog",direction:"right",now:1.14))
        precondition(gate.accept(owner:"live",direction:"right",now:1.15))
        precondition(!gate.accept(owner:"live",direction:"right",now:.nan))
        precondition(TopMenuThemeStyle.implementedThemes.count==30)
        for theme in TopMenuThemeStyle.implementedThemes { precondition(TopMenuThemeStyle.resolve(theme.rawValue)==theme) }
        precondition(TopMenuThemeStyle.resolve("Signal Original Glass") == .signalOriginal)
        for raw in ["Soft Caustics","Liquid Light","Aurora Drift","Glass Refraction","Ocean Glow"] {
            precondition(SignalGlassAtmosphereStyle.resolve(raw) != .off)
            precondition(SignalGlassAtmosphereStyle.resolve(raw).rawValue.hasPrefix("Smoke"))
        }
        print("F38 source alternation/addon fairness, routed-repeat gate, 30 theme identities and smoke migration passed")
    }
}
