import Foundation

@main
struct SignalBackgroundThemeTests {
    static func main() {
        let themes = SignalBackgroundTheme.allCases
        precondition(themes.count == 12)
        precondition(Set(themes.map { $0.rawValue }).count == themes.count)
        for theme in themes {
            precondition(SignalBackgroundTheme.resolve(theme.rawValue) == theme)
            precondition(SignalBackgroundTheme.resolve("  " + theme.rawValue.uppercased() + "\n") == theme)
            precondition(!theme.summary.isEmpty)
        }
        precondition(themes.filter { $0.usesChannelArtwork }.count == 2)
        precondition(!SignalBackgroundTheme.pureBlack.usesChannelArtwork)
        let migrations: [String: SignalBackgroundTheme] = [
            "Pure Black": .pureBlack, "Midnight Graphite": .smokedGlass,
            "Deep Navy": .polarGlass, "Ocean Blue": .polarGlass, "Steel Blue": .polarGlass,
            "Slate": .smokedGlass, "Charcoal": .smokedGlass, "Forest": .auroraVeil,
            "Deep Teal": .auroraVeil, "Emerald Night": .auroraVeil,
            "Royal Purple": .prismGlass, "Plum": .prismGlass, "Burgundy": .cinemaHalo,
            "Deep Red": .cinemaHalo, "Espresso": .silkDunes, "Warm Bronze": .silkDunes,
            "Soft Graphite": .smokedGlass, "Cinema Blue": .polarGlass
        ]
        for (old, expected) in migrations { precondition(SignalBackgroundTheme.resolve(old) == expected) }
        precondition(SignalBackgroundTheme.resolve("unrecognized backup value") == .defaultTheme)
        // Exhaust all 32 states: hidden, Guide, covered, inactive and playback
        // conditions must each independently prevent artwork/abstract ownership.
        for bits in 0..<32 {
            let scene = bits & 1 != 0
            let dashboard = bits & 2 != 0
            let guide = bits & 4 != 0
            let covered = bits & 8 != 0
            let playback = bits & 16 != 0
            let actual = SignalBackgroundTheme.ownsArtworkBudget(sceneActive: scene,
                dashboardVisible: dashboard, guideVisible: guide, covered: covered, playbackActive: playback)
            precondition(actual == (bits == 3), "Lifecycle gate state \(bits)")
        }
        let suite = "SignalF32BackgroundTests." + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        for theme in themes {
            defaults.set(theme.rawValue, forKey: "mainGridBackgroundPreset")
            precondition(SignalBackgroundTheme.resolve(UserDefaults(suiteName: suite)!.string(forKey: "mainGridBackgroundPreset")!) == theme)
        }
        print("F32: 12 background identities, 18 migrations, persistence and 32 lifecycle states passed")
    }
}
