import Foundation

@main struct SignalF37PreviewPolicyTests {
    static func main() {
        precondition(SignalPreviewStartupPolicy.dwellNanoseconds == 650_000_000)
        precondition(SignalPreviewStartupPolicy.revealHoldSeconds == 2.0)
        let focus = 100.0
        precondition(SignalPreviewStartupPolicy.revealWaitNanoseconds(focusedAt:focus, now:focus) == 2_000_000_000)
        let wait = SignalPreviewStartupPolicy.revealWaitNanoseconds(focusedAt:focus, now:focus + 0.65)
        precondition((1_350_000_000...1_350_000_001).contains(wait))
        precondition(SignalPreviewStartupPolicy.revealWaitNanoseconds(focusedAt:focus, now:focus + 2.0) == 0)
        precondition(SignalPreviewStartupPolicy.revealWaitNanoseconds(focusedAt:focus, now:focus + 9) == 0)
        precondition(SignalPreviewStartupPolicy.revealWaitNanoseconds(focusedAt:.nan, now:101) == 2_000_000_000)
        precondition(SignalPreviewStartupPolicy.revealWaitNanoseconds(focusedAt:focus, now:99) == 2_000_000_000)
        // A fast source must stay hidden; a slow source must not reveal a black frame.
        precondition(!SignalPreviewStartupPolicy.mayReveal(frameReady:true, holdElapsed:false))
        precondition(!SignalPreviewStartupPolicy.mayReveal(frameReady:false, holdElapsed:true))
        precondition(!SignalPreviewStartupPolicy.mayReveal(frameReady:false, holdElapsed:false))
        precondition(SignalPreviewStartupPolicy.mayReveal(frameReady:true, holdElapsed:true))
        // Page edges have one delivery filter, without the former 650 ms second-press gate.
        var edge = SignalDuplicateCommandGate()
        precondition(edge.accept(identity:"page2-left",now:1))
        precondition(!edge.accept(identity:"page2-left",now:1.01))
        precondition(edge.accept(identity:"page1-right",now:1.02))
        precondition(edge.accept(identity:"page2-left",now:1.03))
        precondition(edge.accept(identity:"page2-left",now:1.20))
        print("F37 reveal timing/readiness and page-edge delivery tests passed")
    }
}
