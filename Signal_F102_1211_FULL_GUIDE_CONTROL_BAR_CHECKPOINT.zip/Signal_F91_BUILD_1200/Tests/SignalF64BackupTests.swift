import Foundation
// Isolated boundary dependencies; no Keychain/network or migration calls in these tests.
enum BackupStreamingCredentialStore { static func purgeForFreshInstall() -> Bool { true } }
enum MediaFlowCredentialStore { static func purgeForFreshInstall() -> Bool { true } }
enum NuvioPluginPreferences { static func purgeForFreshInstall(defaults: UserDefaults) -> Bool { true } }
enum SignalIntroDBCredential { static func save(_ value: String) -> Bool { true } }

@main struct SignalF64BackupTests {
    static func main() throws {
        let name = "Signal.F64.Backup." + UUID().uuidString
        let store = UserDefaults(suiteName:name)!
        defer { store.removePersistentDomain(forName:name) }
        store.set("button",forKey:"episodeNextStyleV1")
        store.set("season",forKey:"episodeContinuousV1")
        store.set(true,forKey:"episodeAutoIntroV1")
        store.set(false,forKey:"episodeIntroDBV1")
        store.set(true,forKey:"episodeIntroDBKeyPresentV1")
        store.set(false,forKey:"metadataCacheEnabledV1")
        let settings = ReleaseCandidateSecurityManager.sanitizedRestoredSettings(SignalPortableSettings.snapshot(store))
        let vault = ReleaseCandidateSecurityManager.sanitizedCredentialVault(["introDBAPIKey":"idb_fixture", "unknownSecret":"never-copy"])
        precondition(vault.count == 1 && vault["introDBAPIKey"] == "idb_fixture")
        let data = try JSONSerialization.data(withJSONObject:["settings":settings,"credentialVault":vault])
        let envelope = try JSONSerialization.jsonObject(with:data) as! [String:Any]
        let restored = ReleaseCandidateSecurityManager.sanitizedRestoredSettings(envelope["settings"] as! [String:Any])
        precondition(restored["episodeNextStyleV1"] as? String == "button")
        precondition(restored["episodeContinuousV1"] as? String == "season")
        precondition(restored["episodeAutoIntroV1"] as? Bool == true)
        precondition(restored["episodeIntroDBV1"] as? Bool == false)
        precondition(restored["episodeIntroDBKeyPresentV1"] as? Bool == true)
        precondition(restored["metadataCacheEnabledV1"] as? Bool == false)
        precondition(restored["introDBAPIKey"] == nil)
        precondition(ReleaseCandidateSecurityManager.sanitizedCredentialVault(envelope["credentialVault"] as! [String:Any])["introDBAPIKey"] == "idb_fixture")
        precondition(ReleaseCandidateSecurityManager.sanitizedCredentialVault(["introDBAPIKey":String(repeating:"x",count:4097)]).isEmpty)
        precondition(ReleaseCandidateSecurityManager.sanitizedCredentialVault(["introDBAPIKey":"   "]).isEmpty)
        print("F64 real settings/credential-vault JSON round trip and invalid-secret rejection PASS")
    }
}
