@main struct SignalF71ReturnSourcesTests {
    @MainActor static func main() {
        let detail=MediaItem(id:"series",type:"series")
        let episode=MediaItem(id:"series:2:3",type:"series")
        let other=MediaItem(id:"another",type:"movie")
        let links=(0..<200).map { StreamLink(id:"link-\($0)",url:"https://example.invalid/\($0)") }
        let chosen=URL(string:links[190].url!)!
        let store=ReturnFixture();store.selectedDetail=detail
        store.rememberVODReturnSources(for:episode,links:links,selectedURL:chosen)
        precondition(store.vodSourceReturnSnapshot!.links.count == 128)
        precondition(store.vodSourceReturnSnapshot!.links.contains(links[190]))
        precondition(store.consumeVODReturnSources(for:detail) == nil, "Cannot restore before an authorized close")
        store.vodSourceReturnReady=true
        precondition(store.consumeVODReturnSources(for:other) == nil, "Never show another title's links")
        store.playbackURL=chosen
        precondition(store.consumeVODReturnSources(for:detail) == nil)
        store.playbackURL=nil;store.vodExclusivePlaybackActive=true
        precondition(store.consumeVODReturnSources(for:detail) == nil)
        store.vodExclusivePlaybackActive=false
        let restored=store.consumeVODReturnSources(for:detail)!
        precondition(restored.item == episode && restored.selectedURL == chosen && restored.selectedIndex == 127)
        precondition(store.streamLinks.count == 128 && store.visibleStreamLinksItem == episode)
        precondition(store.selectedSourceProvider == "All Providers" && store.streamPublications == 1)
        precondition(store.vodSourceReturnSnapshot == nil && !store.vodSourceReturnReady)
        precondition(store.consumeVODReturnSources(for:detail) == nil && store.streamPublications == 1)
        // A new title replaces the one bounded snapshot; no title/episode map grows indefinitely.
        store.rememberVODReturnSources(for:episode,links:links,selectedURL:chosen)
        store.selectedDetail=other
        store.rememberVODReturnSources(for:other,links:[links[0]],selectedURL:URL(string:links[0].url!)!)
        precondition(store.vodSourceReturnSnapshot!.item == other && store.vodSourceReturnSnapshot!.links.count == 1)
        let empty=ReturnFixture();empty.selectedDetail=detail
        empty.rememberVODReturnSources(for:episode,links:[],selectedURL:chosen)
        empty.rememberVODReturnSources(for:MediaItem(id:"channel",type:"live"),links:links,selectedURL:chosen)
        precondition(empty.vodSourceReturnSnapshot == nil)
        print("F71 source-return: exact episode/detail ownership, 128 cap with selected source retained, active playback/resource gates, single-use release and new-title replacement passed")
    }
}
