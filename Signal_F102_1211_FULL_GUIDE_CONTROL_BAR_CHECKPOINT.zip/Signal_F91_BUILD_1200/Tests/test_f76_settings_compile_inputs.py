#!/usr/bin/env python3
"""Inspect the actual native-check invocation; no compiler execution is claimed."""
from pathlib import Path
from contextlib import redirect_stdout
import io
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'Scripts'))
import check_f64_native_episode_experience as native


def require_preview_definition(command):
    files = [Path(arg) for arg in command if str(arg).endswith('.swift')]
    settings = native.ROOT / 'Sources/SignalEpisodeExperienceSettings.swift'
    assert settings in files, 'SDK check must include the actual Settings view'
    assert 'SignalQuickGuidePreviewMode.allCases' in settings.read_text()
    assert any('enum SignalQuickGuidePreviewMode:' in path.read_text()
               for path in files if path.exists()), 'Missing production SignalQuickGuidePreviewMode definition'


class SettingsCompileInputsTests(unittest.TestCase):
    def sdk_command(self):
        with patch.object(sys, 'argv', ['check_f64_native_episode_experience.py']), \
             patch.object(native.shutil, 'which', return_value='/fixture/swiftc'), \
             patch.object(native.subprocess, 'run') as run, \
             patch.object(native.subprocess, 'check_output', return_value='/fixture/AppleTVOS.sdk'):
            with redirect_stdout(io.StringIO()):
                native.main()
        commands = [call.args[0] for call in run.call_args_list]
        return next(command for command in commands if '-typecheck' in command)

    def test_actual_sdk_invocation_has_preview_policy_dependency(self):
        require_preview_definition(self.sdk_command())

    def test_supplied_log_missing_dependency_is_rejected(self):
        command = self.sdk_command()
        policy = str(native.ROOT / 'Sources/SignalLiveTVResourcePolicy.swift')
        broken = [arg for arg in command if arg != policy]
        with self.assertRaisesRegex(AssertionError, 'Missing production SignalQuickGuidePreviewMode'):
            require_preview_definition(broken)


if __name__ == '__main__':
    unittest.main()
