import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
S=lambda name:(ROOT/'Sources'/name).read_text()
class F88Regressions(unittest.TestCase):
    def test_sports_fixture_only_in_tests(self):
        self.assertNotIn('result.append(test)',S('SignalSportsOnlinePlayer.swift'))
        self.assertNotIn('sports-web-test',S('SignalSportsOnlinePlayer.swift'))
        self.assertNotIn('static let test',S('SignalSportsWebSource.swift'))
        self.assertIn('static let test', (ROOT/'Tests/SignalF85SportsTests.swift').read_text())
    def test_sports_isolation(self):
        root=S('DebridChannelsTVOSApp.swift')
        self.assertIn('@AppStorage("sportsCatalogLayoutV1")',root)
        self.assertIn('fixedPreviewCardWidth: sportsCatalogLayout == "3D Cover Flow" ? nil : 146',root)
        self.assertIn('"sportsCatalogLayoutV1": "Regular Catalog"',S('SignalPortableSettings.swift'))
    def test_perf_shade_static(self):
        src=S('SignalUnityDashboardShade.swift')
        section=src.split('struct SignalUnityDashboardShade: View')[1]
        self.assertEqual(section.count('LinearGradient('),1)
        self.assertNotIn('Material',section)
        self.assertNotIn('blur(',section)
        self.assertNotIn('animation(',section)
    def test_restored_cache_not_wiped_on_initial_scope(self):
        src=S('DebridChannelsTVOSApp.swift')
        start=src.index('private func ensureIPTVScopeRevision()')
        part=src[start:src.index('func loadCachedOrDemo()',start)]
        self.assertIn('guard previous != nil, restricted else { return }',part)
    def test_logo_settings_only(self):
        self.assertIn('topLeftDebridChannelsLogoEnabled && store.selectedTab == .settings',S('DebridChannelsTVOSApp.swift'))
    def test_organizer_nonblocking(self):
        src=S('SignalIPTVImportView.swift')
        self.assertIn('HStack(alignment: .top, spacing: 22)',src)
        self.assertIn('Task { @MainActor in await onApply() }',src)
        self.assertNotIn('await onApply()\n                                applying = false',src)
if __name__=='__main__':unittest.main()
