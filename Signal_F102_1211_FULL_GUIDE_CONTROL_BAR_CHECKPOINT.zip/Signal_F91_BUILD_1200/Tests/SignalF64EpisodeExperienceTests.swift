import Foundation

struct MediaItem {
    var id: String = "tt0903747:1:1"
    var imdbId: String? = "tt0903747"
    var tmdbId: String? = nil
    var tvdbId: String? = nil
    var type: String = "series"
    var seasonNumber: Int? = 1
    var episodeNumber: Int? = 1
}
struct PlaybackChapterMarker { let startSeconds: Double; let endSeconds: Double; let title: String }
struct VODIntroMarker {
    let startSeconds: Double; let endSeconds: Double; let chapterIndex: Int?
    var isStorySafe: Bool { startSeconds >= 0 && endSeconds > startSeconds && endSeconds - startSeconds <= 240 }
}

final class F64MetadataProtocol: URLProtocol {
    private static let lock = NSLock()
    private static var hits = 0, active = 0, peak = 0
    private var finished = false
    private var started = false
    static func counters() -> (Int, Int) { lock.lock(); defer { lock.unlock() }; return (hits, peak) }
    override class func canInit(with request: URLRequest) -> Bool { request.url?.host == "signal-metadata.test" }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.lock.lock()
        guard !finished else { Self.lock.unlock(); return }
        started = true; Self.hits += 1; Self.active += 1; Self.peak = max(Self.peak, Self.active); Self.lock.unlock()
        DispatchQueue.global().asyncAfter(deadline: .now() + 0.05) { [self] in
            Self.lock.lock()
            guard !finished else { Self.lock.unlock(); return }
            finished = true; Self.active -= 1; Self.lock.unlock()
            let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: ["Content-Type":"application/json"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: Data("{\"title\":\"Fixture\"}".utf8))
            client?.urlProtocolDidFinishLoading(self)
        }
    }
    override func stopLoading() {
        Self.lock.lock(); defer { Self.lock.unlock() }
        if !finished { finished = true; if started { Self.active -= 1 } }
    }
}

@main struct SignalF64EpisodeExperienceTests {
    @MainActor static func main() async throws {
        let suite = "Signal.F64." + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        var options = SignalEpisodeOptions.load(defaults)
        precondition(options.skipDB && options.introDB && options.introHater && options.theIntroDB && options.aniSkip)
        precondition(!options.autoIntro && !options.autoRecap && !options.submit && options.credits == "keep")
        precondition(options.countdown == 15 && options.appearance == 240 && options.stillCount == 3)
        defaults.set(-400, forKey: "episodeCountdownV1"); defaults.set(10000, forKey: "episodeNextAppearanceV1")
        defaults.set("not-a-mode", forKey: "episodeContinuousV1")
        options = .load(defaults)
        precondition(options.countdown == 3 && options.appearance == 600 && options.continuous == "series")
        defaults.set("season", forKey: "episodeContinuousV1"); options = .load(defaults)
        precondition(options.allowsNext(currentSeason: 1, nextSeason: 1) && !options.allowsNext(currentSeason: 1, nextSeason: 2))
        precondition(!options.allowsNext(currentSeason: nil, nextSeason: nil))
        defaults.set("off", forKey: "episodeContinuousV1"); options = .load(defaults)
        precondition(!options.allowsNext(currentSeason: 1, nextSeason: 1))
        // F65: execute the actual current parser, embedded chapter adapter and seek policy.
        let recapJSON: [String: Any] = ["recap": ["start_sec": NSNull(), "end_sec": 45]]
        let decodedRecaps = SignalEpisodeSegmentService.parse(recapJSON, provider: "introdb", duration: 1200)
        precondition(decodedRecaps.count == 1 && decodedRecaps[0].start == 0 && decodedRecaps[0].end == 45)
        let chapterRecaps = SignalEpisodeSegmentService.chapterRecaps([
            PlaybackChapterMarker(startSeconds: 0, endSeconds: 40, title: "Previously on Signal"),
            PlaybackChapterMarker(startSeconds: 40, endSeconds: 80, title: "Opening"),
            PlaybackChapterMarker(startSeconds: 800, endSeconds: 850, title: "Recap"),
            PlaybackChapterMarker(startSeconds: 0, endSeconds: .nan, title: "Recap")], duration: 1200)
        precondition(chapterRecaps.count == 1 && chapterRecaps[0].provider == "embedded-chapter")
        defaults.set(true, forKey: "episodeAutoRecapV1")
        let recapOptions = SignalEpisodeOptions.load(defaults)
        precondition(SignalEpisodeSkipPlan.action(segments: chapterRecaps, consumed: [], position: 10, duration: 1200, options: recapOptions) == .seek(40, chapterRecaps[0].id))
        precondition(SignalEpisodeSkipPlan.action(segments: chapterRecaps, consumed: [chapterRecaps[0].id], position: 10, duration: 1200, options: recapOptions) == .none)
        precondition(SignalEpisodeSkipPlan.action(segments: chapterRecaps, consumed: [], position: 40, duration: 1200, options: recapOptions) == .none)
        defaults.set(false, forKey: "episodeAutoRecapV1")
        SignalF68GuideMetadataTests.verify()
        try await SignalF66EpisodeClockTests.verify(options: SignalEpisodeOptions.load(defaults))
        let root = URL(fileURLWithPath: CommandLine.arguments[1])
        for (name, provider, expected) in [("skipdb_out_of_range","skipdb",0),("introdb","introdb",1),("theintrodb","theintrodb",2),("introhater_source_contract","introhater",2)] {
            let json = try JSONSerialization.jsonObject(with: Data(contentsOf: root.appendingPathComponent(name + ".json")))
            let segments = SignalEpisodeSegmentService.parse(json, provider: provider, duration: 3500)
            precondition(segments.count == expected, "Wrong actual-provider decoding: \(name)")
        }
        let invalid: [[String: Any]] = [["start": Double.nan,"end":20,"label":"Intro"],["start":20,"end":10,"label":"Intro"],["start":0,"end":800,"label":"Intro"],["start":0,"end":20,"label":"unknown"]]
        precondition(SignalEpisodeSegmentService.parse(invalid, provider: "introhater", duration: 100).isEmpty)
        let credits = SignalEpisodeSegment(kind: .credits,start: 900,end: 1000,provider:"introdb")
        let scene = SignalEpisodeSegment(kind: .postCredits,start: 950,end: 970,provider:"introdb")
        defaults.set("skip",forKey:"episodeCreditsV1");options = .load(defaults)
        precondition(SignalEpisodeSkipPlan.action(segments:[credits,scene],consumed:[],position:910,duration:1000,options:options) == .seek(950,credits.id))
        precondition(SignalEpisodeSkipPlan.action(segments:[credits,scene],consumed:[],position:960,duration:1000,options:options) == .none)
        precondition(SignalEpisodeSkipPlan.action(segments:[credits],consumed:[credits.id],position:910,duration:1000,options:options) == .none)
        precondition(SignalEpisodeSkipPlan.action(segments:[credits],consumed:[],position:.nan,duration:1000,options:options) == .none)
        defaults.set("next",forKey:"episodeCreditsV1");options = .load(defaults)
        precondition(SignalEpisodeSkipPlan.action(segments:[credits],consumed:[],position:910,duration:1000,options:options) == .next(credits.id))
        defaults.set(true,forKey:"episodeAutoRecapV1");options = .load(defaults)
        let recap = SignalEpisodeSegment(kind:.recap,start:0,end:40,provider:"skipdb")
        precondition(SignalEpisodeSkipPlan.action(segments:[recap],consumed:[],position:10,duration:1000,options:options) == .seek(40,recap.id))
        let chapters = [PlaybackChapterMarker(startSeconds:0,endSeconds:100,title:"A"),PlaybackChapterMarker(startSeconds:100,endSeconds:200,title:"B")]
        precondition(SignalEpisodeSkipPlan.chapterTarget(chapters,position:50,duration:200,forward:true) == 100)
        precondition(SignalEpisodeSkipPlan.chapterTarget(chapters,position:110,duration:200,forward:false) == 100)
        precondition(SignalEpisodeSkipPlan.chapterTarget(chapters,position:110,duration:200,forward:true) == nil)
        let session = SignalContinuousPlaybackSession.shared
        defaults.set(2,forKey:"episodeStillCountV1");defaults.set(0,forKey:"episodeStillMinutesV1");options = .load(defaults)
        let owner = UUID();session.begin(owner,continuing:false);session.begin(owner,continuing:true)
        precondition(!session.needsPrompt(options))
        session.begin(UUID(),continuing:true);precondition(session.needsPrompt(options))
        session.acknowledge();precondition(!session.needsPrompt(options))
        defaults.set(0,forKey:"episodeStillCountV1");defaults.set(1,forKey:"episodeStillMinutesV1");options = .load(defaults)
        session.begin(UUID(),continuing:false)
        for tick in 0...60 { session.tick(Double(tick),playing:true) }
        precondition(session.needsPrompt(options));session.acknowledge()
        session.tick(0,playing:true);session.tick(600,playing:true);session.tick(800,playing:false)
        precondition(!session.needsPrompt(options),"Seeks and pauses must not trigger watched time")
        for (key,value) in SignalEpisodeOptions.defaults { precondition(SignalPortableSettings.snapshot(defaults)[key] != nil);defaults.set(value,forKey:key) }
        let global = UserDefaults.standard, saved = global.object(forKey:"metadataCacheEnabledV1")
        global.set(true,forKey:"metadataCacheEnabledV1")
        defer { if let saved { global.set(saved,forKey:"metadataCacheEnabledV1") } else { global.removeObject(forKey:"metadataCacheEnabledV1") } }
        let config = URLSessionConfiguration.ephemeral; config.protocolClasses = [F64MetadataProtocol.self]
        let http = URLSession(configuration:config)
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("SignalF64-" + UUID().uuidString)
        defer { try? FileManager.default.removeItem(at:folder); http.invalidateAndCancel() }
        let cache = SignalMetadataResponseCache(session:http,folder:folder)
        let request = URLRequest(url:URL(string:"https://signal-metadata.test/meta/shared")!)
        try await withThrowingTaskGroup(of:Void.self) { group in
            for _ in 0..<20 { group.addTask { _ = try await cache.data(for:request) } }
            try await group.waitForAll()
        }
        precondition(F64MetadataProtocol.counters().0 == 1,"Same metadata must coalesce to one request")
        _ = try await cache.data(for:request);precondition(F64MetadataProtocol.counters().0 == 1)
        try await withThrowingTaskGroup(of:Void.self) { group in
            for i in 0..<20 { group.addTask { _ = try await cache.data(for:URLRequest(url:URL(string:"https://signal-metadata.test/meta/\(i)")!)) } }
            try await group.waitForAll()
        }
        precondition(F64MetadataProtocol.counters().1 <= 4,"Metadata concurrency must be bounded")
        let cacheCounters = await cache.counters()
        precondition(cacheCounters.hits > 0 && cacheCounters.network > 0)
        let snapshot = await cache.resourceSnapshot();precondition(snapshot.memoryBytes <= 8*1024*1024 && snapshot.entries <= 192 && snapshot.active == 0 && snapshot.queued == 0)
        let persisted = SignalMetadataResponseCache(session:http,folder:folder)
        let hitsBeforeDisk = F64MetadataProtocol.counters().0
        _ = try await persisted.data(for:request)
        precondition(F64MetadataProtocol.counters().0 == hitsBeforeDisk,"Fresh metadata should survive process-cache recreation")
        var accountA = request; accountA.setValue("fixture-a",forHTTPHeaderField:"X-API-Key")
        var accountB = request; accountB.setValue("fixture-b",forHTTPHeaderField:"X-API-Key")
        let isolated = F64MetadataProtocol.counters().0
        _ = try await cache.data(for:accountA); _ = try await cache.data(for:accountB)
        precondition(F64MetadataProtocol.counters().0 == isolated + 2,"Different account credentials must not share metadata entries")
        let pending = (0..<20).map { i in Task { try? await cache.data(for:URLRequest(url:URL(string:"https://signal-metadata.test/cancel/\(i)")!)) } }
        try await Task.sleep(nanoseconds:10_000_000)
        await cache.suspend()
        for task in pending { _ = await task.value }
        let cancelled = await cache.resourceSnapshot()
        precondition(cancelled.active == 0 && cancelled.queued == 0,"Suspend must release active work and queued waiters")
        await cache.clear()
        let empty = await cache.resourceSnapshot();precondition(empty.entries == 0 && empty.memoryBytes == 0)
        print("F64 actual provider parsing, skip/story boundaries, modes, Still Watching, preferences, metadata coalescing/concurrency/clear PASS")
    }
}
