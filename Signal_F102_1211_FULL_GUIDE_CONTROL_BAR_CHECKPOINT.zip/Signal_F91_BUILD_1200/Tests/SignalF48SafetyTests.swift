import Foundation

@main
struct SignalF48SafetyTests {
    static func main() async {
        let defaults = UserDefaults.standard
        let keys = [SignalProtectedNetworkState.homeIPKey, SignalProtectedNetworkState.homeProxyKey,
            MediaFlowProxyRouter.preferredLocalProfileKey, SignalMediaFlowSafetyPolicy.enabledKey, MediaFlowProxyRouter.enabledKey,
            MediaFlowProxyRouter.lightEnabledKey, MediaFlowProxyRouter.proxyURLKey,
            MediaFlowProxyRouter.publicIPKey, MediaFlowProxyRouter.lightModeKey,
            MediaFlowProxyRouter.lightURLKey, MediaFlowProxyRouter.lightPublicIPKey,
            "mediaFlowSeparateProfilesMigrationV2"]
        let saved = keys.map { ($0, defaults.object(forKey: $0)) }
        defer {
            for (key, value) in saved {
                if let value { defaults.set(value, forKey: key) }
                else { defaults.removeObject(forKey: key) }
            }
            MediaFlowProxyRouter.clearEgressProof()
        }
        defaults.removeObject(forKey: SignalMediaFlowSafetyPolicy.enabledKey)
        defaults.set(true, forKey: "mediaFlowSeparateProfilesMigrationV2")
        defaults.set(false, forKey: MediaFlowProxyRouter.lightEnabledKey)
        defaults.set(false, forKey: MediaFlowProxyRouter.enabledKey)
        let source = URL(string: "https://opaque-cdn.example/video.mkv")!
        let rd = URL(string: "https://api.real-debrid.com/rest/1.0/unrestrict/link")!
        precondition(SignalMediaFlowSafetyPolicy.enabled())
        precondition(SignalPortableSettings.snapshot()[SignalMediaFlowSafetyPolicy.enabledKey] as? Bool == true)
        precondition(SignalPortableSettings.snapshot()[MediaFlowProxyRouter.lastVerifiedKey] == nil)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod) == nil)
        precondition(MediaFlowProxyRouter.forwardRequestIfAllowed(URLRequest(url: rd)) == nil)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: rd, kind: .liveTV) == nil)
        precondition(MediaFlowProxyRouter.liveTVBootstrapRequestsIfAllowed(URLRequest(url: rd), epg: false) == nil)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .liveTV) == source)
        precondition(!SignalMediaFlowSafetyPolicy.protects(vod: false,
            url: URL(string: "https://real-debrid.com.attacker.example/video"), enabled: true))
        defaults.set(false, forKey: SignalMediaFlowSafetyPolicy.enabledKey)
        precondition(SignalPortableSettings.snapshot()[SignalMediaFlowSafetyPolicy.enabledKey] as? Bool == true)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod) == nil)
        defaults.set(true, forKey: SignalMediaFlowSafetyPolicy.enabledKey)

        let base = ProcessInfo.processInfo.environment["SIGNAL_F48_TEST_PROXY"]!
        defaults.set(base, forKey: MediaFlowProxyRouter.proxyURLKey)
        defaults.set(true, forKey: MediaFlowProxyRouter.enabledKey)
        defaults.set("203.0.113.8", forKey: MediaFlowProxyRouter.publicIPKey)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod) == nil)
        precondition(MediaFlowProxyRouter.configurationError(kind: .vod, requireVerifiedEgress: false) == nil)
        let success = await MediaFlowProxyRouter.testConnection(proxyURLString: base,
            apiPassword: "fixture-password", expectedPublicIP: "203.0.113.8", lightProfile: false)
        precondition(success.success)
        precondition(MediaFlowProxyRouter.configurationError(kind: .vod) == nil)
        let wrapped = MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod)!
        precondition(wrapped.host == URL(string: base)!.host)
        precondition(wrapped.path == "/prefix/proxy/stream")
        let query = URLComponents(url: wrapped, resolvingAgainstBaseURL: false)!.queryItems!
        precondition(query.contains { $0.name == "d" && $0.value == source.absoluteString })
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: wrapped, kind: .vod) == wrapped)
        for fake in [base.replacingOccurrences(of: "http:", with: "https:") + "/proxy/stream?d=x",
                     base + "/evil/proxy/stream?d=x",
                     base.replacingOccurrences(of: "/prefix", with: "") + "/proxy/stream?d=x"] {
            let url = URL(string: fake)!
            precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: url, kind: .vod) != url)
        }
        var wrongPort = URLComponents(url: wrapped, resolvingAgainstBaseURL: false)!
        wrongPort.port = wrongPort.port! + 1
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: wrongPort.url!, kind: .vod) != wrongPort.url!)
        var mutation = URLRequest(url: rd)
        mutation.httpMethod = "POST"
        mutation.httpBody = Data("link=fixture".utf8)
        mutation.setValue("Bearer fixture-token", forHTTPHeaderField: "Authorization")
        let routed = MediaFlowProxyRouter.forwardRequestIfAllowed(mutation)!
        precondition(routed.url!.path == "/prefix/proxy/forward")
        precondition(routed.httpMethod == "POST" && routed.httpBody == mutation.httpBody)
        defaults.set("203.0.113.9", forKey: MediaFlowProxyRouter.publicIPKey)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod) == nil)
        let mismatch = await MediaFlowProxyRouter.testConnection(proxyURLString: base,
            apiPassword: "fixture-password", expectedPublicIP: "203.0.113.9", lightProfile: false)
        precondition(!mismatch.success)
        precondition(MediaFlowProxyRouter.forwardRequestIfAllowed(mutation) == nil)
        defaults.set("203.0.113.8", forKey: MediaFlowProxyRouter.publicIPKey)
        // Reverting an IP setting must not revive an old successful proof.
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod) == nil)
        let reverified = await MediaFlowProxyRouter.testConnection(proxyURLString: base,
            apiPassword: "fixture-password", expectedPublicIP: "203.0.113.8", lightProfile: false)
        precondition(reverified.success)
        MediaFlowProxyRouter.clearEgressProof()
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod) == nil)
        defaults.set(base, forKey: MediaFlowProxyRouter.lightURLKey)
        defaults.set("203.0.113.8", forKey: MediaFlowProxyRouter.lightPublicIPKey)
        defaults.set(true, forKey: MediaFlowProxyRouter.lightEnabledKey)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod) == nil)
        let light = await MediaFlowProxyRouter.testConnection(proxyURLString: base,
            apiPassword: "fixture-password", expectedPublicIP: "203.0.113.8", lightProfile: true)
        precondition(light.success)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod) != nil)
        precondition(MediaFlowProxyRouter.forwardRequestIfAllowed(mutation) == nil)
        precondition(MediaFlowProxyRouter.forwardRequestIfAllowed(URLRequest(url: rd))!.url!.path == "/prefix/proxy/stream")
        defaults.set(false, forKey: MediaFlowProxyRouter.lightEnabledKey)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod) == nil)
        // Proxy outage is still a proxy URL, never a source URL, even without a pin.
        defaults.set("", forKey: MediaFlowProxyRouter.publicIPKey)
        defaults.set(base + "/offline", forKey: MediaFlowProxyRouter.proxyURLKey)
        let offline = await MediaFlowProxyRouter.testConnection(proxyURLString: base + "/offline",
            apiPassword: "fixture-password", expectedPublicIP: "", lightProfile: false)
        precondition(!offline.success)
        let offlineRoute = MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod)!
        precondition(offlineRoute != source && offlineRoute.path == "/prefix/offline/proxy/stream")
        defaults.set(false, forKey: MediaFlowProxyRouter.enabledKey)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: wrapped, kind: .vod)?.host == URL(string: base)!.host)

        for effect in SignalLiveTVCardEffect.baseNames {
            for column in 0..<4 {
                let original = SignalLiveTVCardEffect.pose(effect, column: column, focused: true)
                let aligned = effect + SignalLiveTVCardEffect.alignedSuffix
                let fixed = SignalLiveTVCardEffect.pose(aligned, column: column, focused: false)
                precondition(original.yaw == fixed.yaw && original.pitch == fixed.pitch && original.roll == fixed.roll)
                precondition(fixed.x == 0 && fixed.y == 0)
                precondition(fixed == SignalLiveTVCardEffect.pose(aligned, column: column, focused: true))
            }
        }
        precondition(SignalLiveTVCardMotion.scale(focused: true, preview: false, reduceMotion: false) == 1.025)
        precondition(SignalLiveTVCardMotion.scale(focused: true, preview: true, reduceMotion: false) == 1.09)
        precondition(SignalLiveTVCardMotion.scale(focused: true, preview: true, reduceMotion: true) == 1)
        precondition(SignalLiveTVCardMotion.lift(focused: true, reduceMotion: false) == -3)
        precondition(SignalLiveTVCardMotion.lift(focused: true, reduceMotion: true) == 0)
        precondition(SignalLiveTVCardMotion.lift(focused: true, preview: true, reduceMotion: false) == -8)
        precondition(SignalLiveTVCardMotion.lift(focused: true, preview: true, reduceMotion: true) == 0)
        precondition(SignalLiveTVCardMotion.lift(focused: false, preview: true, reduceMotion: false) == 0)
        precondition(SignalLiveTVCardMotion.scale(focused: false, preview: true, reduceMotion: false) == 1)
        print("F48 native PASS: actual router fail-closed paths, proxy/IP verification/revocation, original/aligned poses and bounded focus pop")
    }
}
