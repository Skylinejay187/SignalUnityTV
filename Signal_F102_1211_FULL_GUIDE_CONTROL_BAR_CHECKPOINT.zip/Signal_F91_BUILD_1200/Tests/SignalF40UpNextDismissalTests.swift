import Foundation

@main struct SignalF40UpNextDismissalTests {
    static func main() {
        // A reminder closed during an episode stays hidden until natural EOF, while
        // preserving the user's established automatic-next preference.
        var earlyReminder = SignalUpNextDismissalState()
        precondition(!earlyReminder.promptDismissed && !earlyReminder.autoplayCancelled)
        earlyReminder.dismiss(episodeEnded: false)
        precondition(earlyReminder.promptDismissed && !earlyReminder.autoplayCancelled)
        earlyReminder.reachedEnd()
        precondition(!earlyReminder.promptDismissed && !earlyReminder.autoplayCancelled)

        // Last episode of a season is independent of whether the next source exists.
        // Back/Dismiss during EOF loading must win over delayed completion/retry events.
        var atEOF = SignalUpNextDismissalState()
        atEOF.dismiss(episodeEnded: true)
        precondition(atEOF.promptDismissed && atEOF.autoplayCancelled)
        atEOF.reachedEnd()
        atEOF.reachedEnd()
        precondition(atEOF.promptDismissed && atEOF.autoplayCancelled)
        // A second close cannot downgrade an EOF cancellation to an early reminder.
        atEOF.dismiss(episodeEnded: false)
        precondition(atEOF.promptDismissed && atEOF.autoplayCancelled)

        // Early dismissal followed by a separate EOF dismissal must become sticky.
        earlyReminder.dismiss(episodeEnded: true)
        earlyReminder.reachedEnd()
        precondition(earlyReminder.promptDismissed && earlyReminder.autoplayCancelled)

        // A new immutable episode/player presentation owns a fresh independent state.
        let nextPresentation = SignalUpNextDismissalState()
        precondition(!nextPresentation.promptDismissed && !nextPresentation.autoplayCancelled)
        print("F40 Up Next dismissal lifecycle tests passed")
    }
}
