import Foundation

@main
struct VODCastNavigationPolicyTests {
    static func main() {
        for mode in VODFeaturedCastPresentationMode.allCases {
            // Automatic presentation never controls eligibility for manual focus.
            precondition(mode.permitsManualBrowse(playbackReady: true, awake: true, memberCount: 1))
            precondition(!mode.permitsManualBrowse(playbackReady: false, awake: true, memberCount: 4))
            precondition(!mode.permitsManualBrowse(playbackReady: true, awake: false, memberCount: 4))
            precondition(!mode.permitsManualBrowse(playbackReady: true, awake: true, memberCount: 0))
            for focused in [false, true] {
                for original in [false, true] {
                    let shown = mode.showsPortrait(playbackReady: true, awake: true, memberCount: 4,
                        focusActive: focused, showingOriginalPoster: original)
                    let expected: Bool
                    switch mode {
                    case .off: expected = focused
                    case .compactOverlay: expected = false
                    case .fullPoster: expected = !original
                    }
                    precondition(shown == expected)
                    precondition(!mode.showsPortrait(playbackReady: true, awake: false, memberCount: 4,
                        focusActive: focused, showingOriginalPoster: original))
                    precondition(!mode.showsPortrait(playbackReady: false, awake: true, memberCount: 4,
                        focusActive: focused, showingOriginalPoster: original))
                    precondition(!mode.showsPortrait(playbackReady: true, awake: true, memberCount: 0,
                        focusActive: focused, showingOriginalPoster: original))
                }
            }
        }
        precondition(!VODFeaturedCastPresentationMode.off.automaticallyRotates)
        precondition(VODFeaturedCastPresentationMode.fullPoster.automaticallyRotates)
        precondition(VODFeaturedCastPresentationMode.compactOverlay.automaticallyRotates)
        precondition(VODFeaturedCastPresentationMode.steppedIndex(0, by: -1, count: 4) == 3)
        precondition(VODFeaturedCastPresentationMode.steppedIndex(3, by: 1, count: 4) == 0)
        precondition(VODFeaturedCastPresentationMode.steppedIndex(1, by: -1, count: 4) == 0)
        precondition(VODFeaturedCastPresentationMode.steppedIndex(0, by: 1, count: 4) == 1)
        precondition(VODFeaturedCastPresentationMode.steppedIndex(0, by: 0, count: 4) == nil)
        precondition(VODFeaturedCastPresentationMode.steppedIndex(0, by: 1, count: 0) == nil)
        precondition(VODFeaturedCastPresentationMode.steppedIndex(0, by: 1, count: 1) == nil)
        precondition(VODFeaturedCastPresentationMode.off.next == .compactOverlay)
        precondition(VODFeaturedCastPresentationMode.compactOverlay.next == .fullPoster)
        precondition(VODFeaturedCastPresentationMode.fullPoster.next == .off)
        print("F32R1: all three cast modes, manual portrait visibility, inactive/empty gates, no Off rotation and bidirectional wrap passed")
    }
}
