"""The build audit must accept both fits and reject actual geometry defects."""
from contextlib import redirect_stdout
import importlib.util
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('geometry_audit', ROOT / 'Scripts/check_f41_geometry_math.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


class GeometryAuditTests(unittest.TestCase):
    def test_current_production_coefficients_pass_both_fits(self):
        with redirect_stdout(io.StringIO()) as output:
            audit.audit()
        self.assertIn('1344 fitted quads', output.getvalue())

    def check_mutation_rejected(self, before, after):
        with tempfile.TemporaryDirectory(prefix='signal-f53-negative-') as folder:
            root = Path(folder)
            (root / 'Sources').mkdir()
            for name in ('SignalLiveTVCardEffect.swift', 'SignalLiveTVCardAlignment.swift'):
                source = (ROOT / 'Sources' / name).read_text()
                if name == 'SignalLiveTVCardAlignment.swift':
                    self.assertEqual(source.count(before), 1)
                    source = source.replace(before, after, 1)
                (root / 'Sources' / name).write_text(source)
            with patch.object(audit, 'ROOT', root), self.assertRaises(AssertionError):
                audit.audit()

    def test_stretched_uniform_fit_is_rejected(self):
        self.check_mutation_rejected('let ssY = uniform ? min(fitX, fitY) : fitY', 'let ssY = fitY')

    def test_off_center_fit_is_rejected(self):
        self.check_mutation_rejected('let padX = (width - (maxX - minX) * sx) / 2',
                                     'let padX = (width - (maxX - minX) * sx) / 2 + 3')


if __name__ == '__main__':
    unittest.main()
