import SwiftUI
struct RemoteImageFit: View {
    enum Mode { case fit }
    let url: String?
    var mode: Mode = .fit
    var maxPixelSize: Int = 96
    var body: some View { Color.clear }
}
@main struct ScoreboardTests {
    static func main() {
        func event(_ state: String, completed: Bool = false, name: String = "STATUS_SCHEDULED") -> [String: Any] {
            ["id":"123", "date":"2026-11-02T20:00:00Z", "status":["type":["state":state,"completed":completed,"name":name,"shortDetail":"Fixture status"]],
             "competitions":[["competitors":[["homeAway":"away","score":"24","team":["displayName":"Away"]],["homeAway":"home","score":21,"team":["displayName":"Home"]]]]]]
        }
        let live = SignalSportsGame.espn(event("in"), league: "NFL")!
        precondition(live.state == .live && live.away.score == "24" && live.home.score == "21")
        let next = SignalSportsGame.espn(event("pre"), league: "NFL")!
        precondition(next.state == .upcoming && next.away.score == nil && next.start != nil)
        precondition(SignalSportsGame.espn(event("post",completed:true),league:"NFL")?.state == .final)
        precondition(SignalSportsGame.espn(event("post"),league:"NFL") == nil)
        precondition(SignalSportsGame.espn(event("pre",name:"STATUS_POSTPONED"),league:"NFL") == nil)
        precondition(SignalSportsGame.espn([:],league:"NFL") == nil)
        precondition(SignalSportsGame.distinct([live,live]).count == 1)
        print("F83 real scoreboard parsing: live/pre/final, scores, dates, postponed/missing rejection and exact-ID dedupe PASS")
    }
}
