import Foundation

@main struct SignalF63PauseInfoTests {
    static func main() async {
        typealias P = SignalPauseInfoPolicy
        precondition(P.delayNanoseconds(.nan) == 1_500_000_000)
        precondition(P.delayNanoseconds(-1) == 0 && P.delayNanoseconds(100) == 10_000_000_000)
        let playing = P.Request(presentationID: UUID(), sourceID: "same", renderGeneration: 1, paused: false, eligible: true)
        let dismissal = P.Lease(request: playing)
        precondition(P.mayDismiss(dismissal, current: dismissal, request: playing))
        precondition(!P.mayDismiss(dismissal, current: nil, request: playing))
        let repaused = P.Request(presentationID: playing.presentationID, sourceID: "same", renderGeneration: 1, paused: true, eligible: true)
        precondition(P.sameOwner(playing, repaused) && !P.mayDismiss(dismissal, current: dismissal, request: repaused))
        let replaced = P.Request(presentationID: UUID(), sourceID: "same", renderGeneration: 1, paused: true, eligible: true)
        precondition(!P.sameOwner(playing, replaced))
        precondition(P.revealDelayNanoseconds == 1_500_000_000)
        let session = UUID()
        func request(session: UUID? = nil, source: String = "episode-a", generation: Int = 1,
                     paused: Bool = true, eligible: Bool = true) -> P.Request {
            .init(presentationID: session ?? SignalF63PauseInfoTests.sessionFallback,
                  sourceID: source, renderGeneration: generation, paused: paused, eligible: eligible)
        }
        let a = request(session: session)
        let first = P.Lease(request: a), successor = P.Lease(request: a)
        precondition(P.mayReveal(first, current: first, request: a))
        precondition(!P.mayReveal(first, current: nil, request: a))
        precondition(!P.mayReveal(first, current: successor, request: a), "Old pause must not reveal after a new pause")
        for changed in [request(session: UUID()), request(session: session, source: "episode-b"),
                        request(session: session, generation: 2), request(session: session, paused: false),
                        request(session: session, eligible: false), request(session: session, source: "")] {
            precondition(!P.mayReveal(first, current: first, request: changed))
        }
        let cancelled = Task { await P.waitForReveal() }
        cancelled.cancel()
        let cancelledResult = await cancelled.value
        precondition(!cancelledResult, "Cancellation must not fall through to reveal")
        let completed = await P.waitForReveal(nanoseconds: 0)
        precondition(completed)

        let now = Date(timeIntervalSince1970: 100_000)
        precondition(P.estimatedEnd(now: now, elapsed: 600, duration: 3600) == now.addingTimeInterval(3000))
        precondition(P.estimatedEnd(now: now.addingTimeInterval(90), elapsed: 600, duration: 3600) == now.addingTimeInterval(3090))
        precondition(P.estimatedEnd(now: now, elapsed: 600, duration: 3600, rate: 2) == now.addingTimeInterval(1500))
        for pair in [(Double.nan,3600.0),(-1,3600),(0,Double.infinity),(0,0),(3600,3600),(3601,3600),(0,Double.greatestFiniteMagnitude)] {
            precondition(P.estimatedEnd(now: now, elapsed: pair.0, duration: pair.1) == nil)
        }
        for rate in [0.0, -1, .nan, .infinity] {
            precondition(P.estimatedEnd(now: now, elapsed: 0, duration: 3600, rate: rate) == nil)
        }
        let episode = P.metadata(title: "VisionQuest  S01E05  Firewall", fallbackTitle: "Fallback", season: 1, episode: 5, synopsis: "  A synopsis.  ")
        precondition(episode.title == "VisionQuest" && episode.episode == "S1 · E5 — Firewall" && episode.synopsis == "A synopsis.")
        precondition(P.MetadataInput(title: "VisionQuest  S01E05  Firewall", fallbackTitle: "Fallback", season: 1, episode: 5, synopsis: "  A synopsis.  ").formatted == episode)
        let special = P.metadata(title: "日本語  S00E01 — 特別編", fallbackTitle: "", season: 0, episode: 1, synopsis: "")
        precondition(special.title == "日本語" && special.episode == "S0 · E1 — 特別編")
        let movie = P.metadata(title: "Movie S01E05", fallbackTitle: "", season: nil, episode: nil, synopsis: "")
        precondition(movie.title == "Movie S01E05" && movie.episode.isEmpty)
        precondition(P.metadata(title: "  ", fallbackTitle: "Fallback", season: nil, episode: nil, synopsis: "").title == "Fallback")
        precondition(P.metadata(title: "", fallbackTitle: "", season: -1, episode: 0, synopsis: "").title == "Now Playing")
        print("F63 pause delay, cancellation/ownership, metadata and end-time policy tests PASS")
    }
    private static let sessionFallback = UUID()
}
