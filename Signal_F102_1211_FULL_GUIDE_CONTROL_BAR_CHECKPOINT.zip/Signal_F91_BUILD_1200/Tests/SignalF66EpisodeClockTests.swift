import Foundation

/// Real lookup traffic is intercepted locally; no provider, media URL or API key is used.
final class F66SegmentProtocol: URLProtocol {
    private let lock = NSLock()
    private var stopped = false
    override class func canInit(with request: URLRequest) -> Bool {
        ["api.skipdb.tv", "api.introdb.app", "api.theintrodb.org", "introhater.com"].contains(request.url?.host ?? "")
    }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        let host = request.url?.host ?? ""
        // Verify a fast recap can be published before another provider completes.
        let delay = host == "api.skipdb.tv" ? 0.01 : 0.20
        DispatchQueue.global().asyncAfter(deadline: .now() + delay) { [self] in
            lock.lock(); defer { lock.unlock() }
            guard !stopped else { return }; stopped = true
            let query = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems ?? []
            let episode = query.first(where: { $0.name == "episode" })?.value ?? "1"
            let body: String
            if host == "api.skipdb.tv" { body = "{\"segments\":{\"recap\":{\"start_ms\":0,\"end_ms\":\(episode == "2" ? 50000 : 40000),\"match\":\"exact\"}}}" }
            else if host == "api.theintrodb.org" { body = "{\"recap\":[{\"start_ms\":null,\"end_ms\":45000}]}" }
            else { body = "{\"no_recap\":true}" }
            let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: ["Content-Type":"application/json"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: Data(body.utf8))
            client?.urlProtocolDidFinishLoading(self)
        }
    }
    override func stopLoading() { lock.lock(); stopped = true; lock.unlock() }
}
actor F66ProgressRecorder {
    var fastReady = false
    func receive(_ report: SignalEpisodeSegmentReport) {
        if !report.complete, report.segments.contains(where: { $0.kind == .recap }),
           report.providers["introdb"] == "Looking up this episode…" { fastReady = true }
    }
    func sawFastReady() -> Bool { fastReady }
}
enum SignalF66EpisodeClockTests {
    static func verify(options: SignalEpisodeOptions) async throws {
        let one = UUID(), two = UUID()
        var gate = SignalEpisodeClockGate()
        precondition(gate.shouldEvaluate(owner: one, uptime: 1))
        precondition(!gate.shouldEvaluate(owner: one, uptime: 1.1))
        precondition(gate.shouldEvaluate(owner: one, uptime: 1.5))
        precondition(gate.shouldEvaluate(owner: two, uptime: 1.51))
        precondition(gate.shouldEvaluate(owner: two, uptime: 1.52, force: true))
        precondition(!gate.shouldEvaluate(owner: two, uptime: .nan))
        // 100 decoder samples produce <= 21 control evaluations and only two prompt transitions.
        var ticks = SignalEpisodeClockGate(), changes = 0, evaluations = 0
        var visible: SignalEpisodeSegment?
        let recap = SignalEpisodeSegment(kind: .recap, start: 2, end: 8, provider: "fixture")
        for sample in 0..<100 {
            let position = Double(sample) / 10
            guard ticks.shouldEvaluate(owner: one, uptime: position) else { continue }
            evaluations += 1
            let next = SignalEpisodeSkipPlan.recap(segments: [recap], consumed: [], position: position, duration: 100)
            if next != visible { changes += 1; visible = next }
        }
        precondition(evaluations <= 21 && changes == 2)
        precondition(SignalEpisodeSkipPlan.recap(segments: [recap], consumed: [recap.id], position: 3, duration: 100) == nil)
        var tmdbOnly = MediaItem(); tmdbOnly.id = "provider-show"; tmdbOnly.imdbId = nil; tmdbOnly.tmdbId = "1396"
        let alternate = SignalEpisodeSegmentService.requests(for: tmdbOnly, duration: 1200, options: options)
        precondition(alternate.count == 1 && alternate[0].0 == "theintrodb")
        precondition(alternate[0].1.absoluteString.contains("tmdb_id=1396"))
        tmdbOnly.tvdbId = "81189"
        let preferred = SignalEpisodeSegmentService.requests(for: tmdbOnly, duration: 1200, options: options)
        precondition(preferred[0].1.absoluteString.contains("tvdb_id=81189"))
        var special = MediaItem(); special.seasonNumber = nil; special.episodeNumber = nil; special.id = "tt0903747:0:2"
        let coordinates = SignalEpisodeSegmentService.coordinates(special)
        precondition(coordinates?.0 == 0 && coordinates?.1 == 2)
        let config = URLSessionConfiguration.ephemeral; config.protocolClasses = [F66SegmentProtocol.self]
        let service = SignalEpisodeSegmentService(session: URLSession(configuration: config))
        let recorder = F66ProgressRecorder()
        let first = await service.lookup(for: MediaItem(), duration: 1200, options: options,
            onUpdate: { report in await recorder.receive(report) })
        let sawFastReady = await recorder.sawFastReady(); precondition(sawFastReady)
        precondition(first.complete && first.segments.contains(where: { $0.kind == .recap && $0.end == 40 }))
        var second = MediaItem(); second.id = "tt0903747:1:2"; second.episodeNumber = 2
        let next = await service.lookup(for: second, duration: 1200, options: options)
        precondition(next.segments.contains(where: { $0.kind == .recap && $0.end == 50 }))
        precondition(SignalEpisodeSegmentService.identityKey(second) != SignalEpisodeSegmentService.identityKey(MediaItem()))
        let missingIMDb = await service.lookup(for: tmdbOnly, duration: 1200, options: options)
        precondition(missingIMDb.segments.contains(where: { $0.provider == "theintrodb" && $0.kind == .recap }))
        let again = await service.lookup(for: MediaItem(), duration: 1200, options: options)
        precondition(again == first)
        print("F66 actual clock gate, hidden-control recap boundaries, episode identities, alternate-ID lookup and progressive provider callbacks PASS")
    }
}
