@main struct SignalF70SeekTransportTests {
    @MainActor static func entered(_ engine: AetherEngine, _ count: Int = 1) async {
        for _ in 0..<1000 {
            if engine.targets.count >= count { return }
            await Task.yield()
        }
        preconditionFailure("Seek did not enter engine")
    }
    @MainActor static func main() async {
        // Same production seek method for a resident hit and a target past the cached endpoint.
        for (target, available) in [(40.0, 90.0), (300.0, 90.0)] {
            let host=SeekFixture();let engine=host.engine!;engine.availableEnd=available
            host.seek(to: target);await entered(engine)
            let task=host.seekTask!;precondition(engine.plays == 0)
            engine.complete(0);await task.value
            precondition(engine.plays == 1 && engine.pauses == 0 && engine.refreshes == 1)
            precondition(host.buffered == [max(target, available)])
            precondition(!host.vodSeekTransportPending && host.seekTask == nil)
            host.reconcileVODSeekTransport();precondition(engine.plays == 1, "No repeated play assertions")
        }
        let paused=SeekFixture();paused.transportWantsPlay=false
        paused.seek(to: 40);await entered(paused.engine!)
        let pausedTask=paused.seekTask!;paused.engine!.complete(0);await pausedTask.value
        precondition(paused.engine!.plays == 0 && paused.engine!.pauses == 1)
        let changed=SeekFixture();changed.seek(to: 300);await entered(changed.engine!)
        let changedTask=changed.seekTask!;changed.pause();changed.engine!.complete(0);await changedTask.value
        precondition(changed.engine!.plays == 0 && changed.engine!.pauses == 2, "Latest pause must win")
        let resumed=SeekFixture();resumed.transportWantsPlay=false
        resumed.seek(to:300);await entered(resumed.engine!);let resumedTask=resumed.seekTask!
        resumed.play();resumed.engine!.complete(0);await resumedTask.value
        precondition(resumed.engine!.plays == 2 && resumed.engine!.pauses == 0, "Latest Play during seek must win")
        let newer=SeekFixture();let shared=newer.engine!
        newer.seek(to: 40);await entered(shared);let oldTask=newer.seekTask!
        newer.seek(to: 300);await entered(shared,2);let newTask=newer.seekTask!
        shared.complete(0);await oldTask.value
        precondition(shared.plays == 0 && newer.seekTask != nil, "Retired seek must not clear/resume newer seek")
        shared.complete(1);await newTask.value;precondition(shared.plays == 1)
        let retired=SeekFixture();let oldEngine=retired.engine!
        retired.seek(to: 300);await entered(oldEngine);let retiredTask=retired.seekTask!
        retired.generation += 1;retired.seekTask?.cancel();retired.engine=AetherEngine()
        oldEngine.complete(0);await retiredTask.value
        precondition(oldEngine.plays == 0 && retired.engine!.plays == 0)
        for gate in [0,1,2,3] {
            let host=SeekFixture();let engine=host.engine!
            host.seek(to: 300);await entered(engine);let task=host.seekTask!
            if gate == 0 { host.backgrounded=true }
            if gate == 1 { host.configuredAllowSessionRebuild=false }
            if gate == 2 { engine.isSeeking=true }
            if gate == 3 { engine.isSessionReady=false }
            engine.complete(0);await task.value
            precondition(engine.plays == 0 && host.vodSeekTransportPending)
            host.backgrounded=false;host.configuredAllowSessionRebuild=true;engine.isSeeking=false;engine.isSessionReady=true
            host.reconcileVODSeekTransport();precondition(engine.plays == 1)
        }
        for terminal in [0,1,2,3] {
            let host=SeekFixture();let engine=host.engine!
            host.seek(to: 300);await entered(engine);let task=host.seekTask!
            if terminal == 0 { host.failed=true }
            if terminal == 1 { host.endedPublished=true }
            if terminal == 2 { host.loadedOptions?.isLive=true }
            engine.complete(0,position: terminal == 3 ? 600 : 300);await task.value
            precondition(engine.plays == 0 && engine.pauses == 0, "No resurrection of terminal/live/end park")
        }
        let invalid=SeekFixture()
        for value in [Double.nan, Double.infinity, -1] { invalid.seek(to:value) }
        precondition(invalid.seekTask == nil && invalid.engine!.targets.isEmpty)
        print("F70: resident/miss seeks, latest paused intent, supersession, retired session, proof/background/readiness deferral, terminal/live/EOF and finite inputs passed")
    }
}
