import Foundation

/// Every request is intercepted. No real credentials, proxy or provider is contacted.
private final class HealthTransportFixture: URLProtocol {
    private static let lock = NSLock()
    private static var captured: [URLRequest] = []
    private static var responseStatus = 200

    static func reset(status: Int = 200) {
        lock.lock(); defer { lock.unlock() }
        captured = []; responseStatus = status
    }
    static func requests() -> [URLRequest] {
        lock.lock(); defer { lock.unlock() }
        return captured.filter { !["api.ipify.org", "api64.ipify.org"].contains($0.url?.host ?? "") && !["/signal/health", "/signal/proxy/ip"].contains($0.url?.path ?? "") }
    }
    private static func record(_ request: URLRequest) -> Int {
        lock.lock(); defer { lock.unlock() }
        captured.append(request)
        return responseStatus
    }
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        let requestedStatus = Self.record(request)
        let diagnostic = ["api.ipify.org", "api64.ipify.org"].contains(request.url?.host ?? "") || ["/signal/health", "/signal/proxy/ip"].contains(request.url?.path ?? "")
        let status = diagnostic ? 200 : requestedStatus
        let response = HTTPURLResponse(url: request.url!, statusCode: status,
            httpVersion: "HTTP/1.1", headerFields: ["Content-Type": "application/json"])!
        let body: String
        if ["api.ipify.org", "api64.ipify.org"].contains(request.url?.host ?? "") { body = "{\"ip\":\"203.0.113.9\"}" }
        else if request.url?.path == "/signal/proxy/ip" { body = "{\"ip\":\"203.0.113.8\"}" }
        else { body = status == 200 ? "{}" : "{\"error\":\"fixture denied\"}" }
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(body.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

@main
struct SignalF49HealthTests {
    static func main() async {
        let defaults = UserDefaults.standard
        let keys = [SignalProtectedNetworkState.homeIPKey, SignalProtectedNetworkState.homeProxyKey,
            MediaFlowProxyRouter.preferredLocalProfileKey, SignalMediaFlowSafetyPolicy.enabledKey, MediaFlowProxyRouter.enabledKey,
            MediaFlowProxyRouter.lightEnabledKey, MediaFlowProxyRouter.proxyURLKey,
            MediaFlowProxyRouter.publicIPKey, "mediaFlowSeparateProfilesMigrationV2"]
        let saved = keys.map { ($0, defaults.object(forKey: $0)) }
        let suiteName = "Signal.F49.HealthTests." + UUID().uuidString
        let accounts = UserDefaults(suiteName: suiteName)!
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [HealthTransportFixture.self]
        let session = URLSession(configuration: configuration)
        defer {
            session.invalidateAndCancel()
            accounts.removePersistentDomain(forName: suiteName)
            for (key, value) in saved {
                if let value { defaults.set(value, forKey: key) }
                else { defaults.removeObject(forKey: key) }
            }
            MediaFlowProxyRouter.clearEgressProof()
        }
        defaults.set(true, forKey: SignalMediaFlowSafetyPolicy.enabledKey)
        defaults.set(true, forKey: "mediaFlowSeparateProfilesMigrationV2")
        defaults.set(false, forKey: MediaFlowProxyRouter.enabledKey)
        defaults.set(false, forKey: MediaFlowProxyRouter.lightEnabledKey)
        defaults.set("", forKey: MediaFlowProxyRouter.publicIPKey)
        accounts.set("fixture-rd-token", forKey: "realDebridApiKey")

        HealthTransportFixture.reset()
        let blocked = await ConnectedServicesHealthClient.verifyRealDebrid(defaults: accounts, session: session)
        precondition(blocked.state == .failed)
        precondition(!blocked.details.isEmpty)
        precondition(HealthTransportFixture.requests().isEmpty)

        defaults.set(true, forKey: MediaFlowProxyRouter.enabledKey)
        defaults.set("https://proxy.signal-fixture.invalid/signal", forKey: MediaFlowProxyRouter.proxyURLKey)
        let proxied = await ConnectedServicesHealthClient.verifyRealDebrid(defaults: accounts, session: session)
        precondition(proxied.state == .connected)
        let forwarded = HealthTransportFixture.requests()
        precondition(forwarded.count == 1)
        let request = forwarded[0]
        precondition(request.url!.host == "proxy.signal-fixture.invalid")
        precondition(request.url!.path == "/signal/proxy/forward")
        let query = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)!.queryItems!
        precondition(query.contains { $0.name == "d" && $0.value == "https://api.real-debrid.com/rest/1.0/user" })
        precondition(query.contains { $0.name == "h_Authorization" && $0.value == "Bearer fixture-rd-token" })
        precondition(request.value(forHTTPHeaderField: "Authorization") == nil)

        HealthTransportFixture.reset()
        defaults.set("203.0.113.99", forKey: MediaFlowProxyRouter.publicIPKey)
        let unverified = await ConnectedServicesHealthClient.verifyRealDebrid(defaults: accounts, session: session)
        precondition(unverified.state == .failed && HealthTransportFixture.requests().isEmpty)

        defaults.set("", forKey: MediaFlowProxyRouter.publicIPKey)
        defaults.set("", forKey: MediaFlowProxyRouter.proxyURLKey)
        let invalid = await ConnectedServicesHealthClient.verifyRealDebrid(defaults: accounts, session: session)
        precondition(invalid.state == .failed && HealthTransportFixture.requests().isEmpty)

        defaults.set("https://proxy.signal-fixture.invalid/signal", forKey: MediaFlowProxyRouter.proxyURLKey)
        HealthTransportFixture.reset(status: 401)
        let rejected = await ConnectedServicesHealthClient.verifyRealDebrid(defaults: accounts, session: session)
        precondition(rejected.state == .failed)
        precondition(rejected.details.joined().contains("HTTP 401"))
        precondition(HealthTransportFixture.requests().count == 1)

        defaults.set(false, forKey: MediaFlowProxyRouter.enabledKey)
        defaults.set(false, forKey: SignalMediaFlowSafetyPolicy.enabledKey)
        HealthTransportFixture.reset()
        let optOut = await ConnectedServicesHealthClient.verifyRealDebrid(defaults: accounts, session: session)
        precondition(optOut.state == .connected)
        precondition(HealthTransportFixture.requests().count == 1)
        precondition(HealthTransportFixture.requests()[0].url!.host == "proxy.signal-fixture.invalid")

        // The original F48 guard was accidentally in this unrelated service.
        // A non-throwing health result must remain usable when RD is blocked.
        defaults.set(true, forKey: SignalMediaFlowSafetyPolicy.enabledKey)
        defaults.set("", forKey: MediaFlowProxyRouter.proxyURLKey)
        accounts.set("fixture-offcloud-token", forKey: "offcloudApiKey")
        HealthTransportFixture.reset()
        let all = await ConnectedServicesHealthClient.verifyAll(defaults: accounts, session: session)
        precondition(all.first { $0.id == "realdebrid" }?.state == .failed)
        precondition(all.first { $0.id == "offcloud" }?.state == .connected)
        precondition(HealthTransportFixture.requests().count == 1)
        precondition(HealthTransportFixture.requests()[0].url!.host == "offcloud.com")
        precondition(HealthTransportFixture.requests()[0].httpMethod == "POST")
        print("F49 health behavior PASS: blocked RD emits no request; valid route uses proxy; unverified/invalid/HTTP errors return failure; explicit opt-out and independent Offcloud result preserved")
    }
}
