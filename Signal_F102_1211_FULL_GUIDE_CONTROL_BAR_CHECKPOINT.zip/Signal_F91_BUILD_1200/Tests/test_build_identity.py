"""Regression: legacy workflow entry points must accept current source versions."""
from pathlib import Path
import importlib.util
import plistlib
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
BASE = plistlib.loads((ROOT/'Sources/Info.plist').read_bytes())
BASE_BUILD = BASE['CFBundleVersion']
BASE_VERSION = BASE['CFBundleShortVersionString']
spec = importlib.util.spec_from_file_location('identity', ROOT/'Scripts/check_build_identity.py')
identity = importlib.util.module_from_spec(spec)
spec.loader.exec_module(identity)

class BuildIdentityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        for name in ('Sources/Info.plist', 'TopShelfExtension/Info.plist', 'project.yml'):
            target = self.root/name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT/name, target)
    def tearDown(self):
        self.temp.cleanup()
    def edit_plist(self, name, key, value):
        p = self.root/name
        data = plistlib.loads(p.read_bytes())
        data[key] = value
        p.write_bytes(plistlib.dumps(data))
    def test_current_source_passes(self):
        self.assertEqual(identity.validate(self.root)['build'], BASE_BUILD)
    def test_future_consistent_version_is_not_blocked_by_old_pin(self):
        for name in ('Sources/Info.plist', 'TopShelfExtension/Info.plist'):
            self.edit_plist(name, 'CFBundleShortVersionString', '2.0.0')
            self.edit_plist(name, 'CFBundleVersion', '2000')
            self.edit_plist(name, 'DebridChannelsReleaseID', 'Signal-Future')
        p = self.root/'project.yml'
        p.write_text(p.read_text().replace(BASE_VERSION, '2.0.0').replace('CURRENT_PROJECT_VERSION: '+BASE_BUILD, 'CURRENT_PROJECT_VERSION: 2000'))
        self.assertEqual(identity.validate(self.root)['build'], '2000')
    def test_extension_build_mismatch_is_rejected(self):
        self.edit_plist('TopShelfExtension/Info.plist', 'CFBundleVersion', str(int(BASE_BUILD)+1))
        with self.assertRaisesRegex(identity.BuildIdentityError, 'Top Shelf CFBundleVersion'):
            identity.validate(self.root)
    def test_project_target_mismatch_is_rejected(self):
        p = self.root/'project.yml'
        p.write_text(p.read_text().replace('CURRENT_PROJECT_VERSION: '+BASE_BUILD, 'CURRENT_PROJECT_VERSION: '+str(int(BASE_BUILD)+1), 1))
        with self.assertRaisesRegex(identity.BuildIdentityError, 'CURRENT_PROJECT_VERSION'):
            identity.validate(self.root)
    def test_missing_release_identity_is_rejected(self):
        self.edit_plist('Sources/Info.plist', 'DebridChannelsReleaseID', '')
        with self.assertRaisesRegex(identity.BuildIdentityError, 'missing DebridChannelsReleaseID'):
            identity.validate(self.root)
    def test_both_workflow_entrypoints_run_successfully(self):
        for name in ('check_f29_build_identity.py', 'check_f31_build_identity.py'):
            result = subprocess.run([sys.executable, str(ROOT/'Scripts'/name)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn('build '+BASE_BUILD, result.stdout)

if __name__ == '__main__':
    unittest.main()
