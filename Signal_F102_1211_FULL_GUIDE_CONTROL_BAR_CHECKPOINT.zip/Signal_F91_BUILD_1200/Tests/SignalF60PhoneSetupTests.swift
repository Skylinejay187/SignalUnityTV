import Foundation

@main
struct SignalF60PhoneSetupTests {
    static func rejected(_ text: String) -> Bool {
        if case .rejected = SignalPhoneSetupHTTP.parse(Data(text.utf8)) { return true }
        return false
    }
    static func main() throws {
        let body = "{\"values\":{\"liveM3UURL\":\"https://example.test/list.m3u\"},\"clear\":[]}"
        let head = "POST /api/settings HTTP/1.1\r\nHost: 192.168.1.2:8080\r\nContent-Type: application/json\r\nContent-Length: \(body.utf8.count)\r\n\r\n"
        let bytes = Data((head + body).utf8)
        // Every possible TCP split remains incomplete until the bounded request is complete.
        for count in 0..<bytes.count {
            if case .incomplete = SignalPhoneSetupHTTP.parse(Data(bytes.prefix(count))) {} else {
                preconditionFailure("Premature parse at TCP split \(count)")
            }
        }
        guard case .request(let request) = SignalPhoneSetupHTTP.parse(bytes) else { fatalError("Valid POST rejected") }
        precondition(request.path == "/api/settings" && request.body == Data(body.utf8))
        precondition(rejected(head + body + "GET / HTTP/1.1\r\nHost: x\r\n\r\n"))
        precondition(rejected("POST / HTTP/1.1\r\nHost: x\r\nContent-Length: 0\r\ncontent-length: 0\r\n\r\n"))
        precondition(rejected("POST / HTTP/1.1\r\nHost: x\r\nTransfer-Encoding: chunked\r\n\r\n"))
        precondition(rejected("POST / HTTP/1.1\r\nHost: x\r\nContent-Length: -1\r\n\r\n"))
        precondition(rejected("POST / HTTP/1.1\r\nHost: x\r\nContent-Length: 999999999\r\n\r\n"))
        precondition(rejected("GET /?token=secret HTTP/1.1\r\nHost: x\r\n\r\n"))
        precondition(rejected(String(repeating: "x", count: SignalPhoneSetupHTTP.maximumHeader + 1)))
        precondition(SignalPhoneSetupHTTP.equalSecret("secret", "secret"))
        precondition(!SignalPhoneSetupHTTP.equalSecret("", ""))
        precondition(!SignalPhoneSetupHTTP.equalSecret("Secret", "secret"))
        for address in ["10.1.2.3", "172.16.0.1", "172.31.255.1", "192.168.1.2", "169.254.1.2"] {
            precondition(SignalPhoneSetupHTTP.isPrivateIPv4(address))
        }
        for address in ["8.8.8.8", "172.15.0.1", "172.32.0.1", "127.0.0.1", "0.0.0.0", "10.invalid.1.2.3", "10.1.2.999", "localhost"] {
            precondition(!SignalPhoneSetupHTTP.isPrivateIPv4(address))
        }
        let changes = try SignalPhoneSetupSchema.changes(["values": ["liveM3UURL": " https://a.test/one\nhttps://b.test/two ", "tmdbApiKey": ""], "clear": ["omdbApiKey"]])
        precondition(changes == ["liveM3UURL": "https://a.test/one\nhttps://b.test/two", "omdbApiKey": ""])
        let invalid: [[String: Any]] = [
            ["values": ["topMenuThemePreset": "Changed"], "clear": []],
            ["values": ["mediaFlowVODSafetyLockEnabledV1": "false"], "clear": []],
            ["values": ["liveM3UURL": "file:///etc/passwd"], "clear": []],
            ["values": ["tmdbApiKey": "new", "liveXMLTVURL": "javascript:alert(1)"], "clear": []],
            ["values": ["tmdbApiKey": "new"], "clear": ["tmdbApiKey"]],
            ["values": ["liveXtreamPassword": "unsupported|separator"], "clear": []],
            ["values": [:], "clear": ["notAllowed"]],
            ["values": [:], "clear": [], "extra": "ignored?"]
        ]
        for payload in invalid {
            do { _ = try SignalPhoneSetupSchema.changes(payload); preconditionFailure("Invalid batch accepted") }
            catch is SignalPhoneSetupSchema.InputError {}
        }
        let restoredCode = try SignalPhoneSetupSchema.restoreCode(" abc-123 \n")
        precondition(restoredCode == "ABC-123")
        do { _ = try SignalPhoneSetupSchema.restoreCode("ABC/../123"); preconditionFailure("Invalid restore code accepted") }
        catch is SignalPhoneSetupSchema.InputError {}
        let response = String(data: SignalPhoneSetupHTTP.response(status: 200, body: Data("{}".utf8)), encoding: .utf8)!
        for expected in ["Cache-Control: no-store", "Connection: close", "Content-Length: 2", "frame-ancestors 'none'", "Referrer-Policy: no-referrer"] { precondition(response.contains(expected)) }
        print("F60 actual request parser, TCP splits, input validation, secret comparison and response tests passed")
    }
}
