import Foundation
import SwiftUI
import UIKit
// Only the backing loader/frame-service interfaces are stubbed. Production UIKit,
// CoreImage, CoreAnimation and cancellation code is checked against the real tvOS SDK.
@MainActor final class PremiumRemoteImageLoader: ObservableObject {
    @Published var image: UIImage?
    var imageURL: URL?
    func loadAfterNavigationSettles(_ url: URL?, preserveCurrentImage: Bool, maxPixelSize: Int) {}
    func cancel() {}
}
enum PremiumArtworkURL { static func url(_ raw: String?) -> URL? { raw.flatMap(URL.init(string:)) } }
@MainActor final class UnityFrameRuntime {
    static let shared = UnityFrameRuntime()
    enum Lane { case backgroundPrefetch }
    func waitUntilPermittedDurably(_ lane: Lane) async -> Bool { true }
}
