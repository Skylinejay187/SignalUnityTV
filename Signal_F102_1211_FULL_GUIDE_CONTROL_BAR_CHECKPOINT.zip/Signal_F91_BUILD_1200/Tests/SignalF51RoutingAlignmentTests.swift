import Foundation

private final class NetworkFixture: URLProtocol {
    private static let lock = NSLock()
    private static var localIP = "203.0.113.8"
    private static var preferredIP = "203.0.113.8"
    private static var proxyAvailable = true
    private static var requests: [URLRequest] = []
    static func scenario(local: String, preferred: String? = nil, proxy: Bool = true) {
        lock.lock(); localIP = local; preferredIP = preferred ?? local; proxyAvailable = proxy; requests = []; lock.unlock()
        SignalProtectedNetworkState.invalidate()
        MediaFlowProxyRouter.clearEgressProof()
    }
    private static func reply(_ request: URLRequest) -> (Int, String) {
        lock.lock(); defer { lock.unlock() }; requests.append(request)
        if request.url?.host == "api.ipify.org" { return (200, "{\"ip\":\"" + localIP + "\"}") }
        if request.url?.host == "api64.ipify.org" { return (200, "{\"ip\":\"" + preferredIP + "\"}") }
        guard request.url?.host == "proxy.signal-fixture.invalid" else { return (599, "{}") }
        if !proxyAvailable { return (503, "{}") }
        if request.url?.path == "/home/proxy/ip" { return (200, "{\"ip\":\"203.0.113.8\"}") }
        return (200, "{}")
    }
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        let (status, text) = Self.reply(request)
        let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: "HTTP/1.1", headerFields: [:])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(text.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

@main struct SignalF51RoutingAlignmentTests {
    static func main() async {
        let defaults = UserDefaults.standard
        let keys = [MediaFlowProxyRouter.enabledKey, MediaFlowProxyRouter.lightEnabledKey,
            MediaFlowProxyRouter.proxyURLKey, MediaFlowProxyRouter.publicIPKey,
            SignalMediaFlowSafetyPolicy.enabledKey, SignalProtectedNetworkState.homeIPKey,
            SignalProtectedNetworkState.homeProxyKey, MediaFlowProxyRouter.preferredLocalProfileKey,
            "mediaFlowSeparateProfilesMigrationV2"]
        let saved = keys.map { ($0, defaults.object(forKey: $0)) }
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [NetworkFixture.self]
        let session = URLSession(configuration: configuration)
        defer {
            session.invalidateAndCancel(); SignalProtectedNetworkState.invalidate(); MediaFlowProxyRouter.clearEgressProof()
            for (key, value) in saved {
                if let value { defaults.set(value, forKey: key) } else { defaults.removeObject(forKey: key) }
            }
        }
        defaults.set(true, forKey: "mediaFlowSeparateProfilesMigrationV2")
        defaults.set(false, forKey: MediaFlowProxyRouter.enabledKey)
        defaults.set(false, forKey: MediaFlowProxyRouter.lightEnabledKey)
        defaults.set(false, forKey: SignalMediaFlowSafetyPolicy.enabledKey)
        defaults.set("https://proxy.signal-fixture.invalid/home", forKey: MediaFlowProxyRouter.proxyURLKey)
        defaults.set("203.0.113.8", forKey: MediaFlowProxyRouter.publicIPKey)
        let protected = URL(string: "https://cdn.real-debrid.com/video.mkv")!
        let opaque = URL(string: "https://opaque-addon.invalid/video.mkv")!
        let torbox = URL(string: "https://cdn.torbox.app/video.mkv")!

        NetworkFixture.scenario(local: "203.0.113.8")
        let enrollment = await MediaFlowProxyRouter.testConnection(proxyURLString: "https://proxy.signal-fixture.invalid/home",
            apiPassword: "fixture-password", expectedPublicIP: "203.0.113.8", lightProfile: false, session: session)
        precondition(enrollment.success)
        NetworkFixture.scenario(local: "203.0.113.8", proxy: false)
        let home = await MediaFlowProxyRouter.prepareSafetyError(for: protected, session: session)
        precondition(home == nil)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: protected, kind: .vod) == protected)
        precondition(!defaults.bool(forKey: MediaFlowProxyRouter.enabledKey))

        NetworkFixture.scenario(local: "203.0.113.9")
        let away = await MediaFlowProxyRouter.prepareSafetyError(for: protected, session: session)
        precondition(away == nil)
        let wrapped = MediaFlowProxyRouter.playbackURLIfAllowed(for: protected, kind: .vod)!
        precondition(wrapped.host == "proxy.signal-fixture.invalid" && wrapped != protected)
        precondition(!defaults.bool(forKey: MediaFlowProxyRouter.enabledKey))
        precondition(SignalMediaFlowSafetyPolicy.enabled()) // shared legacy Off is powerless

        NetworkFixture.scenario(local: "203.0.113.9", proxy: false)
        let failure = await MediaFlowProxyRouter.prepareSafetyError(for: protected, session: session)
        precondition(failure != nil)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: protected, kind: .vod) == nil)

        NetworkFixture.scenario(local: "invalid-IP", proxy: false)
        let uncertain = await MediaFlowProxyRouter.prepareSafetyError(for: opaque, session: session)
        precondition(uncertain != nil && !SignalProtectedNetworkState.isHome(MediaFlowProxyRouter.snapshot(), light: false))
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: torbox, kind: .vod) == torbox)
        precondition(!SignalMediaFlowSafetyPolicy.protects(vod: true, url: torbox, enabled: true))
        precondition(SignalMediaFlowSafetyPolicy.protects(vod: true, url: URL(string: "https://torbox.app.attacker.invalid/x"), enabled: true))

        NetworkFixture.scenario(local: "203.0.113.8", preferred: "2001:db8::8")
        let mixedFamily = await MediaFlowProxyRouter.prepareSafetyError(for: protected, session: session)
        precondition(mixedFamily == nil)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: protected, kind: .vod)?.host == "proxy.signal-fixture.invalid")

        // A verified home identity can be learned from the authenticated proxy; a
        // remote device's own address is never written into the home anchor.
        defaults.set("", forKey: MediaFlowProxyRouter.publicIPKey)
        defaults.removeObject(forKey: SignalProtectedNetworkState.homeIPKey)
        defaults.removeObject(forKey: SignalProtectedNetworkState.homeProxyKey)
        NetworkFixture.scenario(local: "203.0.113.9")
        let learned = await MediaFlowProxyRouter.prepareSafetyError(for: opaque, session: session)
        precondition(learned == nil)
        precondition(defaults.string(forKey: SignalProtectedNetworkState.homeIPKey) == "203.0.113.8")
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: opaque, kind: .vod)?.host == "proxy.signal-fixture.invalid")
        NetworkFixture.scenario(local: "203.0.113.8", proxy: false)
        let learnedHome = await MediaFlowProxyRouter.prepareSafetyError(for: opaque, session: session)
        precondition(learnedHome == nil)
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: opaque, kind: .vod) == opaque)
        SignalProtectedNetworkState.invalidate()
        precondition(MediaFlowProxyRouter.playbackURLIfAllowed(for: opaque, kind: .vod) != opaque)

        let imported: [String: Any] = [MediaFlowProxyRouter.enabledKey: false,
            MediaFlowProxyRouter.lightEnabledKey: false, SignalMediaFlowSafetyPolicy.enabledKey: false,
            MediaFlowProxyRouter.preferredLocalProfileKey: "Light", "vodDiskCachePolicyV1": "2gb",
            MediaFlowProxyRouter.proxyURLKey: "https://saved-proxy.invalid"]
        let restorable = SignalMediaFlowSafetyPolicy.settingsForThisDevice(imported)
        precondition(restorable[MediaFlowProxyRouter.enabledKey] == nil && restorable[SignalMediaFlowSafetyPolicy.enabledKey] == nil)
        precondition(restorable["vodDiskCachePolicyV1"] as? String == "2gb")
        precondition(restorable[MediaFlowProxyRouter.proxyURLKey] != nil)

        // Repeated column quads line up in all three rows; a single uniform scale
        // fits each quad without the old independent X/Y stretch.
        for effect in SignalLiveTVCardEffect.baseNames {
            for column in 0..<4 {
                let pose = SignalLiveTVCardEffect.pose(effect + SignalLiveTVCardEffect.alignedSuffix, column: column, focused: false)
                for (w, h) in [(480.0, 270.0), (320.0, 183.0)] {
                    let projection = SignalLiveTVCardProjection.uniformlyFitted(pose: pose, width: w, height: h)
                    let points = [(0.0,0.0),(w,0.0),(0.0,h),(w,h)].map { projection.project(x:$0.0,y:$0.1) }
                    precondition(points.allSatisfy { $0.x >= -0.00001 && $0.x <= w+0.00001 && $0.y >= -0.00001 && $0.y <= h+0.00001 })
                    let minX = points.map(\.x).min()!, maxX = points.map(\.x).max()!
                    let minY = points.map(\.y).min()!, maxY = points.map(\.y).max()!
                    precondition(abs(minX - (w-maxX)) < 0.00001 && abs(minY - (h-maxY)) < 0.00001)
                    for row in 0..<3 {
                        let offset = Double(row)*(h+23)
                        precondition(abs((minY+offset)-minY-offset) < 0.00001)
                    }
                }
            }
        }
        precondition(SignalLiveTVCardMotion.scale(focused:true,preview:true,reduceMotion:false) == 1.09)
        print("F51 native PASS: home direct with proxy Off; away forced proxy; unavailable/unknown blocked; mixed-family safe route; no synced-Off bypass; TorBox exemption; learned home anchor; uniform aligned quads; popup preserved")
    }
}
