import Foundation

@main enum SignalF58SearchNavigationTests {
    static func main() {
        let move = SignalSearchResultsLayout.movedIndex
        precondition(move(2, 14, 4, 0, 1) == 6)
        precondition(move(6, 14, 4, 0, 1) == 10)
        precondition(move(10, 14, 4, 0, 1) == 13) // partial last row
        precondition(move(13, 14, 4, 0, 1) == nil)
        precondition(move(13, 14, 4, 0, -1) == 9)
        precondition(move(2, 14, 4, 0, -1) == nil)
        precondition(move(3, 14, 4, 1, 0) == nil)
        precondition(move(4, 14, 4, -1, 0) == nil)
        precondition(move(12, 14, 4, 1, 0) == 13)
        precondition(move(13, 14, 4, 1, 0) == nil)
        precondition(move(-1, 14, 4, 0, 1) == nil)
        precondition(move(0, 0, 4, 0, 1) == nil)
        precondition(move(0, 14, 0, 0, 1) == nil)
        precondition(move(0, 14, 4, 1, 1) == nil)
        precondition(move(0, 14, 4, 0, 0) == nil)
        for count in 1...97 {
            for columns in 1...4 {
                for index in 0..<count {
                    for (dx, dy) in [(0, 1), (0, -1), (1, 0), (-1, 0)] {
                        if let target = move(index, count, columns, dx, dy) {
                            precondition(target >= 0 && target < count)
                            if dy != 0 { precondition(target / columns == index / columns + dy) }
                            else { precondition(target / columns == index / columns && target == index + dx) }
                        }
                    }
                }
                // A long query's grid reaches its last row, rather than getting stuck
                // when the next lazy row has not yet been mounted by SwiftUI.
                var current = 0, steps = 0
                while let target = move(current, count, columns, 0, 1) {
                    precondition(target > current)
                    current = target; steps += 1
                    precondition(steps <= count)
                }
                precondition(current / columns == (count - 1) / columns)
            }
        }
        print("F58 native PASS: row/column navigation, partial rows, boundaries and long-result traversal")
    }
}
