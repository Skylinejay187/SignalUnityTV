import Foundation

@main struct SignalFocusOrderTests {
    static func main() {
        for count in 1...20 {
            for i in 0..<count {
                for delta in [-10,-1,0,1,10] {
                    let next = SignalFocusOrder.step(index:i,delta:delta,count:count)
                    precondition((0..<count).contains(next))
                    precondition(abs(next-i) <= 1, "A command skipped a logical slot")
                    precondition(next == min(count-1,max(0,i+(delta<0 ? -1 : delta>0 ? 1 : 0))))
                }
            }
            var index = 0
            for _ in 0..<(count+4) { index = SignalFocusOrder.step(index:index,delta:1,count:count) }
            precondition(index == count-1)
            for _ in 0..<(count+4) { index = SignalFocusOrder.step(index:index,delta:-1,count:count) }
            precondition(index == 0)
        }
        // Search is the final logical slot inside the menu, even after membership filtering.
        for tabs in 1...8 {
            var index = 0
            for _ in 0..<tabs { index = SignalFocusOrder.step(index:index,delta:1,count:tabs+1) }
            precondition(index == tabs)
            precondition(SignalFocusOrder.step(index:index,delta:-1,count:tabs+1) == tabs-1)
        }
        precondition(SignalFocusOrder.step(index:0,delta:1,count:0) == 0)
        precondition(SignalPreviewStartupPolicy.dwellNanoseconds == 650_000_000)
        print("F35: exhaustive adjacent-step, boundaries and Search reachability tests passed")
    }
}
