import Foundation

@main
struct TopMenuThemeModelTests {
    static func main() {
        let themes: [TopMenuThemeStyle] = TopMenuThemeStyle.implementedThemes
        precondition(themes.count == 30)
        precondition(Set(themes).count == 30)
        precondition(Set(themes.map { $0.rawValue }).count == 30)
        precondition(Set(themes) == Set(TopMenuThemeStyle.allCases))
        for theme in themes {
            precondition(TopMenuThemeStyle.resolve(theme.rawValue) == theme)
            precondition(TopMenuThemeStyle.resolve("  " + theme.rawValue.uppercased() + "\n") == theme)
            precondition(!theme.summary.isEmpty)
        }
        for group in TopMenuThemeGroup.allCases {
            precondition(themes.contains { $0.group == group })
        }
        let fixtureURL = URL(fileURLWithPath: "Tests/F31NavigationBaseline.json")
        let fixture = try! JSONSerialization.jsonObject(with: Data(contentsOf: fixtureURL)) as! [String: Any]
        let legacy = fixture["legacy_expected_names"] as! [String: String]
        precondition(legacy.count == 48)
        for (oldName, expectedName) in legacy {
            precondition(TopMenuThemeStyle.resolve(oldName).rawValue == expectedName, "Migration: " + oldName)
        }
        precondition(TopMenuThemeStyle.resolve("Classic") == .classicMediaBar)
        precondition(TopMenuThemeStyle.resolve("Liquid Glass Pro") == .liquidGlassIsland)
        precondition(TopMenuThemeStyle.resolve("Polar Frost") == .iconDock)
        precondition(TopMenuThemeStyle.resolve("Studio Chrome") == .titaniumToolbar)
        precondition(TopMenuThemeStyle.resolve("Minimal / No Background") == .studioMinimal)
        precondition(TopMenuThemeStyle.resolve("Unknown future theme") == .defaultTheme)
        precondition(TopMenuThemeStyle.resolve("") == .defaultTheme)
        // Use a throwaway suite: never modify the app's standard preferences.
        let suite = "SignalF31ThemeTests." + UUID().uuidString
        let first = UserDefaults(suiteName: suite)!
        defer { first.removePersistentDomain(forName: suite) }
        for theme in themes {
            first.set(theme.rawValue, forKey: "topMenuThemePreset")
            let reloaded = UserDefaults(suiteName: suite)!.string(forKey: "topMenuThemePreset")!
            precondition(TopMenuThemeStyle.resolve(reloaded) == theme)
        }
        print("F31: theme identity, legacy migration, groups and persistent selection passed")
    }
}
