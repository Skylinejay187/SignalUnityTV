import Foundation

@main struct SignalF44UpNextGuideTests {
    static func main() {
        typealias P = SignalUpNextAutoplayPolicy
        func decide(_ settled: Bool = true, cancelled: Bool = false, automatic: Bool = true,
                    episode: Bool = true, ready: Bool = true, armed: Bool = false, countdown: Int = 15) -> P.Decision {
            P.decision(endSettled: settled, cancelled: cancelled, automatic: automatic,
                       hasEpisode: episode, sourceReady: ready, armed: armed, countdown: countdown)
        }
        precondition(decide(false) == .wait) // never replace a playing/unsettled episode
        precondition(decide(cancelled: true, armed: true, countdown: 0) == .wait)
        precondition(decide(automatic: false, armed: true, countdown: 0) == .offer)
        precondition(decide(episode: false, ready: false) == .prepareEpisode)
        precondition(decide(ready: false) == .prepareSource)
        precondition(decide() == .arm)
        precondition(decide(armed: true, countdown: 1) == .wait)
        precondition(decide(armed: true, countdown: 0) == .play)
        // First playable publication commits even if other provider child tasks have not returned.
        precondition(decide(ready: false, armed: true, countdown: 0) == .prepareSource)
        precondition(decide(ready: true, armed: true, countdown: 0) == .play)
        var dismissal = SignalUpNextDismissalState()
        dismissal.dismiss(episodeEnded: false)
        dismissal.reachedEnd()
        precondition(!dismissal.promptDismissed && !dismissal.autoplayCancelled)
        precondition(decide(cancelled: dismissal.autoplayCancelled) == .arm)
        dismissal.dismiss(episodeEnded: true)
        dismissal.reachedEnd()
        precondition(decide(cancelled: dismissal.autoplayCancelled, armed: true, countdown: 0) == .wait)
        // Full truth table: dismissal, decoder settle, and disabled preference always win.
        for settled in [false, true] { for cancelled in [false, true] { for automatic in [false, true] {
            for episode in [false, true] { for ready in [false, true] { for armed in [false, true] {
                for countdown in [-1, 0, 1, 15] {
                    let result = decide(settled, cancelled: cancelled, automatic: automatic, episode: episode,
                                        ready: ready, armed: armed, countdown: countdown)
                    if !settled || cancelled { precondition(result == .wait) }
                    if result == .play { precondition(settled && !cancelled && automatic && episode && ready && armed && countdown <= 0) }
                }
            } } }
        } } }
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        let now = calendar.date(from: DateComponents(year: 2026, month: 10, day: 25, hour: 23, minute: 47))!
        for width in [1280.0, 1536, 1920, 3840] {
            let axis = SignalGuideTimeline(now: now, width: width, calendar: calendar)
            precondition(calendar.component(.minute, from: axis.start) == 30)
            precondition(abs(axis.scheduleOrigin + axis.scheduleWidth - width) < 0.0001)
            for minute in 0..<120 {
                let start = axis.start.addingTimeInterval(Double(minute) * 60)
                let end = start.addingTimeInterval(60)
                let slot = axis.slot(start: start, end: end)!
                precondition(abs(slot.x - Double(minute) * axis.pointsPerMinute) < 0.0001)
                precondition(abs(slot.width - axis.pointsPerMinute) < 0.0001)
            }
            let crossing = axis.slot(start: axis.start.addingTimeInterval(-1800), end: axis.start.addingTimeInterval(900))!
            precondition(crossing.x == 0 && abs(crossing.width - 15 * axis.pointsPerMinute) < 0.0001)
            precondition(axis.slot(start: axis.start.addingTimeInterval(-1800), end: axis.start) == nil)
            precondition(axis.slot(start: axis.end, end: axis.end.addingTimeInterval(3600)) == nil)
            precondition(axis.slot(start: now, end: now) == nil)
            precondition(axis.slot(start: now.addingTimeInterval(60), end: now) == nil)
            let whole = axis.slot(start: axis.start.addingTimeInterval(-3600), end: axis.end.addingTimeInterval(3600))!
            precondition(whole.x == 0 && whole.width == axis.scheduleWidth)
            precondition(calendar.component(.day, from: axis.end) == 26)
        }
        print("F44 Up Next policy truth table and EPG clipping/time alignment passed")
    }
}
