import Foundation
// Compile the production engine extension against small deterministic host doubles.
// No playback transport methods exist here: refreshing cannot depend on Play/Pause.
@MainActor final class TestClock { var currentTime = 10.0; var bufferedPosition = 10.0 }
@MainActor final class TestSoftwareHost {
    var bufferedSessionTime = 0.0; var displayCushionSeconds: Double? = 2
    var cachedVODSessionTime: Double? = 30
}
@MainActor final class TestNativeSession {
    var ahead = 40.0
    func contiguousForwardReadAheadSeconds(playlistSeconds: Double) -> Double { ahead }
}
@MainActor final class TestNativeHost {
    var currentTime = 10.0; var end = 25.0
    func signalCachedBufferEnd() -> Double { end }
}
@MainActor final class AetherEngine {
    var isLive = false; let clock = TestClock(); var duration = 300.0
    var softwareHost: TestSoftwareHost?; var nativeHost: TestNativeHost?
    var nativeVideoSession: TestNativeSession?
}
enum SoftwareBufferFrontier {
    static func bufferedPosition(currentTime: Double, liveFrontier: Double, cushion: Double?, cachedVODFrontier: Double?) -> Double {
        max(currentTime, liveFrontier, currentTime + (cushion ?? 0), cachedVODFrontier ?? currentTime)
    }
}
@main struct SignalF42CacheFrontierTests {
    @MainActor static func main() {
        let engine = AetherEngine(), software = TestSoftwareHost()
        engine.softwareHost = software
        engine.refreshSignalBufferFrontier()
        precondition(engine.clock.bufferedPosition == 30)
        // Producer grows while presentation remains at exactly the same time.
        software.cachedVODSessionTime = 130
        engine.refreshSignalBufferFrontier()
        precondition(engine.clock.bufferedPosition == 130 && engine.clock.currentTime == 10)
        software.cachedVODSessionTime = 600
        engine.refreshSignalBufferFrontier()
        precondition(engine.clock.bufferedPosition == 300)
        // A seek/new cache island is allowed to shrink; do not retain phantom coverage.
        software.cachedVODSessionTime = 15
        engine.refreshSignalBufferFrontier()
        precondition(engine.clock.bufferedPosition == 15)
        engine.softwareHost = nil
        let host = TestNativeHost(), session = TestNativeSession()
        engine.nativeHost = host; engine.nativeVideoSession = session
        engine.refreshSignalBufferFrontier(); precondition(engine.clock.bufferedPosition == 50)
        session.ahead = 120
        engine.refreshSignalBufferFrontier(); precondition(engine.clock.bufferedPosition == 130)
        engine.nativeVideoSession = nil
        engine.refreshSignalBufferFrontier(); precondition(engine.clock.bufferedPosition == 25)
        host.end = 80
        engine.refreshSignalBufferFrontier(); precondition(engine.clock.bufferedPosition == 80)
        engine.isLive = true; host.end = 160
        engine.refreshSignalBufferFrontier(); precondition(engine.clock.bufferedPosition == 80)
        engine.isLive = false; engine.clock.currentTime = .nan
        engine.refreshSignalBufferFrontier(); precondition(engine.clock.bufferedPosition == 80)
        print("F42 cache frontier tests passed: stationary presentation, software/native growth, duration clamp, shrink, Live TV isolation, invalid clock")
    }
}
