import Foundation

private final class HomeNetworkFixture: URLProtocol {
    private static let lock = NSLock()
    private static var localIP = "203.0.113.8"
    private static var diagnosticAvailable = true
    private static var proxyAvailable = true
    private static var diagnostics = 0
    static func scenario(local: String, diagnostic: Bool = true, proxy: Bool = true) {
        lock.lock(); defer { lock.unlock() }
        localIP = local; diagnosticAvailable = diagnostic; proxyAvailable = proxy
    }
    static func diagnosticCount() -> Int {
        lock.lock(); defer { lock.unlock() }; return diagnostics
    }
    private static func reply(_ request: URLRequest) -> (Int, String) {
        lock.lock(); defer { lock.unlock() }
        if ["api.ipify.org", "api64.ipify.org"].contains(request.url?.host ?? "") {
            diagnostics += 1
            return diagnosticAvailable ? (200, "{\"ip\":\"" + localIP + "\"}") : (503, "{}")
        }
        guard request.url?.host == "home-proxy.signal-fixture.invalid", proxyAvailable else { return (503, "{}") }
        return request.url?.path == "/home/proxy/ip" ? (200, "{\"ip\":\"203.0.113.8\"}") : (200, "{}")
    }
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        let (status, text) = Self.reply(request)
        client?.urlProtocol(self, didReceive: HTTPURLResponse(url: request.url!, statusCode: status,
            httpVersion: "HTTP/1.1", headerFields: [:])!, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(text.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

@main enum SignalF56HomePlaybackTests {
    static func main() async {
        let defaults = UserDefaults.standard
        let keys = [MediaFlowProxyRouter.enabledKey, MediaFlowProxyRouter.lightEnabledKey,
            MediaFlowProxyRouter.proxyURLKey, MediaFlowProxyRouter.publicIPKey,
            MediaFlowProxyRouter.preferredLocalProfileKey, SignalProtectedNetworkState.homeIPKey,
            SignalProtectedNetworkState.homeProxyKey, "mediaFlowSeparateProfilesMigrationV2"]
        let saved = keys.map { ($0, defaults.object(forKey: $0)) }
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [HomeNetworkFixture.self]
        let session = URLSession(configuration: configuration)
        defer {
            session.invalidateAndCancel(); SignalProtectedNetworkState.invalidate(); MediaFlowProxyRouter.clearEgressProof()
            for (key, value) in saved {
                if let value { defaults.set(value, forKey: key) } else { defaults.removeObject(forKey: key) }
            }
        }
        defaults.set(true, forKey: "mediaFlowSeparateProfilesMigrationV2")
        defaults.set(false, forKey: MediaFlowProxyRouter.enabledKey)
        defaults.set(false, forKey: MediaFlowProxyRouter.lightEnabledKey)
        defaults.set("Full", forKey: MediaFlowProxyRouter.preferredLocalProfileKey)
        defaults.set("https://home-proxy.signal-fixture.invalid/home", forKey: MediaFlowProxyRouter.proxyURLKey)
        defaults.set("203.0.113.8", forKey: MediaFlowProxyRouter.publicIPKey)
        SignalProtectedNetworkState.invalidate(); MediaFlowProxyRouter.clearEgressProof()
        HomeNetworkFixture.scenario(local: "203.0.113.8")
        let enrollment = await MediaFlowProxyRouter.testConnection(proxyURLString: "https://home-proxy.signal-fixture.invalid/home",
            apiPassword: "fixture-password", expectedPublicIP: "203.0.113.8", lightProfile: false, session: session)
        precondition(enrollment.success)
        let source = URL(string: "https://cdn.real-debrid.com/show.mkv")!
        let owner = UUID()
        let headers = ["Authorization": "fixture-upstream-token"]
        let home = await MediaFlowProxyRouter.prepareSafetyError(for: source, session: session)
        precondition(home == nil)
        let route = MediaFlowProxyRouter.preparedPlaybackRoute(for: source, sessionID: owner, kind: .vod, upstreamHeaders: headers)!
        precondition(route.networkURL == source && route.headers == headers && route.isHomeDirect)

        // Up Next/API discovery must reuse the live home proof, even if the unrelated
        // diagnostic service and home proxy temporarily stop answering.
        let requests = HomeNetworkFixture.diagnosticCount()
        HomeNetworkFixture.scenario(local: "203.0.113.9", diagnostic: false, proxy: false)
        for _ in 0..<20 {
            let background = await MediaFlowProxyRouter.prepareSafetyError(for: source, session: session)
            precondition(background == nil)
        }
        precondition(HomeNetworkFixture.diagnosticCount() == requests)
        precondition(SignalProtectedNetworkState.isHome(MediaFlowProxyRouter.snapshot(), light: false))
        precondition(!route.requiresRecheck(eventEpoch: route.epoch, sessionID: owner))

        // Uncertainty may close new direct routing without rewriting the running URL/headers.
        SignalProtectedNetworkState.clearHomeProofForNewRequests()
        precondition(!SignalProtectedNetworkState.isHome(MediaFlowProxyRouter.snapshot(), light: false))
        let future = MediaFlowProxyRouter.preparedPlaybackRoute(for: source, sessionID: UUID(), kind: .vod, upstreamHeaders: headers)!
        precondition(future.networkURL != source && future.headers.isEmpty && !future.isHomeDirect)
        precondition(route.networkURL == source && route.headers == headers)
        let rejected = SignalProtectedNetworkState.revokeHomeProof()
        precondition(rejected > route.epoch && route.requiresRecheck(eventEpoch: rejected, sessionID: owner))
        precondition(!route.requiresRecheck(eventEpoch: rejected, sessionID: UUID()))
        precondition(!future.requiresRecheck(eventEpoch: rejected, sessionID: future.sessionID))

        // A routine path update at the same home re-verifies even with the proxy offline.
        SignalProtectedNetworkState.invalidate(notify: true); MediaFlowProxyRouter.clearEgressProof()
        HomeNetworkFixture.scenario(local: "203.0.113.8", proxy: false)
        let rechecked = await MediaFlowProxyRouter.prepareSafetyError(for: source, session: session)
        precondition(rechecked == nil)
        let resumed = MediaFlowProxyRouter.preparedPlaybackRoute(for: source, sessionID: owner, kind: .vod, upstreamHeaders: headers)!
        precondition(resumed.networkURL == source && resumed.isHomeDirect)
        precondition(!resumed.requiresRecheck(eventEpoch: resumed.epoch, sessionID: owner))

        // A real network change removes that permission. Away uses the saved proxy;
        // no usable proxy/diagnostic permits a direct fallback.
        SignalProtectedNetworkState.invalidate(notify: true); MediaFlowProxyRouter.clearEgressProof()
        HomeNetworkFixture.scenario(local: "203.0.113.9")
        let away = await MediaFlowProxyRouter.prepareSafetyError(for: source, session: session)
        precondition(away == nil)
        let proxied = MediaFlowProxyRouter.preparedPlaybackRoute(for: source, sessionID: owner, kind: .vod, upstreamHeaders: headers)!
        precondition(proxied.networkURL.host == "home-proxy.signal-fixture.invalid" && proxied.headers.isEmpty && !proxied.isHomeDirect)
        precondition(!defaults.bool(forKey: MediaFlowProxyRouter.enabledKey))
        SignalProtectedNetworkState.invalidate(); MediaFlowProxyRouter.clearEgressProof()
        HomeNetworkFixture.scenario(local: "203.0.113.9", proxy: false)
        let blocked = await MediaFlowProxyRouter.prepareSafetyError(for: source, session: session)
        precondition(blocked != nil)
        precondition(MediaFlowProxyRouter.preparedPlaybackRoute(for: source, sessionID: owner, kind: .vod, upstreamHeaders: headers) == nil)
        SignalProtectedNetworkState.invalidate(); MediaFlowProxyRouter.clearEgressProof()
        HomeNetworkFixture.scenario(local: "203.0.113.8", diagnostic: false, proxy: false)
        let unknown = await MediaFlowProxyRouter.prepareSafetyError(for: source, session: session)
        precondition(unknown != nil && MediaFlowProxyRouter.playbackURLIfAllowed(for: source, kind: .vod) == nil)
        print("F56 native PASS: stable home background checks; pinned URL/headers; session/epoch ownership; home path recheck; away proxy and unavailable/unknown blocking")
    }
}
