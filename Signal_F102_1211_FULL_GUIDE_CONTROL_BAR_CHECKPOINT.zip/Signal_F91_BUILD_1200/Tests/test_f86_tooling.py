import unittest,tempfile,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'Scripts'))
from regression_manifest_cache import read_manifest,_read
from check_f86_native_search import fixture
class F86ToolingTests(unittest.TestCase):
    def test_manifest_reuse_and_edit_invalidation(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'manifest.json';path.write_text('{"hash":"a"}')
            _read.cache_clear();first=read_manifest(path)
            for _ in range(50):self.assertIs(read_manifest(path),first)
            self.assertEqual(_read.cache_info().misses,1)
            path.write_text('{"hash":"b"}')
            self.assertEqual(read_manifest(path),{'hash':'b'})
            self.assertEqual(_read.cache_info().misses,2)
    def test_history_pass_runs_once(self):
        path=Path(__file__).resolve().parents[1]/'Scripts/f72_approved_deltas.py'
        self.assertEqual(path.read_text().count('source=previous_f73(source,path)'),1)
    def test_native_fixture_extracts_production(self):
        text=fixture()
        for marker in ['for await batch in group','onUpdate?(accumulated)','Fast result waited for slow providers','Incomplete results poisoned query cache']:
            self.assertIn(marker,text)
if __name__=='__main__':unittest.main()
