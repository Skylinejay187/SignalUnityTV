"""Run the ENTIRE F80 suite from an installed parent project, as XcodeGen does.

This local fixture is a dependency-lifecycle test, not engine compilation.
"""
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from test_f80_engine_hash_lifecycle import copy_project_fixture, stage_fixture


class InstalledParentSuiteTests(unittest.TestCase):
    def test_entire_f80_suite_from_installed_parent(self):
        with tempfile.TemporaryDirectory(prefix='signal-f81-installed-parent-') as directory:
            root = Path(directory) / 'source'
            copy_project_fixture(root)
            stage_fixture(root)
            self.assertFalse((root / 'Vendor/AetherEngine/Sources/AetherEngine/Placeholder.swift').exists())
            engine = root / 'Vendor/AetherEngine'
            before = {p.relative_to(engine).as_posix(): p.read_bytes()
                      for p in engine.rglob('*') if p.is_file() and '.git' not in p.relative_to(engine).parts}
            # Deliberately run only F80 here: including F81 would recursively invoke this test.
            result = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'Tests',
                                     '-p', 'test_f80_engine_hash_lifecycle.py'],
                                    cwd=root, capture_output=True, text=True, timeout=120)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn('Ran 6 tests', result.stderr)
            after = {p.relative_to(engine).as_posix(): p.read_bytes()
                     for p in engine.rglob('*') if p.is_file() and '.git' not in p.relative_to(engine).parts}
            self.assertEqual(before, after, 'Fixture suite modified the installed parent engine')
            for checker in ['check_f79_playback_artwork.py', 'check_f78_artwork.py']:
                with self.subTest(checker=checker):
                    checked = subprocess.run([sys.executable, str(root / 'Scripts' / checker)],
                                             capture_output=True, text=True, timeout=90)
                    self.assertEqual(checked.returncode, 0, checked.stdout + checked.stderr)


if __name__ == '__main__':
    unittest.main()
