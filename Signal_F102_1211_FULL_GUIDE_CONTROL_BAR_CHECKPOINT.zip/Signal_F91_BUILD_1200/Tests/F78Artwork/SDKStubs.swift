import SwiftUI
@MainActor enum VODExclusivePlaybackGate { static var isActive = false }
@MainActor final class UnityAnimationCoordinator {
    static let shared = UnityAnimationCoordinator()
    func shouldDeferVisualPublication(allowDuringSurfaceHandoff: Bool, allowDuringPlayback: Bool) -> Bool { false }
}
@MainActor final class UnityFrameRuntime {
    static let shared = UnityFrameRuntime()
    enum Lane { case criticalArtwork, playbackArtwork, backgroundPrefetch }
    struct Snapshot {
        var navigationActive = false, sceneActive = true, playbackActive = false, trailerActive = false
    }
    var snapshot = Snapshot()
    func permits(_ lane: Lane) -> Bool { true }
    func waitUntilPermitted(_ lane: Lane, maxWait: Double, poll: Double) async -> Bool { true }
    func waitUntilPermittedDurably(_ lane: Lane) async -> Bool { true }
}
