import Foundation
import AppKit
import Kingfisher

@main struct ArtworkChecks {
    @MainActor static var handles: [SignalArtworkRequest] = []
    @MainActor static func fetch(_ url: URL, _ pixels: Int, prefetch: Bool = false, legacy: String? = nil) async throws -> RetrieveImageResult {
        let result: Result<RetrieveImageResult, KingfisherError> = await withCheckedContinuation { continuation in
            handles.append(SignalArtworkTransport.retrieve(url: url, maxPixelSize: pixels,
                speculative: prefetch, legacyKey: legacy) { continuation.resume(returning: $0) })
        }
        return try result.get()
    }
    @MainActor static func flushMemory() {
        SignalArtworkTransport.processedCache.clearMemoryCache()
        SignalArtworkTransport.originalCache.clearMemoryCache()
    }
    @MainActor static func clearDisk() async {
        for cache in [SignalArtworkTransport.processedCache, SignalArtworkTransport.originalCache] {
            await withCheckedContinuation { continuation in cache.clearDiskCache { continuation.resume() } }
        }
        flushMemory()
    }
    @MainActor static func main() async throws {
        let args = CommandLine.arguments
        let base = args[1], phase = args[2]
        let poster = URL(string: base + "/assets/0123456789abcdef0123456789abcdef/poster.webp")!
        let initialTransfers = SignalArtworkDiagnostics.shared.snapshot()["networkTransfers", default: 0]
        if phase == "cold" {
            await clearDisk()
            _ = try await fetch(poster, 320, prefetch: true)
            for size in [384, 640, 1024, 0] { _ = try await fetch(poster, size) }
            precondition(SignalArtworkDiagnostics.shared.snapshot()["networkTransfers", default: 0] - initialTransfers == 1,
                         "One URL / multiple sizes / prefetch must transfer exactly once")
            flushMemory()
            _ = try await fetch(poster, 640)
            precondition(SignalArtworkDiagnostics.shared.snapshot()["networkTransfers", default: 0] == 1)
            precondition(SignalArtworkDiagnostics.shared.snapshot()["prefetchReuses", default: 0] > 0)
            let concurrent = URL(string: base + "/assets/1123456789abcdef0123456789abcdef/poster.webp")!
            async let small = fetch(concurrent, 384)
            async let large = fetch(concurrent, 1024)
            let (a,b) = try await (small,large)
            precondition(a.image.size.width < b.image.size.width, "Decode sizes must remain independent")
            precondition(SignalArtworkDiagnostics.shared.snapshot()["networkTransfers", default: 0] == 2,
                         "Concurrent sizes must share the underlying transfer")
        } else if phase == "warm" {
            // Runs in a SECOND process with the server refusing all requests.
            for size in [320, 640, 1280, 0] { _ = try await fetch(poster, size) }
            precondition(SignalArtworkDiagnostics.shared.snapshot()["networkTransfers", default: 0] == 0,
                         "Restart/new size/offline must reuse original disk bytes")
        } else {
            flushMemory()
            let parsed = KingfisherParsedOptionsInfo(SignalArtworkTransport.options(url: poster, maxPixelSize: 640, speculative: false))
            let corrupt = SignalArtworkTransport.processedCache.cachePath(forKey: poster.absoluteString, processorIdentifier: parsed.processor.identifier)
            try Data("not an image".utf8).write(to: URL(fileURLWithPath: corrupt), options: .atomic)
            _ = try await fetch(poster, 640)
            precondition(SignalArtworkDiagnostics.shared.snapshot()["networkTransfers", default: 0] == 0,
                         "Corrupt processed image must repair from originals without network")
            let legacyURL = URL(string: base + "/assets/2123456789abcdef0123456789abcdef/poster.webp")!
            let data = try SignalArtworkTransport.originalCache.diskStorage.value(forKey: poster.absoluteString)!
            var hash: UInt64 = 14_695_981_039_346_656_037
            for byte in legacyURL.absoluteString.utf8 { hash ^= UInt64(byte); hash &*= 1_099_511_628_211 }
            let folder = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!.appendingPathComponent("SignalArtworkSourceCache-v296")
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            try data.write(to: folder.appendingPathComponent(String(format: "%016llx.art", hash)))
            _ = try await fetch(legacyURL, 512)
            precondition(SignalArtworkDiagnostics.shared.snapshot()["networkTransfers", default: 0] == 0,
                         "Legacy original-byte migration must not download")
            let legacyProcessed = URL(string: base + "/assets/3123456789abcdef0123456789abcdef/poster.webp")!
            let oldKey = legacyProcessed.absoluteString + "|decode=640|domain=persistent"
            let image = try await fetch(poster, 640).image
            await withCheckedContinuation { continuation in
                SignalArtworkTransport.processedCache.store(image, forKey: oldKey, processorIdentifier: parsed.processor.identifier) { _ in continuation.resume() }
            }
            _ = try await fetch(legacyProcessed, 640, legacy: oldKey)
            precondition(SignalArtworkDiagnostics.shared.snapshot()["networkTransfers", default: 0] == 0)
            let missing = URL(string: base + "/missing.png")!
            for _ in 0..<2 {
                do { _ = try await fetch(missing, 384); preconditionFailure("404 should fail") }
                catch { /* expected */ }
            }
            precondition(SignalArtworkDiagnostics.shared.snapshot()["negativeCacheHits", default: 0] == 1)
            var cancelledDelivered = false
            let cancelled = SignalArtworkTransport.retrieve(url: URL(string: base + "/slow.png")!, maxPixelSize: 384, speculative: true) { _ in cancelledDelivered = true }
            try await Task.sleep(nanoseconds: 80_000_000)
            cancelled.cancel()
            try await Task.sleep(nanoseconds: 450_000_000)
            precondition(!cancelledDelivered, "Cancelled request must not publish or fall back")
            // Corrupt ORIGINAL plus evicted processed files must recover with one real transfer.
            await withCheckedContinuation { continuation in SignalArtworkTransport.processedCache.clearDiskCache { continuation.resume() } }
            flushMemory()
            let originalPath = SignalArtworkTransport.originalCache.cachePath(forKey: poster.absoluteString)
            try Data("broken original".utf8).write(to: URL(fileURLWithPath: originalPath), options: .atomic)
            _ = try await fetch(poster, 768)
            precondition(SignalArtworkDiagnostics.shared.snapshot()["networkTransfers", default: 0] == 1)
            let beforeEviction = SignalArtworkDiagnostics.shared.snapshot()["diskEvictions", default: 0]
            SignalArtworkTransport.processedCache.diskStorage.config.sizeLimit = 1
            await withCheckedContinuation { continuation in SignalArtworkTransport.processedCache.cleanExpiredDiskCache { continuation.resume() } }
            precondition(SignalArtworkDiagnostics.shared.snapshot()["diskEvictions", default: 0] > beforeEviction)
        }
        let result = SignalArtworkDiagnostics.shared.snapshot()
        let encoded = try JSONSerialization.data(withJSONObject: ["phase": phase, "metrics": result], options: [.sortedKeys])
        print(String(decoding: encoded, as: UTF8.self))
    }
}
