import Foundation

@main struct SignalLiveTVCardEffectTests {
    static func main() {
        precondition(SignalLiveTVCardEffect.names.count == 56)
        precondition(Set(SignalLiveTVCardEffect.names).count == 56)
        var value = "Original"
        for _ in SignalLiveTVCardEffect.names { value = SignalLiveTVCardEffect.next(value) }
        precondition(value == "Original")
        precondition(SignalLiveTVCardEffect.normalized("unknown") == "Original")
        precondition(SignalLiveTVCardEffect.resolved("Original", legacyShape: "UNITY 3D Left") == "Tilt Left")
        let old = ["Original", "Tilt Left", "Tilt Right", "Dual Inward", "Split Inward", "Dual Inward Strong", "Split Inward Strong"]
        for name in old { precondition(SignalLiveTVCardEffect.normalized(name) == name) }
        for name in SignalLiveTVCardEffect.names {
            precondition(SignalLiveTVCardEffect.usesCenterGutter(name) == SignalLiveTVCardEffect.baseName(name).hasPrefix("Split "))
            for col in -1...4 {
                for focused in [false,true] {
                    let p = SignalLiveTVCardEffect.pose(name, column: col, focused: focused)
                    precondition([p.yaw,p.pitch,p.roll,p.x,p.y,p.depth,p.bevel].allSatisfy { $0.isFinite })
                    precondition(abs(p.yaw) <= 24 && abs(p.pitch) <= 9 && abs(p.roll) <= 2)
                    precondition(abs(p.x) <= 10 && abs(p.y) <= 10)
                    precondition((0...18).contains(p.depth) && (0...1).contains(p.bevel))
                }
            }
        }
        for col in 0..<4 {
            let regular = SignalLiveTVCardEffect.pose("Dual Inward",column:col,focused:true)
            let strong = SignalLiveTVCardEffect.pose("Dual Inward Strong",column:col,focused:true)
            let maxDepth = SignalLiveTVCardEffect.pose("Dual Inward Max",column:col,focused:true)
            precondition(abs(regular.yaw) < abs(strong.yaw) && abs(strong.yaw) < abs(maxDepth.yaw))
            precondition(maxDepth.yaw * (col < 2 ? 1 : -1) > 0)
            precondition(maxDepth == SignalLiveTVCardEffect.pose("Split Inward Max",column:col,focused:true))
        }
        let signatures = Set(SignalLiveTVCardEffect.baseNames.filter { !$0.hasPrefix("Split") }.map { name in
            (0..<4).map { "\(SignalLiveTVCardEffect.pose(name,column:$0,focused:true))" }.joined(separator:"|")
        })
        precondition(signatures.count == 22, "Only Split modes intentionally share poses with Dual")
        for old in ["Gallery Fan","Cinema Arc","Floating Shelf","Isometric Deck","Cascade Stack"] {
            precondition(SignalLiveTVCardEffect.normalized(old) != "Original")
        }
        precondition(SignalMirrorSearchPlacement.resolve("missing") == .menu)
        precondition(SignalMirrorSearchPlacement.menu.next == .clock)
        precondition(SignalMirrorSearchPlacement.clock.next == .menu)
        for placement in SignalMirrorSearchPlacement.allCases {
            precondition(SignalMirrorSearchPlacement.resolve(placement.rawValue) == placement)
        }
        precondition(!SignalCatalogMotionBudget.rapidRepeat(now:1,previous:0))
        precondition(SignalCatalogMotionBudget.rapidRepeat(now:1.1,previous:1))
        precondition(!SignalCatalogMotionBudget.rapidRepeat(now:1.3,previous:1))
        precondition(!SignalCatalogMotionBudget.rapidRepeat(now:0.5,previous:1))
        print("F34 card poses, migrations, Max depth, Search choices and repeat cadence passed")
    }
}
