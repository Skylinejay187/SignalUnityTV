import unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'Scripts'))
from f87_approved_deltas import previous_source
from check_f84_settings_history import audit_preferences
from check_f87_native_unity_sports import metadata_fixture,route_fixture
class F87UnitySportsTests(unittest.TestCase):
    def test_new_shade_is_omitted_only_after_hash_validation(self):
        name='Sources/SignalUnityDashboardShade.swift';source=(ROOT/'Tests/F87OriginalSignalUnityDashboardShade.swift.txt').read_text()
        self.assertEqual(previous_source(source,name),'')
        # F88 edits the current compositor; F87 provenance is checked against its immutable archived input.
        self.assertEqual(previous_source(source,name),'')
        with self.assertRaises(AssertionError):previous_source(source+'\n// unexpected\n',name)
    def test_sports_background_must_be_portable(self):
        registry=(ROOT/'Sources/SignalPortableSettings.swift').read_text()
        sources=[p.read_text() for p in (ROOT/'Sources').rglob('*.swift')]
        self.assertGreater(audit_preferences(registry,sources),0)
        with self.assertRaises(AssertionError):
            audit_preferences(registry.replace('"sportsBackdropStyleV1": "Dimmed Dashboard",',''),sources)
    def test_native_fixtures_extract_current_actual_properties(self):
        self.assertIn('if isOnlineSportsPlayback',metadata_fixture())
        self.assertIn('item.posterURL ?? item.landscapeURL',metadata_fixture())
        text=route_fixture()
        self.assertIn('kind == .liveTV',text)
        self.assertIn('sourceURL.user == nil',text)
if __name__=='__main__':unittest.main()
