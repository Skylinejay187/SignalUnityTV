
@main struct SignalF62PlaybackGuideTests {
    @MainActor static func settle(_ host: PlaybackFixture) async {
        for _ in 0..<1000 {
            if host.sessionAdjustmentTask == nil { return }
            await Task.yield()
        }
        preconditionFailure("Session adjustment did not settle")
    }
    @MainActor static func main() async {
        typealias P = SignalPlaybackRefreshPolicy
        precondition(P.gain(.nan) == 0 && P.gain(.infinity) == 0 && P.gain(-10) == 0 && P.gain(20) == 12)
        let now = Date(timeIntervalSince1970: 100_000)
        precondition(P.currentGuideRow(title: "Real show", realTiming: true, start: now, end: now.addingTimeInterval(1800), now: now))
        precondition(!P.currentGuideRow(title: "No EPG", realTiming: false, start: now, end: now.addingTimeInterval(1800), now: now))
        precondition(!P.currentGuideRow(title: "Expired", realTiming: true, start: now.addingTimeInterval(-1800), end: now, now: now))
        precondition(!P.currentGuideRow(title: "Bad dates", realTiming: true, start: now, end: now.addingTimeInterval(-1), now: now))
        precondition(!P.currentGuideRow(title: " ", realTiming: true, start: now, end: now.addingTimeInterval(1800), now: now))
        for playing in [true, false] {
            let host = PlaybackFixture();let engine = host.engine!
            host.transportWantsPlay = playing
            host.aetherPrepareForBackground();engine.isSessionReady = false
            host.aetherRecoverAfterBackground();host.aetherRecoverAfterBackground()
            await settle(host)
            precondition(engine.reloads == 1 && engine.isSessionReady)
            precondition(playing ? engine.plays == 1 : engine.pauses == 1)
            host.aetherRecoverAfterBackground();await settle(host)
            precondition(engine.reloads == 1, "Duplicate foreground must not restart playback")
        }
        let ready = PlaybackFixture();ready.aetherPrepareForBackground();ready.aetherRecoverAfterBackground()
        await settle(ready);precondition(ready.engine!.reloads == 0)
        let blocked = PlaybackFixture();blocked.configuredAllowSessionRebuild = false
        blocked.aetherPrepareForBackground();blocked.engine!.isSessionReady = false;blocked.aetherRecoverAfterBackground()
        precondition(blocked.engine!.reloads == 0 && blocked.sessionAdjustmentTask == nil)
        blocked.configuredAllowSessionRebuild = true;blocked.reconcileSessionAdjustments();await settle(blocked)
        precondition(blocked.engine!.reloads == 1)
        let ended = PlaybackFixture();ended.endedPublished = true;ended.aetherPrepareForBackground();ended.aetherRecoverAfterBackground()
        precondition(ended.engine!.reloads == 0)
        for playing in [true, false] {
            let gain = PlaybackFixture();let engine = gain.engine!
            engine.playbackBackend = .software;gain.transportWantsPlay = playing
            for value in [6.0, 9, 12, 0, 3, 0, Double.nan, Double.infinity, -1, 20] {
                gain.configuredAudioGainDB = value;gain.aetherApplyAudioGain()
                precondition(engine.gain == P.gain(value) && gain.notices.last == P.gain(value))
                precondition(engine.reloads == 0 && engine.corrections == 0)
                precondition(engine.plays == 0 && engine.pauses == 0 && gain.sessionAdjustmentTask == nil,
                             "Gain must never alter transport, video session, or paused intent")
            }
        }
        for playing in [true, false] {
            let native = PlaybackFixture(); let engine = native.engine!
            native.transportWantsPlay = playing
            native.configuredAudioGainDB = 6; native.aetherApplyAudioGain()
            native.configuredAudioGainDB = 9; native.aetherApplyAudioGain()
            await settle(native)
            precondition(native.notices.last == 9 && engine.gain == 9 && native.failures.isEmpty)
            precondition(engine.corrections == 1 && engine.reloads == 0)
            precondition(playing ? engine.plays == 1 : engine.pauses == 1)
            native.configuredAudioGainDB = 0; native.aetherApplyAudioGain()
            native.configuredAudioGainDB = 12; native.aetherApplyAudioGain()
            precondition(engine.gain == 12 && engine.corrections == 1, "Off/re-enable must stay on decoded route")
        }
        let refused = PlaybackFixture();refused.engine!.refuseCorrection = true
        refused.configuredAudioGainDB = 6;refused.aetherApplyAudioGain();await settle(refused)
        precondition(refused.notices.last == 0 && refused.engine!.corrections == 0)
        precondition(refused.sessionAdjustmentTask == nil && !refused.audioGainUpdatePending)
        let cancelledGain = PlaybackFixture();cancelledGain.configuredAudioGainDB = 6;cancelledGain.aetherApplyAudioGain()
        cancelledGain.configuredAudioGainDB = 0;cancelledGain.aetherApplyAudioGain();await settle(cancelledGain)
        precondition(cancelledGain.engine!.corrections == 0 && cancelledGain.engine!.gain == 0)
        let during = PlaybackFixture();during.engine!.holdCorrection = true
        during.configuredAudioGainDB = 6;during.aetherApplyAudioGain()
        while during.engine!.correctionHold == nil { await Task.yield() }
        during.configuredAudioGainDB = 12;during.aetherApplyAudioGain()
        during.engine!.correctionHold?.resume();during.engine!.correctionHold = nil
        await settle(during)
        precondition(during.engine!.gain == 12 && during.engine!.corrections == 1)
        let staleGain = PlaybackFixture();let staleEngine = staleGain.engine!
        staleEngine.holdCorrection = true;staleGain.configuredAudioGainDB = 6;staleGain.aetherApplyAudioGain()
        while staleEngine.correctionHold == nil { await Task.yield() }
        staleGain.generation += 1;staleGain.sessionAdjustmentTask?.cancel()
        staleEngine.correctionHold?.resume();staleEngine.correctionHold = nil
        for _ in 0..<20 { await Task.yield() }
        precondition(staleEngine.gain == 0 && staleGain.notices.isEmpty && staleEngine.plays == 0)
        let pending = PlaybackFixture();pending.engine!.playbackBackend = .software
        pending.backgrounded = true;pending.configuredAudioGainDB = 6;pending.aetherApplyAudioGain()
        pending.configuredAudioGainDB = 9;pending.aetherApplyAudioGain()
        precondition(pending.audioGainUpdatePending && pending.engine!.gain == 0)
        pending.backgrounded = false;pending.applyPendingAudioGain()
        precondition(pending.engine!.gain == 9 && !pending.audioGainUpdatePending)
        let live = PlaybackFixture();live.loadedOptions?.isLive = true;live.configuredAudioGainDB = 12
        live.aetherApplyAudioGain();precondition(live.engine!.gain == 0 && live.notices.isEmpty)
        let finished = PlaybackFixture();finished.endedPublished = true;finished.configuredAudioGainDB = 6
        finished.aetherApplyAudioGain();precondition(finished.engine!.gain == 0 && finished.notices.isEmpty)
        let retired = PlaybackFixture();retired.aetherPrepareForBackground();retired.engine!.isSessionReady = false
        retired.aetherRecoverAfterBackground();retired.generation += 1
        retired.sessionAdjustmentTask?.cancel();await Task.yield()
        precondition(retired.engine!.plays == 0, "Retired surface must not resume")
        let guide = GuideFixture()
        let automatic = Task { @MainActor in await guide.refreshFromConfiguredSources(userInitiatedForce: false) }
        while guide.starts.isEmpty { await Task.yield() }
        let manual = Task { @MainActor in await guide.refreshFromConfiguredSources(userInitiatedForce: true) }
        while guide.starts.count < 2 { await Task.yield() }
        var duplicateEntered = false, backgroundEntered = false
        let duplicate = Task { @MainActor in
            duplicateEntered = true;await guide.refreshFromConfiguredSources(userInitiatedForce: true)
        }
        let backgroundRefresh = Task { @MainActor in
            backgroundEntered = true;await guide.refreshFromConfiguredSources(userInitiatedForce: false)
        }
        while !duplicateEntered || !backgroundEntered { await Task.yield() }
        precondition(guide.isGuideRefreshing && guide.releases.count == 2, "Loading must cover real EPG work")
        guide.releases.forEach { $0.resume() };guide.releases.removeAll()
        await automatic.value;await manual.value;await duplicate.value;await backgroundRefresh.value
        precondition(guide.starts == [false,true] && guide.completions == 1)
        precondition(!guide.isGuideRefreshing && guide.providerRefreshTask == nil)
        print("F62 policy, paused/playing recovery, duplicate foreground, proof gate, EOF, in-place gain, no transport/reload, single native correction/refusal, coalesced clicks, deferred latest gain, stale session and refresh coalescing passed")
    }
}
