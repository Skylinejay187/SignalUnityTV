import Foundation

enum SignalF68GuideMetadataTests {
    static func verify() {
        struct Key: Hashable { let channel: Int; let start: Date; let width: Double }
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        let axis = SignalGuideTimeline(now: now, width: 1400)
        let program = SignalGuideTimeline.Entry(id: 1, start: axis.start, end: axis.start.addingTimeInterval(1800))
        let cache = SignalGuideMetadataCache<Key, [SignalGuideTimeline.ProgramSlot]>(limit: 3)
        let key = Key(channel: 1, start: axis.start, width: axis.scheduleWidth)
        var builds = 0
        for _ in 0..<100 {
            let slots = cache.value(for: key) { builds += 1; return axis.slots([program]) }
            precondition(slots == axis.slots([program]))
        }
        precondition(builds == 1 && cache.hits == 99 && cache.count == 1)
        let wide = SignalGuideTimeline(now: now, width: 1800)
        let resized = cache.value(for: Key(channel: 1, start: wide.start, width: wide.scheduleWidth)) {
            builds += 1; return wide.slots([program])
        }
        precondition(builds == 2 && resized == wide.slots([program]) && resized != axis.slots([program]))
        cache.clear()
        let updated = SignalGuideTimeline.Entry(id: 2, start: axis.start.addingTimeInterval(600), end: axis.start.addingTimeInterval(2400))
        let fresh = cache.value(for: key) { builds += 1; return axis.slots([updated]) }
        precondition(builds == 3 && fresh.first?.id == 2)
        for channel in 2...20 {
            _ = cache.value(for: Key(channel: channel, start: axis.start, width: axis.scheduleWidth)) { axis.slots([updated]) }
        }
        precondition(cache.count == 3)
        let none = SignalGuideMetadataCache<Int, [Int]>(limit: 2)
        _ = none.value(for: 0) { [] }; _ = none.value(for: 0) { preconditionFailure("Empty result must also be reused") }
        precondition(none.hits == 1)
        let owner = UUID(); var gate = SignalEpisodeClockGate()
        precondition(gate.shouldEvaluate(owner: owner, uptime: 1))
        precondition(!gate.shouldEvaluate(owner: owner, uptime: 1.1, precision: true))
        precondition(gate.shouldEvaluate(owner: owner, uptime: 1.2, precision: true))
        let recap = SignalEpisodeSegment(kind: .recap, start: 42, end: 75, provider: "fixture")
        precondition(SignalEpisodeSkipPlan.recap(segments: [recap], consumed: [], position: 41.2, duration: 100) == nil)
        precondition(SignalEpisodeSkipPlan.recap(segments: [recap], consumed: [], position: 41.2, duration: 100, lead: 1) == recap)
        precondition(SignalEpisodeSkipPlan.recap(segments: [recap], consumed: [], position: 40, duration: 100, lead: 100) == nil)
        let suite = "Signal.F68." + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        defaults.set(true, forKey: "episodeAutoRecapV1")
        let options = SignalEpisodeOptions.load(defaults)
        precondition(SignalEpisodeSkipPlan.action(segments: [recap], consumed: [], position: 41.2, duration: 100, options: options) == .none)
        precondition(SignalEpisodeSkipPlan.action(segments: [recap], consumed: [], position: 42, duration: 100, options: options) == .seek(75, recap.id))
        print("F68 actual guide cache: reuse/bounds/refresh/width and recap prompt lead vs exact auto-skip PASS")
    }
}
