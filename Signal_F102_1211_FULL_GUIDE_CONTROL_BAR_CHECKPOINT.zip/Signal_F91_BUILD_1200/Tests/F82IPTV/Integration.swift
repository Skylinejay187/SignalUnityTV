import Foundation

struct LiveTVChannel: Sendable {
    var id: Int = 1
    var name: String = ""
    var category: String = ""
    var source: String = ""
    var tvgID: String = ""
    var now: String = ""
    var next: String = ""
    var description: String = ""
    var streamURL: String = "https://fixture.invalid/live"
    var bestArtworkURL: String = ""
}
struct LiveProgram { var title = "Fixture"; var isLive = true; var startText = "10:00" }
struct MediaItem {
    var id: String; var title: String; var year: String; var type: String; var catalog: String
    var description: String; var genres: [String]; var rating: String
    var posterURL: String?; var landscapeURL: String?; var logoURL: String?; var previewURL: String?
    var addonName: String?; var addonIconURL: String?
}
final class IPTVProtocol: URLProtocol, @unchecked Sendable {
    static let lock = NSLock()
    static var requests: [URL] = []
    override class func canInit(with request: URLRequest) -> Bool { request.url?.host == "fixture.invalid" }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func stopLoading() {}
    override func startLoading() {
        guard let url = request.url else { return }
        Self.lock.lock(); Self.requests.append(url); Self.lock.unlock()
        let query = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? []
        let action = query.first { $0.name == "action" }?.value ?? ""
        let payload: String
        switch action {
        case "get_live_categories": payload = #"[{"category_id":"10","category_name":"Sports"},{"category_id":"20","category_name":"News"}]"#
        case "get_live_streams": payload = #"[{"stream_id":1,"name":"ESPN 2","category_id":"10","num":1,"epg_channel_id":"espn.two","stream_icon":"https://fixture.invalid/poster.webp"},{"stream_id":2,"name":"World News","category_id":"20","num":2}]"#
        case "get_vod_categories", "get_series_categories": payload = #"[{"category_id":"30","category_name":"Favorites"}]"#
        case "get_vod_streams": payload = #"[{"stream_id":7,"name":"The Matrix","year":"1999","category_id":"30","container_extension":"mkv","tmdb":"603"}]"#
        case "get_series": payload = #"[{"series_id":9,"name":"Fixture Show","year":"2026","category_id":"30"}]"#
        case "get_series_info": payload = #"{"episodes":{"2":[{"id":92,"season":2,"episode_num":2,"title":"Second","container_extension":"mkv"},{"id":91,"season":2,"episode_num":1,"title":"First","container_extension":"mp4"}]}}"#
        default: payload = #"[]"#
        }
        client?.urlProtocol(self, didReceive: HTTPURLResponse(url: url, statusCode: 200, httpVersion: nil, headerFields: nil)!, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(payload.utf8)); client?.urlProtocolDidFinishLoading(self)
    }
    static func count() -> Int { lock.lock(); defer { lock.unlock() }; return requests.count }
}
@main struct F82Checks {
    @MainActor static func main() async throws {
        let suite = "SignalF82-" + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        defaults.set("https://fixture.invalid/|user&a|p+q|Sports Only\nhttps://fixture.invalid|user&a|p+q|Both", forKey: "liveXtreamAccounts")
        precondition(SignalIPTVImport.sourceURLs("https://fixture.invalid/mount/list.m3u?categories=1,2; https://other.invalid/list").count == 2)
        let sources = SignalIPTVImport.sources(defaults: defaults)
        precondition(sources.count == 1 && sources[0].legacyMode == .sports)
        let source = sources[0]
        let api = source.api("get_live_streams")!
        let query = URLComponents(url: api, resolvingAgainstBaseURL: false)!.queryItems!
        precondition(query.first { $0.name == "username" }?.value == "user&a")
        precondition(query.first { $0.name == "password" }?.value == "p+q")
        precondition(api.absoluteString.contains("%2B"))
        precondition(SignalIPTVImport.server("https://fixture.invalid/player_api.php?x=1") == "https://fixture.invalid")
        precondition(source.stream(kind: .movie, id: "7", ext: "../bad").hasSuffix("/7.mp4"))
        var selection = SignalIPTVImport.Selection(mode: .sports)
        selection.categories["live"] = []
        precondition(!selection.allows(kind: .live, category: "10", id: "1"))
        selection.categories["live"] = ["10"]; selection.entries["live"] = ["1"]
        SignalIPTVImport.save(selection, for: source, defaults: defaults)
        precondition(SignalIPTVImport.selection(for: source, defaults: defaults) == selection)
        let encoded = defaults.string(forKey: SignalIPTVImport.settingsKey)!
        precondition(!encoded.contains("p+q") && !encoded.contains("user&a"))
        precondition(!SignalIPTVImport.looksSports("Raw News — event updates"))
        precondition(SignalIPTVImport.looksSports("UK | Sky Sports F1 HD"))
        let config = URLSessionConfiguration.ephemeral; config.protocolClasses = [IPTVProtocol.self]
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let repo = SignalIPTVRepository(session: URLSession(configuration: config), cacheDirectory: directory)
        let live = try await repo.entries(source, kind: .live, selection: selection)
        precondition(live.count == 1 && live[0].id == "1" && live[0].epgID == "espn.two")
        let before = IPTVProtocol.count()
        _ = try await repo.entries(source, kind: .live, selection: selection)
        precondition(IPTVProtocol.count() == before, "Warm data downloaded again")
        let restart = SignalIPTVRepository(session: URLSession(configuration: config), cacheDirectory: directory)
        _ = try await restart.entries(source, kind: .live, selection: selection)
        precondition(IPTVProtocol.count() == before, "Disk data downloaded after repository restart")
        selection.categories["live"] = []
        let none = try await repo.entries(source, kind: .live, selection: selection)
        precondition(none.isEmpty && IPTVProtocol.count() == before)
        let movies = try await repo.entries(source, kind: .movie)
        precondition(movies.count == 1 && movies[0].url.hasSuffix("/7.mkv"))
        precondition(SignalIPTVImport.matches(movies[0], title: "The Matrix", year: "1999", tmdb: nil, imdb: nil))
        precondition(!SignalIPTVImport.matches(movies[0], title: "The Matrix", year: "2021", tmdb: nil, imdb: nil))
        precondition(!SignalIPTVImport.matches(movies[0], title: "The Matrix", year: "1999", tmdb: "999", imdb: nil))
        let series = try await repo.entries(source, kind: .series)
        let episodes = try await repo.episodes(source, series: series[0])
        precondition(episodes.map { $0.episode! } == [1, 2] && episodes[0].url.hasSuffix("/91.mp4"))
        let m3u = "#EXTM3U\n#EXTINF:-1 tvg-name=\"Arena\" group-title=\"Special Events\" tvg-id=\"a\",Arena\n/live/a.ts\n#EXTINF:-1 group-title=\"Films\",Film\n/movie/a.mp4\n"
        let parsed = SignalIPTVRepository.parseM3U(m3u, base: URL(string: "https://fixture.invalid/list.m3u")!)
        precondition(parsed.count == 2 && parsed[0].category == "Special Events" && parsed[1].kind == .movie)
        precondition(parsed[0].url == "https://fixture.invalid/live/a.ts")
        precondition(SportsChannelClassifierManager.shared.sportsSection(forRawText: "RAW NEWS") == nil)
        precondition(SportsChannelClassifierManager.shared.sportsSection(forRawText: "College Football ESPN") == "College Sports")
        let model = SportsCenterViewModel()
        var channels = (0..<750).map { LiveTVChannel(id: $0, name: "News \($0)", category: "News") }
        channels[700] = LiveTVChannel(id: 700, name: "ESPN", category: "Sports")
        await model.refresh(channels: channels, assignedGroupsRaw: "", manualChannelIdsRaw: "") { _ in LiveProgram() }
        precondition(model.sportsRows.flatMap { $0.1 }.contains { $0.title == "ESPN" }, "Sports beyond channel 600 was dropped")
        precondition(model.sportsRows.flatMap { $0.1 }.allSatisfy { $0.rating != "LIVE" }, "EPG airing was mislabelled live fixture")
        model.releaseForSurfaceExit(); precondition(model.sportsRows.isEmpty)
        print("F82 production provider transport/policy/cache/episodes and Sports classification executable checks PASS; device/full app compilation separate")
    }
}
