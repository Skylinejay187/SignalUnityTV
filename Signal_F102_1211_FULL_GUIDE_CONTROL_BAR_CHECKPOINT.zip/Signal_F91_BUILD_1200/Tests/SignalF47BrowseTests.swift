import Foundation

@main struct SignalF47BrowseTests {
    static func main() {
        for inPlayer in [false, true] { for active in [false, true] { for exclusive in [false, true] {
            let allowed = SignalPlaybackBrowsePolicy.searchAllowed(inPlayer: inPlayer, browserActive: active, exclusivePlayback: exclusive)
            if inPlayer { precondition(allowed == active) }
            else { precondition(allowed == !exclusive) }
        } } }
        let suite = "SignalF47Tests-" + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        for value in ["Golden", "Classic", "", "Preview Mirror"] {
            defaults.set(value, forKey: SignalDashboardMode.legacyKey)
            defaults.set(9, forKey: "vodAudioAmplificationDBV1")
            SignalDashboardMode.migrate(defaults)
            SignalDashboardMode.migrate(defaults)
            precondition(defaults.string(forKey: SignalDashboardMode.legacyKey) == "Preview Mirror")
            precondition(defaults.integer(forKey: "vodAudioAmplificationDBV1") == 9)
        }
        PlaybackControlCompileFixture.verify()
        print("F47 foreground Search gate, dashboard migration, real player control/destination contracts passed")
    }
}
