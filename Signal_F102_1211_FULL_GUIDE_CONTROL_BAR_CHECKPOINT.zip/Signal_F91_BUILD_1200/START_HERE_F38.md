# Signal F38 — Build 1147

Version **1.0.1147**, patched forward from F37R1 / 1146. The F37R1 Carousel compile repair, 2.5-second preview reveal, fast Aether startup, page destination math and Search spotlight are preserved.

This is a source delivery. Local checks passed; **a new Xcode build and physical Apple TV validation have not been performed** in this Linux workspace. Older release documents are retained as history; this file describes the current package.

## Up Next prepares links before the popup

The old popup could appear with four minutes left while source discovery waited until 210 seconds, retried only near 75 seconds, and scanned installed providers sequentially. Full playback metadata enrichment also sat in front of link discovery. These paths can explain a long delay between seeing Up Next and receiving a playable episode URL.

F38 begins next-episode identity lookup before the source-preparation window. Source preparation may start with up to ten minutes remaining, adjusted for short episodes. It does not wait for the popup, pause, EOF or a 30-second countdown. Cast/logo/date hydration no longer blocks it; the episode inventory and inherited series identifiers supply the lookup identity.

Up to **three discovery lanes** run concurrently, including direct Xtream and configured addon sources. Stremio JSON decoding runs off the main actor. A completed provider response containing a qualifying complete episode returns immediately instead of probing more IDs and types. The first prepared result is published to Up Next immediately; slower pending provider work is cancelled. The already resolved URL is reused when Play is selected, without creating or prewarming another decoder.

A failed early attempt can retry before the popup, with bounded backoff. A third attempt remains available at EOF, so a temporary early provider outage cannot consume every recovery attempt. Presentation and URL ownership guards reject stale completions after an episode/source switch. Finite network timeouts and the existing preview/sample, exact-episode and full-episode size protections remain. Eligible autoplay sources must be **larger than 1 GB**; when available, original provider byte counts are used instead of rounded labels. Unknown/small assets do not qualify for autoplay.

Prepared means a direct URL has been resolved, not that video has been decoded or that an external provider is guaranteed to stay available. No app can guarantee an instant playable link when every configured service is unavailable. Current playback, audio, timeshift and the Aether engine are untouched by this link-only worker. MediaFlow routing and provider request headers remain part of the handoff.

## Debrid and addon results stay mixed

The old code balanced providers and then globally sorted the balanced list again, undoing the alternating order. The final popup also reapplied playback-memory priority without balancing afterward.

F38 rotates available services, then rotates addons inside each service while preserving each addon's internal rank. With TorBox and Real-Debrid, this produces alternating service results while cycling through Torrentio, Comet and other returning addons. Once a queue is exhausted, remaining results continue normally. The first service can depend on the best-ranked available result; the ordering does not fabricate missing sources.

The ordinary 25/50 cap remains. Native TorBox Usenet results remain uncapped. Final publication and the All Providers display both preserve the interleaving. Provider-specific filters retain their normal ranking, and playback memory influences rank within the available queues. No account secrets or stream URLs are used as grouping identifiers.

## Manual cast focus stays on the poster

With Featured Cast set to Off, manual poster browsing remains available. While Cast owns focus, changing portraits reasserts the same focus target. Geometric focus assignments to player chips are rejected until an explicit navigation route leaves Cast. Overlay and drawer auto-hide timers cannot pull focus away during this session. Entering Cast no longer inherits the timeline's previous input delay.

Left/Right browse, Select opens the displayed cast member, and Down returns to the timeline. Back and existing overlay/browser transitions retain their established exit behavior. Automatic rotation remains disabled in Off mode. No additional cast focus target was added.

## Restored favorite and new top menus

**Signal Original Glass** restores the compact shared smoked-glass capsule from the supplied image, with icon labels and a restrained inset selection. It is an explicit selectable theme, not an alias for a different layout.

Five more new options join it: **Floating Lens, Graphite Capsule, Cinema Rail, Crystal Outline and Slim Dock**. The collection now has **30 canonical themes**. Each new option has its own mapped renderer, chrome and exact persistent identity. Existing selections and legacy migrations are preserved.

The live menu and picker preview share the renderer and slot geometry. The original-style capsule uses a shorter visual slot to restore its compact proportions. Accent remains a highlight/tint, not an opaque replacement for the entire bar. Native tvOS per-item focus and existing menu destinations remain unchanged; no virtual cursor was reintroduced.

## Smoke blended with blurred glass

The rejected light-ribbon patterns are replaced by soft drifting smoke billows: **Soft, Cinematic, Drift, Wisps and Deep Blue**, plus Off. Appearance exposes these under **Smoke Atmosphere**. Existing saved light-style choices migrate to smoke choices through the same preference key; backup/restore continues to work.

Smoke is drawn beneath the existing glass tint and edge shading so it shares the same blue/neutral palette as the blurred artwork. It adds no second artwork blur and no white overlay over cards. Soft radial gradients are scaled into billows with transparent edges; there are no hard ribbon strokes or external image assets.

The existing 20 FPS maximum and lifecycle protections remain: smoke animates only on its eligible visible dashboard, freezes its phase during video previews, and is removed from covered surfaces. Reduce Motion uses a static phase. Pure Black remains effect-free. Smoke will therefore be static while an active preview owns the video budget; that behavior is deliberate.

## Duplicate routed input

The previous duplicate guard was tied to one card ID, so a repeated delivery reaching the next card or row could pass it. F38 shares a **120 ms same-direction window per routed surface** across adjacent cards/rows. Catalog row routing, Live TV edge routing, cast browsing and catalog-customization controls use it. Opposite directions and another surface are immediately eligible. Rejected duplicates do not extend the window.

Redundant per-card/per-DPAD delays are removed from the Live TV edge route. The accepted one-outward-press page change and row-preserving destination math are retained. Native top-menu and Settings-category Left/Right focus remain native. This specifically addresses duplicate app-routed commands; physical remote repeat behavior and native focus movement still require device testing. It does not claim to prove every reported system-wide jump is resolved.

## Verification and next build

Local checks: aligned build identity; six build-identity unit tests; F31–F38 source checks; exact reviewed deltas against immutable historical fixtures; preserved Aether bridge/host, 2.5-second preview policy and Carousel repair; 213 of 220 tracked VOD functions byte-identical to F37R1, with seven intentional Up Next/focus-timer changes; seven redaction cases; remote-thumbnail safety; 22 FastZap wiring checks; no new Swift grammar diagnostics; workflow/source entries; archive CRC and all-entry source-byte comparisons.

The new executable Swift model tests cover service/addon ordering, exhausted queues, caps, duplicate-command timing, all 30 theme identities and smoke-choice migration. They are included in macOS CI but **were not executed locally**. Syntax parsing is not Swift type checking or Xcode compilation.

Build this complete source ZIP with the existing workflow. After a successful build, verify:

1. Up Next on a real episode with multiple addons: link readiness before the popup, immediate selection of the prepared URL, unavailable-provider recovery, EOF autoplay and cancellation after changing episode.
2. All Providers ordering with TorBox/Real-Debrid and several addons; provider filters, 25/50 caps and uncapped Usenet.
3. Featured Cast Off: Up to the poster, several Left/Right presses, waiting beyond old auto-hide times, Select and Down/Back. Repeat with the other cast modes.
4. Select Signal Original Glass and each new menu theme; confirm the actual top bar changes and survives restart/backup. Test Search in both placements and all menu sizes.
5. Smoke styles with blue glass, blurred focused artwork, transparency changes, previews, Guide/catalogs/Settings, Reduce Motion and Pure Black.
6. Rapid and held remote input across rows/page edges, including alternating directions. Record any remaining native double hop; source checks alone cannot measure physical input delivery.
