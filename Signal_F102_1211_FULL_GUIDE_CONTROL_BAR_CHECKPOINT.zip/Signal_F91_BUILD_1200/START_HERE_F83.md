# F83 / build 1192

Fixes F82's IPTV organizer Swift type-check timeout by splitting its form into separate view sections and its task IDs/loaders into explicitly typed properties/methods. The uploaded F82 logs confirm the native IPTV/provider/cache/episode tests passed before the organizer SDK check failed.

Sports now has a visible Sports Center scoreboard above the existing channel/catalog rails: Live Scores, Next Games, and Final Results. Fixtures show team names/logos, actual scores where provided, status and local kickoff time. Choose Glass, Scoreboard or Compact in Settings > Sports > Sports widget style. The setting is included in portable Backup & Restore.

Scores use existing ESPN feeds and their structured live/scheduled/completed status. Unavailable data produces empty states. Postponed/cancelled games are excluded from Next Games. Refresh waits 60 seconds after each pass, runs only while Sports owns the active scene, and cancels on exit/background/VOD. Failed refreshes retain the previous timestamped scores. Widgets are informational; this build does not add automatic fixture-to-IPTV channel matching or claim every league's coverage.

F83_VALIDATION.json records local source/grammar checks. Twelve existing Python regression tests also passed. F83's native scoreboard parsing tests and actual widget tvOS SDK typecheck are wired into preflight, alongside F82's organizer/provider checks. Swift/Xcode/Apple TV are unavailable locally, so full compilation and device layout/remote/playback validation remain pending.

Existing playback, artwork pipeline, IPTV extraction, guide and catalog layouts outside the added Sports panels are preserved. Read F83_CHANGED_FILES.txt and the exact source manifests for scope.
