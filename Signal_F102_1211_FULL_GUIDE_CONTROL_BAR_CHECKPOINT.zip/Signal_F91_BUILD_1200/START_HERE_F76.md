# F76 / build 1185

Fixes the supplied F75 build-log failure: the Settings SDK type-check now includes the real SignalQuickGuidePreviewMode definition from SignalLiveTVResourcePolicy.swift. This resolves the missing-type cause of the cascading ForEach/Binding errors. The previous pause-fixture repair remains included and the new log confirms its native SDK check passed.

Two regression tests inspect the actual checker command and reject the original missing dependency; they do not execute a compiler. All 169 Swift files remain unchanged. Full native SDK/app build is not available locally; see F76_VALIDATION.json.
