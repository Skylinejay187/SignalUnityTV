# vBRDC390 artwork checkpoint (NOT FINAL)
Base: vBRDC390 EPG checkpoint derived from vBRDC389R2.
Change: separate Kingfisher cache identity for CDN-to-origin fallback, preventing fallback bytes from being stored under the CDN resource identity. Preserve Signal's decode/domain key and existing surface publication pipeline.
Validation: Swift frontend syntax parse of modified file; ZIP CRC verification.
Not verified: full tvOS build, physical Apple TV, full artwork first-presentation, Live TV decoding, VOD clock/resume.
Do not label as completed v390 release.
