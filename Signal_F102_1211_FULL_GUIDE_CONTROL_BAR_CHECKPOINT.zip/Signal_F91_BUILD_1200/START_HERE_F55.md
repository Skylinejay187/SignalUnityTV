# Signal F55 — build 1164

Forward from F54/build 1163. Reference: the supplied vBRDC228 source ZIP, specifically GlobalSearchScreen, SearchResultCard and FocusedSidewaysCardEffect.

## Search presentation restored

Search results return to a native vertically scrolling lazy grid with compact landscape cards, rather than the catalog rail. At a standard 1920-point canvas the grid has four columns with 360 × 202.5-point images, matching v228's approximately 360 × 202 proportions. Narrower canvases reduce the column count/card width. Search always uses a 16:9 image slot, independent of the catalog's portrait/3D Cover Flow preferences. Portrait-only fallback artwork is fitted inside that slot rather than growing into a tall poster.

The existing v228-style FocusedSidewaysCardEffect remains unchanged: the focused card turns 10 degrees around its vertical axis with a 1.02 scale and a 0.30-second spring (damping 0.86). Native tvOS focus owns ordinary animated vertical scrolling. This Search card respects Reduce Motion. Fixed label space avoids focus-dependent grid reflow. A darker single scrim keeps the retained Live TV grid from competing with Search text/results; in-player Search retains its existing black-glass surface.

Cards are image-only, capped at a 768-pixel image request and created through LazyVGrid. They do not create preview decoders, repeating animations, animation timers, reflections or material blur. The former catalog rail cannot impose giant portrait previews. The original theme-overlay pulse/shadow machinery is not reintroduced.

## Current behavior retained

The current async search pipeline, debounce, detached channel scan, cancellation/generation ownership, query/focus memory, quick metadata hydration, settled-focus prefetch and in-player work policy are retained. Search filters and Live TV matches remain available. Query focus stays at the search field on open. Selecting a result opens the same Media Information path; closing details restores the same media identity. A scoped view task mounts an offscreen lazy result before restoring native focus, checking cancellation, request identity, active scene, surface ownership and header/query focus before committing. Normal remote scrolling does not run a manual scroll task per focus step.

Only the Search screen, its new compact result card and a pure layout/focus-target helper change in production code. All 136 other prior Swift files remain byte-identical. Guide edge fades, red season focus outlines, Up Next, cache progress, home/away routing, card alignment and playback are preserved. AetherEngine 7.44.0 and Kingfisher 8.11.0 stay pinned.

## Validation

Executed here: all available Python preflight checks including the new current Search/source-scope guard, exact approved source-delta reversal, unchanged Swift comparisons, no new Swift grammar errors versus F54, clean grammar for the new layout/native test/extracted real UI fixture, build identity with six unit tests, shell/Python syntax and ZIP integrity. See F55_VALIDATION.json.

The macOS preflight now additionally compiles/runs the actual pure layout/focus-target tests and type-checks the actual new Search card, grid and focus-restoration methods against the tvOS SDK (model/image dependencies use explicit small fixtures). This does not replace the complete app build. No Swift compiler or Apple SDK exists in this environment: those native tests, full Xcode compilation, physical Apple TV focus/visual/scrolling behavior and device performance remain unverified. In particular, no local numeric execution of the new Swift layout helper or runtime screenshot is claimed.

Device checks: run a query with many movie/show results; navigate across/down/up several rows; open and close details; change filters; cancel/replace a query; test large catalog artwork preferences; verify Reduce Motion; then repeat Search over VOD and Live TV playback while confirming uninterrupted playback and artwork publication.
