# vBRDC398R17F9 — Five fully visible Spotlight posters

Base: vBRDC398R17F8. The Spotlight Hub is 480pt wide with 11pt horizontal inner padding. Removed the horizontal ScrollView from Related on Trakt and fitted five 70x105pt posters with 6pt spacing and a 43pt section label. Total strip width 436pt including its 14pt horizontal padding, below the available 458pt. All five posters can be displayed without the fifth being cut off. The same five-item source selection remains unchanged. Other dashboard, backup, and playback changes are preserved.

Validation: Swift frontend parse and ZIP integrity check. No Xcode/tvOS device compilation or visual test performed.
