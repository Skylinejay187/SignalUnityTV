# Signal Setup & Connection Center — Pass 1

Patch-forward from Phase 3 Pass 1 source. Added a guided launcher under Settings > General and a tvOS sheet with Live TV (Channels DVR, M3U/XMLTV, HDHomeRun, Xtream) and Debrid/Addons (Real-Debrid, TorBox, Torrentio, other providers, custom Stremio addon) routes to existing configuration editors. Added explicit real verification through ConnectedServicesHealthClient.verifyAll(), with busy indicator and returned status rows. No simulated percentages, no invented connected state, no credential migration, no playback changes.

Limits: This is an initial navigation/verification pass, not yet a complete multi-step wizard or per-source import progress instrumented through the playlist/EPG pipeline. Channels DVR import and other integrations remain governed by existing implementation. Swift frontend parse passed, but Xcode compilation and device testing are outstanding.
