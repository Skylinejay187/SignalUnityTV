# vBRDC398R5 Cover Flow geometry and production-card integration

- Replaced widely spaced side posters with 83-point compressed positions, mild 9-degree yaw, and shallow depth scale.
- Reused `FixedSlotFocusedCatalogCard` for selected landscape artwork, title-themed logo, and existing preview session behavior.
- Wrapped visual neighbors within each row to fill both sides when the selection is at the beginning; original selection and catalog actions remain canonical.
- Moved the glass floor to the reflection region and faded reflected artwork from the card baseline.
- Increased dedicated rail height to 316 points. Classic Rows remains unchanged.

Validation: Swift frontend parse only; Xcode build, focus/navigation, device playback and reflection appearance require Apple TV testing. The requested precise row-to-row spacing still depends on parent catalog geometry and is not asserted as device-verified.
