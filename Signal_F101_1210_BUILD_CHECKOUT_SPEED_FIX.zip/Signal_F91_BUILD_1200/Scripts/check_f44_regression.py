#!/usr/bin/env python3
"""F44 source ownership and geometry contracts; device rendering is validated in Xcode."""
from pathlib import Path
import hashlib,json,re
from check_f31_top_menu_regression import block
from f44_approved_deltas import previous_source
from f45_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    records=json.loads((ROOT/'Tests/F44ApprovedSourceDeltas.json').read_text())
    for name,record in records.items():
        text=historical_source(ROOT/name)
        assert hashlib.sha256(text.encode()).hexdigest()==record['after_sha256'],name
        previous_source(text,name)
    for name,sha in json.loads((ROOT/'Tests/F44UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==sha,name
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
    old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    vod=block(app,'struct VODPlayerScreen: View')
    dismiss=block(vod,'    private var upNextDismissButton:')
    assert 'Label("Dismiss", systemImage: "xmark")' in dismiss
    assert 'SignalUpNextButtonStyle' in dismiss and '.frame(width: 158, height: 48)' in dismiss
    assert '.opacity(' not in dismiss and '.hidden(' not in dismiss
    regular=block(vod,'    private var upNextEpisodeOverlay:')
    compact=block(vod,'    private var upNextCinematicOverlay:')
    assert 'upNextDismissButton' in regular and 'upNextDismissButton' in compact
    assert 'upNextDismissButton' in block(vod,'    private var upNextUnavailableOverlay:')
    assert '.bordered' not in regular and '.bordered' not in compact
    style=(ROOT/'Sources/SignalGuideChrome.swift').read_text()
    assert 'focused ? 0.25 : 0.14' in style and 'focused ? 1 : 0.40' in style
    assert 'static let panelFill = Color.black.opacity(0.78)' in style
    assert '.fill(SignalGuideChrome.panelFill)' in block(vod,'    private var livePlaybackBottomQuickGuideOverlay:')
    assert '@AppStorage("signalAutoNextEnabledV393") private var upNextAutomaticPlaybackEnabled: Bool = true' in vod
    assert 'UserDefaults.standard.set' not in block(vod,'    private func reconcileUpNextAfterEOF(')
    reconcile=block(vod,'    private func reconcileUpNextAfterEOF(')
    assert 'naturalEpisodeBookkeepingCompleted && !isPlaying' in reconcile
    assert 'SignalUpNextAutoplayPolicy.decision' in reconcile
    assert 'scheduleUpNextEOFSourceRetryIfNeeded()' in reconcile
    assert 'reconcileUpNextAfterEOF()' in block(vod,'    private func schedulePostEOFUpNextWork(')
    assert 'reconcileUpNextAfterEOF()' in block(vod,'    private func startUpNextCountdown(')
    sources=block(vod,'    private func prepareUpNextSourcesIfNeeded(')
    assert sources.count('reconcileUpNextAfterEOF()')>=2
    watchdog=block(vod,'    private func startUpNextWatchdogIfNeeded(')
    clock=watchdog.split('if total.isFinite, total > 30,',1)[1].split('let introNeedsPrecision',1)[0]
    assert '!upNextAutoNextCancelled' in clock and '!upNextDismissed' not in clock
    assert 'schedulePostEOFUpNextWork()' in clock
    assert '!isPlaying && duration.isFinite' in block(vod,'    private func cancelUpNextCountdown(')
    # Existing cancellation, Manual Play, remote dismissal, source selection, and player launch stay owned.
    for token in ('upNextDismissal.dismiss(episodeEnded: episodeEnded)','upNextPreparationTask?.cancel()',
                  'vodAsyncRuntime.upNextEOFSourceRetryTask?.cancel()'):
        assert token in block(vod,'    private func cancelUpNextCountdown(')
    for marker in ('    private func playPreparedUpNextEpisode(', '    private func nextEpisode(',
                   '    private func routeUpNextMove(', '    private func seekAbsolute('):
        assert block(vod,marker)==block(block(old,'struct VODPlayerScreen: View'),marker),marker
    live=block(app,'struct LiveTVScreen: View')
    for marker in ('    private func guideView(', '    private func rollbackGoogleGuideCategoryRail(',
                   '    private func rollbackGoogleGuideHero(', '    private func rollbackGoogleGuideTimeline(',
                   '    private func googleGuideTimelineRow('):
        scope=block(live,marker)
        assert '.background(Color.black)' not in scope,marker
    assert 'SignalGuideChrome.panelFill' in block(live,'    private func guideView(')
    row=block(live,'    private func googleGuideTimelineRow(')
    assert 'axis.slot(start: start, end: end)' in row and 'program.isAiring(at: now)' in row
    assert 'program.width *' not in row and '10 - programs.count' not in row
    assert 'slot.width - 6' in row
    assert 'guideTimeSlots' not in block(live,'    private func googleGuideTimelineHeader(')
    timeline=block(live,'    private func rollbackGoogleGuideTimeline(')
    assert 'if liveVisualWorkActive' in timeline and '.periodic(from: .now, by: 60)' in timeline
    preview=block(live,'    private func rollbackGoogleGuideBackdropPreview(')
    assert 'AsyncImage' not in preview and 'maxPixelSize: 768' in preview
    assert 'auxiliaryPlayback: true' in preview
    assert block(live,'    private func liveGridContent(')==block(block(old,'struct LiveTVScreen: View'),'    private func liveGridContent(')
    # Fixed button geometry fits every regular/cinematic panel, independent of focus.
    assert 330+158+14 <= 760-48
    assert 156+158+2*15+250 <= 700-32
    # Dates use one exact axis with clipped cells, not min/max duration distortion.
    axis=(ROOT/'Sources/SignalGuideTimeline.swift').read_text()
    station=float(re.search(r'stationWidth: Double = ([\d.]+)',axis)[1])
    gap=float(re.search(r'stationGap: Double = ([\d.]+)',axis)[1])
    horizon=float(re.search(r'horizonMinutes: Double = ([\d.]+)',axis)[1])
    cases=0
    for width in [1280,1536,1920,3840]:
        schedule=width-station-gap;ppm=schedule/horizon
        for start,end in [(-30,15),(0,30),(15,30),(30,60),(60,120),(105,180),(0,1)]:
            left=max(0,start*ppm);right=min(schedule,end*ppm)
            assert 0<=left<right<=schedule
            assert abs(station+gap+schedule-width)<1e-9
            if start>=0 and end<=horizon:assert abs((right-left)-(end-start)*ppm)<1e-9
            cases+=1
    for path in ['Sources/SignalUpNextAutoplayPolicy.swift','Sources/SignalGuideChrome.swift','Sources/SignalGuideTimeline.swift']:
        assert path in (ROOT/'project.yml').read_text()
    print(f'F44 PASS: always-painted fixed actions; EOF retry owner/first-ready handoff; unchanged preference/manual launch; shared transparent black; real-date EPG axis ({cases} arithmetic cases); unchanged grid/performance scope')
if __name__=='__main__':verify()
