#!/usr/bin/env python3
"""Current F41 contracts; source evidence does not replace Xcode/device tests."""
from f42_approved_deltas import historical_source as f41_source
from pathlib import Path
import ast,hashlib,json
from check_f31_top_menu_regression import block
from f41_approved_deltas import previous_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    for name,record in json.loads(f41_source((ROOT/'Tests/F41ApprovedSourceDeltas.json'))).items():
        source=f41_source((ROOT/name))
        assert hashlib.sha256(source.encode()).hexdigest()==record['after_sha256'],name
        previous_source(source,name)
    for name,sha in json.loads(f41_source((ROOT/'Tests/F41UnchangedSourceHashes.json'))).items():
        assert hashlib.sha256(f41_source((ROOT/name)).encode()).hexdigest()==sha,name
    app=f41_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    before=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    for marker in ('struct VODPlayerScreen: View','struct LiveTVScreen: View'):
        assert block(app,marker)==block(before,marker),marker
    effect=f41_source((ROOT/'Sources/SignalLiveTVCardEffect.swift'))
    oldeffect=previous_source(effect,'Sources/SignalLiveTVCardEffect.swift')
    bases=ast.literal_eval(effect.split('static let baseNames = ',1)[1].split('\n    static let alignedSuffix',1)[0])
    legacy=ast.literal_eval(oldeffect.split('static let names = ',1)[1].split('\n    private static let migrations',1)[0])
    assert len(bases)==28 and len(set(bases))==28
    assert bases[:23]==legacy
    assert bases[23:]==['Dual Outward Strong','Dual Outward Max','Split Outward','Split Outward Strong','Split Outward Max']
    assert 'static let names = baseNames + baseNames.map { $0 + alignedSuffix }' in effect
    assert block(effect,'enum SignalLiveTVCardTheme')==block(oldeffect,'enum SignalLiveTVCardTheme')
    pose=block(effect,'    private static func basePose(')
    pose=pose.replace('    private static func basePose(','    static func pose(',1).replace('switch raw {','switch normalized(raw) {',1)
    pose=pose.replace('case "Dual Outward", "Split Outward":','case "Dual Outward":')
    for line in ['        case "Dual Outward Strong", "Split Outward Strong": return .init(yaw: -side * (focused ? 18 : 12))\n','        case "Dual Outward Max", "Split Outward Max": return .init(yaw: -side * (focused ? 24 : 16))\n']:
        assert line in pose;pose=pose.replace(line,'')
    assert pose==block(oldeffect,'    static func pose('),'Existing 23 pose formulas changed'
    aligned_pose=block(effect,'    static func pose(')
    assert 'focused: true' in aligned_pose and 'fixed.x = 0; fixed.y = 0' in aligned_pose
    assert 'baseName(raw).hasPrefix("Split ")' in effect
    host=block(app,'private struct LiveTVGridFocusMotionHost<Content: View>')
    for token in ('guard !aligned else { return 1 }','focused: aligned ? false : isFocused',
                  'x: aligned ? 0 :','y: aligned ? 0 :','enabled: aligned && !containsLivePreview).ignoredByLayout()'):
        assert token in host,token
    assert 'return containsLivePreview ? SignalLiveTVCardPose() : p' in host
    geometry=f41_source((ROOT/'Sources/SignalLiveTVCardAlignment.swift'))
    visual=f41_source((ROOT/'Sources/SignalLiveTVCardAlignmentVisuals.swift'))
    for prohibited in ('TimelineView','@State','Task {','Timer','rowIndex','screenOrigin'):
        assert prohibited not in geometry and prohibited not in visual,prohibited
    assert 'width / (maxX - minX)' in geometry and 'height / (maxY - minY)' in geometry
    assert 'ProjectionTransform(transform)' in visual
    assert 'transform.m14 = CGFloat(m.p)' in visual and 'transform.m44 = CGFloat(m.r)' in visual
    nav=block(app,'struct TopMenuBar: View')
    assert 'SignalMirrorSearchLayout.centerY(headingTop:' in nav
    header=block(app,'private struct SignalLiveTVMirrorHeader<')
    assert 'SignalMirrorSearchLayout.headingTopPadding' in header
    assert 'showCornerClock ? proxy.frame(in: .global) : .zero' in header
    assert 'minimumCenterY: Double = 48' in geometry
    assert 'headingGap: Double = 12' in geometry
    assert 'headingTopPadding: Double = 38' in geometry
    customization=block(app,'private struct SignalLiveTVThemeConfirmationScreen:')
    assert 'Layout: Aligned' in customization and 'Layout: Original' in customization
    assert 'togglingAlignment(effectCandidate)' in customization
    assert 'SignalLiveTVDashboardConfirmation(shape: candidate, effect: effectCandidate' in customization
    assert 'SignalLiveTVCardEffect.normalized(effectCandidate)' in customization
    assert '"signalLiveTVCardEffectV344": SignalLiveTVCardEffect.resolved' in app
    assert 'SignalLiveTVCardEffect.normalized(settings["signalLiveTVCardEffectV344"]' in app
    project=f41_source((ROOT/'project.yml'))
    for name in ('SignalLiveTVCardAlignment.swift','SignalLiveTVCardAlignmentVisuals.swift'):
        assert 'Sources/'+name in project
    preflight=f41_source((ROOT/'Scripts/check_f28_source_preflight.sh'))
    assert 'Sources/SignalLiveTVCardAlignmentVisuals.swift' in preflight
    assert 'Tests/SignalF41GridAlignmentTests.swift' in preflight
    print('F41 current checks passed: 23 original formulas + 5 outward choices; 28 aligned counterparts; fitted cell-local projection; fixed focus geometry; paired Layout selector; safe lowered Search/header spacing')
    print('F41 unchanged scope: entire LiveTVScreen and VODPlayerScreen, Up Next dismissal, source discovery, Aether bridge/host and playback policies')
if __name__=='__main__':verify()
