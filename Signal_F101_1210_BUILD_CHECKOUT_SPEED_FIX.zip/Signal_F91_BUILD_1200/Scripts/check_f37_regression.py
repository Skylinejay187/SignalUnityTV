#!/usr/bin/env python3
"""Current F37 wiring plus exact historical invariance; hardware validation pending."""
from f39_approved_deltas import historical_source
from pathlib import Path
from f38_approved_deltas import previous_source as previous_f38
from check_f31_top_menu_regression import block
from check_f36_regression import verify as verify_f36
from f37_approved_deltas import previous_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    verify_f36()
    app=previous_f38(historical_source((ROOT/'Sources/DebridChannelsTVOSApp.swift')),'Sources/DebridChannelsTVOSApp.swift')
    old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    schedule=block(app,'    private func scheduleLiveTVGridFocusPreview(')
    cancel=block(app,'    private func cancelLiveTVGridFocusPreview(')
    leaf=block(app,'private struct LiveTVGridFocusPreviewSurface: View')
    tile=block(app,'    private func liveTile(channel:')
    route=block(app,'    private func routeLiveSpecialMove(')
    assert schedule.index('SignalPreviewStartupPolicy.dwellNanoseconds') < schedule.index('gridFocusPreviewChannelID = channelID') < schedule.index('revealWaitNanoseconds(') < schedule.index('gridFocusPreviewRevealChannelID = channelID')
    assert 'focusedAt: focusedAt, now: ProcessInfo.processInfo.systemUptime' in schedule
    assert 'generation == gridInteractionRuntime.previewGeneration' in schedule and 'tileFocus == channelID' in schedule
    assert 'gridFocusPreviewRevealChannelID = nil' in cancel and 'previewArmTask?.cancel()' in cancel
    assert 'mayReveal(frameReady: ready, holdElapsed: revealAllowed)' in leaf
    assert 'playbackMuted: !visible' in leaf and '.opacity(visible ? 1 : 0)' in leaf
    assert '.onChange(of: visible)' in leaf and 'if shown { onReady?() }' in leaf
    assert 'containsLivePreview: gridFocusPreviewReadyChannelID == channel.id' in tile
    assert 'gridFocusPreviewRevealChannelID == channel.id' in tile
    assert 'gridFocusPreviewReadyChannelID != channel.id' in tile
    assert 'armLiveTVGridPreviewStop(channelID: channel.id' in tile
    stop=block(app,'    private func armLiveTVGridPreviewStop(')
    assert 'previewStopTask?.cancel()' in stop and 'generation == gridInteractionRuntime.previewGeneration' in stop
    assert 'cancelLiveTVGridFocusPreview()' in stop
    # Do not touch the proven row/paging destination math or any top-menu focus behavior.
    assert block(app,'    private func advanceLiveTVGridPage(')==block(old,'    private func advanceLiveTVGridPage(')
    for marker in ('        if direction == .right, isLiveTVTileLastBoxInRow', '        if direction == .left, isLiveTVTileFirstBoxInRow'):
        edge=block(route,marker)
        paging=edge.split('// Preview Mirror has no left Quick Guide rail;')[0]
        assert 'advanceLiveTVGridPage(forward:' in paging
        assert 'acceptSingleDpadStep' not in paging and 'deliberateGap' not in paging
    assert 'edgeCommandGate.accept(' in route
    nav=block(app,'struct TopMenuBar: View')
    assert nav.count('SignalSearchSpotlightTarget(active: searchFocused')==2
    assert '.focused($focusedTab, equals: tab)' in nav and 'routeMenuMove' not in nav
    assert '.overlayPreferenceValue(SignalSearchSpotlightAnchorKey.self)' in app
    assert 'searchFocusSpotlightEnabled && unityTopNavigationOwnsFocus' in app
    for phrase in ('Search Focus Spotlight:', '"signalSearchFocusSpotlightV1": searchFocusSpotlightEnabled', 'settings["signalSearchFocusSpotlightV1"] as? Bool', 'searchFocusSpotlightEnabled = true'):
        assert phrase in app
    light=historical_source((ROOT/'Sources/SignalSearchSpotlight.swift'))
    for phrase in ('proxy[anchor]', 'FillStyle(eoFill: true)', '.allowsHitTesting(false)', '.accessibilityHidden(true)', 'scenePhase == .active'):
        assert phrase in light
    assert 'TimelineView' not in light and '.focusable' not in light and 'Task {' not in light
    assert 'signalSearchFocusSpotlightV1' in historical_source((ROOT/'Sources/ReleaseCandidateSecurityManager.swift'))
    assert 'Sources/SignalSearchSpotlight.swift' in historical_source((ROOT/'project.yml'))
    host=historical_source((ROOT/'Sources/PlaybackKit/PlaybackKitAetherSurface.swift'))
    bridge=historical_source((ROOT/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift'))
    assert 'var playbackMuted: Bool = false' in host
    assert host.index('forKey: "configuredMuted"') < host.index('Self.performNoArgumentSelector("aetherLoadConfiguredMedia"')
    assert 'if playbackMuted != coordinator.lastPlaybackMuted' in host and 'aetherApplyMute' in host
    assert '@objc public dynamic var configuredMuted: Bool = false' in bridge
    assert bridge.index('engine.volume = configuredMuted ? 0 : 1') < bridge.index('engine.bind(view: playerView)')
    assert '@objc public func aetherApplyMute() { engine?.volume = configuredMuted ? 0 : 1 }' in bridge
    assert bridge == historical_source((ROOT/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift'))
    # The reviewed bridge delta contains only mute: startup/recovery is byte-preserved.
    old_bridge=previous_source(bridge,'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift')
    for marker in ('    private func startLiveAttempt(', '    private func liveOptions(', '    private func scheduleLiveRecovery('):
        if marker in old_bridge: assert block(bridge,marker)==block(old_bridge,marker)
    print('F37 checks passed: quiet preparation; >=2.5-second first-frame-gated reveal; retained fast startup; one outward page command; noninteractive Search spotlight with saved toggle')
if __name__=='__main__':verify()
