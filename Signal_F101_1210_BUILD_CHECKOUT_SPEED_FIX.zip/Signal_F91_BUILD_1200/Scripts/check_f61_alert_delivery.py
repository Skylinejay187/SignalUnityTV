#!/usr/bin/env python3
"""Notification cancellation, rendered-surface acknowledgement and narrow-scope guards."""
from pathlib import Path
import hashlib
import json
from check_f31_top_menu_regression import block
from f61_approved_deltas import previous_source
from f62_approved_deltas import historical_source

ROOT = Path(__file__).resolve().parents[1]


def audit(root):
    timer = block(root, '    private func schedulePassiveEpisodeAlertDismiss(')
    for token in ('episodeAlertRenderedReceipt', 'episodeAlertVisibleSurfaceID',
                  'waitForDisplayDuration', '!Task.isCancelled', 'mayDismiss(lease',
                  'currentLease: rootAsyncRuntime.episodeAlertDismissLease'):
        assert token in timer, token
    assert 'try? await Task.sleep' not in timer
    assert timer.index('mayDismiss(lease') < timer.index('dismissRealEpisodeAlert')
    confirm = block(root, '    private func confirmEpisodeAlertPresentation(')
    assert 'surfaceID == episodeAlertSurfaceID' in confirm
    assert confirm.index('guard episodeAlertVisibleSurfaceID == surfaceID') < confirm.index('markEpisodeAlertPresented')
    assert confirm.index('episodeAlertRenderedReceipt = receipt') < confirm.index('schedulePassiveEpisodeAlertDismiss')
    prepare = block(root, '    private func prepareAlertPresentation(')
    assert 'invalidatePassiveEpisodeAlertDismiss()' in prepare
    assert 'schedulePassiveEpisodeAlertDismiss' not in prepare
    assert 'receipt.surfaceID == episodeAlertVisibleSurfaceID' in prepare
    invalidate = block(root, '    private func invalidatePassiveEpisodeAlertDismiss(')
    assert invalidate.index('episodeAlertDismissLease = nil') < invalidate.index('?.cancel()')
    assert 'stopNewEpisodeHeartbeat(reason: "scene inactive")\n                invalidatePassiveEpisodeAlertDismiss()' in root
    assert 'episodeAlertOwner' in root and 'surfaceID: episodeAlertOwner' in root
    assert '.mainAndVOD && !episodeAlertPlaybackCoverVisible ? activeNewEpisodeAlert : nil' in root
    assert '.id("main-episode-alert-\\(alert.id)")' in root


def verify():
    for name, record in json.loads((ROOT / 'Tests/F61ApprovedSourceDeltas.json').read_text()).items():
        current = historical_source(ROOT / name)
        assert hashlib.sha256(current.encode()).hexdigest() == record['after_sha256']
        previous_source(current, name)
    for name, digest in json.loads((ROOT / 'Tests/F61UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT / name).encode()).hexdigest() == digest, name
    app = historical_source(ROOT / 'Sources/DebridChannelsTVOSApp.swift')
    old = previous_source(app, 'Sources/DebridChannelsTVOSApp.swift')
    root = block(app, 'struct RootView: View')
    prior = block(old, 'struct RootView: View')
    audit(root)
    try:
        audit(prior)
    except AssertionError:
        pass
    else:
        raise AssertionError('F60 cancelled-timer implementation must be rejected')
    old_timer = block(prior, '    private func schedulePassiveEpisodeAlertDismiss(')
    assert 'try? await Task.sleep' in old_timer and '!Task.isCancelled' not in old_timer
    for name in ('runRealEpisodeAlertScan', 'activateNewEpisodeAlertScheduler', 'restartNewEpisodeHeartbeat',
                 'presentNextQueuedNewEpisodeAlertIfPossible', 'persistEpisodeAlertDeliveryState'):
        assert block(root, '    private func ' + name + '(') == block(prior, '    private func ' + name + '('), name
    for marker in ('struct GlobalSearchScreen: View', 'struct SettingsScreen: View', 'struct LiveTVScreen: View',
                   'struct MediaInfoPopup: View', 'struct ManualEpisodesRow: View'):
        assert block(app, marker) == block(old, marker), marker
    # Freeze the entire VOD implementation except this notification's paint order.
    before = block(old, 'struct VODPlayerScreen: View')
    after = block(app, 'struct VODPlayerScreen: View')
    assert before.count('.zIndex(120)') == 1
    assert after == before.replace('.zIndex(120)', '.zIndex(400)', 1)
    policy = (ROOT / 'Sources/SignalEpisodeAlertDeliveryPolicy.swift').read_text()
    assert 'catch { return false }' in policy and 'return !Task.isCancelled' in policy
    assert 'lease == currentLease' in policy and 'lease.receipt.surfaceID == visibleSurfaceID' in policy
    assert 'Sources/SignalEpisodeAlertDeliveryPolicy.swift' in (ROOT / 'project.yml').read_text()
    print('F61 PASS: actual F60 cancellation bug rejected; display starts after surface receipt; cancelled/stale timers cannot dismiss successor; startup cover waits; foreground/scope recovery; only passive VOD paint order changed. Scanner, metadata, playback continuity, Search and phone setup preserved. Native/device tests pending.')


if __name__ == '__main__':
    verify()
