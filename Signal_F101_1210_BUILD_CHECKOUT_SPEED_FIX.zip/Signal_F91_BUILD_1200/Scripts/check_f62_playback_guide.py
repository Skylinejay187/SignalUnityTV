#!/usr/bin/env python3
"""Exact scope and current integration contracts; rejects all three predecessor bugs."""
from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from f62_approved_deltas import previous_source
from f63_approved_deltas import historical_source
from f69_approved_deltas import historical_source as source_before_f69
ROOT=Path(__file__).resolve().parents[1]

def bridge_audit(s):
    worker=block(s,'    private func reconcileSessionAdjustments(')
    for token in ('configuredAllowSessionRebuild', 'sessionAdjustmentTask == nil', 'loadTask == nil',
                  'self.generation == owner', 'self.adjustmentID == requestID', '!self.endedPublished',
                  'needsForegroundReload', 'engine.reloadAtCurrentPosition()',
                  'engine.reloadAtCurrentPosition(applying:', '.preferredDecodePath = .software',
                  'engine.setDecodedAudioGainDB(latest)', 'self.transportWantsPlay',
                  'self.startLiveAttempt(', 'engine.bind(view: self.playerView)'):
        assert token in worker,token
    assert 'Task.sleep' not in worker and 'Timer' not in worker
    stop=block(s,'    private func stopSession(')
    assert 'sessionAdjustmentTask?.cancel()' in stop and 'adjustmentID = UUID()' in stop
    recover=block(s,'    @objc public func aetherRecoverAfterBackground(')
    assert 'guard backgrounded, !endedPublished' in recover
    assert 'foregroundRecoveryPending = true' in recover

def guide_audit(s):
    refresh=block(s,'    func refreshFromConfiguredSources(')
    assert 'if !userInitiatedForce || providerRefreshIsForced' in refresh
    assert 'await current.value' in refresh and 'current.cancel()' in refresh
    assert refresh.index('await task.value') < refresh.index('isGuideRefreshing = false')
    body=block(s,'    private func performConfiguredSourceRefresh(')
    assert 'await self.loadDeferredXtreamShortGuide(' in body
    assert 'guideHealthy && receivedFreshGuide' in body
    assert 'previous listings retained' in body
    health=block(s,'    private func hasCurrentOrUpcomingGuideCoverage(')
    assert 'realTiming: program.hasRealTiming' in health
    assert 'lineup ?? channels' in health
    assert 'currentGuideRow' in health
    for name in ('suspendForVODPlayback','suspendForSurfaceExit','prepareForFullScreenPlayback'):
        assert 'providerRefreshTask?.cancel()' in block(s,'    func '+name+'(')

def verify():
    records=json.loads((ROOT/'Tests/F62ApprovedSourceDeltas.json').read_text())
    for name,record in records.items():
        s=historical_source(ROOT/name)
        assert hashlib.sha256(s.encode()).hexdigest()==record['after_sha256'],name
        previous_source(s,name)
    for name,digest in json.loads((ROOT/'Tests/F62UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==digest,name
    bridge=source_before_f69(ROOT/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift')
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
    bridge_audit(bridge);guide_audit(app)
    for audit,s,path in [(bridge_audit,bridge,'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift'),
                         (guide_audit,app,'Sources/DebridChannelsTVOSApp.swift')]:
        try:audit(previous_source(s,path))
        except (AssertionError,ValueError):pass
        else:raise AssertionError('F61 failed implementation accepted: '+path)
    assert bridge==source_before_f69(ROOT/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift')
    assert (ROOT/'Sources/SignalPlaybackRefreshPolicy.swift').read_bytes()==(ROOT/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/SignalPlaybackRefreshPolicy.swift').read_bytes()
    host=(ROOT/'Sources/PlaybackKit/PlaybackKitAetherSurface.swift').read_text()
    assert 'allowSessionRebuild && !auxiliaryPlayback' in host
    assert 'aetherRecoverAfterBackground' in host and 'aetherPrepareForBackground' in host
    assert 'aetherAllowSessionRebuild: !protectedRouteRecheckInProgress && !protectedRouteStopped && scenePhase == .active' in app
    old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    for marker in ('    private func reconcileProtectedPlaybackRoute(', '    private func stopProtectedPlaybackRoute(',
                   '    private var activePlaybackURL:', '    private func handleNaturalEpisodeEnd(',
                   '    private func playPreparedUpNextEpisode(', 'struct GlobalSearchScreen: View',
                   'struct MediaInfoPopup: View', 'struct RootView: View'):
        assert block(app,marker)==block(old,marker),marker
    assert 'Sources/SignalPlaybackRefreshPolicy.swift' in (ROOT/'project.yml').read_text()
    print('F62 source contracts PASS: owned background rebuild, decoded gain correction, transport intent, route-proof gate, coalesced manual EPG, awaited fallback, real timing health; F61 negative controls rejected; protected routing, Up Next, Search and notification root unchanged. Native/device checks still required.')

if __name__=='__main__':verify()
