from regression_manifest_cache import read_manifest
"""Reverse exact compile-repair hunks for historical invariance checks."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    from f38_approved_deltas import previous_source as previous_f38
    source=previous_f38(source,path)
    records=read_manifest(ROOT/'Tests/F37R1ApprovedSourceDeltas.json')
    if path not in records:return source
    record=records[path]
    assert hashlib.sha256(source.encode()).hexdigest()==record['after_sha256'],'Unreviewed F37R1 source change: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256']
    return source
