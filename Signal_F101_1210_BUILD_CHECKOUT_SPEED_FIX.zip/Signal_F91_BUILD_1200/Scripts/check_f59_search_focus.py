#!/usr/bin/env python3
"""Current Search focus ownership and native-platter regression checks.

These source checks cannot substitute for Siri Remote testing on Apple TV.
"""
from pathlib import Path
import hashlib
import json
import re
from check_f31_top_menu_regression import block
from f59_approved_deltas import previous_source
from f60_approved_deltas import historical_source

ROOT = Path(__file__).resolve().parents[1]


def audit(search):
    assert re.findall(r'@FocusState private var (\w+)', search) == ['searchFocus']
    for target in ('.query)', '.close)', '.scope(scope))', '.result(item.id))'):
        assert '.focused($searchFocus, equals: ' + target in search, target
    assert 'focusedSearchHeader' not in search
    request = block(search, '    private func requestSearchResultFocus(')
    # Retain the source until mounting; never clear one binding before setting another.
    assert 'searchFocus =' not in request
    mounted = block(search, '    private func focusMountedSearchResult(')
    assert 'searchFocus = .result(id)' in mounted and 'searchFocus = nil' not in mounted
    assert '!queryFieldFocused' not in mounted  # entry still owns the query until transfer
    for token in ('Task.isCancelled', 'resultFocusRequest == request', 'resultFocusTargetID == id',
                  'searchSurfaceActive', 'scenePhase == .active', 'store.selectedDetail == nil'):
        assert token in mounted, token
    scroll = block(search, '    private func restoreSearchGridFocus(')
    assert 'transaction.disablesAnimations = true' in scroll and 'proxy.scrollTo' in scroll
    assert 'withAnimation' not in scroll and '!queryFieldFocused' not in scroll
    entry = block(search, '    private func focusResults(')
    assert 'fallback: restoreSelection ? selectedResultIndex : 0' in entry
    assert entry.index('resultsFocusRequested = true') < entry.index('guard let index')
    assert 'focusResults(restoreSelection: true)' in search
    publish = block(search, '    private func restoreSearchResultFocus(')
    assert 'if resultsFocusRequested {' in publish
    assert '(!queryFieldFocused' not in publish
    grid = block(search, '    private func searchResultsGrid(')
    assert '.buttonStyle(SportsNoPlatterButtonStyle())' in grid
    assert '.buttonStyle(.plain)' not in grid and '.focusable(' not in grid
    assert search.count('.focusSection()') == 1  # results, not the filters above them
    assert 'if case .result(_)? = searchFocus { searchFocus = nil }' in search


def verify():
    for name, record in json.loads((ROOT / 'Tests/F59ApprovedSourceDeltas.json').read_text()).items():
        current = historical_source(ROOT / name)
        assert hashlib.sha256(current.encode()).hexdigest() == record['after_sha256']
        previous_source(current, name)
    for name, digest in json.loads((ROOT / 'Tests/F59UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT / name).encode()).hexdigest() == digest, name
    app = historical_source(ROOT / 'Sources/DebridChannelsTVOSApp.swift')
    old = previous_source(app, 'Sources/DebridChannelsTVOSApp.swift')
    search = block(app, 'struct GlobalSearchScreen: View')
    prior = block(old, 'struct GlobalSearchScreen: View')
    audit(search)
    try:
        audit(prior)
    except AssertionError:
        pass
    else:
        raise AssertionError('F58 competing focus bindings/platter must fail')
    # The real existing custom style draws only the supplied label; no system platter.
    style = block(app, 'struct SportsNoPlatterButtonStyle:')
    assert 'configuration.label' in style
    for token in ('background', 'RoundedRectangle', 'Color.white', 'Button(', '.buttonStyle'):
        assert token not in style
    for marker in ('struct SearchResultCard: View', 'struct FocusedSidewaysCardEffect:',
                   'struct VODPlayerScreen: View', 'struct LiveTVScreen: View', 'struct MediaInfoPopup: View'):
        assert block(app, marker) == block(old, marker), marker
    for marker in ('    private func openSearchResult(', '    private func scheduleSearchProductionPrefetch(',
                   '    private func prewarmSearchProductionDetails('):
        assert block(search, marker) == block(prior, marker)
    # Only empty-query focus cleanup changes in the retained async search pipeline.
    expected = block(prior, '    private func scheduleUnifiedSearch(').replace(
        'focusedID = nil', 'if case .result(_)? = searchFocus { searchFocus = nil }')
    assert block(search, '    private func scheduleUnifiedSearch(') == expected
    from check_f55_native_search import ui_fixture
    fixture = ui_fixture()
    for token in ('private var searchHeaderFixture:', '.focused($searchFocus, equals: .query)',
                  '.buttonStyle(SportsNoPlatterButtonStyle())', 'searchFocus = .result(id)'):
        assert token in fixture
    print('F59 PASS: single Search focus binding; atomic mounted destination handoff; no second scroll animation; first-row entry/selection restore; no native white result platter. F58 negative control rejected; cards, query work and full playback unchanged. Apple TV validation pending.')


if __name__ == '__main__':
    verify()
