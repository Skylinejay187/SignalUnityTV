"""Reconstruct exact pre-F87 source without masking current source changes."""
from pathlib import Path
import hashlib,re
from regression_manifest_cache import read_manifest
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    # Historical adapters for F45–F86 start with today's source. When F91 has
    # an independently pinned post-F87 edit, enter the reverse-delta chain
    # using the exact, separately SHA-verified F87 snapshot instead.
    # An unreviewed mutation remains rejected rather than silently normalized.
    snapshot=ROOT/'Tests/F91InheritedF87Baseline'/path
    if snapshot.is_file() and source == (ROOT/path).read_text():
        current_hashes=read_manifest(ROOT/'Tests/F91ApprovedPostF87Hashes.json')
        assert path in current_hashes, 'Unpinned post-F87 source: '+path
        assert hashlib.sha256(source.encode()).hexdigest()==current_hashes[path], 'Unreviewed F91 source: '+path
        record=read_manifest(ROOT/'Tests/F87ApprovedSourceDeltas.json').get(path)
        additions=read_manifest(ROOT/'Tests/F87NewSourceHashes.json')
        expected=record['after_sha256'] if record is not None else additions.get(path)
        if expected is None:
            expected=read_manifest(ROOT/'Tests/F87UnchangedSourceHashes.json').get(path)
        assert expected is not None, 'Untracked F87 snapshot: '+path
        assert hashlib.sha256(snapshot.read_bytes()).hexdigest()==expected, 'Altered F87 snapshot: '+path
        source=snapshot.read_text()
    added=read_manifest(ROOT/'Tests/F87NewSourceHashes.json')
    if path in added:
        data=(snapshot if snapshot.is_file() else ROOT/path).read_bytes() if source=='' else source.encode()
        assert hashlib.sha256(data).hexdigest()==added[path],'Unreviewed F87 addition: '+path
        return ''
    record=read_manifest(ROOT/'Tests/F87ApprovedSourceDeltas.json').get(path)
    if record is None:return source
    if source=='' and path in read_manifest(ROOT/'Tests/F85NewSourceHashes.json'):
        historical = snapshot if snapshot.is_file() else ROOT/path
        assert hashlib.sha256(historical.read_bytes()).hexdigest()==record['after_sha256'],path
        return ''
    digest=hashlib.sha256(source.encode()).hexdigest()
    accepted={record['before_sha256']}
    for p in ROOT.glob('Tests/F*ApprovedSourceDeltas.json'):
        m=re.match(r'F(\d+)',p.name)
        if not m or int(m[1])>=87:continue
        rec=read_manifest(p).get(path)
        if rec:accepted.update((rec['before_sha256'],rec['after_sha256']))
    # New F85 files may already have been omitted by a repeated older history pass.
    if digest in accepted:return source
    assert digest==record['after_sha256'],'Unreviewed F87 source: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1,path
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256'],path
    return source

def historical_source(path):
    name=path.relative_to(ROOT).as_posix()
    snapshot=ROOT/'Tests/F91InheritedF87Baseline'/name
    # Post-F87 edits are validated separately by check_f91_inherited_f87.py.
    # Reconstruct F86 history from the original, SHA-verified F87 source.
    return previous_source(snapshot.read_text() if snapshot.is_file() else path.read_text(),name)
