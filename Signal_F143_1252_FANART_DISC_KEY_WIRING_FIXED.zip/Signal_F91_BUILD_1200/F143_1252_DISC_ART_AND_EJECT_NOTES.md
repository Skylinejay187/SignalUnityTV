# F143/1252 — Authentic Disc Art and Optional Eject Motion

- VOD disc prefers Fanart.tv movie `moviedisc` art via already-configured Fanart.tv API key and the existing production metadata snapshot.
- TMDB ID is used for Fanart.tv movie lookup; failed/missing Fanart.tv requests do not block the existing TMDB data.
- When actual disc art is absent, Signal creates an original dark Signal Cinema label based on title, not a recycled movie poster image.
- Disc Peek and Disc Eject Animation are independent toggles; both default off. Eject animation slides from underneath the poster's left side whenever the playback overlay is shown again.
- Existing SOURCE metadata styling remains inline; no extra badge rail. Existing player, caching, and preview behavior not modified by this patch.
- Validation: Swift syntax parse + F143 reviewed manifest/source membership. Xcode/tvOS compile and device animation not performed in this environment.
