# F143 / 1252 – Disc art and format styling correction

- Authentic Fanart.tv movie disc artwork remains first choice when available.
- When authentic disc art is unavailable, use a **different poster from the same TMDB movie**, excluding the displayed poster by artwork filename. Prefer the second alternative where present, then a stable first alternative. Never substitute artwork from an unrelated title. If TMDB provides no distinct poster, render a Signal-branded graphic disc.
- This is a disc *label* fallback, cropped circular with spindle and grooves; separate disc eject animation setting remains intact.
- Existing SOURCE technical-fact slot now renders individual typography badges for supported format values reported by the selected source (e.g. 4K, HEVC, MKV). No duplicate metadata row. No format is shown unless detected from existing source text.
- Tests: swiftc frontend syntax parsing and F143 exact reviewed-source manifest, app membership and packaged Aether parity checks. Full Xcode tvOS compilation and on-device visuals still unverified.
