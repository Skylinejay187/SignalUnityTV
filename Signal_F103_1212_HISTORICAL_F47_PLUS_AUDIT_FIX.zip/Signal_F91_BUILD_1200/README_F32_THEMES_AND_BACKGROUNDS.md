# Signal F32 — Expanded navigation and independent Live TV backgrounds

Current package: **1.0.1138 / build 1138 / Signal-F32**. Full source, patched from
F31R1 build 1137. App, Top Shelf and project metadata agree. The compatibility
entry points for both F29 and F31 build checks remain supported.

## Top menu: 18 layouts

The ten approved F31 layouts remain available and keep their saved identities.
Eight new layouts have their own exact renderer, chrome and picker preview:

| Layout | Structure |
| --- | --- |
| Crystal Slabs | Beveled frosted tiles with a luminous top edge |
| Orbit Rail | Circular destination emblems on a fine connecting rail |
| Cinema Ticket | Notched tickets with a separate icon stub |
| Stacked Cards | Offset backing plates beneath floating destination cards |
| Signal Terminal | Monospaced station identifiers and bracketed selection |
| Gallery Tabs | Angled tabs attached to a shared ledge |
| Beacon Rail | Open text with small illuminated selection beacons |
| Halo Dock | Circular icon medallions above destination labels |

Accent selection, font, size, destinations, remote commands, Search, auto-hide,
and Settings selection behavior retain their existing owners. There is no
navigation subtree remount on theme changes. Old theme-name migration remains.
Crystal Slabs observes Reduce Transparency. No new menu animation timers.

## Backgrounds: 12 choices

Settings → Appearance → UNITY · Live TV Background.

- **Pure Black**: truly black; no decorative wallpaper or smoke.
- **Dynamic Channel Artwork**: the focused channel's current programme image,
  blurred across the canvas; channel icon/artwork is the fallback when programme
  artwork is unavailable. It follows focus without starting video or tuning.
- **Frosted Channel Artwork**: the same focus-driven art under a stronger blur
  and soft white veil, inspired by the supplied frosted-background references.
- **Smoked Glass**, **Polar Frost**, **Prismatic Glass**: diffused studio light,
  frosted horizons, or intersecting translucent planes.
- **Silk Dunes**, **Aurora Veil**: flowing sculpted folds and diffused curtains.
- **Contour Studio**, **Orbital Bloom**, **Midnight Facets**, **Cinema Halo**:
  topographic lines, atmospheric halos, angular glass planes, and projector light.

The old solid-color menu choices are removed. Pure Black keeps its saved value;
other historical choices migrate to the new family. Smoked Glass is the new
neutral default. Existing backups use the same preference key.

Card styling and dashboard backgrounds are independent: card-theme background
renderers no longer conceal the selected background. The card customization
confirmation uses this same background renderer. Guide intentionally retains a
static matching base palette for readability. Dynamic channel artwork is for
the visible dashboard, not an added global background over other app screens.

Selecting a background turns off optional legacy animated wallpaper and smoke
so the selected design is visible. Those controls remain available for static
abstract backgrounds. Pure Black and the two channel-artwork options always take
priority. No new raster asset downloads or large video wallpapers are required.

## Resource ownership

One focus-artwork loader, capped to a 640-pixel decode (this is a deliberately
blurred background, not a foreground poster). Focus updates coalesce for 180ms;
loader cache-miss work also yields during navigation. The existing artwork cache
and decoder are reused. No new stream resolution, metadata requests, or players.

The new artwork/abstract layer is removed when Guide, catalogs, Settings, Search,
media detail, playback, a quick panel, or an inactive scene owns the surface.
SwiftUI cancels obsolete focus tasks; the image loader is unmounted. Abstract
art is original resolution-independent static Canvas drawing with no continuous
TimelineView, timer, or animation player. Equal static abstract views skip
unrelated redraws. Broad dark gradients protect foreground text contrast.

## Validation and limits

Local checks passed:

- Six build-identity tests, including both workflow checker entry points and
  rejection of mismatched app/extension/project versions.
- F31 migration/rendering/navigation regression locks, updated for 18 layouts.
- F32 wiring locks: 118 Live TV functions byte-for-byte unchanged from F31R1;
  scoped background ownership, bounded loader and true-black branch present.
- Spotlight Related on Trakt added-logo removal and original poster geometry.
- Diagnostic redaction (seven cases) and remote thumbnail safety gates.
- Changed Swift files have no new third-party grammar diagnostics; existing
  monolithic-source parser limitations are unchanged.

The macOS CI workflow also includes executable Swift model tests for all menu
identities, 18 background migrations, preference round trips, and all 32
background ownership input combinations. Those Swift tests, full tvOS Xcode
compilation and physical Apple TV visual/performance checks have **not** run in
this Linux environment. Run the existing ZIP build workflow before installation.
This package contains source, not an IPA or a claim of a successful Xcode build.

Suggested device checks: cycle each new menu layout, keep Settings open while
selecting, move focus across Live TV with both dynamic backgrounds, switch to
Guide/catalogs/Settings and back, and confirm Pure Black and restored settings.
Check light and dark programme images and rapid paging for readable text.

## Design references

Original Signal implementations draw on the supplied screenshots and these
public design references; third-party product assets were not copied:

- Apple Materials: https://developer.apple.com/design/human-interface-guidelines/materials
- Apple Designing for tvOS: https://developer.apple.com/design/human-interface-guidelines/designing-for-tvos/
- Plex Modern Layout: https://www.plex.tv/blog/choose-your-own-adventure-introducing-modern-layout/

Bluetooth/HomeKit lighting integration is not included in this visual update.
