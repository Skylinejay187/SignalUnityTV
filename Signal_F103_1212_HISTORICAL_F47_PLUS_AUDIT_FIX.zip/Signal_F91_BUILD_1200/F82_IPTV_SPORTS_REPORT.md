# F82 IPTV extraction and Sports work

## Actual disabled paths found

- Xtream account saves and mode normalization forced Full TV, regardless of the old choices.
- The category organizer displayed suggestions and explicitly did not apply them.
- Sports-only Xtream discovery returned an empty array.
- Xtream VOD/movie/series lookup returned empty arrays.
- The active Sports foundation rows omitted imported sports-only channel cards.
- Sports classification inspected only the first 600 lineup entries. Some short substring/team-name matches could classify ordinary news/program text as Sports, and an EPG programme airing now was labelled LIVE without fixture proof.

## Implemented

SignalIPTVImport provides per-source routing and exact category/title allowlists, shared by normal Live TV, Sports and IPTV VOD. Modes are Full TV, Sports Only, Both, VOD Only, All and Disabled. Missing selection means all; an explicit empty selection means none. Selection membership uses sets. Provider-native category IDs and title/stream IDs are used before category display normalization. An explicit Sports Only category/channel choice is authoritative even with unusual provider names. Legacy saved Sports Only/Both modes are recognized.

SignalIPTVImportView is an actual editor, available from Live TV Sources and Sports settings. It loads category lists first. Large title lists are requested only when the user asks to load titles from the selected categories. It supports search within loaded titles and progressive display. Apply persists the selection and refreshes actual Live TV/catalog models. Provider errors retain the saved selection. Choices are registered in portable settings and the explicit legacy backup dictionary; credentials remain in the existing account/backup paths. Selection keys contain hashed source identities, without duplicating passwords.

Xtream API requests use URLQueryItem encoding, including literal plus signs in credentials. Stream path components are escaped. M3U/Xtream server mount paths remain intact; URL-list parsing preserves commas inside ordinary category query values. Existing plain-HTTP provider support uses the existing PlainHTTPClient. HTTPS uses URLSession. Provider metadata responses use a bounded memory cache (12 MB retained data), an atomic 64 MB disk cache, a 30-minute freshness window and up to 24-hour stale data on transient failures. Credentials are part of hashed request identity, so a credential change cannot reuse the previous request's cache key. Cancellation propagates to transport. These are metadata lists, not media/video caching.

Live TV checks source routing before requesting/publishing channels. Applying a selection removes stale IPTV-only presentation entries before refresh and preserves other tuner/DVR channel entries. A changed scope invalidates stale source-mode snapshots. Deliberately selecting no live categories/titles does not arm endless guide recovery. Multi-account incremental publication retains earlier accounts while adding the next one.

Sports-only/Both imports now produce real playable live cards in Sports rows. Exact main-lineup duplicates are omitted, and name exclusions are applied. Imported-provider fetching is explicitly enabled only for the active Sports surface; global ticker loads do not start it. Classification searches the whole retained lineup on a cancellable utility task and bounds mapped card graphs afterward. Publication retains its generation/surface ownership guards. IDs are stable. Short substring false positives were tightened, College Sports has precedence over NFL/NBA heuristics, and Tennis/Golf/Cricket/Rugby have sections. EPG-current cards say ON AIR; public fixture feeds retain their existing statuses. Comma-separated favorite-team input now appears in the active Favorites row.

Selected IPTV movies/series are added as paged provider catalog rows while ordinary catalog sources keep their existing priority/customization. Provider-owned IDs resolve immediately against the exact selected source, without waiting for unrelated addon/debrid waves or reviving cached links from a disabled selection. Xtream series info supplies the real season/episode list and episode URLs. Other catalog titles can match enabled IPTV copies by explicit IDs or conservative exact title/year identity; conflicting IDs and remakes are rejected. Existing Aether playback and source-session ownership remain the playback path. M3U VOD entries with recognizable movie/series paths are supported; M3U series rows are individual direct entries rather than an invented full season listing.

## Nuvio-ReSeq review

Reviewed the repository's default dev branch README and SportsGuideCache, SportsEventIdentity, SportsGuideEvents and BroadcastNames implementations. Useful patterns are per-playlist controls, bounded metadata discovery, guide-revision-aware caching, careful broadcaster identity, and distinguishing a current airing from a verified live fixture. Signal's changes are independently implemented Swift; ReSeq Kotlin/assets were not incorporated.

Primary references:
- https://github.com/abbaskip/Nuvio-ReSeq/blob/dev/README.md
- https://github.com/abbaskip/Nuvio-ReSeq/blob/dev/app/src/main/java/com/nuvio/tv/livetv/sports/SportsGuideCache.kt
- https://github.com/abbaskip/Nuvio-ReSeq/blob/dev/app/src/main/java/com/nuvio/tv/livetv/sports/SportsEventIdentity.kt
- https://github.com/abbaskip/Nuvio-ReSeq/blob/dev/app/src/main/java/com/nuvio/tv/livetv/sports/SportsGuideEvents.kt
- https://github.com/abbaskip/Nuvio-ReSeq/blob/dev/app/src/main/java/com/nuvio/tv/livetv/sports/BroadcastNames.kt

This build restores extraction and channel/catalog paths. It does not implement ReSeq's complete fixture-to-channel matching engine, competition taxonomy, Stalker portal support, cloud sports feed, replay/catch-up discovery or optional Gemini assistance. Those require separate protocol/UI work and verification.

## Verification and limits

Local checks passed: current F82 wiring/scope checks and three disabled-routing negative controls; current F78/F79 artwork/guide checks; build identity and 117-file app source membership; existing F31, F64, F68, F70, F71 and F73 contracts; twelve existing Python regression tests, including installed-parent engine lifecycle checks. Updated Swift grammar checks report no new errors; the large app retains the same two baseline parser errors at line 10545. Grammar checks are not compilation.

The native F82 test compiles the actual import provider, existing HTTP transport, classifier and Sports view model, executes fixture provider requests/cache restart/selection/episode tests, checks a sports channel at position 700, and type-checks the actual organizer against the tvOS SDK. It is wired into build preflight. It was NOT executed here because Swift/Xcode/Apple SDKs are unavailable. Full application compilation, real-subscription interoperability, CPU/memory profiling and device focus/playback remain unverified. No measured speedup is claimed.

Existing provider list safety ceilings remain relevant: list processing is capped at 30,000 entries, metadata responses are accepted up to 48 MB, and very large libraries should be narrowed by category. Free-score coverage and timing remain provider dependent. Existing Up Next eligibility rules, including declared-size checks, remain in force. IPTV data without a recognized identity is kept in its provider catalog rather than guessed into a different title.

Five pre-existing Swift files changed; 166 remain byte-identical to F81. New app files and native fixtures have exact hashes. Reviewed source deltas allow historical checks to reconstruct their original source while F82 checks the current paths. Aether/vendor code, poster-processing/download code, resources and workflow files are unchanged. F81 build-test isolation remains in place.
