# Signal F32R1 — build 1139 — manual cast browsing with presentations off

Full source based on F32 build 1138, including all 18 top-menu layouts, 12
background choices and the Spotlight Related on Trakt duplicate-logo fix.
App, Top Shelf and project are 1.0.1139 / 1139 / Signal-F32R1.

The prior Off setting disabled native focus on the main poster and skipped the
Cast zone when moving Up from the timeline. Off now disables automatic featured
cast presentation while preserving user-initiated browsing.

With Full Poster and Cast Banner off:

1. Reveal the VOD controls. The existing first navigation still lands on the
   timeline; cast cannot steal focus when the drawer first opens.
2. Press Up from the timeline to focus the main poster/cast area.
3. Press Left or Right to browse cast, wrapping at either end.
4. Press Select to open the existing Cast Explorer for the displayed actor.
5. Press Down to return to the timeline and restore the movie/show poster.

Off mode has no cast banner and no automatic cast rotation. Actor imagery only
mounts while its visible cast area owns focus; ordinary title-poster appearance
is preserved outside that interaction. The current metadata must contain an
actor portrait to enter the existing portrait-based browser. Empty/no-portrait
cast lists skip this zone. Actor labels and Select identity continue to follow
the displayed image, retaining the existing decoded-image publication behavior.

Full Poster and Cast Banner modes keep their existing automatic behavior. No
player engine, resume handling, seeking, stream discovery, Live TV commands,
menu/background selection, or Spotlight behavior was replaced.

Validation completed here:

- Six build-identity tests, including both historical workflow entry points.
- Existing menu/background/protected playback-source checks.
- 118 Live TV functions and 220 unrelated VOD functions unchanged.
- Cast production wiring: Off focus eligibility, timeline entry, Left/Right
  navigation, Select explorer, Down exit, and automatic-rotation exclusion.
- Diagnostic redaction and remote thumbnail safety gates.
- No new Swift grammar diagnostics relative to F32.
- Complete ZIP directory, project.yml, all file bytes and archive CRC verification.

Executable Swift tests cover all three presentation modes, hidden/loading/empty
states, Off portrait visibility, no Off auto-rotation and both wrap directions.
They are included in the macOS CI workflow, but have not run in this Linux
environment. Full Xcode compilation and physical Apple TV remote testing remain
pending. This is source, not an IPA or a successful-build claim.
