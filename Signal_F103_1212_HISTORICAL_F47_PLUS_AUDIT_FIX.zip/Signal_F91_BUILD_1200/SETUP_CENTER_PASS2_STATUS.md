# Signal Setup Center — Pass 2A Restore Safety
Base: Signal_F29_SETUP_CENTER_PASS1_SOURCE.zip.
Changes: explicit restore confirmation (Cancel is safe default); existing Clear Backup destructive confirmation retained; actual restore lifecycle text for download/validation, application, playback-history sync, completion/failure. No fake percentages, no new server calls, no Classic View removal.
Limitations: This is a narrow checkpoint, not the complete provider setup wizard or full transactional restore engine. Existing restore application is not atomic; review/rollback support remains for Phase 5. GitHub Actions build and device tests are outstanding.
Performance direction: compare native SwiftUI scrolling vs custom navigation, instrument surface retention and tasks, then A/B Classic View; no speculative removal.
Validation: swiftc -frontend -parse succeeded.
