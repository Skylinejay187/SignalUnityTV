# vBRDC398R17F6 — Spotlight Related on Trakt five-poster correction

Based on vBRDC398R17F5 source. Corrects the related-item selection cap from four to five in the Spotlight Hub, both when adding candidates and when deciding whether catalog fallback is necessary. Existing Trakt-first, same-type/genre-ranked real catalog fallback and duplicate/valid-artwork filtering remain intact. The horizontal strip can scroll if five posters exceed available width. No synthetic titles are created; fewer than five may display only if fewer than five distinct valid-poster candidates exist.

Validation: `swiftc -frontend -parse Sources/DebridChannelsTVOSApp.swift` passed on Linux. Not Xcode compiled or tvOS device tested.
