# F74 / build 1183

Removes only the SIGNAL label from the pause-card header in all themes. The compact size, movie/show title artwork, episode title, end time, timings, themes and playback controls remain unchanged. See F74_VALIDATION.json. Source checks passed; full Xcode/Apple TV validation not run here.
