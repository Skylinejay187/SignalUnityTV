# F81 / 1190 — build-test fixture isolation

## Failure shown by the supplied F80 logs

The engine installation completed successfully. XcodeGen's pre-generation script then ran the F80 lifecycle regression suite. Five EngineLifecycleTests failed during setUp because the tests copied Vendor/AetherEngine/Sources/AetherEngine/Placeholder.swift from the live project after the real installer had already removed it. The sixth ordering test passed, which masked this gap in the earlier local validation: it checked child checkers around a simulated install, but not the entire suite running from an already-installed parent project.

This was a test-fixture bug introduced in F80. The log stops before application compilation. The F80 source-integrity helper was not the cause of these errors.

## Fix

Tests/F80EnginePlaceholders.json preserves the exact two packaged placeholder texts as immutable test data. The test fixture builder validates their bytes against the existing F79 manifest before writing them into a temporary fixture. It no longer reads either placeholder from the mutable installed engine directory.

The project fixture copier excludes the production AetherEngine checkout, dependency build cache, Python cache and Git metadata, then seeds its own packaged fixture. Installed-parent runs therefore do not copy or alter the installed engine or depend on its removed placeholder.

Tests/test_f81_build_test_independence.py now stages an isolated parent project and runs the ENTIRE six-test F80 suite from that project, matching the CI condition that failed. It also executes the actual F78/F79 checkers against the installed parent and verifies that the suite did not change the installed parent's engine files. The meta-test runs only the F80 suite inside its child process, avoiding recursive invocation. Both suites are wired into the pre-generation script.

## Validation actually performed

- Replayed the original, unmodified F80 test suite from an installed-parent fixture: reproduced the exact five missing-placeholder errors from the uploaded logs.
- Corrected six-test F80 suite: PASS.
- New installed-parent regression: PASS, including all six child F80 tests and both current artwork/guide checkers.
- Existing five F75/F76 fixture and compile-input tests: PASS.
- Build identity, explicit app source membership/bridge parity, current F78/F79 checks and shell syntax: PASS.
- All 171 pre-existing Swift files are byte-identical to F80, with none added or deleted. The F80 source hash integrity helper, engine installer, engine integration checker, vendor content and resources remain unchanged.
- Source ZIP CRC and every archived entry's bytes checked during packaging.

F81_VALIDATION.json contains the original expected failure and the successful corrected outputs. Deliberate negative controls may print integration-rejection diagnostics; their unittest results are successful.

Only test fixtures, test support, the shell test invocation, build identity and release documentation changed. Build identity is Signal-F81 / 1.0.1190.

No Xcode/Apple SDK or Apple TV is available in this environment. Full native application compilation and device playback were not run. The installed engine used by local lifecycle tests is explicitly a small local fixture, not real engine compilation. Existing native/SDK preflight checks remain in the package for the macOS runner.
