# Stage 8 — Verification lifecycle hardening

Based on Stage 7 source. In `Sources/DebridChannelsTVOSApp.swift`:
- Starting a new real provider-health verification invalidates the previous result set, so old green provider results are not shown while new checks are underway.
- Finish and Configure Later are disabled while verification is running, preventing dismissal mid-flight through those actions. The view's existing cancellation path remains for other dismissals.

Validation: `swiftc -frontend -parse Sources/DebridChannelsTVOSApp.swift` passed; ZIP integrity checked. Full Xcode tvOS compilation, integration tests, first-run entitlement gating, actual EPG import progress, and restore rollback remain unverified/unimplemented. Do not treat this as final wizard build.
