# Signal tvOS vBRDC398R13 — Cover Flow black-glass floor
Base: vBRDC398R12 source. Source-only build; no tvOS device validation.
- Cover Flow quick panel moves down another 12 points (total +46 relative to original).
- Cover Flow dark floor behind reflection masks the Live TV guide tiles.
- Image-only reflections strengthened; no second player/preview.
- Side posters remain unrotated; center preserves 1.5-degree perspective.
- Classic Artwork 4 / Hero 2 portrait reflections strengthened and extended.
- Classic focused landscape remains without reflection.
- No changes to Up Next/Autoplay.
Validation: Swift parser only; Xcode Actions and Apple TV screenshot review required.
