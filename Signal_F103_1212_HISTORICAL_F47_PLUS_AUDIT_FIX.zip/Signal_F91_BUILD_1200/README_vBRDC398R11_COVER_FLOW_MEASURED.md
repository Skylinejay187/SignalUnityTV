# Signal tvOS — vBRDC398R11 (1.0.1112, build 1112)

## Source baseline and scope
- Based on full vBRDC398R10 source. Replaces **only** its 3D Cover Flow renderer/geometry, adds a slight Cover Flow-specific focus-tilt parameter to the original focused card, and corrects the 3D surface placement. Classic Rows retain their original finite navigation and card geometry; side-card reflections are modestly brightened, with **no** reflection beneath the Classic focused card.
- Source reference: user's annotated Dexter concept `41318.png`, 1546-pixel reference width. 1920-pixel target scale is `1920/1546`. The selected card's 360×217 reference geometry gives ~447×270 at 1920-wide output.
- Side poster heights and OUTER-edge offsets are individually measured per slot: left heights [185,181,169,157,137], offsets [98,201,288,370,416]; right heights [185,180,173,161,134,119], offsets [85,174,252,327,374,408]. Poster aspect 2:3. Side baseline = selected-card bottom −12px. No side-card 3D rotation. Nearest slots draw over distant slots, all tuck behind the focused card.
- Original `FixedSlotFocusedCatalogCard` remains instantiated **once** and retains artwork/logo, preview-player lifecycle, theme chrome and focus callbacks. Only the Cover Flow view requests 1.5° focus tilt. Other existing usages retain their original 10° presentation.
- Artwork-only short reflections 40 reference pixels, top opacity 30%, fade to black; no duplicated live video layers. Classic portrait-reflection mask brightened one step; classic focus reflection remains disabled.
- Preserves original selected-item handling, circular Cover Flow navigation, focus, long press, History/Resume actions, and Aether playback routines.
- Adds a visual-only title/hint row under the focused card. Does not add extra focusable buttons or QR code.

## Validation performed
- `swiftc -frontend -parse` on all Swift sources: pass.
- `validation_vBRDC398R11/test_coverflow_geometry.py`: pass (measured dimensions, layer and focus isolation, even/odd circular indexing, release metadata).
- Both Info.plists validated with Python plistlib; `project.yml` and both bundles at 1.0.1112 / 1112.
- ZIP integrity verified on generated archive.

## Validation **not** performed
- **No macOS Xcode/tvOS full compile or Apple TV runtime screenshot** was available in this environment. The visual geometry is source-calibrated and requires GitHub Actions compilation and Apple TV evaluation. No claim of pixel-perfect match.
- The separately requested Up Next/Autoplay handoff repair is **not** included; it remains a separate playback task to avoid conflating a geometry rebuild with the AetherEngine lifecycle fix.
