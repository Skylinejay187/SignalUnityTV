# Signal F71 / build 1180 — UNITY artwork and source links after VOD

Based on verified F70/build1179 source ZIP, SHA256 71243aa0bbfbceede0d067c7eac4aad9bf049990d761ab76952caeac2ebd17c2, current version35.

## Returning artwork and EPG

The existing post-VOD generation already requested an artwork bootstrap while Movies/Shows covered the retained Live TV root, but the bootstrap required selectedTab == .live and returned immediately. F71 grants that specific VOD-return path a bounded exception for UNITY catalog/sports branches. Dedicated Settings/Membership and inactive scenes remain ineligible. Existing visible-page/corridor limits, decode sizes and retained-image suspension are unchanged. The existing 10-second bootstrap settles back to zero covered image requests; no looping animation, preview player, permanent refresh timer or whole-lineup image prefetch is introduced.

A schedule that expired during a long VOD can also have no current program/artwork when the grid remounts. If the existing guide-health check reports incomplete data, F71 performs one silent guide repair after VOD ends, then re-arms the same bounded artwork corridor. Healthy metadata stays immediately available. Provider work remains suspended during VOD. Missing/unreachable upstream guide or artwork cannot be fabricated; normal channel fallbacks remain available.

## Returning source links

MediaInfoPopup is removed during VOD and recreated afterward. Its default onAppear reset previously closed the Source Intelligence panel, even though an onChange handler expected the old view to remain mounted. F71 captures one current movie/episode's value metadata at the verified playback commit boundary and restores the panel on remount or a retained-view return.

The snapshot holds at most 128 StreamLink records, the exact episode item, parent detail identity and selected source URL. It retains no image, view, decoder, player or provider task, and does no network work during playback. Prepared Up Next/episode-switch sources are passed through the same verified launch boundary, so another episode's links are not mistaken for the current episode's sources. Return readiness is granted only by the owning close after existing presentation/URL guards. Consumption restores the exact episode's panel, paging and source focus once, then releases the snapshot. New titles replace it; clearing detail/source state releases it.

The ordinary multi-title source cache retains its original four-minute TTL and 48-entry limit. This separate one-active-playback snapshot deliberately survives a long movie without scanning links in the background. Signed provider URLs may expire; the existing Refresh action and normal playback/protection checks remain in place. Retaining a row is not proof that its URL is still available.

## Validation and limits

See F71_VALIDATION.json. The new Swift test fixture extracts actual store capture/consume methods and covers the cap, selected-source retention, exact episode/detail ownership, active playback/resource gates, single consumption and new-title replacement. It runs in normal macOS build preparation before engine downloads.

Local checks include source contracts with negative controls, all prior source regression checks, build identity, Python/shell syntax, Swift grammar comparison to the base and generated fixture grammar. No local Swift compiler, Apple SDK, Xcode or Apple TV is available. Executable native tests, full compilation, actual provider/artwork IO, GPU/RAM measurements and visual/focus behavior have not run here. No measured no-lag guarantee is claimed.

## Device acceptance

Open links for a movie, play for long enough to cross an EPG program boundary, then Back. Verify the exact source panel reopens and the visible UNITY background cards recover without scrolling. Close the panel/detail and verify grid artwork stays visible. Repeat for a selected season/episode, automatic Up Next and an explicit prepared episode switch. Choose another retained link; use Refresh if an upstream signature expired. During playback verify no Live TV preview audio or ambient animations run. Test rapid exit/relaunch and switching to Settings/background during recovery; older work must not overwrite the current presentation. Check memory and scrolling on the target Apple TV, including a guide/provider outage.
