# Signal F34 — 1.0.1142 / build 1142

Foundation: the full F33 / 1141 source. This ZIP is a complete source tree, not a patch.

## Changes

- **Preview Mirror Search placement:** Appearance → Preview Mirror Search → Inside Top Menu or Beside Clock. Inside remains the default. The outside Search target sits immediately left of the persistent clock, remains visible when the menu hides, and is omitted from the menu. Both use the 🔍 glyph with a static accent halo and a small focus transition. Outside Search opens the existing global search; Down returns to content and Up/Left reveals navigation. Selection is saved, backed up/restored and reset with appearance defaults.
- **Catalog row motion:** removed the second selected-index animation on the Cover Flow subtree. One persistent phase now owns horizontal arrival. Rapid repeated presses use a 100 ms translation-only arrival; ordinary effects have bounded depth, opacity and timing. Setting changes invalidate queued phase completions and reset only rails that actually moved. No extra timers, image identities or catalog reloads were introduced. A duplicate UserDefaults write in the effect picker was removed. Reduce Motion disables rail animation.
- **Live TV card rendering:** the new photo also shows the stepped/rectangular spill in a static customization screen with no video. The shared renderer now composites only the bounded static artwork before 3D transforms, clips blur output after filtering, removes content-derived transformed shadows, and uses a transparent full-screen artwork blur. Customization controls have fitted custom capsule focus styling. These changes apply to the shared production card renderer and the customization confirmation; the photo alone does not prove the exact runtime cause.
- **15 card effects:** the seven previous choices remain. Eight additions are Dual Inward Max, Split Inward Max, Dual Outward, Gallery Fan, Cinema Arc, Floating Shelf, Isometric Deck and Cascade Stack. Max raises the inward angle to 20° on focus / 12° at rest. Split Max shares the existing center gutter. All effects preserve the 4 × 3 channel IDs and focus lattice; they do not create extra players or timers.

## Engine status — explicit

KSPlayer has **not** been reintroduced in this build. It is absent from the current dependency graph. Its current upstream package uses a separate prebuilt binary and FFmpeg dependencies; mixing this into the pinned Aether graph requires an isolated dependency/link and preview lifecycle validation pass on macOS. An uncompiled conditional import would not constitute a working integration. Aether remains the actual Live TV preview engine, with the existing teardown, auxiliary activity and full playback ownership intact. No full-screen or VOD engine routing changed.

The static customization artifact requires a rendering correction independently of any preview engine choice. Reconsider a preview-only KSPlayer branch if the artifact persists after the shared rendering retest, or if the user explicitly chooses the separate engine integration next.

## Preserved behavior

- F33's 24 top-menu layouts, accent tinting, readable selection ink and custom picker focus.
- Blue/glass blur and transparency controls; smoke underneath the shared glass/vignette; Pure Black exclusions and inactive surface budget.
- Off-mode manual cast navigation; Spotlight posters without duplicate themed logos.
- All existing destination activation / menu auto-hide / top-menu Down command regression locks.
- The original 118 Live TV function baseline is retained. Only the center-gutter condition in liveGridContent intentionally changes; its new helper expression is reversed before the original baseline hash comparison. New Search callbacks are separate functions. Existing tuning, paging and guide functions are unchanged.
- 220 unrelated VOD function locks and all protected Aether/PlaybackKit sources.

## Validation and limits

Local Python build identity tests, source regression locks, diagnostic redaction and remote thumbnail safety checks pass. Swift grammar checks show no new diagnostics relative to F33. Foundation-only card geometry, Search migration and repeat-cadence tests are included in the macOS workflow.

**Full Xcode/tvOS compilation, Swift executable tests and physical Apple TV visual/performance testing have not run in this Linux workspace.** This is source ready for the user's build workflow, not a certified compiled app.

## Apple TV retest

1. Build 1142 through the existing ZIP-aware workflow; report its first compiler error if any.
2. Try the Adult Swim lineup in Frosted Edges and Full Card Artwork; enable/disable focused preview and move rapidly across the bottom row. Repeat in customization without video, with smoke Off/On, and with the original / Strong / Max effects.
3. In Appearance, switch Search between both placements. Verify one target only, left of the clock outside, useful when the menu auto-hides; Select opens Search, Back returns, and Down returns to the current catalog or channel.
4. Test several catalog effects, holding Left/Right and switching effects repeatedly. Selection must not lag behind keypresses; no old effect may continue after switching. Check Classic and Cover Flow, Settings return, details return and Reduce Motion.
5. In customization, cycle all 15 effects with each size. Confirm no white native focus platter or clipped second-row/third-row artwork and that Apply persists / Cancel leaves the saved choice unchanged.
