# Signal F79 / build 1188

Authoritative base: verified F78 / build 1187, preserving the F78 Kingfisher optimization and all packaged features. This is an updated source package, not a compiled or device-verified binary.

Changes:
- Restore previously saved Live TV/Gracenote artwork from local source bytes when covered Unity tiles have lost their decoded RAM images.
- Keep the VOD Live TV Quick Guide open while browsing; exclude it from VOD chrome/shelf hide timers and the Live TV-only ten-second guide timeout.
- Start the VOD focused-channel preview request after 1.5 seconds. Keep existing FastZap and audio modes. Fullscreen Live TV Quick Guide dwell remains 3 seconds.
- Optional 60-second paused inactivity dimmer, default off, keeping the pause card bright. Setting: Episode behavior & metadata > Paused playback card. Included in portable Backup & Restore.

See F79_PLAYBACK_GUIDE_REPORT.md and F79_SOURCE_CHECK_RESULTS.json for exact scope and validation limits. Existing macOS/Xcode preflight and native checks remain wired into Scripts/prepare_build_deps_vBRDC280.sh, now also running the F79 source contract.
