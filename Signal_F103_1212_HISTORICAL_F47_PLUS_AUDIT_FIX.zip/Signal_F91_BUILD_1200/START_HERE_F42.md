# Signal F42 — build 1151

Based on F41 / 1150. Use this complete ZIP with the existing universal source-ZIP GitHub workflow. The included dedicated workflow also recognizes signal/f42-* branches.

## Changes

- VOD cache progress: refresh actual software packet-cache/native segment-cache coverage at 4 Hz, independently of playback-clock motion. The pinned Aether 7.44.0 producer hook works during play and pause without toggling transport. Common run-loop mode keeps this small metadata refresh active during remote tracking. No estimated cache progress is used.
- Full code backup: manual and automatic backups use the same complete portable-preference snapshot, including untouched defaults. All 197 AppStorage keys are classified; 192 portable default entries also cover manager-owned preferences. Included VOD settings cover cache policy, Auto Next, audio amplification, subtitle color, video fit, cast/production panels, Spotlight/catalog settings, overlays, dock and shelf. App-wide Live TV, Search, background, typography and feature preferences are included. Existing source/provider/favorites exports remain. Per-title audio/subtitle/delay/source memory is exported as a bounded typed blob. Both MediaFlow credential profiles pass vault sanitization. Round-trip verification includes these fields.
- Search beside clock: fixed trailing X and 55-point center Y replace the category-text anchor. Switching category names/counts cannot move it.
- Aligned cards: the production renderer uses the same perspective stack and physical surface as Original. Fitted width/height normalization is no longer applied. Aligned freezes the original resting column pose and suppresses focus scale/lift/translation; the selected-card ring remains. Original effects remain available.
- Eight additional physical frames: Cinema Soft Curve, Cinema Glass, Cinema Slate, Studio Frame, Gallery Frame, Panorama Curve, Obsidian Frame and Pearl Edge. Total: 22 shapes and 56 effects. Soft contours, restrained bevels and depth preserve the artwork aspect ratio.
- Full-screen customization uses the actual production LiveTVScreen, current dashboard mode, saved lineup/EPG, background, spacing, footer and card renderer. Draft changes apply only after Apply. Hide Controls or Play/Pause reveals the unobstructed dashboard; Play/Pause restores controls. Back restores hidden controls first, then cancels. A focus canvas retains remote ownership while controls are hidden. Choosing a theme starts no stream.

## Backup use

After installing, run Backup Now once with your existing code. Older payloads cannot contain settings omitted by older builds. Old codes/payloads remain compatible. Device membership/entitlement, device IDs, OAuth session tokens, migration markers, transient status, backup bookkeeping and decoder/cache data remain excluded from portable preferences.

## Validation

Local checks passed: current F42 source contracts; all AppStorage keys classified; historical F31–F41 exact reviewed-delta checks; 106 unchanged Swift source/test hashes; entire VODPlayerScreen/Up Next byte-identical to F41; preview timing, paging and playback scope locks; pinned 7.44.0 API contracts and cache-patch idempotence; existing audio-gain and Swift 6 patches applied alongside the new hook; packaged bridge/source equality; 6 build identity tests; 7 redaction cases; 22 FastZap checks; remote thumbnail gate; YAML and shell checks. Swift grammar inspection found no new errors across 12 changed/new files; the existing multiline-operator parser limitation matches F41 exactly.

Native Swift executable tests for actual JSON/UserDefaults backup round-trip and stationary-clock cache growth are included in macOS preflight. They were NOT run locally. Xcode/tvOS SDK compilation and physical Apple TV remote/rendering tests were NOT run here.

## Apple TV checks

1. Watch real VOD cache progress during playback and pause under each cache policy.
2. Save code backup, change VOD/app preferences, restore, and verify values including per-title audio/subtitle delay and both MediaFlow profiles.
3. Switch short/long categories in Preview Mirror: Search beside clock remains fixed.
4. Compare Original/Aligned at the same size: no fitted-axis stretching; resting column poses repeat across rows.
5. Try the eight new shapes in full-screen customization; hide/show controls; Cancel and Apply; check Golden and Preview Mirror.
6. Recheck season-final Up Next Dismiss/Back; its implementation is preserved.
