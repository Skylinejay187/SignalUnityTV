# Signal F37R1 — Build 1146

Version **1.0.1146**, patched directly from F37 / 1145. This is a focused source compile repair. The preview timing, edge paging and Search spotlight work from F37 are retained.

## Supplied build failure

The attached logs identify F37 / 1145. The full compiler log contains one fatal source diagnostic: `DebridChannelsTVOSApp.swift:53166:19`, within `liveCarouselCard`, could not be type-checked in reasonable time. The other nearby `onChange` messages are deprecation warnings.

Source inspection found an omitted required argument: F37 added `revealAllowed` to `LiveTVGridFocusPreviewSurface`, but the Carousel call still used the old initializer. The main Grid/List card call had already been updated. This mismatch was missed by the earlier source checks and is corrected here.

## Repair

- Carousel now supplies the 2.5-second reveal gate and a guarded first-visible-frame callback. Its visible preview duration restarts once after reveal, matching the main card path. Preview identity follows its URL.
- The large Carousel expression is split into separate card styling, presentation, focus and action expressions. Artwork/preview rendering and captions are checked in separate opaque-return helper functions, reducing the expression the compiler must solve at once.
- Existing caption content, visual modifier order, fixed dimensions, scale/tilt values and Select/Play/long-press/directional handlers are preserved. No `AnyView`, extra focus target or replacement decoder was added.
- A new check audits **every** `LiveTVGridFocusPreviewSurface` initializer for the reveal argument and callback, so this missed call cannot silently pass the same checks again.

## Preserved F37 behavior

One silent hidden preview prepares after the existing 650 ms focus settle. Picture, sound, preview turn, Pop Out and dimming wait until the same focus has lasted at least 2.5 seconds and a frame is ready. One outward press from a focused page-edge card changes page. Search Focus Spotlight remains an independent On/Off Appearance option.

The Aether bridge/host, preview timing policy, card shape/effect model, glass-light renderer and Search spotlight source are byte-identical to F37. All app source outside the Carousel extraction is byte-identical. Historical baseline fixtures remain intact, with the precise compile-repair delta reviewed separately.

## Verification

Local checks passed: build identity alignment; six build-identity unit tests; F31–F37R1 regression checks; all preview initializer coverage; exact Carousel caption/modifier/action preservation; protected F37 source hashes; 220 unrelated VOD function locks; seven redaction cases; remote-thumbnail safety; 22 FastZap wiring checks; no new Swift grammar diagnostics; workflow/source metadata; archive CRC and source-byte comparisons.

**A new Xcode build has not been run in this Linux workspace.** Syntax parsing and source checks do not prove successful Swift type checking or tvOS linking. The supplied logs establish that F37 failed; this package addresses that failure, but build 1146 compilation and Apple TV runtime behavior remain pending.

Use the existing source-ZIP build workflow with this complete archive. The included macOS validation workflow also runs `Scripts/check_f37r1_regression.py` before compiling.

After compilation, check Carousel focus/Select/long press and its delayed preview reveal, then verify the regular Grid's 2.5-second reveal, page edges and Search spotlight. Read `START_HERE_F37.md` for the complete F37 behavior and device checklist. Older notes and reports are retained as history.
