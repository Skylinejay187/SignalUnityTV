# vBRDC398R17F1 source candidate (not Xcode/device validated)
Base: vBRDC398R17 motion/logo source candidate.
Changes: 3D-only optional Shift Row Left for Media Information (default Off); animated 370-point offset while detail is active and restoration on close; 3D-only Hide Plain Card Title (default Off); corrected 3D popup's previously hardcoded 91% black backdrop to honor the existing Media Information Glass Transparency setting. Classic Rows left unchanged.
Existing R17 Card Push and themed logo preference are retained, but real-device verification of motion smoothness and themed artwork availability remains outstanding. Popup glass may still have independent artwork/tint layers. No Apple TV compilation or runtime validation has been performed.
Swift parser check: Sources/DebridChannelsTVOSApp.swift passed swiftc -frontend -parse.
