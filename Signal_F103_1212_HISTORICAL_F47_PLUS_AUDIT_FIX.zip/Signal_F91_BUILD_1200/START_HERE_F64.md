# Signal F64 — build 1173

Source update from F63/build1172. Use the existing ZIP build workflow on macOS. This is source, not a signed or installed Apple TV binary.

## Where to find the controls

Main Settings → Playback → **Episode behavior & metadata cache**. The same sheet is available from the VOD player's Settings menu. The sheet uses native tvOS Form, Picker and Toggle navigation with its own modal focus boundary.

- **Metadata caching:** shared metadata-response cache for focused catalog information, unified/addon Search results, media details and episode metadata. Reuses requests across visits and process-cache recreation; fresh results return immediately, stale results can return while a bounded refresh runs. Request keys hash URL, request headers, cookies and language so account contexts do not share entries. No credentials or raw URL are used as filenames. Four active metadata requests, at most 32 queued misses, 8 MB raw response memory, 192 memory entries, 32 MB disk and 256 disk entries. Disk I/O and JSON validation run on an actor rather than in SwiftUI bodies. Clear/disable releases the added cache and the focused-hero cache. Existing artwork and playback caches retain their own controls. New-episode discovery and season-list feeds retain their original live request paths, so metadata caching cannot delay show notifications or newly available episodes. This improves repeat metadata loading; it is not a claim that GPU/decoder or all scrolling bottlenecks are solved.
- **Skip providers:** individual SkipDB, IntroHater, IntroDB, TheIntroDB and AniSkip switches. Disabled providers are excluded from requests and cached results. Provider status is available in the settings sheet. Exact-file intro chapters retain precedence. TheIntroDB uses its current v4 endpoint; TMDb-only episode intro lookup remains supported. AniSkip remains an independent supplementary source. Playback does not wait for these services.
- **IntroDB key and contributions:** public reads work without a key. The optional user key is stored in Keychain, appears only in the protected backup credential vault, and is never populated into the input field for readback. A saved-status label and Remove action are provided. Optional automatic contributions submit validated exact-file intro chapter timings after playback is established (at least 15 playback seconds, outside loading/seeking/panels), using the user's key. Only title identity, season/episode and timings are sent. Provider data and uncertain audio recurrence guesses are not submitted. Successful submissions are deduplicated; attempts have backoff. Contributions are best effort and failures never interrupt playback.
- **Automatic intro / recap skipping:** independent toggles, off by default. Intro seeking waits until the actual verified start, not the manual prompt's early lead. Recaps require validated early-episode windows. Invalid, non-finite, out-of-duration and SkipDB out-of-range timings are rejected.
- **Credits:** Keep playing (default), Skip credits, or Jump to next episode when ready. Skip credits preserves **known** post-credit windows and does not seek away while inside one. Services may lack scene information; Keep playing retains everything. Jump to next respects Auto Next, continuous mode, explicit dismissal, source readiness and Still Watching.
- **Next presentation:** existing Up Next panel/countdown or a compact manual Next button. Both always paint Dismiss. Manual-button mode never auto-advances. Appearance choices: 10/30/60/120/180/240/300/600 seconds remaining, capped so an episode does not offer the next item during its first 30 seconds. Countdown choices: 3/5/10/15/20/30/60 seconds. Normal automatic countdown still belongs to settled natural EOF, preserving story playback; the explicit credits-jump option is the early-transition choice.
- **Continuous playback:** Off, current season only, or across seasons. The existing main Auto Next Episode toggle must also be enabled. Explicit manual Next remains available independently.
- **Still Watching:** configurable episode count and viewing-time limits, each independently disabled with zero. Defaults: 3 episodes or 120 minutes. Checks before the next automatic episode. Viewing time excludes pauses and large seeks. Continue acknowledges the limits; Stop or Back latches cancellation and restores player controls, including when the credits prompt appears before EOF.
- **Chapter navigation:** Previous/Next Chapter in player Settings when valid embedded container chapters are available. AetherEngine 7.44.0's actual `mediaChapters` publisher is now bridged through the dynamic host to the existing chapter model, for movies and episodes. No second player, AVURLAsset probe or media download is created. Files without published chapters show an explanatory label. Disc-specific title/chapter navigation is not added.
- **Backup/restore:** all 17 added portable values are registered, including unset defaults. The optional key is included in explicit/periodic protected credential-vault backup, with length validation and fresh-install purge. A deliberately removed key restores as removed. Cache files, session counters, API status and submission deduplication history are regenerable/device-session data and are not added to configuration backups.

## Defaults and preserved behavior

Provider lookups and metadata caching are enabled; automatic intro/recap skipping and timing submissions are off; credits keep playing. Up Next defaults remain 240-second appearance and 15-second EOF countdown. Continuous mode follows the existing Auto Next preference, with Still Watching limits above.

AetherEngine remains pinned to 7.44.0 and Kingfisher to 8.11.0. Existing protection decisions, at-home stream continuity, EOF settle/bookkeeping, Up Next source selection/minimum size, dismissal button, guide, Search focus/card rendering, live dashboard appearance and F63 pause information are preserved. New pause text stays hidden beneath episode settings and Still Watching sheets. Covering the player with these native sheets is explicitly distinguished from a real close/handoff, so it cannot run teardown/reload. Heavy VOD chrome is unmounted beneath the sheets; new show banners wait until the player is visible again. The only new engine observation is the read-only, generation-owned chapter publisher; it is removed with existing cancellables.

The focused metadata cache also received a generation guard: a retired request cannot erase a newer flight after cancellation/clear. Failed hero requests now use a short retry lifetime rather than a six-hour nil result.

## Research and service status

Primary references used:

- https://developer.apple.com/videos/play/wwdc2026/321/
- https://developer.apple.com/videos/play/wwdc2021/10252/
- https://developer.apple.com/documentation/Foundation/NSCache
- https://skipdb.tv/docs
- https://introdb.app/docs/api
- https://theintrodb.github.io/theintrodb-npm/functions.html
- https://github.com/introhaterapp/IntroHater/blob/main/src/routes/api.js
- https://github.com/introhaterapp/IntroHater/blob/main/src/services/skip-service.js
- https://github.com/superuser404notfound/AetherEngine/blob/7.44.0/Sources/AetherEngine/AetherEngine.swift
- https://github.com/superuser404notfound/AetherEngine/blob/7.44.0/Sources/AetherEngine/Disc/DiscMetadata.swift

Read-only live probes returned JSON/200 for IntroDB, SkipDB and TheIntroDB. The SkipDB probe included out-of-range data, which the new code correctly excludes. IntroHater returned HTTP 503 during research; its `/api/segments/:videoId` route and `{start,end,label}` shape were verified from current upstream source. Its fixture is explicitly a source-contract fixture, not a captured successful live response. No timing submission was performed during research.

## Validation limits

See F64_VALIDATION.json for checks actually run. Historical audits reverse only exact reviewed F64 deltas before checking prior release locks; the independent F64 audit checks the new wiring and current key coverage. Supplied native tests compile actual provider parsers, policies, cache and settings with local-only URLProtocol traffic: coalescing, concurrency, cancellation, disk reuse, account separation, skip boundaries, post-credit scenes, chapters, mode/count/time behavior and protected backup JSON. An SDK fixture also type-checks the actual new bridge subscription against the pinned public chapter shape.

**No Swift compiler, Apple SDK, Xcode build or Apple TV is available here. Native executable/SDK tests and full application/device validation have NOT run.** Grammar checks are not Swift compiler validation. Runtime smoothness and memory/CPU/GPU measurements require Apple TV testing.

## Apple TV verification

1. Build with the normal workflow; ensure the F64 native preflight runs before install.
2. Visit catalog/detail/Search, leave and return. Repeat after relaunch; confirm metadata reuse, correct account/language identity, Clear and disable. Record Instruments/HUD scrolling and memory before/after.
3. Toggle each provider independently. Test no timestamps, offline, 404/503, duration mismatch, a cold-open intro, manual skip, automatic skip and recap. No pause, restart, focus theft or provider error should block normal playback.
4. Test a file with embedded chapters in Aether: Previous/Next lands correctly, and Intro chapters can drive the existing manual/automatic prompt. A file without chapters explains its availability.
5. Test all credits modes, including a known post-credit scene. Verify early jump only when explicitly selected and next source is ready; missing sources keep the current episode playing.
6. Test manual Next, normal EOF countdown, every timing choice, pause/resume, last episode/season boundary and all continuous modes. Dismiss must remain painted, Back must work, and late callbacks must not rearm cancellation.
7. Lower Still Watching to 2 episodes; test Continue, Stop and Back. Verify manual Next does not trigger an automatic prompt and stopped autoplay does not resume later.
8. Enable contributions with a user IntroDB key only if desired; verify successful status and deduplication. Wrong/removed key and disabled submissions must not affect playback.
9. Back up changed values and key, restore on another device, and test a backup with the key deliberately removed. Verify existing protection, amplification, foreground return, guide load and the F63 pause fade still work.
