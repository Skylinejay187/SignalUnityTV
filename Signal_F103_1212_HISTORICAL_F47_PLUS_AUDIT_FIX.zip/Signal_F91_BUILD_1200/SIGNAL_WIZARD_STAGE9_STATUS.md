# Stage 9 — Provider validation and stale health protection

Based strictly on Stage 8 source.

- Validates the optional XMLTV guide URL before writing the M3U provider settings.
- Requires a `manifest.json` URL for custom Stremio addon input.
- Invalidates previously verified provider-health results after saving changed connection details, preventing stale green status from being presented as current.
- No first-run membership flow or restore transaction semantics changed.

Validation: Swift frontend parse passed. Full tvOS compilation and device testing remain pending. Real channel/EPG progress, transactional restore recovery, and membership-gated first-run presentation are still outstanding.
