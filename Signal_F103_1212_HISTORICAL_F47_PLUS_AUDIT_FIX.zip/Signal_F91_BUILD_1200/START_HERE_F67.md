# Signal F67 — build 1176

Build fix from the supplied F66/build1175 Xcode logs. The single blocking error was `cannot find SignalEpisodeClockGate in scope` in DebridChannelsTVOSApp.swift. The helper existed in Sources but was absent from project.yml's explicit app target source list. Added that source entry.

All production and test Swift files are byte-identical to the verified F66 source. Recap/credit hidden-control clock fixes, provider lookups, cache diagnostics, guide and existing playback behavior are retained.

The normal XcodeGen dependency preparation script and full source preflight now run check_app_source_membership.py before dependency downloads/compilation. It verifies all 114 app Swift files are in the target and checks the separate packaged bridge dependency/copy parity. Its negative control removes the exact clock-gate source entry and verifies that the check catches this failure.

Validation here: app membership and exact negative control passed; current F66 integration audit passed; all Swift bytes compared against the current original F66 ZIP; six build-identity tests passed; app/Top Shelf/project version 1.0.1176/build1176 aligned; changed shell/Python scripts passed syntax checks. Archive CRC and entry bytes verified. No Swift compiler, Xcode or Apple SDK is available here, so the corrected full Xcode build and Apple TV runtime remain unverified.

Use the existing source-ZIP workflow with this F67 ZIP. The supplied logs reached real Xcode app module emission; the listed warnings were not the cause of this failure. Native episode fixtures remain supplied in the full preflight, and the normal app build will compile the newly included clock helper.
