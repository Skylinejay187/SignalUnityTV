# Signal F43 — 1.0.1152 / build 1152

Patch forward from F42 / 1151. Use the existing universal source-ZIP workflow, or the included F43 workflow. This is a complete source package.

This build addresses concrete image transport, blur, decoder teardown and model-rebuild causes of Live TV scrolling and playback-return pressure. It adds Pure Black smoke support and an optional four-row grid. Read F43_RESOURCE_BUDGET.md for source findings, resource arithmetic and the distinction between configured budgets and measured device footprint.

## User-facing changes

- Wallpaper and frosted card-edge blur use small prepared bitmaps rather than live large blur passes. Old processing jobs are cancelled by identity; sharp foreground artwork remains.
- Smoke uses native reusable textures and compositor animation, with no per-frame SwiftUI Canvas redraw. It also works on Pure Black when the independent atmosphere setting is enabled. Covered/inactive surfaces remove the renderer and animations; Reduce Motion shows a static composition.
- Artwork transport has a dedicated bounded Kingfisher cache, asynchronous disk reads, serial background processing and protected request generations. Image and encoded-byte cache ceilings are smaller.
- Grid/Guide previews register immediate Aether release handlers. Host stop unbinds the render view and cancels thumbnail work. Stopped auxiliary coordinators cannot revive themselves before disposal.
- Unchanged channel/guide snapshots and browse indexes survive playback. Quick Guide preparation is bounded to 48 channels and still resolves other channel metadata directly on demand. Covered logos, focus clocks and guide recovery stay quiescent.
- In Live TV Card Customization, choose Rows: 4 for a centered 4 × 4 grid with matching 16:9 cells. Rows: 3 remains the default. The full-screen preview uses the same production row sizing. Cancel discards the draft; Apply persists it. The row setting is covered by code backups.
- Existing VOD cache progress, Up Next dismissal, 2.0-second grid-preview reveal, provider routing, full-screen FastZap choice, subtitles and display-match policies are preserved. The complete VODPlayerScreen block remains byte-identical to F42.

## Validation status

Passed locally: F43 ownership/source contracts, 96 numeric production-expression layout cases, 107 unchanged Swift source/test hashes, historical F31–F42 exact reviewed-delta checks, Swift grammar inspection with no new errors, 6 build-identity tests, 7 redaction tests, 22 FastZap checks, remote thumbnail gate, YAML/shell/Python checks and ZIP byte/CRC checks.

Real tvOS SDK typechecks for the native smoke/host/resource code and backdrop code, Foundation executable resource-policy tests, and a full Xcode build are wired into CI. They were NOT run in this environment. Physical Apple TV CPU/GPU profiling and repeated-cycle memory measurements were NOT available. This package does not claim measured elimination of every device spike.

## Apple TV acceptance checks

1. Scroll and change card/background themes repeatedly with Dynamic Channel Artwork, Frosted Channel Artwork, other backgrounds and Pure Black. Check responsiveness without entering playback.
2. Enter a Live TV channel and exit repeatedly. Compare the existing memory logs, new resource counters and optional FPS HUD after the first cycle and after 10 cycles.
3. Open catalogs, Search, Settings, Guide and full-screen playback: the covered dashboard must not continue smoke, focus glow, artwork transport or guide recovery. Return must preserve focus and warm cached pixels.
4. Select an atmosphere on Pure Black: smoke appears behind the cards, then stops on cover/exit. Atmosphere Off leaves a flat black canvas.
5. Compare Rows: 3 and Rows: 4 under all shapes/effects, including split/gutter layouts. Check final/partial pages, left/right paging and vertical focus. Cancel/Apply and code-backup restore must preserve the chosen behavior.
6. Recheck Live TV audio/timeshift, 2.0-second frame-ready preview, VOD cache progress and season-final Up Next Dismiss/Back.
