# F79 playback guide and idle presentation changes

## Root causes and implementation

The covered Unity grid intentionally disables network/provider artwork work. Its cache-only restore method previously consulted decoded NSCache entries and the bounded playback-return cache only. These can be evicted during long VOD sessions even while original Gracenote image bytes remain on disk. The restore method now falls back to PersistentArtworkSourceCache, decodes on a utility task under the existing two-decode gate, and publishes only for the current request generation. It cancels when ownership changes and clears completed task handles on success or failure. It does not start a network request or live preview. Existing decoded hits remain synchronous. This addresses lost pixels when local source bytes remain available; it cannot recover a source actually evicted from storage while network work is disabled.

The shared Quick Guide had a ten-second auto-dismiss timer. VOD overlay and shelf hide scheduling also lacked Quick Guide exclusions. The auto-dismiss now applies only to fullscreen Live TV; VOD browsing ends through explicit exit or channel selection. Both initial and delayed VOD hide guards exclude the guide, and opening it cancels pending hide tasks. Existing preview ownership, cancellation, protection and audio-restoration paths are retained.

The existing preview host already requests FastZap with fastLiveJoin true and skips display matching for auxiliary previews. Only the VOD focus dwell changes from three seconds to 1.5 seconds. This is request-start timing, not a guaranteed time to first video frame. Fullscreen Live TV Quick Guide dwell is unchanged.

The new optional pause dimmer uses one cancellable 60-second sleep keyed to playback/source eligibility, setting and routed remote activity. No polling or new repeating timer is introduced. Direction, select and play/pause input reset inactivity. Resume, modal/guide presentation, source change, backgrounding, disabling the setting and view removal cancel eligibility. A black 72%-opacity layer fades in behind the existing compact pause card, leaving that card bright and non-focusable. The switch defaults off and is registered for portable Backup & Restore. Existing pause-card show/hide delays, theme, title and size are preserved.

## Scope

Only four production Swift files changed: DebridChannelsTVOSApp.swift, SignalPausedPlaybackInfoOverlay.swift, SignalEpisodeExperienceSettings.swift and SignalPortableSettings.swift. F79ApprovedSourceDeltas.json records exact prior/current hashes and reversible reviewed hunks; F79UnchangedSourceHashes.json protects all other pre-existing Swift files. Vendor, engine, resources, Kingfisher artwork transport, catalog appearance and player transport implementations are unchanged. Build identity is F79 / 1.0.1188.

Test support changes add the current F79 contract to build preflight, supply the remote-activity input to the existing native pause-mapping fixture, and let historical checks reconstruct their original source versions. Historical AppStorage auditing now reads historical source consistently; F79 separately audits the complete current registry, including the new key.

## Validation actually run

- F79 current cache/timeout/dwell/dimmer/portable-setting contracts and unchanged-source hashes: PASS.
- Build identity and explicit 115-file app membership/bridge parity: PASS.
- F78 artwork contracts and four predecessor negative controls: PASS.
- F73 historical Quick Guide contracts and eight predecessor negative controls: PASS.
- Five existing F75/F76 fixture and compile-input regression tests: PASS.
- Swift tree-sitter grammar checks: no errors in changed overlay/settings/portable files or emitted pause mapping; the large application retains exactly the same two baseline parser errors at line 10545 (min/m), with no new errors. This is not Swift compilation.
- Full archive entry/CRC and byte validation: performed during packaging; digest recorded beside the ZIP.

No Swift compiler, Xcode, Apple SDK or connected Apple TV is available here. Native compilation, stream playback, GPU/CPU measurements and end-to-end device behavior have NOT been verified. The existing native transport/SDK/guide/preview/pause checks remain in the packaged macOS build preflight. No FPS, memory or latency improvement is claimed as measured.

## Device acceptance checks still required

1. Load Gracenote posters, watch VOD long enough for decoded-cache pressure, exit to Unity/Home/Movies/Shows; check saved source artwork restores and covered tiles generate no provider image requests. Missing/evicted files must remain graceful placeholders until normal loading resumes.
2. In VOD Quick Guide, focus a channel for 1.5 seconds, then leave its preview visible beyond 10 and 15 seconds. Check it remains open; change focus rapidly and close/reopen it. Test all three existing audio modes and one-audio ownership on dismissal/channel selection.
3. Enable the dimmer, pause eligible VOD and wait 60 seconds without input. Check the scene dims while the card stays bright. Any direction/select/play-pause activity should clear dimming; a fresh idle minute may dim again. Resume and confirm no dim layer remains. Test opening the guide/settings, switching sources and background/foreground during the wait.
4. Disable the switch, repeat pause, and confirm no dimming. Export/restore settings and verify the switch round-trips.
