# Signal F52 — build 1161

Forward from F51/build 1160. This release removes the hard horizontal background boundary between the Guide and its upper menu/header.

The full Guide translucent backdrop now extends 96 points into the header with a static 160-point fade. The decorative hero scrim fades over its first 64 points; its text is not masked. The existing preview mask now reaches complete transparency at its edges rather than stopping at 40%/72% opacity. The result is a blended background instead of a rectangular seam, in both expanded and collapsed category layouts.

Only those three Guide decoration blocks change in production Swift. Existing content frames, focus routing, timeline clipping, playback/preview ownership, cache updates, popup/alignment behavior and automatic home/away protection remain the F51 implementation. AetherEngine 7.44.0 and Kingfisher 8.11.0 remain pinned. No new blur, animation, decoder, timer or network work is added.

Local validation: exact production-source scope comparison, historical regression checks, Swift grammar comparison and build identity checks. Native Xcode compilation and Apple TV visual verification are unavailable in this environment and remain required. See F52_VALIDATION.json. F51's routing/native validation limitations still apply.
