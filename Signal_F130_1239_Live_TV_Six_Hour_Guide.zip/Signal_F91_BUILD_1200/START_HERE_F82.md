# Signal F82 / build 1191 — IPTV extraction and Sports repair

Base: F81 / build 1190. Existing playback, cache, artwork and dashboard work is retained.

Open Settings > Live TV Sources > IPTV Import Organizer (also available under Sports). Save an Xtream connection or M3U URL first. Choose the provider, then Full TV, Sports Only, Both, VOD Only, All or Disabled. Choose Live channels/Sports, Movies or TV Shows, select categories, optionally load their titles for individual selection, then Apply selection & refresh.

For a small subset, choose No categories and enable the required categories. For individual channels/titles, load titles from those categories, choose No titles and enable the ones you want. All removes a restriction; No imports nothing. Choices are per source and content type and are included in Backup & Restore.

Sports-only sources appear in Sports, while selected VOD appears in provider catalog rows. Both makes selected live channels available to Live TV and routes recognizable sports channels into Sports. Source extraction and playback-link lookup are connected to the saved choices.

F82_IPTV_SPORTS_REPORT.md covers implementation, ReSeq findings and limits. F82_VALIDATION.json records local source/regression results. Native provider/Sports/SDK checks are wired into the Apple build preflight but could not run here. This package has not been fully compiled or tested with a live subscription/device in this environment.
