# Signal tvOS vBRDC398R17F18 — targeted resume removal and 3D metadata alignment

Base: vBRDC398R17F17 (patched forward only). MediaFlow and Up Next F17 changes retained.

## Source changes
- CatalogStore: `removeFromContinueWatchingOnThisDevice` persists hidden identity and immediately publishes filtered Continue Watching rows before rebuilding playback-derived shelves; no cloud watched-history deletion or forced network refresh.
- Catalog long-press and context-menu Remove from Continue Watching actions both call this same method.
- 3D Cover Flow: focused card's themed logo/title and genre/action metadata block moves 21 scaled points closer to the card; Classic remains unchanged.
- App and Top Shelf version: 1.0.1123 / 1123, release ID vBRDC398R17F18.

## Verification and remaining work
- Swift syntax parsing passed for changed files; XML plist and archive integrity checked.
- No Xcode/tvOS build, Siri Remote test, scrolling profile, or device playback validation was possible here.
- Up Next F17 remains unconfirmed by user. MediaFlow confirmed working on F16/F17 lineage.
- This is an incremental test candidate, **not** a completed comprehensive performance stabilization. Next: instrument Instruments Time Profiler/Core Animation on Apple TV, reproduce scrolling stalls, inspect high-frequency state publishing, focus geometry invalidations, image decoding and ambient lifecycle; fix measured bottlenecks in separate validated patches.
- NuvioTVOS reference: https://github.com/bobsupra/NuvioTVOS; compare native SwiftUI focus, image and playback lifecycle, without wholesale importing GPL-licensed code.
