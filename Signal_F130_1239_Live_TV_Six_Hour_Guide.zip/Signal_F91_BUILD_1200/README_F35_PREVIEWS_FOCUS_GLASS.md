# Signal F35 — 1.0.1143 / build 1143

Full source, patched forward from F34 / 1142. AetherEngine stays pinned to 7.44.0; KSPlayer is not reintroduced.

## Preview startup

- Grid focus dwell is now 650 ms instead of three seconds. Existing cancellation, scene/surface guards and one-player ownership remain. Passing across a card does not prewarm neighbouring channels.
- Grid, Guide and preview-window hosts request fast join explicitly. The bridge now requests the actual upstream `.fastZap` segment profile AND `liveJoinStartsImmediately` on the first attempt. Previously the bridge forced Standard segmentation even when the immediate-start flag was enabled.
- Failed initial fast joins retry on Standard. Recovery/retune options reset both controls; no aggressive retry loop was added.
- Full-screen Live TV remains Standard by default, with its existing separate FastZap opt-in. VOD routing, timeshift/DVR depth, audio gain, source headers and decode/recovery ladder are preserved.
- Diagnostics separately record time to first picture and time to moving playback, using Aether's published playback phase. The new diagnostic contains route, elapsed milliseconds and attempt number, never the source URL.

## Navigation and Search

- The top menu is one physical focus anchor with an ordered logical cursor. Left/Right advances exactly one visible destination, clamped at boundaries. Search is the final logical destination when inside the menu. With outside Search, Right from the last menu destination enters the actual Search target; Left returns to the final menu destination.
- Search outside the menu is now owned by global chrome rather than the Live TV header disabled beneath catalogs. Global chrome remains reachable while catalog or Sports content is open, subject to existing membership, onboarding, overlay and playback guards. Outside Search Down restores the current catalog instead of forcing Live TV.
- Settings category navigation uses one fixed viewport anchor and one category cursor. Every horizontal command selects the adjacent category; Down enters its controls and Up requests the global menu. Category scrolling happens without a focus animation. Individual controls inside each Settings panel retain native tvOS focus.
- Menu slot widths no longer change with focused font weight. Category and common Settings controls no longer scale or cast a changing focus shadow. The theme picker no longer forces focus/scroll to a distant selected theme on appearance.
- Search uses the requested 🔍 glyph plus a slow rim glint at 12 FPS. Its drawing has fixed bounds. Hidden/inactive/Reduce Motion states use a still image; covered detail/playback/Search surfaces do not keep the glint running.

## Visual changes

- Neutral charcoal/glass remains the dominant top-menu material. The selected accent supplies low-opacity tint, fine edges and selection highlights rather than flooding the entire bar.
- Six rejected designs have genuinely new renderers: Luminous Glass, Cinema Pearl, Opal Glass, Slate Atelier, Satin Rail and Frosted Ribbon. Former Reborn saved names migrate to these; the overall collection remains 24 layouts.
- Card effects now have 19 choices. New/reworked physical treatments include Raised Glass, Deep Float, Beveled Cinema, Layered Slate, Curved Wall, Tilted Pedestal, Inset Lens, Gallery Lift and Prism Bevel. Previous Inward/Strong/Max and Split choices remain; five F34 experimental poses migrate to the new treatments.
- Raised cards use bounded vector ledges and bevel strokes, not a shadow or blur sampled from video contents. The same renderer is used in customization and real Live TV. Active native preview video stays flat while retaining its frame treatment.
- Smoke is drawn as coloured light OVER blue glass with one final readability veil. The extra post-smoke blur/dimming/tint stack is removed. The smoke texture is clipped to its viewport before rasterization. Blue, artwork blur and transparency remain independent; Pure Black remains pure black.
- Smoke still stops under catalogs, Guide, Settings, details, full playback and inactive scenes. The missing focused-GRID-preview exclusion is fixed too, so smoke cannot compete with either preview owner. Disable focused previews while inspecting continuous smoke blending.
- Removed optional GPU flattening from the catalog rail because that rail can contain a native decoder surface. Catalog arrival transforms are also excluded while its native preview is active. Live card focus now has a fixed outer slot around the transformed artwork.

## Verification and limitations

Passed locally: six build identity unit tests; source regression checks; all historical theme migrations; approved-delta comparison with the original navigation/playback fixtures; 220 unrelated VOD function checks; redaction (seven cases); remote-thumbnail safety; FastZap wiring (22 cases); and Swift grammar comparison with F34.

The original F31/F32 baseline fixtures were not reset. Exact reviewed source hunks are recorded in `Tests/F35ApprovedSourceDeltas.json`, and the legacy checks reverse only those hunks. F35-specific checks then validate the current implementation. Of 118 tracked Live TV functions, 113 are byte-identical to F34; one has a comment-only update and four have reviewed preview/viewport edits.

Foundation Swift tests cover ordered focus boundaries, Search reachability, card depth/pose limits and old-name migration. They are included in the macOS workflow but have NOT run in this Linux workspace.

**Full Xcode/tvOS compilation, physical remote testing, graphical correctness and startup/performance measurements are NOT verified here.** This source addresses concrete integration/rendering causes; it does not prove every random system-wide artifact is resolved.

## Apple TV retest

1. Confirm installed About version 1.0.1143 / build 1143. Run the existing ZIP-aware build workflow and inspect its first failing step if it fails.
2. Compare several HDHomeRun and IPTV grid/Guide previews: focus-to-picture, picture-to-motion, audio continuity, repeated channel changes, fast-to-Standard fallback. Cold streams and long-GOP sources may remain slower.
3. From Home/Movies/Shows catalogs, reach Search in BOTH placements. Test Right through every menu destination, Left back, Down to content, Select/Search/Back, Settings entry/exit, menu auto-hide and membership visibility.
4. Move one step and hold through Settings categories. Enter long Appearance lists, open/close theme pickers, and test native panel Up/Down. Other native Settings controls were not replaced by a global custom focus engine.
5. Disable focused video previews; select blue artwork/frost backgrounds and each smoke mode. Check blur/transparency independently. Enable previews and confirm smoke stops while video plays and returns afterward.
6. Test raised card options at each size in customization and in the real grid. Test Adult Swim with Frosted Edges, full artwork, inline/Pop Out preview, long scrolling sessions, catalog returns and background/foreground transitions.
7. If an artifact persists, record the exact surface/theme/card effect, preview/smoke/GPU settings, device model and installed build. A video/log can distinguish a remaining focus issue from a decoder/compositor defect.
