# Signal F69 / build 1178 — VOD amplification playback continuity

This is a focused source change based on the verified F68/build1177 source archive. It does not implement the separate Couch Streamer feature backlog.

Audio gain requests no longer enter the asynchronous session-rebuild worker. On an existing software/decoded-PCM audio route, changing amplification calls the running decoder's gain hook directly. Gain changes do not issue Play, Pause, Seek, reload, rebind the video layer, or change the preferred video decoder. Turning gain off retains the running route. Latest requests deferred during initial load/background are applied after load/recovery. Actual foreground recovery still rebuilds a missing session and preserves paused/playing intent.

## Material limitation

Pinned Aether 7.44's Signal gain extension only reaches SoftwarePlaybackHost's decoded PCM. Native passthrough streams cannot be boosted by this hook. F69 explicitly reports this route as unavailable and keeps video playing rather than reloading the entire session to force software video. This is a limitation, not a completed universal/native amplification implementation. No new unsupported audio-tap or second-player workaround was added. Native amplification needs a separately implemented and device-tested audio processing route.

## Validation

See F69_VALIDATION.json. Source audits and grammar checks run locally; no Swift compiler, Apple SDK, Xcode, or Apple TV is available here. The transport-counting Swift fixture extracts the actual production methods and covers gain toggles, finite clamps, paused state, native refusal, deferred latest gain, live exclusion, EOF, foreground recovery, and EPG refresh. Its executable now runs in normal macOS build preparation before engine downloads. Local fixture generation/grammar checking is not execution.

## Device acceptance

On decoded-PCM VOD, test Off → +6 → +9 → +12 → Off while playing and while paused. Verify volume changes, continuous picture, unchanged playhead, and preserved paused state. Repeat after an audio-track change and returning from another app. On native/Dolby Vision VOD, verify the explicit unavailable notice and no interruption. Run the full Xcode build before installation; this ZIP contains source, not a signed app or proof of device performance.
