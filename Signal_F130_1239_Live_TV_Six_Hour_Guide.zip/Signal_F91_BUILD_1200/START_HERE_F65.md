# Signal F65 — build 1174

Patch forward from the current F64/build1173 source ZIP. Source update; not a signed Apple TV binary.

## Fixes

- **Skip Recap:** adds a visible bottom-right prompt during a validated recap, routed through the existing remote Select handler to the mounted player's precise seek. Independent of the automatic-recap setting. Automatic skipping uses the same segment list and existing playback tick. Embedded chapters explicitly named Recap or Previously On take priority over community timings; unnamed chapters are never guessed. Paused/manual seeking, other panels, protected routes, retired sessions and duplicate seeks are guarded.
- **Provider retries:** failed or missing recap lookups can retry after 15 seconds and then 60 seconds, at most three attempts per presentation/runtime/provider key. Retries bypass the segment service's cached result. They do not restart playback. Null-start recap windows are accepted for supported seconds and milliseconds field formats. Existing provider switches and automatic-recap default remain unchanged.
- **Refresh Guide:** explicit loads bypass HTTP response caches and bound the native Xtream EPG batch publication wait to 0.8 seconds. Automatic background work retains its existing scrolling gate. Multiple full XMLTV documents are parsed separately rather than concatenated into invalid XML. The quick rail shows the actual provider/result status, including retained old listings on failure. Artwork refresh and completion feedback run immediately after the provider refresh, instead of waiting behind a retry loop. Existing independently owned incomplete-guide recovery remains available.
- **Metadata caching audit:** verified actual focused catalog, Search and detail request calls use the response cache. Cache implementation and limits are unchanged. This update does not claim a measured scrolling-performance improvement.

## Limits and verification

Skip Recap requires validated provider timings or an explicitly named embedded recap chapter. Services do not cover every episode/release. No timing means no guessed skip. Automatic recaps still require the existing Automatically skip verified recaps setting.

Current-source integration checks cover the actual F65 mounted Select/seek route, retries, guide request/publication and XML document boundaries. Historical regression checks reconstruct reviewed prior source only for their historical locks; a separate F65 audit checks the current code. Native preflight executes added tests against the actual parser, chapter adapter and skip policy, alongside existing cache coalescing/concurrency/disk and playback/guide orchestration tests.

No Swift compiler, Xcode, Apple SDK or Apple TV is available in this environment. Native executable tests, application compilation and device verification have NOT run here. Tree-sitter grammar checks are not compiler or device validation. See F65_VALIDATION.json for checks actually run.

Build using the existing source-ZIP workflow. Test a known recap with automatic skipping off (visible prompt + Select), on (single seek), a named recap chapter, offline provider retries, and a title with no timings (no guessed seek). Refresh Guide with one and multiple XMLTV sources, then with a temporarily unreachable source: successful listings should update; failures should retain previous listings and show the provider status. Verify Search/catalog cache reuse separately from frame-rate measurements.

Provider contract references checked for this repair:

- https://skipdb.tv/docs
- https://introdb.app/docs/api
- https://theintrodb.org/docs
