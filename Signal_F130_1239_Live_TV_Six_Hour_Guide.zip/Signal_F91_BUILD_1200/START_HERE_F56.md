# Signal F56 — build 1165

Forward from F55/build 1164. Addresses the reported debrid protection interruption during an already playing show at home.

## False-trigger paths corrected

The previous implementation treated every network-monitor callback as an immediate playback failure. It also repeated public-IP diagnostics during protected-source preparation, allowing a diagnostic timeout to revoke a working home route. The player's URL and headers were recalculated from that global routing state on subsequent view updates, so background work could also replace the current stream's route. These are confirmed code paths consistent with the report; the exact device event was not recorded here.

A live home proof is now reused for the current network generation and matching server/profile/password identity. Up Next and other source/API preparation do not keep polling the diagnostic endpoints while that proof remains valid. A restored backup or shared Off switch still cannot create a home proof. Actual network updates invalidate it.

Each VOD player captures its checked URL and request headers together for its exact source and playback session. That transport stays stable while unrelated background preparation runs. A failed diagnostic can close new direct routing without rewriting the already verified stream. A confirmed mismatch or a network-path update advances the generation and signals revalidation. Queued updates superseded by a newer generation are ignored; an already re-prepared player rejects an event from its own or an older generation.

Only an affected, older direct-home session reacts. It releases its old decoder/transport before awaiting verification, preserving the PlaybackSession, time and current Play/Pause intent. A successful home recheck reconnects automatically at the captured position, including with the master proxy switch Off. Away, a usable saved proxy is enforced automatically. An unavailable or unverified route remains blocked and displays its actual failure after verification. Already proxied playback and stale session events do not enter this home-only recovery. Backgrounded apps defer decoder recovery until foreground; pending checks are canceled on dismissal or a newer request.

A genuine path update may still cause a brief reconnect. It no longer immediately presents the generic protection interruption. Uncertain cold starts still require a verified home route or usable proxy; no arbitrary home/away override, private-subnet bypass or direct fallback is added. IPv4/IPv6 diagnostic rules and provider classification remain unchanged.

## Preserved scope

Three existing production Swift files change: network proof state, the router and the player route/lifecycle integration. The other 136 prior Swift files are byte-identical. F55 compact tilted Search, Guide edge fades, red season focus outlines, Up Next discovery/autoplay/dismissal, seek/cache behavior and engine/bridge code are retained. No new persistent setting, timer, decoder family or background polling loop is introduced. AetherEngine stays 7.44.0; Kingfisher stays 8.11.0.

## Validation

Executed locally: all available Python preflight checks, the new current ownership/safety guard, exact approved-delta reversal and unchanged-source comparisons, six build-identity unit tests, changed/new Swift grammar comparison, shell/Python syntax and ZIP/source integrity. See F56_VALIDATION.json.

The macOS preflight adds actual-router mock-network tests for repeated home source preparation with failed diagnostics/proxy, pinned URL/header stability, owner/epoch filtering, same-home path recheck, away proxy routing and unavailable/unknown blocking. It also type-checks the actual new player recheck and route-accessor methods against the tvOS SDK using small explicit store/engine fixtures. Tests use no real debrid account.

Not run here: those new native executables/SDK checks, full Xcode compilation or Apple TV playback/network testing. No Swift compiler or Apple SDK is available. Source checks do not establish runtime success or guarantee against provider restrictions.

On-device checks: play a show at home with Full/Light masters Off through Up Next preparation; pause/resume; trigger a network refresh and verify automatic position recovery; switch to a genuinely different network and confirm proxy-or-block behavior; test an unavailable proxy, failed cold-start diagnostics, app background/return and rapid source/episode changes. Confirm an already proxied session is not stopped by a home-proof event.
