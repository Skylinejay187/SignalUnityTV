# F104 — Configured AIOStreams bridge without duplicate TorBox key

- Permit Source Intelligence TorBox Usenet lane when either a TorBox key or configured AIOStreams Direct Manifest is available.
- Permit bridge discovery without a separate TorBox key; do not attempt native TorBox API requests with empty credentials.
- Restore only bridge-direct cached results in manifest-only mode.
- Native TorBox NZB retrieval still requires a TorBox API key.
- Swift parser validation only; Xcode build and device tests pending.
