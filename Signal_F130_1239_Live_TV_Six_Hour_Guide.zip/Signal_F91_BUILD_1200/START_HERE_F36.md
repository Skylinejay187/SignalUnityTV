# Signal F36 — Build 1144

Version **1.0.1144**. Built on the complete F35 / 1143 source snapshot.

This is a source delivery, not a compiled Apple TV app. The Linux workspace passed the source checks listed in `F36_VALIDATION.json`; Xcode compilation and physical Apple TV validation have not been performed. The included macOS workflow builds the app and runs the Swift model tests.

## Scrolling and the recording

The supplied 26-second recording shows abrupt grid brightness changes and a black focused preview card while loading. It does not reveal the physical remote input, so it cannot establish how many presses were delivered.

F35's virtual top-menu and Settings-category cursors have been removed. Both now use the earlier F34 native per-item tvOS focus logic, including native Left/Right movement. The fixed visual dimensions and global Search ownership fixes remain. Search has one target for the chosen placement, with no extra Left/Right cursor. Its Down handoff has the same short dispatch guard as the existing menu handoff.

Live TV interior movement remains native, and existing paging/edge math is retained. A 120 ms guard rejects a repeated delivery for the same card and direction at an edge. Different cards and directions remain eligible immediately. This guard is not proof that the recording's flash was caused by duplicate presses.

## Preview handoff

- The Aether bridge, playback host and accepted F35 startup policy are unchanged. The user confirmed that previews now start promptly. The existing 650 ms focus dwell, first-attempt FastZap and Standard recovery remain.
- The artwork stays visible beneath the player until Aether reports its first frame. The decoded video then fades in over 180 ms; there is no additional black loading layer.
- Optional dimming waits for that first frame. It now reduces other cards by 16%, rather than abruptly reducing them to 28% opacity, and uses a 280 ms transition.
- Pop Out also waits for readiness. Native preview cards remain flat and front-facing while loading and playing.
- Focused wallpaper uses two bounded image slots. It retains the current decoded image until the incoming image is ready, then crossfades over 300 ms. A rapid return to a retained cached image is handled too. Rapid focus changes coalesce artwork requests for 300 ms; video startup is independent.

These changes address observed code paths that can cause flashing; their visual result needs confirmation on Apple TV.

## Shape and Effect are separate

**Shape** controls the outline, raised frame and bevel. **Effect** controls orientation and movement. For example, Raised Glass can now be combined with Dual Inward Max.

There are **14 shapes** and **23 effects**. All 19 prior effect identifiers remain compatible. Previous finish-like effect labels are clarified as motion labels; the physical finish is selected under Shape. When migrating from F35 with Original UNITY as the shape, a finish previously embedded in the effect is transferred to Shape. An explicitly selected outline is preserved.

Curved Wall now has **Soft, Standard, Strong, Deep and Max** levels. Stronger levels increase the artwork-card curvature, while active native video stays straight. Shape and Effect remain independent in the production grid and customization preview. Backup export includes a surface-schema marker; older backups receive the same finish migration where appropriate.

## Glass Atmosphere replaces Classic Smoke

Classic Smoke and its rendering tree have been removed. Appearance now offers **Off, Soft Caustics, Liquid Light, Aurora Drift, Glass Refraction and Ocean Glow** under Glass Atmosphere.

The replacement uses broad reflected-light patterns over the selected glass background. It does not add another blur layer or change the Blur setting. It animates at a maximum of 20 updates per second on an eligible visible dashboard, freezes its current phase during previews, and is removed from covered dashboard surfaces. Reduce Motion uses a static phase. Pure Black stays black. Old smoke choices migrate to an appropriate light style; an already saved new choice is preserved.

## Search effects

Appearance offers **11 choices** shared by both Search placements: Off, Orbit Glint, Breathing Halo, Glass Sweep, Prism Arc, Comet Trail, Double Orbit, Soft Ripple, Starlight, Aurora Ring and Focus Only.

The effects stay within the fixed icon bounds and never move the focus target. Animated styles update at most 12 times per second, with visibility, scene and Reduce Motion guards. Focus Only animates only while focused. Search placement, effect and Glass Atmosphere are included in backup/restore.

## Validation and next build

Local checks passed: aligned app/project/Top Shelf version; six build-identity unit tests; F31–F36 source regression checks; protected playback source hashes; 220 unrelated VOD function locks; seven redaction cases; remote-thumbnail safety gate; 22 FastZap wiring checks; no new Swift grammar diagnostics relative to F35; workflow YAML/source entries; archive CRC and byte comparisons.

The Swift executable tests are included in macOS CI but **were not run locally**. The new model test covers 2,576 shape/effect/focus/column combinations, saved-choice migration, curvature levels, option cycles and duplicate-command filtering when run in CI. Grammar parsing is not Swift type checking or Xcode compilation.

Generate the Xcode project from `project.yml` and build using the existing project workflow. Its diagnostic evidence identifies F36 / 1144. The workflow retains redacted build logs and does not claim physical remote testing.

On Apple TV, verify these before calling the changes complete:

1. Press and hold Right/Left across the top menu; enter and leave Settings categories without a reversed move or skipped category.
2. Reach Search in both Inside Top Menu and Beside Clock modes from Live TV and catalog rows; use Down to return to the current content.
3. Browse Live TV rapidly in every direction and across page edges, especially Left. Pause for previews; confirm fast startup, retained artwork and gentle dimming. Try dimming Off as a comparison.
4. Pair Raised Glass with Dual Inward and other motion options. Check every Curved Wall level in the real grid and customization preview. Confirm video remains flat.
5. Test the five glass-light styles with existing glass/blur/transparency settings, Pure Black, Reduce Motion, Guide, Search, details, catalogs and full-screen playback. Check that covered surfaces do not keep animating.
6. Try Search effects while idle/focused, change placement, and restore old and new backups.

No KSPlayer or replacement playback engine was introduced. The existing Guide, 4×3 grid destinations, full-screen playback, VOD cast controls and unrelated VOD functions remain protected by the regression checks.
