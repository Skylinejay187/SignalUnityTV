# F104 — AIOStreams bridge connection test

- Adds a focusable connection-test control to the existing TorBox Pro Search Bridge settings.
- Validates HTTPS manifest format, HTTP success, JSON manifest ID and stream resources.
- Reports connection vs stream capability separately; does not claim playback readiness.
- Does not log or display token-bearing manifest URLs or networking error descriptions.
- Preserves native TorBox Cache & Play and bounded AIOStreams placeholder retries.

Validation: swiftc -frontend -parse of DebridChannelsTVOSApp.swift; no Xcode build or Apple TV device test.
