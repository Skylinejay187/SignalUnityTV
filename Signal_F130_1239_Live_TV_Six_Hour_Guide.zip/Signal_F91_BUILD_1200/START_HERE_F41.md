# Signal F41 — Build 1150

Version **1.0.1150**, patched forward from F40 / 1149.

## Lower Search, with space above the channel heading

The outside magnifier no longer follows a heading that left it almost against the screen edge. It now has a minimum center Y of 48 points, giving the 42-point icon at least 27 points of top clearance. The Preview Mirror header reserves 38 points above its channel heading in the Beside Clock placement. At the normal 50-point header origin this puts the icon center at 55, its top at 34, and its bottom 12 points above the heading.

The icon keeps its existing horizontal position near the ALL / CHANNELS boundary. The clock stays in its existing location. Inside Top Menu placement keeps its existing header layout. Only the real clock-bearing header publishes the positioning anchor; the Settings preview cannot replace it with a mock header's coordinates.

## Existing effects plus aligned counterparts

All **23 original effects** retain their names, order and pose formulas. All 14 physical shapes remain unchanged. Five new effects are added:

- Dual Outward Strong
- Dual Outward Max
- Split Outward
- Split Outward Strong
- Split Outward Max

Outward levels use 12°, 18° and 24° focused yaw, with the left/right sides mirrored. Split Outward adds the same consistent center gutter used by the inward split family. The default and existing saved selections remain unchanged.

Every one of the **28 base effects** also has a **· Aligned** counterpart: **56 effect choices total**. This applies with every existing physical Shape and Size choice.

Open Live TV Card Customization and select **Layout: Aligned** to switch the current effect to its paired version. Select **Layout: Original** to return to that same base effect. You can also cycle through the effects normally. Preview and Apply use the same production renderer; Apply saves the exact aligned identity through the existing effect preference, including backup/restore.

## What Aligned changes

A card's projection is calculated in its own cell coordinates and fitted back to that cell's exact bounds. It has no row index, screen-origin or global vanishing-point input. The middle and bottom rows therefore repeat the same corresponding-column geometry as the top row, with consistent gutters and mirrored halves for Dual/Split patterns.

Aligned versions use a stable visible pose for every card and do not enlarge, raise or shift a focused card. The focus ring still identifies the selection. Physical depth is held at its nonfocused value so focusing a shape cannot alter its outer footprint. The user-selected Compact/Standard/Large scale still applies uniformly. Original versions retain their established focus motion.

The native video preview retains its existing flat rendering path. In Aligned mode it stays in the same fixed slot without a focus pop-out. No second player, timeline, background task, image blur or geometry-driven state publication is added by the alignment renderer.

## Validation

Passed locally:

- Current F41 source contracts and exact unchanged-scope checks.
- Historical F31–F40 checks through exact reviewed source projections; original fixtures retained.
- 107 unchanged Swift source/test-file hashes. The entire LiveTVScreen and VODPlayerScreen remain byte-identical to F40. Grid paging/navigation, Aether integration, 2.0-second preview timing and always-dismissible Up Next are retained.
- A numeric audit of the production Swift coefficient expressions against an independent rotated-corner reference: **672 angle/column/focus/size cases**, finite positive projection, exact fitted cell bounds and repeated row gutters. This audit does not compile Swift or prove tvOS pixel rendering.
- Six build-identity tests, seven redaction cases, remote seek-thumbnail safety and 22 FastZap wiring checks.
- Workflow YAML, preflight shell syntax and Python check syntax.

**Not run locally:** Swift/Xcode compilation, executable Swift model tests and physical Apple TV validation. The macOS preflight now type-checks the new standalone alignment renderer with Search, runs F41's source/numeric checks and executes the Swift alignment model tests. Existing card-option tests have been updated for 56 effects and 6,272 shape/effect/focus/column combinations.

After a successful build, check Search in both placements and check each desired effect using Layout: Aligned. Move focus through all three rows, compare corresponding columns, test Compact/Standard/Large and both grid spacing modes, then start/stop a preview. Verify that Layout: Original restores the existing motion. Actual screenshot alignment and performance still require the Apple TV test.

Implementation uses Apple's documented GeometryEffect and projection APIs:

- https://developer.apple.com/documentation/swiftui/geometryeffect
- https://developer.apple.com/documentation/swiftui/view/projectioneffect(_:)
