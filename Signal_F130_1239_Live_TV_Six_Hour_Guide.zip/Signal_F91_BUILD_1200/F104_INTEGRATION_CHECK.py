#!/usr/bin/env python3
"""F104 source-level integration smoke checks; not an Xcode build."""
from pathlib import Path
import re, subprocess, sys
root = Path(__file__).resolve().parent
app = (root/'Sources/DebridChannelsTVOSApp.swift').read_text()
bridge = (root/'Sources/TorBoxUsenetClient.swift').read_text()
checks = {
 'bridge manifest configured and persisted': 'torBoxUsenetBridgeManifestURLV1' in app,
 'bridge manifest test implemented': 'testAIOStreamsBridgeManifest()' in app,
 'manifest test invalidated on edit': 'Manifest changed; test connection again' in app,
 'AIOStreams can search without native TorBox API key': 'if key.isEmpty {' in bridge and 'completedDiscoveryRoute' in bridge,
 'bridge stream URL query preserved': 'URLComponents(url: manifest, resolvingAgainstBaseURL: false)' in bridge and 'streamComponents.percentEncodedPath =' in bridge,
 'bridge never sends TorBox API key': 'searchViaConfiguredBridge(\n                    item: item,\n                    manifestURL: cleanBridge,\n                    session: session' in bridge,
 'preparation placeholders excluded': 'if isBridgePreparationPlaceholder(stream) { return nil }' in bridge,
 'readiness retry bounded': 'for readinessAttempt in 0..<3' in bridge,
 'native TorBox cache-and-play setting': 'torBoxUsenetCacheAndPlay' in app,
 'native TorBox timeout setting': 'torBoxUsenetWaitMinutes' in app,
 'Guide focus controller retained': 'SignalFullGuideFocusController' in app,
 'Guide source present': (root/'Sources/SignalGuideNavigation.swift').exists(),
 'XcodeGen project present': (root/'project.yml').exists(),
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()): sys.exit(1)
result = subprocess.run(['swiftc','-frontend','-parse',str(root/'Sources/DebridChannelsTVOSApp.swift'),str(root/'Sources/TorBoxUsenetClient.swift'),str(root/'Sources/SignalGuideNavigation.swift')],capture_output=True,text=True)
print('PASS: Swift frontend syntax parse' if result.returncode == 0 else 'FAIL: Swift frontend syntax parse\n'+result.stderr[:2000])
sys.exit(result.returncode)
