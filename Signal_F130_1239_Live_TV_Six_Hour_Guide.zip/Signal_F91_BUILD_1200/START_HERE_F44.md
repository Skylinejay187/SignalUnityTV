# Signal F44 — build 1153

Based on F43 / build 1152. Open this source folder with the existing universal tvOS ZIP workflow. App, Top Shelf, project version, and dedicated workflow evidence identify F44 / 1153.

## Up Next

- Dismiss has an explicit, always-painted label, background, and border. Moving focus to Play changes its focus border, never its presence. The regular, compact, and missing-metadata surfaces all keep Dismiss visible.
- Both action columns have fixed, contained dimensions; the compact card no longer depends on the intrinsic width of system tvOS button platters.
- Autoplay remains the existing `signalAutoNextEnabledV393` preference, default true. This patch neither resets it nor overwrites the user's saved value. Manual Play remains available when the source is ready.
- Fixed a concrete stalled-autoplay path: natural EOF retires the watchdog, while source preparation could return early during retry backoff and leave no future worker. The settled EOF reconciliation now always installs a cancellable retry when needed.
- First playable-source publication and completed countdowns reconcile through the same preference, source, decoder-settle, and dismissal gates. They do not wait for all remaining provider lanes to return before committing a ready episode.
- Closing an early reminder keeps the user's EOF-autoplay preference. Back/Dismiss after EOF cancels the current handoff, including delayed provider callbacks. An early reminder dismissal no longer disables the playback-clock EOF fallback if a decoder omits its completion event.
- An actively playing final half-second is no longer classified as completed solely by the clock when dismissing the early reminder.

## Guide

The active full Guide and Bottom Quick Guide share the same `SignalGuideChrome.panelFill`: black at 78% opacity. Removed the active full Guide's opaque-black root, rail, timeline, and hero planes. The existing UNITY backdrop remains underneath; a Pure Black backdrop is naturally still black underneath a translucent overlay.

The Google TV references informed the presentation: tighter program hero with more space for schedule rows, refined title/metadata hierarchy, brighter secondary text, softer separated cells, rounded channel lanes, and a quiet red current-time marker with its own timestamp. The selected program/live preview still owns the hero; no synthetic listings or extra video players were added.

The timeline now uses one two-hour real-date axis for every program, time label, and current-time marker. Cells clip programs at the viewport boundaries, preserve actual durations and schedule gaps, and do not widen short programs into the next time slot. There are no repeated fake placeholder listings. Channel focus, Select-to-play, long-press actions, and Left/Back category navigation remain.

One 60-second timeline refresh serves the visible guide and stops when covered. Guide hero artwork uses the existing bounded/cancellable artwork loader at 768 pixels, replacing unbounded AsyncImage transport. Prior F43 playback teardown, prepared wallpaper blur, smoke, four-row customization, cache budgets, and shared indexes remain intact.

## Validation and limits

Local checks passed: historical F31–F43 approved-delta regressions; current F44 ownership/wiring checks; 28 timeline arithmetic cases; prior resource/geometry math; six build-identity tests; seven diagnostic-redaction cases; 22 FastZap wiring checks; remote-thumbnail gate; YAML, shell, Python, and Swift grammar checks. Every unchanged prior Swift file is checked against its F43 hash.

This environment has no Xcode/tvOS SDK or Apple TV. The native Swift policy/geometry executable tests, SDK typechecks, full compilation, physical remote-focus rendering, and real episode-to-episode playback were NOT run here. The preflight includes the new native tests and helper typechecks for the macOS build.

See `F44_VALIDATION.json` and `Tests/SignalF44UpNextGuideTests.swift` for exact local results and native coverage.

Before installation acceptance on Apple TV: move between Play and Dismiss in both overlay sizes; dismiss an EOF source-loading prompt; close an early reminder and let playback reach EOF; let a source become ready after a retry delay; verify exactly one automatic next-episode launch with the preference enabled and none with it disabled; open/close Guide and inspect real listings against the time labels.
