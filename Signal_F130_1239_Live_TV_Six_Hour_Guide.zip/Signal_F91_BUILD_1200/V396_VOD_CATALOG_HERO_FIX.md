# vBRDC396 VOD catalog Hero 2 first-load fix

Scope: VOD Home/Movies/Shows catalog background, **not** Live TV grid.

- Include the focused catalog backdrop URL at the front of visible artwork hydration prefetch.
- Disable navigation deferral for the full-screen catalog hero RemoteImageFit, while retaining image identity, cache, overlays, and playback publication protections.
- No changes to Live TV grid artwork.

Validation: Swift frontend syntax parse passed. Apple TV runtime/device validation is not available in this environment. This is a targeted source patch, not a full v396 Phase 5 completion.
