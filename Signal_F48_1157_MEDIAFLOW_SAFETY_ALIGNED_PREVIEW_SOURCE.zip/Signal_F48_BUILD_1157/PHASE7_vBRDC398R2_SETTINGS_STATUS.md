# vBRDC398R2 Spotlight settings integration

- Preserves the restored original Spotlight Hub and existing portrait Trakt related poster strip.
- Adds VOD Player Settings controls for display mode, rotation interval, single theme and enabled themes.
- Spotlight presentation remains passive: no remote focus controls on the panel.
- Auto Showcase rotates between *available data-backed sections* only; Single Panel chooses one; Vertical Stack shows enabled available sections.
- Existing data sources only: Trakt pulse, personal Trakt, related Trakt, providers, review. Unverified 12-theme content is deliberately not invented.
- Theme-order editor and twelve independently sourced visual themes are NOT complete. The theme toggle currently adds the next disabled theme; it is not a full list editor.
- Linux Swift parser succeeded. Xcode/tvOS compile and device tests unavailable.
