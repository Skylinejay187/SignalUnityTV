# Phase 2 Pass 4 — thumbnail regression rollback

Reverts only Pass 3 thumbnail cancellation changes in both Aether bridge copies and the SwiftUI overlay. Restores Pass 2 thumbnail lifecycle/request behavior, including its 140 ms request coalescing. Preserves Pass 1 branding and backup safety, Pass 2 changes, and Phase 1 cache fix.

This is a regression-isolation candidate, NOT a verified thumbnail repair. Live TV join speed, FastZap performance and accumulated lag remain open. Test on signal/f28-test; no main merge.
