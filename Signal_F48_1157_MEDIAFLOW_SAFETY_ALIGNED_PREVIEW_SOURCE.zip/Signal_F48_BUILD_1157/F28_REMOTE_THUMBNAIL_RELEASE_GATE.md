# F28 1134 — Remote Debrid seek-thumbnail release gate

## Current safe behavior
The existing `VODSeekFrameExtractor` only accepts readable local file URLs. The player UI rejects remote URL extraction. This is intentional: `AVAssetImageGenerator` on a Debrid HTTP URL can open another remote demux/decode path, competing with the sole AetherEngine playback session. Do not bypass the local-file guard.

## Acceptable implementation paths
1. **AetherEngine-owned decoded-frame reuse**: only if the pinned 7.44.0 API provides a documented, non-destructive frame snapshot for an arbitrary seek target without altering playback position or allocating a second decoder. Audit upstream implementation and verify on Apple TV before wiring it.
2. **Provider-supplied trickplay images**: if a selected source provides an explicit, authenticated thumbnail storyboard or per-time image index, fetch only those small still-image resources with bounded caching, request cancellation, credential redaction, and session identity checks. Do not infer image endpoints from video URLs.
3. **Local-file extraction**: keep current implementation for actual local files. A temporary playback cache is not automatically a valid random-access local file.

## Required tests
- Confirm scrubbing a remote Debrid URL never starts AVFoundation video asset generation or a second Aether decoder.
- Confirm missing trickplay metadata yields no thumbnail, without disrupting playback or seeking.
- Verify frame timing, cancellation, memory pressure, session replacement, and authorization handling on physical Apple TV.

**Status:** remote thumbnails unsupported pending a verified API or explicit image metadata. This is a known feature gate, not a completed implementation.
