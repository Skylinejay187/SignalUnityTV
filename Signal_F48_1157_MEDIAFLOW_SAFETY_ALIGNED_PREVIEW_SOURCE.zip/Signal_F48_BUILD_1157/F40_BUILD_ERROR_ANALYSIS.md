# F40 build repair

Input logs: `logs_108998430049.zip` and `Signal_tvOS_build_logs (11).zip`.

The build used F39 / 1148 and failed in `SignalSearchGlyph.swift` at its UIView subclass's `focused` declaration:

- `overriding property must be as accessible as its enclosing type`
- `cannot override with a stored property 'focused'`

These are two diagnostics for one UIKit naming collision. F40 renames only that internal stored focus state to `glyphHasFocus`. The existing renderer, visual effect choices and lifecycle remain unchanged. A real tvOS SDK type-check step is added to the existing preflight script, which the attached universal-workflow logs confirm is invoked before the full app build.

The supplied logs do not prove F40 compiles: this repair requires a new macOS/Xcode run. The deployment-target/AppIntents/library-evolution messages were warnings, not the fatal failure reported here.
