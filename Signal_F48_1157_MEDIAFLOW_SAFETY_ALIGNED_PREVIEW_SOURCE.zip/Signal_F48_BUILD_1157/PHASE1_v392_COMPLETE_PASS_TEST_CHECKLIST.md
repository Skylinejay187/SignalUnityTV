# Signal vBRDC392 — Phase 1 consolidated source pass

This is ONE consolidated source package covering all eight Phase 1 steps, based on the latest v392 artwork ownership checkpoint. No intermediate step packages are needed for this phase. Source-level fixes are NOT proof of Apple TV runtime success.

## Source work / owner test

1. Artwork during extended playback — prior v392 lifecycle patch retained. Test 60–120 minutes of VOD playback, then open overlay; logos/posters/cast should appear.
2. Hidden controls do not cancel artwork — prior v392 patch retained. Auto-hide controls repeatedly and reopen; no persistent missing artwork.
3. Reopen recovery — prior v392 reveal notification and Cast Explorer return recovery retained. Test returning from Cast Explorer, episode browser and hidden chrome.
4. Flicker/empty panels — metadata publication now retains previously hydrated poster, backdrop and cast when a sparse asynchronous result arrives. Test opening overlay repeatedly during active playback and source metadata hydration.
5. Resume accuracy — remove speculative seek-request checkpoint; persist AVPlayer seek after successful completion, preserve decoder-confirmed position for internal engine, reject impossible duration overshoot. Test stop/reopen at 10m, 30m, after forward/back seek, and after backgrounding; report actual vs expected seconds.
6. Bluetooth/Now Playing — re-install/reconcile media command targets on foreground return while retaining existing 180ms duplicate-event suppression and route/interruption recovery. Test Bluetooth headset pause/play, Siri Remote play/pause, Control Center and Now Playing.
7. tvOS overlays — foreground return is guarded by active playback session identity; reassert media ownership and rehydrate visible VOD artwork without rebuilding the decoder. Test Control Center, app switcher, Settings overlay and return, both paused and playing.
8. Long-session playback — seek persistence is guarded against speculative positions and invalid clocks; existing playback/teardown lifecycle retained. Test 90–120m playback, several seeks, pause/resume, app switch, EOF and a second title.

## Verification status
- Swift frontend parse: passed in available environment.
- ZIP archive integrity: passed.
- Full Xcode tvOS typecheck/link/sign: NOT run (Xcode/tvOS SDK unavailable here).
- Apple TV runtime validation: NOT run; user acceptance pending.

Mark each test PASS or FAIL with the title/source, playback engine, timestamp, and reproduction steps. Keep v392 open for any failures. Do not advance to v393 until user confirms phase acceptance.
