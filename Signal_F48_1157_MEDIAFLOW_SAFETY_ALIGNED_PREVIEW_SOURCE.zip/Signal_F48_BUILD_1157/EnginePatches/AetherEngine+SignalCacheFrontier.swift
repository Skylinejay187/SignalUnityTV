import Foundation

extension AetherEngine {
    /// Re-read the producer's contiguous cache coverage without changing transport or time.
    /// Clock sinks alone cannot report a growing reservoir while presentation is stationary.
    @MainActor public func refreshSignalBufferFrontier() {
        guard !isLive, clock.currentTime.isFinite else { return }
        let current = max(0, clock.currentTime)
        let endpoint: Double
        if let host = softwareHost {
            endpoint = SoftwareBufferFrontier.bufferedPosition(
                currentTime: current, liveFrontier: host.bufferedSessionTime,
                cushion: host.displayCushionSeconds, cachedVODFrontier: host.cachedVODSessionTime)
        } else if let host = nativeHost {
            if let session = nativeVideoSession {
                let ahead = session.contiguousForwardReadAheadSeconds(playlistSeconds: host.currentTime)
                endpoint = current + max(0, ahead)
            } else {
                // These ranges were already copied by off-main KVO. No synchronous AVF/XPC read.
                endpoint = current + max(0, host.signalCachedBufferEnd() - host.currentTime)
            }
        } else {
            return
        }
        guard endpoint.isFinite else { return }
        let bounded = duration.isFinite && duration > 0 ? min(duration, max(current, endpoint)) : max(current, endpoint)
        if abs(clock.bufferedPosition - bounded) >= 0.01 { clock.bufferedPosition = bounded }
    }
}
