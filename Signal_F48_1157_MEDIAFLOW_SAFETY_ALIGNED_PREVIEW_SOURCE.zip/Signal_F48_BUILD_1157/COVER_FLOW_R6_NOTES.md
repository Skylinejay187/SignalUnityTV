# vBRDC398R6 Cover Flow geometry candidate

Base: vBRDC398R5 ZIP. Changed only Sources/DebridChannelsTVOSApp.swift in GridOSFixedSlotCatalogRail.

- Center landscape 358x214 design points scaled against 1536-wide design space.
- Side portrait 112x174 design points; first poster near hero edge; subsequent steps 56 points, approximately 50% overlap before perspective.
- Progressive inward-facing Y-axis rotation 4.95 to 12 degrees and perspective scale down to 0.77.
- Reflection region 128 design points with graduated opacity; dark floor extends under reflections.
- Additional vertical layout allocation for metadata, controls, reflections and row separation.
- Non-focusable Play, Details and Hold for Options hints; actual Siri Remote actions unchanged.
- Circular left/right wrap in 3D Cover Flow only. Classic Rows navigation unchanged.
- Existing selected focused card, playback preview and artwork ownership retained.

Validation: swiftc -frontend -parse on Linux passed. Not compiled using Xcode/tvOS SDK; no Apple TV device visual verification. Parent catalog layout may require additional vertical sizing after on-device screenshot comparison. This is a test candidate, not a pixel-perfect final build.
