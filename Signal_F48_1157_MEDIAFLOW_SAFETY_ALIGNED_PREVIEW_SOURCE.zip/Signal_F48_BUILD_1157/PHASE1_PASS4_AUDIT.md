# F29 Phase 1 Pass 4 — audit checkpoint

Based on Pass 3. Not an Apple TV build or a completed Phase 1 repair.

## Changes
- Spotlight: explicit panels now render an informative unavailable state instead of appearing blank or silently reverting to Trakt Pulse when provider/review data is missing. The settings button now describes its actual behavior (cycling a single displayed Spotlight panel).
- Previous Pass 1–3 seek-thumbnail, cache UI and intro seek safety changes retained.

## Verified by source audit; still open
- Remote Debrid thumbnails: AetherPlaybackBridge.handleScrubThumbnailRequest checks `engine.supportsCacheBackedStills`. This gate prevents extraction for streams that do not advertise cache-backed still support. Removing it without an Aether API contract could cause failed or disruptive seeks; remote uncached extraction remains unsupported/unverified.
- Cache indicator: AetherPlaybackBridge subscribes to `engine.clock.$bufferedPosition` and polls `engine.clock.bufferedPosition` at 2 Hz. If the engine clock does not advance as disk cache fills, UI changes cannot make this accurate. Requires engine-side telemetry inspection and device logs.
- Skip Intro: prompt is contingent on a story-safe marker, series identity, playback readiness and no conflicting overlays. Community marker availability and service licensing not verified.
- Spotlight: only five panel implementations currently exist; do not claim that the previously proposed twelve themed panels have been restored.

## Device test checklist
1. Change Spotlight panel in Settings; reopen VOD; verify selected panel, or explicit unavailable message, not Trakt Pulse fallback.
2. Remote seek back/forward with cached and uncached Debrid media; record whether image appears and when.
3. Watch VOD without pausing for 60s; note whether buffered endpoint advances and capture bridge logs if it stalls.
4. Test Skip Intro on multiple episode releases; report whether prompt is absent, late, or seek is incorrect.
