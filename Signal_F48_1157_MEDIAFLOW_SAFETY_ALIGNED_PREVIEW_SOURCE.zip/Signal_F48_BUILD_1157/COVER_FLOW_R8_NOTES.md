# vBRDC398R8 — compile fix and concept geometry calibration

- Corrects GitHub Actions Swift opaque return error at `catalogRail` (previously line 9012): explicit `return ZStack(...)` required because the function contains local declarations and is not a `@ViewBuilder`.
- 3D Cover Flow only: 140 × 210 portrait cards (design-space points at 1536 reference width); 50-point center-to-center side-poster step; initial poster centers at 56% of focused landscape width from center; 145-point reflection region.
- Classic catalog geometry and navigation remain unchanged. Classic artwork reflection fade now starts at 33% opacity, fading through 17% to clear.
- Existing 358 × 214 landscape-focused component and preview preserved.
- Syntax parse only; full Xcode/tvOS build and Apple TV visual tests not available here.
