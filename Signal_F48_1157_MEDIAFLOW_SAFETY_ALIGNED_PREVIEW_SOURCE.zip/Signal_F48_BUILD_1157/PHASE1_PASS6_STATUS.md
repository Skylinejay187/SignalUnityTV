# Phase 1 Pass 6 — Cache UI telemetry cadence

Changes: Aether buffered-position sampling now occurs at 4 Hz for VOD, with smaller notification deltas and 350 ms coalescing. The cached-progress rail animates between *actual* buffered-position updates over 450 ms. All cache policies share this path. No estimated buffer progress is synthesized. Back/forward chips retain Pass 5 direct-seek behavior.

Limit: If AetherEngine 7.44.0 `clock.bufferedPosition` stays constant during paused disk prefetch, the UI cannot report unexposed cache growth. This requires engine-level disk cache telemetry or a verified upstream fix. Swift parsing passed; Xcode compilation and device behavior are unverified. Do not call Phase 1 complete until tested.
