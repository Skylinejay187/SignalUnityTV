# Signal Wizard — Pass 29 GitHub build handoff

## Current status
- Input: Stage 28 full source ZIP.
- Linux validation passed: `bash Scripts/check_f28_source_preflight.sh` (74 Swift files); `python3 Scripts/check_f29_build_identity.py`; `python3 Scripts/check_f28_diagnostic_redaction.py`; `python3 Scripts/check_f28_remote_thumbnail_gate.py`; `swiftc -frontend -parse Sources/DebridChannelsTVOSApp.swift`.
- **NOT** a successful macOS/tvOS compile. Apple TV runtime verification is also pending.
- The existing GitHub `signal/f28-test` workflow is named `Universal Signal tvOS - Full Source ZIP to IPA`; it listens to ZIP file pushes and workflow_dispatch, unlike the workflow in this source ZIP. The GitHub branch workflow is the one that actually runs.
- No source ZIP has been uploaded to GitHub by this pass; no workflow was dispatched. The available GitHub connector does not expose a workflow-dispatch action.

## Next action
1. Upload the complete Stage 28 ZIP to the `signal/f28-test` branch (not main) using the existing ZIP workflow's documented input filename/location.
2. Confirm the workflow is building the uploaded Stage 28 ZIP, not a previous source package.
3. Run Actions and inspect sanitized diagnostics, correct compiler errors, and rerun until a successful unsigned tvOS build is confirmed.
4. Verify wizard, Siri Remote, membership handoff and Smart Restore on an Apple TV; then mark the wizard test-ready.

## Locks
- AetherEngine 7.44.0 only; no KSPlayer, no prewarming.
- Preserve Live TV timeshift, VOD playback, FastZap default stable mode, 3D Cover Flow and current UI navigation.
- Do not change website domain or push to main.
