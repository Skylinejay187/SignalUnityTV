# Phase 2 Pass 2 — VOD scrub workload coalescing

Source change: remote Aether scrub-thumbnail notifications now wait 140 ms and cancel superseded requests. This reduces decode pressure during rapid timeline movement without changing forward/backward chip direct-seek behavior. Local-file thumbnail handling unchanged. AetherEngine 7.44.0 retained.

FastZap audit: Settings and player both read signalFastZapFullScreenV1; bridge applies fast join on first live attempt only and uses conservative recovery. No unverified performance claim or startup timing optimization is included.

Validation: Swift frontend parse passed; bridge copies matched byte-for-byte. Full source preflight exceeded execution window; GitHub Actions/Xcode and device testing required.

Not yet completed: measurable Live TV startup optimization, full overlay performance profiling, all Phase 2 regression tests. Phase 3 foreground black-screen issue remains mandatory; Phase 5 real live speed test; Phase 6 cast poster-only scrolling.
