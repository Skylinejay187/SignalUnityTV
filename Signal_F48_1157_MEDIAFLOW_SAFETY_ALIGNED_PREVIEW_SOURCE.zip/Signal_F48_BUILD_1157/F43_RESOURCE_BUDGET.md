# F43 resource audit — what changed and what still needs measurement

This report contains source findings and arithmetic. It does not claim measured Apple TV CPU/GPU percentages or a measured peak-memory reduction.

## Concrete causes corrected

| Path | F42 behavior | F43 change |
|---|---|---|
| Dynamic/frosted wallpaper | Small source image enlarged to the display before a live blur; two mounted image owners | One source owner, serial small-bitmap filtering, native image-plane fade; old jobs revoked |
| Frosted grid cards | Blurred fill evaluated under each moving/perspective card | One prepared fill, longest edge 192 px, per displayed image; sharp foreground preserved |
| Smoke | 9/12 radial-gradient billows redrawn by a SwiftUI Timeline/Canvas | 9/12 compositor layers reusing two 256 px textures; 8–15 Hz pacing hints; no CPU redraw timer |
| Pure Black | Smoke excluded by the wallpaper branch | Independent smoke option; same visible-only lifetime as other themes |
| Image transport | Kingfisher default cache plus Signal caches; synchronous disk-load option; completion waiting on original/processed disk caching | Dedicated 8 MiB transport cache, async disk path, serial utility processing, no redundant original-byte write/wait |
| Same-URL artwork replacement | Retired callback could finish against a new registry entry | Per-load token rejects obsolete completion and fallback |
| Preview/full-screen handoff | Auxiliary identity registration without an immediate Aether stop handler | Explicit release handler; observer removal; revoked coordinator cannot restart; synchronous stop before exclusive handoff |
| Aether exit | Host kept its bound renderer until surface disposal; thumbnail worker not explicitly cancelled in stop | Explicit unbind, thumbnail cancellation, then stop and nil the engine |
| Lineup return | Main model discarded channels/guide, forcing browse-index reconstruction | Retained immutable session and COW browse indexes shared by the main and player-guide models; versioned reuse |
| Quick Guide preparation | Multiple initial calls could prepare every channel; fallback scanned all guide keys per channel | At most 48 prepared channels, shared exact alias index, duplicate-call coalescing; other channels retain direct on-demand EPG lookup |
| Covered Live TV | Some logos/focus clocks could remount/re-arm; cancelled refresh could restart guide recovery | Environment eligibility gates leaves; decoded-cache-only paint while covered; recovery checks foreground/cancellation before rearming |
| Playback return | Optional network work restarted about 220 ms into grid restoration | Focus first; optional root work waits 1.25 seconds and the idle frame lane; MediaFlow may reuse its existing health result |

## Cache arithmetic

These are nominal configured soft limits, not allocations, hard process bounds or additive physical footprint. Several caches hold references to the same UIImage. Visible view-owned images, decoder buffers, guide objects, framework storage and temporary work are outside the sum.

| Reservoir group | F42 MiB | F43 MiB |
|---|---:|---:|
| Signal catalog/sports/favorites/return decoded caches | 224 | 144 |
| Live TV artwork/logo/return decoded caches | 152 | 76 |
| Encoded URLCache memory | 96 | 24 |
| Kingfisher transport decoded cache | Device RAM / 4 by upstream default | 8 |

On a 2 GiB device, the old target sum was 984 MiB including Kingfisher's 512 MiB default. The new explicit target sum is 252 MiB. This is a configuration comparison; it is not a measured 732 MiB saving. Disk caches remain bounded and asynchronous, preserving warm artwork reuse.

## Texture arithmetic

For uncompressed RGBA, bytes = width × height × 4:

| Example | MiB |
|---|---:|
| One 3840 × 2160 full-screen intermediate | 31.641 |
| Two 640 × 360 wallpaper bitmaps | 1.758 |
| Sixteen 192 × 108 card-edge bitmaps | 1.266 |
| Two shared 256 × 256 smoke textures | 0.500 |

The first figure illustrates why extra full-display filter passes are expensive. It does not assert how many such intermediates Core Animation allocated. Normal display composition still happens. Clearer wallpaper settings retain their higher bounded source resolution; 640 px is the normal strongly blurred case. The smoke texture cache has a 2 MiB/8-entry soft ceiling across color changes.

## Work and layout math

- A naive 30,000-channel × 30,000-guide-key fallback has up to 900 million candidate comparisons per preparation pass. The replacement builds normalized aliases once per actual guide publication and prepares at most 48 channels using dictionary lookup. Direct on-demand guide lookup preserves metadata outside that window.
- Three rows remain the default: 4 × 3 = 12 card slots. Four rows opt in: 4 × 4 = 16 slots. No off-page grid cards are mounted.
- Row height is bounded by (canvas height − shared header/footer reserve − total row gaps) / row count, and by available card width. Split layouts account for the extra gutter and its fourth HStack gap. Four-row cells remain 16:9 and the complete row is centered.
- The production scalar Swift layout expressions were numerically evaluated for 96 combinations: 720p/1080p/2160p canvases, 3/4 rows, Golden/Preview Mirror, Current/Spread Out, standard/expanded canvas and split/non-split spacing. Equal gutters and bounds passed. Native Swift tests are also included for CI.

## Device verification and counters

`[LiveTVResources][F43]` lines accompany the existing memory samples at grid exit, player presentation/teardown, grid restore and 1.25-second settlement. They include interval-average process CPU and counts of requested Aether hosts, auxiliary hosts, smoke owners and wallpaper owners. CPU may exceed 100% when multiple cores are used. These counters do not inspect private decoder internals or measure GPU utilization.

Expected steady ownership: at most one eligible smoke/background owner for the visible dashboard; no dashboard effects during full-screen playback; no auxiliary host after teardown; one primary host while playing and none after exit. The existing optional FPS HUD remains available. Repeated enter/exit cycles on the Apple TV must confirm stable footprint, idle work and frame pacing; Instruments is needed for actual GPU utilization and signposts/hitches.

## Primary implementation references inspected

- Pinned AetherEngine 7.44.0: public `unbind(view:)` and final `stop()` ownership.
- Pinned Kingfisher 8.11.0: `ImageCache.createMemoryStorage`, target cache, asynchronous retrieval and processing-queue options. Its original-image option writes original bytes to disk; it is not treated here as proof of a second full-resolution decoded original.
- Apple Core Animation `CAAnimation.preferredFrameRateRange` (tvOS 15+): https://developer.apple.com/documentation/quartzcore/caanimation/preferredframeraterange . Pacing is a system hint, not a guaranteed refresh rate.
