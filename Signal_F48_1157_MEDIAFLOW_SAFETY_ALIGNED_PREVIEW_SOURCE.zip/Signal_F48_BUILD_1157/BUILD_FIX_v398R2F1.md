# vBRDC398R2F1 — Spotlight Settings Xcode Compile Fix

The uploaded GitHub Actions log reports 12 `cannot find ... in scope` errors in the Spotlight settings section of `Sources/DebridChannelsTVOSApp.swift` (lines 40455–40477).

Added four `@AppStorage` declarations to the VOD Settings view for `spotlightDisplayModeV398`, `spotlightRotationSecondsV398`, `spotlightEnabledThemesV398`, and `spotlightSingleThemeV398`, matching the keys and defaults already used by the Spotlight presentation views. No changes to playback, artwork, Spotlight layout, or app/Top Shelf version numbers.

Validation: Swift frontend syntax parse and ZIP integrity only. A complete tvOS Xcode compile is not available in this environment; re-run GitHub Actions to confirm.
