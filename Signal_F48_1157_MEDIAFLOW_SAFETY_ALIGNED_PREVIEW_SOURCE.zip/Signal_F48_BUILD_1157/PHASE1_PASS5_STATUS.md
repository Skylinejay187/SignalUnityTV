# Signal F29 Phase 1 Pass 5 — transport seek rollback and cache audit

## Implemented
- Restore direct backward/forward transport seek chips: no scrub-preview assignment, timeline focus transfer, or thumbnail request.
- Keep thumbnail extraction tied to explicit timeline scrub changes.

## Cache-progress audit (unresolved; do not claim fixed)
- All five user cache policies (Auto, 1 GB, 2 GB, 3 GB, Unlimited) feed the same VOD buffer UI path. Their target sizes may affect Aether's disk-prefetch behavior, but no per-policy animation path was found in the main view.
- AetherPlaybackBridge reads `engine.clock.bufferedPosition` via Combine and 0.5-second timer. The bridge coalesces unchanged values. If the clock stays stale while paused, neither timer nor UI re-publication can produce a truthful cached endpoint.
- Next investigation: inspect Aether 7.44.0 actual disk-cache writer/readable-range telemetry and ensure the bridge reports cache extent independently of decoder playhead, including paused state. Verify source identity and range discontinuities on seeks.
- Device matrix: each policy, while playing and paused, with cache fill underway; verify endpoint increases only with actual cached bytes, no jumps on pause/play, and no false growth after cache limit reached.

## Validation
- `swiftc -frontend -parse Sources/DebridChannelsTVOSApp.swift` passed.
- Not Xcode compiled or Apple TV verified. Phase 1 remains open.
