# Signal F29 Phase 2 — Pass 1

Built from Phase 1 Pass 6F1 (bridge parity correction), not the stale Pass 6 worktree bridge.

Implemented:
- Confirmation dialog (Cancel / destructive Delete Backup) before deleting the server-side restore-code backup.
- CFBundleName and CFBundleDisplayName both set to Signal; bundle identifier unchanged.
- Preserves Phase 1 Pass 6F1 playback/cache changes.

Phase 2 still outstanding: Live TV FastZap join-speed measurement and tuning, VOD overlay lag profiling/repair, Live TV preview speed, and startup/EPG audit. No claim of fixing those in this checkpoint.
Phase 3: foreground black-screen and accumulating app-wide lag.
Phase 5: real-time manual network speed test in About, plus Backup & Restore release verification.

Validation: Swift syntax parse and archive integrity only; full Xcode compilation and device verification pending.
Keep on signal/f28-test; do not merge main.
