# Signal F143 — Dual Settings Layout

The existing horizontal category carousel is preserved as **Standard**, the default.

**Vertical List** adds a 490-point scrollable category rail with the same category icons and a 1270-point content panel. The selected category, actual controls, values, focus identifiers, and credential storage are shared across both views.

A two-choice switch is present in Settings header. Choice persists via `signalSettingsLayoutV1` (`standard` or `vertical`). Switching back to Standard does not reset any setting. Category selection continues to update on focus; Right enters the selected category controls.

Only `Sources/DebridChannelsTVOSApp.swift` and the exact F143 reviewed-source SHA-256 manifest were changed. The source membership and F143 integrity checks pass. Linux Swift parser passed; Xcode/tvOS SDK compilation and Apple TV visual/focus testing remain required.
