# F143 Usenet-only initial preparation notice

- Usenet resolving overlay shows an initial up-to-60-second preparation message and a seconds countdown.
- The timer is **informational**: there is no forced 60-second sleep before playback. The existing resolver starts the player immediately when a playable URL arrives.
- If stream resolution exceeds one minute, the UI says that Usenet is still preparing, rather than falsely claiming cached data or guaranteed playback.
- Only `link.isTorBoxUsenetCandidate && !link.isDirectPlayable` enters this notice, including supported NZBgeek native NNTP and TorBox cloud preparations. Already direct playable AIOStreams HTTP URLs open normally without delay or extra notification.
- Not a replacement for progressive NNTP or cloud provider support. It does not invent video data, force cloud links to become progressively readable, or alter non-Usenet playback.
