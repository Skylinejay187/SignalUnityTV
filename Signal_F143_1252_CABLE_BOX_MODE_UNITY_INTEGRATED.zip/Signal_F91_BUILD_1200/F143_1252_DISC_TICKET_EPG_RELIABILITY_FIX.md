# F143 1252: Poster attachment geometry + EPG source verification

Based on Signal_F143_1252_FORCE_GUIDE_REFRESH_FIX.zip.

- Movie disc: 136pt diameter, extended offset -78pt from poster's leading edge (~57% exposed). Retains separate authentic Fanart/movie disc artwork selection and existing animation behavior.
- Series Season Pass portrait-left: 78pt wide, extended offset -64pt (~82% exposed), 14pt retained behind poster. No additional HStack spacing.
- Series Season Pass horizontal-right: 148pt wide, extended offset +112pt relative to 138pt poster (~122pt exposed), 26pt overlap. Add 122pt metadata leading clearance only for this configuration; avoid placing ticket behind title and synopsis.
- All style toggles/off, movie-only disc constraints, existing presentation transitions, and unrelated VOD surfaces are preserved.
- EPG: separately record verified fresh coverage for Channels DVR, XMLTV/M3U, Xtream and mirror paths, instead of exclusively recognizing HDHomeRun; preserve previous program rows on error or incomplete coverage.
- Explicit Refresh Guide still bypasses mirror and triggers fresh provider load. No new endpoint or providers introduced.
- Swift syntax parse, current F143 exact 136-file SHA preflight, diagnostics and source membership: PASS locally.
- Full Xcode tvOS compilation, real-device visual placement, and live EPG provider behavior: NOT VERIFIED. Test on Apple TV and upload build logs for any failures.
