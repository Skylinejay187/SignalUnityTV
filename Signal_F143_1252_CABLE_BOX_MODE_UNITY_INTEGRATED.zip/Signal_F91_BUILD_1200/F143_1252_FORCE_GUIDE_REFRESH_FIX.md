# F143 — Force Refresh Guide targeted fix

The Live TV quick panel's **Refresh Guide** action was still subject to the generic 300 ms selection debounce and could silently ignore a click during focus handoff. It also allowed a healthy-looking NAS mirror result to skip the IPTV provider's fresh XMLTV even on an explicit forced refresh.

Changes to Sources/DebridChannelsTVOSApp.swift:
1. Explicit Refresh Guide bypasses the generic selection debounce (other actions retain their existing throttles).
2. Immediate visible status on press, without wiping the current cached guide.
3. Manual force refresh bypasses the NAS EPG mirror shortcut and fetches provider XMLTV directly. Normal automatic refresh still uses the mirror.
4. Existing supersedePending task cancellation, force HTTP cache policy, generation fences, VOD playback restrictions and guide presentation remain unchanged.

Verification: Swift parser, F143 reviewed exact source hashes, diagnostic static contracts, targeted refresh regression and ZIP integrity. Full Apple tvOS compilation and provider-level runtime tests require GitHub and Apple TV.

No backend, IPTV credentials, catalog, playback, or artwork code was changed.
