# F143 backup/restore coverage — November 24, 2026

Based on F143 1252 aligned top/bottom row geometry build; preserves Settings lifecycle stability fix.

The protected backend profile already exported and restored six user-facing preferences: Open Channel in Full Guide, Full Guide video layout, VOD Poster Disc Peek, Disc Eject Animation, TV Season Pass position, and Source Information Style. This patch registers those values in the portable-preferences default/allowlist as well, preventing dropping them during profile sanitization.

It additionally adds `signalSettingsLayoutV1` (Standard or Vertical List) to the protected profile export and restore. Unknown layout variants normalize to Standard. Missing fields in older backup codes use current/default values; existing backups and settings stay compatible.

Static coverage check: `python3 Scripts/check_f143_backup_presentation_coverage.py`. Full Apple TV/Xcode runtime verification not performed.
