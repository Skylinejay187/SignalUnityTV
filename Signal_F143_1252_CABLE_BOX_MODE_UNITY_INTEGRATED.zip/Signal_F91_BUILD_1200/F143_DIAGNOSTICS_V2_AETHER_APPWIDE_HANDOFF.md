# Signal F143 Diagnostic Center v2 — Cache + System Signals

Baseline: F143 Extended Cache (10 GB target) safe source ZIP. No modifications to Aether cache scheduling or video decode.

## Additional report fields
- `session_timeline.json`: numerical allowlisted metrics include the effective Aether `forward_segment_target` (not GB), `buffer_frontier_seconds`, `playhead_seconds`, `duration_seconds`, `ahead_seconds`, `coverage_percent` (timeline fraction), `buffer_stall_seconds`, `free_disk_bytes`, `thermal_level`, `low_power_mode`, and `memory_warning_count`.
- `diagnostics_summary.json`: latest observed values and anomaly counts.
- `manifest.json`: `aether_cache_bytes_available=false` — the Aether engine still does not expose verified disk cache byte counts through the shipped interface.
- `performance_trace.txt`: existing frame pacing trace.
- `README.txt`: interpretation warnings, especially that buffer coverage is not actual cache-file byte count.

## Behavior
All monitoring is opt-in; 2-second buffer samples, 5-second playhead samples, 15-second resource snapshots and bounded 2,400 events. Emit signposts only for memory warnings or observed no-progress cache frontier. Existing app-wide guide, Trakt, Usenet, artwork, preview event hooks remain available. Sensitive stream URLs, provider keys, titles, and account IDs are not captured. Export still uses expiring one-time LAN token.

## Caveats and next proof
- tvOS physical-device and GitHub/Xcode compile still required.
- Engine does not publish actual downloaded/cache-resident bytes; cannot validate 10 GB target solely with these metrics. To prove bytes, extend the Aether 7.44 disk cache implementation with verified written-byte and eviction counters.
- A cache frontier that does not advance may reflect pause, end-of-file, upstream behavior, or other reasons; it is an investigation clue, not conclusive diagnosis.
- Apple Instruments with signpost tracing and XCTest with xcresult bundles can provide complementary developer-side detail; they do not run on end-user Apple TVs automatically.
