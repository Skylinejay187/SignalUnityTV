# F143 / build 1252 — tvOS compiler repair (November 22/23 2026)

Source: Signal_F143_1252_DIAGNOSTICS_V2_CACHE_APPWIDE.zip.
Reviewed GitHub logs: Signal_tvOS_build_logs (27).zip, (28).zip, logs_122045816934.zip.

Changes in Sources/DebridChannelsTVOSApp.swift:
- Removed `.textSelection(.enabled)` from the Diagnostics export-address label. This modifier is unavailable in tvOS.
- Added `.diagnostics` branch to the SettingsCategoryCard accent-color switch to satisfy exhaustiveness.
- Updated Tests/F143ReviewedSourceHashes.json for the reviewed source change.

Checks executed on Linux:
- Scripts/check_f143_reviewed_source.py — PASS
- Scripts/check_signal_diagnostics_v2.py — PASS
- swiftc -frontend -parse Sources/DebridChannelsTVOSApp.swift — PASS

No Xcode SDK is present in this environment. The repaired ZIP requires a GitHub Actions tvOS build for compiler/links confirmation.

Masking backend note: The Apple TV source package does not include the running UGREEN backend's live model inference sources, database schema, or Docker volume mounts. No backend worker or stored masks were changed or deleted.
