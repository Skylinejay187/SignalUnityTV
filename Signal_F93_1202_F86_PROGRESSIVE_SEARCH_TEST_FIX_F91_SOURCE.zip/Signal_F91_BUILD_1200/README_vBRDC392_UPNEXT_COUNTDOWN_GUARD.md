# vBRDC392 Up Next transition guard — intermediate

This checkpoint builds on the v392 VOD artwork lifecycle source package.

- At countdown expiry, verify the next episode still has a prepared playable URL and is sourceReady.
- If source readiness was lost, keep Up Next visible, disarm auto-advance, reset countdown and focus Cancel rather than attempting a broken handoff.
- Manual playback handoff also requires sourceReady.

Validation: Swift syntax parse only; no tvOS SDK compilation, device test, or complete Up Next/skip/Trakt regression test. Aether-only migration and KSPlayer removal are not included.
