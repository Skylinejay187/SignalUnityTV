# Signal F73 / build 1182

Foundation: verified F72/build1181 ZIP SHA256 13ebfbcd054e97a007baff127ab5799c8826dc10019d4d8f17017e7228a220ff, current version37.

## Compact pause card

Card width is 390 points (was 600), with title branding constrained to 284x46 (was 480x76). Padding, type, accent rail and shadow shrink with it. Existing show/hide timing and three themes remain. The card is suppressed while Quick Guide is visible so the preview's temporary primary pause does not display another card over navigation.

## Optional Quick Guide focus preview

Settings -> Episode behavior & metadata -> Quick Guide previews (Live TV & VOD). Off by default. Stable focused channel selection waits three seconds before opening ONE Aether auxiliary live player inside that selected Quick Guide card. No adjacent-channel prewarming. The same PlayerScreen/rail handles both Live TV and VOD Quick Guide.

Three choices:
- Pause main + preview audio (default mode): retain the main session, synchronously pause its real host, then start audible preview. Originally paused main playback stays paused afterward.
- Continue main + silent preview: leave main playback/audio intact; preview is muted.
- Continue main muted + preview audio: leave main video moving, synchronously mute its host, then allow preview audio.

The main host acknowledges pause/mute before an audible preview is mounted; a missing acknowledgement refuses the preview instead of risking overlapping audio. Native AV fallback is paused/muted directly. Main Aether mute is also wired through UniversalVideoSurface so subsequent SwiftUI updates preserve it. The preview uses Aether's secondary shared-output role, suppresses HDMI matching, and does not claim Now Playing.

Focus/category/mode/eligibility changes cancel the dwell and synchronously release the old auxiliary host. Closing, selecting a channel, manual transport, player teardown, source replacement, preview failure, background, protected-route gates and playback modals are handled. The registered auxiliary decoder is stopped BEFORE main audio/playing intent is restored. Only the owning presentation can restore its main state. Background keeps paused intent until a valid foreground return. Preview failure restores the main program without changing its URL or playhead.

Continuing main video uses two video pipelines and can increase load, especially for high-resolution channels. Pause-main mode saves decode work. The setting is optional and included in portable Backup/Restore. Source/provider connection limits and network quality still apply.

## Performance review and concrete changes

- All auxiliary Aether live previews now use a 30-second internal transport/DVR window rather than inheriting full-screen Live TV's 1800-second window. The short ring is retained for Aether's existing live audio stability. User-facing full-screen timeshift stays 30 minutes. This limits unnecessary preview history; it is not a measured RAM reduction claim.
- Auxiliary surfaces use sharedOutputRole.secondary, so they never negotiate display criteria or own system Now Playing.
- Shared Live/VOD Quick Guide contained artwork decoding is capped at 512 pixels rather than 768. Existing decode gates, caches, async IO and cancellation are preserved.
- A temporary Quick Guide pause skips VOD's manual-pause enrichment and synchronous resume-cache flush. Normal manual pauses/exit retain durable resume behavior. No background API/poster wave is launched by preview focus.
- Reviewed main Unity metadata/Guide-row reuse, ambient visibility gates, existing auxiliary release registry, scoped pause-card timeline and bounded Quick Guide window. These remain in place. No speculative global animation rewrite, cache expansion, new engine or polling/retry loop was added.

No profiler, Apple TV, Xcode or Apple SDK is available locally. CPU/GPU/RAM, actual decoder concurrency and audio/display handoffs have not been measured or device-verified. The two-pipeline modes explicitly trade resources for simultaneous video. No claim of eliminating all system-wide performance issues is made.

## Validation

See F73_VALIDATION.json. Source contracts follow real settings -> dwell -> selected card -> Aether host -> primary pause/mute -> decoder release -> restoration wiring, with negative controls and exact reviewed historical regression checks. Native preview-mode policy tests are wired into normal macOS build preparation. They verify one audible lane for all three policies; they do not emulate AVFoundation. Local grammar/syntax/source checks are not type checking or runtime playback tests.

## Device acceptance

Build with Xcode, enable previews and test both Live TV and VOD guides in each of the three modes. Focus a channel for <3s (no preview), then >3s. Confirm only one audio lane, correct selected-card video, no HDMI flash/remote ownership theft, and preserved main playhead. Rapidly scroll/change category, close, disable/change mode, select a channel, manually pause/play, switch source/background/return, and trigger an unavailable channel. Verify no auxiliary host remains after exit and original paused/muted state is respected. Test Still Watching and protected-route transitions. Confirm full-screen Live TV timeshift still has its original window. Profile frame rate, memory, CPU/GPU on the target Apple TV before recommending simultaneous-video mode.
