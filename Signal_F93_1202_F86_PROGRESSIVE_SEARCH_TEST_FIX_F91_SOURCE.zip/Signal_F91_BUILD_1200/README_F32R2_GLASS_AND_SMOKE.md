# Signal F32R2 — build 1140 — shared glass and smoke

Current full source: **1.0.1140 / 1140 / Signal-F32R2**, patched from F32R1.
All 18 top-menu layouts, 12 backgrounds, manual cast browsing with automatic
presentations Off, and the Spotlight duplicate-logo fix remain included.

## Appearance controls

Settings → Appearance → UNITY · Live TV Background:

- Background Blur, 0–100%: less blur makes focused channel/programme artwork
  recognizable; more blur diffuses it into ambient color. This affects the two
  focused-artwork backgrounds. Strong blur keeps a 640-pixel decode budget;
  clearer settings use 1280 or 1920 pixels to reveal detail without an unlimited
  original-size decode. Foreground cards and posters are unchanged.
- Glass Transparency, 0–100%: more transparency reduces the glass/blue tint over
  both artwork and smoke. It does not change the chosen blur value. Opaque card
  text and dark edge shading remain for readability. Reduce Transparency in
  system Accessibility deliberately keeps a stronger tint.
- Ambient Classic Smoke: Off / Subtle / Cinematic / Heavy / Orbs. Keep the
  existing preferred mode; changing backgrounds no longer switches smoke Off.
  If a previous version already saved Off, select the desired smoke mode once.

Both new percentages are saved, clamped, included in backup/restore, and reset
only by the existing explicit settings reset. Default blur is 70%, default
transparency 35%. Pure Black bypasses all artwork, glass and smoke effects.

## Unified composition

Focused artwork or the selected abstract design is the base. The approved
Classic smoke geometry adds soft palette-matched light with Screen blending.
One shared glass layer and one shared readability vignette then treat the
artwork and smoke together. Smoke no longer has a separate dark veil or an
opaque wallpaper plane that erases the background blur.

Blue glass uses blue/cyan smoke highlights; other designs receive compatible
warm, violet or teal highlights. Heavy and Orbs remain available. The existing
strict Live dashboard ownership gate removes animation under catalogs, Guide,
quick controls, Settings, Search, details, full-screen playback, active Live TV
preview playback, or inactive/background scenes. Returning recreates the one
eligible smoke owner. No duplicate wallpaper player is added.

## Removed standalone wallpaper feature

The Dynamic Live TV Wallpaper switch, built-in wallpaper style picker, custom
animated URL switch and URL field are removed. Their procedural renderer,
video-loop player, animated GIF/WebP player, download/cache loader and Live TV
mount are deleted. Four obsolete saved preference keys are retired and are not
accepted through restored settings. The focused-channel artwork option remains;
it is an image-driven background, not the retired animation/URL feature.

## Validation

Completed locally:

- Six version/identity tests, including legacy workflow compatibility.
- Menu/theme migration and rendering scope checks.
- 118 Live TV interaction functions unchanged from the approved navigation base.
- 220 unrelated VOD functions unchanged; manual-cast production wiring retained.
- New checks for wallpaper removal, both backup keys, independent control wiring,
  shared smoke/glass order, no smoke reset on background choice, Pure Black and
  the existing strict lifecycle gates.
- Diagnostic redaction, remote thumbnail safety and FastZap wiring checks.
- No new Swift grammar diagnostics relative to F32R1.
- Complete source archive, project.yml, all archive CRCs and byte checks.

Swift executable tests for clamping, 101 control steps, independent blur/tint,
adaptive decode sizes and idempotent retirement are in the macOS CI workflow.
Full Xcode compilation, those Swift tests and Apple TV visual/performance testing
have not run in this Linux environment. Run the ZIP build workflow before
installation. This package is full source, not an IPA or a successful-build claim.

On device: choose Frosted Channel Artwork, set smoke to Subtle/Cinematic, lower
Blur and increase Glass Transparency. Move focus through channels, try Pure
Black, and leave/reenter via Guide, Settings and playback. Confirm the smoke
choice survives switching backgrounds and the title poster still supports
manual cast navigation when Full Poster/Cast Banner are off.
