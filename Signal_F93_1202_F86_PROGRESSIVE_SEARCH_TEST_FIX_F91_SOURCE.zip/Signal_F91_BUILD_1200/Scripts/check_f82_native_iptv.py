from pathlib import Path
import platform,shutil,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
if platform.system()!='Darwin' or not all(shutil.which(x) for x in ['xcrun','swiftc']):
 raise SystemExit('F82 native provider/Sports checks require macOS and Xcode; not executed')
with tempfile.TemporaryDirectory(prefix='signal-f82-native-') as directory:
 executable=Path(directory)/'iptv-tests'
 subprocess.run(['swiftc','-swift-version','5','-parse-as-library','-target',platform.machine()+'-apple-macos14.0',
  str(ROOT/'Sources/SignalIPTVImport.swift'),str(ROOT/'Sources/PlainHTTPClient.swift'),str(ROOT/'Sources/SportsChannelClassifierManager.swift'),
  str(ROOT/'Sources/SportsCenterViewModel.swift'),str(ROOT/'Tests/F82IPTV/Integration.swift'),'-o',str(executable)],check=True,timeout=120)
 subprocess.run([str(executable)],check=True,timeout=60)
 sdk=subprocess.check_output(['xcrun','--sdk','appletvos','--show-sdk-path'],text=True).strip()
 subprocess.run(['xcrun','--sdk','appletvos','swiftc','-swift-version','5','-typecheck','-sdk',sdk,
  '-target','arm64-apple-tvos18.0',str(ROOT/'Sources/SignalIPTVImport.swift'),str(ROOT/'Sources/PlainHTTPClient.swift'),str(ROOT/'Sources/SignalIPTVImportView.swift')],check=True,timeout=120)
print('F82 native executable checks and actual organizer tvOS SDK typecheck PASS')
