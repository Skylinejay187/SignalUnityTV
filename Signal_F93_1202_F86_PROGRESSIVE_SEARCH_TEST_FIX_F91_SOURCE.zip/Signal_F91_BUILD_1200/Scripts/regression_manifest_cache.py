"""Cache parsed manifest bytes, never source-validation results. Edits invalidate immediately."""
from pathlib import Path
from functools import lru_cache
import json

@lru_cache(maxsize=512)
def _read(path, mtime_ns, ctime_ns, size):
    return json.loads(Path(path).read_text())

def read_manifest(path):
    path = Path(path).resolve()
    stat = path.stat()
    return _read(str(path), stat.st_mtime_ns, stat.st_ctime_ns, stat.st_size)
