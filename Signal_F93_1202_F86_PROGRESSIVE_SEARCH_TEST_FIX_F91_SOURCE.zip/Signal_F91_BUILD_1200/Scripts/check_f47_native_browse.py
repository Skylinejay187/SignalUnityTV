#!/usr/bin/env python3
"""Compile real player enums/navigation order with native policy tests on macOS."""
from pathlib import Path
import argparse,subprocess,tempfile,shutil
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]
def fixture():
    app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    destination=block(app,'private enum PlaybackUnityCatalogDestination:')
    player=block(app,'struct VODPlayerScreen: View')
    controls=block(player,'enum PlayerControl:')
    order=block(player,'    private var primaryControlOrder:')
    return 'import Foundation\n'+destination+'''\nstruct PlaybackControlCompileFixture {
    let isLivePlayback: Bool
'''+controls+'\n'+order+'''
    static func verify() {
        let vod = Self(isLivePlayback: false).primaryControlOrder
        let live = Self(isLivePlayback: true).primaryControlOrder
        precondition(vod.contains(.television) && vod.contains(.playerSearch))
        precondition(live.contains(.quickGuide) && live.contains(.playerSearch) && !live.contains(.television))
        precondition(Set(vod).count == vod.count && Set(live).count == live.count)
        precondition(PlaybackUnityCatalogDestination.search.title == "Search")
        precondition(PlaybackUnityCatalogDestination.movies.catalogFilter == "movie")
        precondition(PlaybackUnityCatalogDestination.shows.catalogFilter == "series")
        precondition(PlaybackUnityCatalogDestination.allCases.count == 3)
    }
}
'''
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--emit',type=Path);args=parser.parse_args()
    text=fixture()
    if args.emit:args.emit.write_text(text);return
    compiler=shutil.which('swiftc')
    if not compiler:raise SystemExit('Swift compiler required for F47 native tests')
    with tempfile.TemporaryDirectory(prefix='signal-f47-') as d:
        source=Path(d)/'PlaybackFixture.swift';source.write_text(text);exe=Path(d)/'tests'
        subprocess.run([compiler,'-swift-version','5',str(source),str(ROOT/'Sources/SignalDashboardMode.swift'),
                        str(ROOT/'Sources/SignalPlaybackBrowsePolicy.swift'),str(ROOT/'Tests/SignalF47BrowseTests.swift'),'-o',str(exe)],check=True)
        subprocess.run([str(exe)],check=True)
if __name__=='__main__':main()
