"""Verify preserved F87 snapshots and explicitly pinned post-F87 F91 sources.
This supplements, rather than rewrites, the original F87 manifests.
"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def check():
    current=json.loads((ROOT/'Tests/F91ApprovedPostF87Hashes.json').read_text())
    assert len(current)==10, 'Expected ten reviewed post-F87 paths'
    f87={}
    for name in ('F87ApprovedSourceDeltas','F87NewSourceHashes','F87UnchangedSourceHashes'):
        data=json.loads((ROOT/'Tests'/ (name+'.json')).read_text())
        for path,rec in data.items():f87[path]=rec['after_sha256'] if isinstance(rec,dict) else rec
    for path,digest in f87.items():
        original=ROOT/'Tests/F91InheritedF87Baseline'/path if path in current else ROOT/path
        assert original.is_file() and sha(original)==digest, 'F87 baseline changed: '+path
    for path,digest in current.items():
        assert (ROOT/path).is_file() and sha(ROOT/path)==digest, 'Unreviewed post-F87 source change: '+path
    player=(ROOT/'Sources/SignalSportsOnlinePlayer.swift').read_text()
    for token in ('store.startPlayback(item: live, url: resolved.url','headers: resolved.headers','handedOff = true; resourceClaimed = false'):
        assert token in player, 'Sports handoff missing: '+token
    for token in ('PlaybackKitAetherHost(', 'AVPlayer('):
        assert token not in player, 'Unexpected secondary sports player: '+token
    app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    for token in ('struct SportsFoundationQuickPanelSurface: View','struct GridOSCatalogOverlay: View','struct VODPlayerScreen: View'):
        assert token in app, 'Required surface missing: '+token
    print('F91 inherited F87 historical hashes + 10 pinned post-F87 sources + sports contracts PASS')
if __name__=='__main__':check()
