#!/usr/bin/env python3
"""Bound the stronger preview transform and preserve reveal, navigation and safety."""
from pathlib import Path
import hashlib,json,re
from check_f31_top_menu_regression import block
from f50_approved_deltas import previous_source
from f51_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    changes=json.loads(historical_source(ROOT/'Tests/F50ApprovedSourceDeltas.json'))
    assert set(changes)=={'Sources/DebridChannelsTVOSApp.swift','Sources/SignalLiveTVCardEffect.swift','Tests/SignalF48SafetyTests.swift'}
    for name,record in changes.items():
        text=historical_source(ROOT/name);assert hashlib.sha256(text.encode()).hexdigest()==record['after_sha256'];previous_source(text,name)
    for name,sha in json.loads(historical_source(ROOT/'Tests/F50UnchangedSourceHashes.json')).items():
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==sha,name
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift');old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    # This edit changes only the motion-host lift argument and Settings explanation.
    old_call='SignalLiveTVCardMotion.lift(focused: isFocused, reduceMotion: reduceMotion)'
    new_call='SignalLiveTVCardMotion.lift(focused: isFocused, preview: previewPopOut, reduceMotion: reduceMotion)'
    old_text='Standard keeps the current in-card preview. Pop Out lifts the focused card slightly farther forward only after live preview actually starts; normal browsing geometry stays unchanged.'
    new_text='Standard gives the focused card a gentle lift. Pop Out raises the live preview farther toward you with a larger 9% scale and eight-point lift, only after video is ready. Both use the same quick transition; card positions and navigation stay fixed.'
    assert app.replace(new_call,old_call).replace(new_text,old_text)==old
    host=block(app,'private struct LiveTVGridFocusMotionHost<Content: View>')
    prior=block(old,'private struct LiveTVGridFocusMotionHost<Content: View>')
    assert host.replace(new_call,old_call)==prior
    assert '.easeOut(duration: 0.14), value: isFocused' in host
    assert '.easeOut(duration: 0.18), value: previewPopOut' in host
    for forbidden in ('Timer(', 'Task.sleep(', 'repeatForever', '.spring(', '.blur(', '.drawingGroup('):assert forbidden not in host
    for marker in ('struct VODPlayerScreen: View','struct GlobalSearchScreen: View','private struct SignalLiveTVThemeConfirmationScreen: View'):
        assert block(app,marker)==block(old,marker),marker
    live=block(app,'struct LiveTVScreen: View');previous_live=block(old,'struct LiveTVScreen: View')
    assert live==previous_live,'Reveal/preview-decoder/navigation/slot geometry must remain unchanged'
    assert 'previewPopOut: gridFocusPreviewReadyChannelID == channel.id && LiveTVGridPreviewStyle.normalized(liveTVGridFocusPreviewStyle) == "Pop Out"' in live
    effect=historical_source(ROOT/'Sources/SignalLiveTVCardEffect.swift');motion=block(effect,'enum SignalLiveTVCardMotion {')
    assert 'guard focused, !reduceMotion else { return 1 }' in motion
    assert 'guard focused, !reduceMotion else { return 0 }' in motion
    pop,standard=map(float,re.search(r'return preview \? ([\d.]+) : ([\d.]+)',motion).groups())
    pop_lift,standard_lift=map(float,re.search(r'return preview \? (-[\d.]+) : (-[\d.]+)',motion).groups())
    assert 1.018<standard<1.03<pop<=1.10 and pop_lift<standard_lift<-2
    # At supported logical TV widths and every size, the raised card's horizontal
    # edge stays inside the existing 40pt screen inset. Overlap of grid gutters is
    # intentional foreground presentation, never a re-layout of the focus targets.
    for width in (1280,1600,1920):
        for split in (False,True):
            card_width=(width-80-(4 if split else 3)*29-(46 if split else 0))/4
            for size in (.90,1,1.04):
                overhang=max(0,(card_width*size*pop-card_width)/2)
                assert overhang<40,(width,split,size,overhang)
    print('F50 PASS: stronger Standard/Pop Out scale+lift; same focus/reveal transitions; no extra rendering owners; screen-edge bounds; complete grid/player/safety implementation preserved')
if __name__=='__main__':verify()
