#!/usr/bin/env python3
"""Evaluate the production Swift scalar layout expressions; report analytic budgets.
This is a numeric/source audit, not Swift execution or measured GPU/CPU performance.
"""
from pathlib import Path
import re,math,json
ROOT=Path(__file__).resolve().parents[1]
TOKEN=re.compile(r'\s*(==|!=|<=|>=|[?:()+*/<>,\-]|\d+(?:\.\d+)?|[A-Za-z_]\w*)')
class Expression:
    def __init__(self,text,values):
        self.tokens=TOKEN.findall(text);self.i=0;self.values=values
    def take(self):t=self.tokens[self.i];self.i+=1;return t
    def peek(self):return self.tokens[self.i] if self.i<len(self.tokens) else None
    def conditional(self):
        c=self.binary(0)
        if self.peek()=='?':
            self.take();a=self.conditional();assert self.take()==':'
            b=self.conditional();return a if c else b
        return c
    def binary(self,minimum):
        a=self.atom();precedence={'==':1,'!=':1,'<':1,'>':1,'<=':1,'>=':1,'+':2,'-':2,'*':3,'/':3}
        while self.peek() in precedence and precedence[self.peek()]>=minimum:
            op=self.take();b=self.binary(precedence[op]+1)
            a={'==':lambda:a==b,'!=':lambda:a!=b,'<':lambda:a<b,'>':lambda:a>b,'<=':lambda:a<=b,'>=':lambda:a>=b,
               '+':lambda:a+b,'-':lambda:a-b,'*':lambda:a*b,'/':lambda:a/b}[op]()
        return a
    def atom(self):
        t=self.take()
        if t=='-':return -self.atom()
        if t=='(':
            a=self.conditional();assert self.take()==')';return a
        if t[0].isdigit():return float(t)
        if t in ('true','false'):return t=='true'
        if self.peek()=='(':
            self.take();args=[self.conditional()]
            while self.peek()==',':self.take();args.append(self.conditional())
            assert self.take()==')'
            return {'min':min,'max':max,'Double':float,'rows':lambda n:4 if n==4 else 3}[t](*args)
        return self.values[t]
def value(expr,values):
    p=Expression(expr,values);v=p.conditional();assert p.peek() is None,(expr,p.tokens[p.i:]);return v

def audit():
    source=(ROOT/'Sources/SignalLiveTVResourcePolicy.swift').read_text()
    body=source.split('    static func cardHeight(',1)[1].split('\n    }',1)[0]
    assignments=re.findall(r'^        let (\w+) = (.+)$',body,re.M)
    returns=re.findall(r'^\s*return (.+)$',body,re.M)
    assert len(returns)==2
    cases=0
    for width,height in [(1280,720),(1920,1080),(3840,2160)]:
        for rows in [3,4]:
            for mirror in [False,True]:
                for spread in [False,True]:
                    for expanded in [False,True]:
                        for split in [False,True]:
                            variables={'width':width,'height':height,'value':rows,'mirror':mirror,'spread':spread,'expanded':expanded,'split':split}
                            for name,expr in assignments:variables[name]=value(expr,variables)
                            h=value(returns[0] if mirror else returns[1],variables)
                            assert math.isfinite(h) and h>0
                            assert rows*h+(rows-1)*variables['rowGap']+variables['reserved']<=height+1e-6
                            if rows==4:
                                w=h*16/9
                                total=4*w+(4 if split else 3)*variables['columnGap']+(46 if split else 0)+variables['horizontal']
                                assert total<=width+1e-6
                                # All four rows repeat precisely the same width, height, gap and center.
                                top=(height-variables['reserved']-(rows*h+(rows-1)*variables['rowGap']))/2
                                ys=[top+r*(h+variables['rowGap']) for r in range(rows)]
                                assert all(abs(ys[i+1]-ys[i]-h-variables['rowGap'])<1e-6 for i in range(rows-1))
                            cases+=1
    budgets={
        'layout_expression_cases':cases,
        'guide_window_channels':48,
        'nominal_artwork_soft_limits_MiB':{
            'F42_Signal_decoded':376,'F42_encoded_URLCache':96,
            'F42_default_Kingfisher_on_2GiB_device':512,
            'F42_sum_example':984,
            'F43_Signal_decoded':220,'F43_encoded_URLCache':24,'F43_Kingfisher':8,'F43_sum':252},
        'RGBA_texture_MiB':{
            'one_3840x2160_intermediate':3840*2160*4/2**20,
            'two_640x360_wallpaper_images':2*640*360*4/2**20,
            'sixteen_192x108_frosted_card_fills':16*192*108*4/2**20,
            'two_256x256_smoke_textures':2*256*256*4/2**20},
        'notes':['Soft cache limits are targets, not process footprint bounds. Shared image references can overlap between reservoirs.',
                 'The 4K figure is arithmetic for one RGBA intermediate; no count of actual GPU intermediates is claimed.',
                 'No local Apple TV CPU/GPU/footprint measurements were possible. Native tests and SDK typechecks are wired into CI.']}
    (ROOT/'F43_RESOURCE_MATH.json').write_text(json.dumps(budgets,indent=2)+'\n')
    print(f'F43 math audit PASS: {cases} production-expression layouts; 3/4 rows, all spacing/split modes; 16:9 4-row cells fit; finite equal gutters; analytic resource budgets emitted')
if __name__=='__main__':audit()
