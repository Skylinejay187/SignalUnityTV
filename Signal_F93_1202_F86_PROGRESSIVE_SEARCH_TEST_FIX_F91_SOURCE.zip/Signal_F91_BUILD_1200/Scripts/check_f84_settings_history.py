"""Validate actual settings separately from older, precisely reconstructed trees."""
from pathlib import Path
import re
from f83_approved_deltas import previous_source

ROOT = Path(__file__).resolve().parents[1]
SYMBOLIC = {
    'TraktSyncManager.enabledDefaultsKey': 'traktResumeSyncEnabledV1',
    'DebridNowShowingDirectPushManager.serverURLDefaultsKey': 'debridNowShowingServerURLV1',
    'DebridNowShowingDirectPushManager.pushTokenDefaultsKey': 'debridNowShowingPushTokenV1',
    'DebridNowShowingDirectPushManager.statusDefaultsKey': 'debridNowShowingPushStatusV1',
}

def audit_preferences(registry, sources):
    defaults = registry.split('static let defaults: [String: Any] = [', 1)[1].split('\n    ]', 1)[0]
    exclusions = registry.split('static let excludedKeys: Set<String> = [', 1)[1].split('\n    ]', 1)[0]
    portable = set(re.findall(r'"([^"\\]+)"\s*:', defaults))
    excluded = set(re.findall(r'"([^"\\]+)"', exclusions))
    observed = set()
    for text in sources:
        observed.update(re.findall(r'@AppStorage\("([^"\\]+)"\)', text))
        for expression in re.findall(r'@AppStorage\(([^)\n]+)\)', text):
            assert expression.startswith('"') or expression in SYMBOLIC, 'Unclassified symbolic setting: ' + expression
            if expression in SYMBOLIC:
                observed.add(SYMBOLIC[expression])
    assert not portable & excluded
    assert observed <= portable | excluded, sorted(observed - portable - excluded)
    assert 'sportsWidgetStyleV1' in observed & portable
    return len(observed)

def verify():
    registry = (ROOT / 'Sources/SignalPortableSettings.swift').read_text()
    sources = [p.read_text() for p in (ROOT / 'Sources').rglob('*.swift')]
    count = audit_preferences(registry, sources)
    # Negative control: deleting the widget's backup mapping must still fail.
    try:
        audit_preferences(registry.replace('"sportsWidgetStyleV1": "Glass",', ''), sources)
    except AssertionError:
        pass
    else:
        raise AssertionError('Missing Sports backup mapping accepted')
    name = 'Sources/SignalSportsScoreboard.swift'
    source = (ROOT / name).read_text()
    assert previous_source(source, name) == ''
    assert previous_source(previous_source(source, name), name) == ''
    # Historical omission must never hide a modification to a new file.
    try:
        previous_source(source + '\n// unreviewed change\n', name)
    except AssertionError:
        pass
    else:
        raise AssertionError('Modified new source accepted by historical view')
    assert previous_source('unregistered source', 'Sources/Unregistered.swift') == 'unregistered source'
    print(f'F84 current settings PASS: {count} AppStorage keys classified, Sports style portable; exact new-file history and two negative controls PASS')

if __name__ == '__main__':
    verify()
