"""Current Unity compositing and shared Sports playback contracts, exact source scope."""
from pathlib import Path
import json,hashlib
from check_f31_top_menu_regression import block
from source_hash_integrity import verify_unchanged_sources
from f87_approved_deltas import historical_source,previous_source
ROOT=Path(__file__).resolve().parents[1]
def check():
    for name,record in json.loads((ROOT/'Tests/F87ApprovedSourceDeltas.json').read_text()).items():
        baseline=ROOT/'Tests/F91InheritedF87Baseline'/name
        source=(baseline if baseline.is_file() else ROOT/name).read_text()
        assert hashlib.sha256(source.encode()).hexdigest()==record['after_sha256'],name
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==record['before_sha256'],name
        try:previous_source(source+'\n// unreviewed mutation\n',name)
        except AssertionError:pass
        else:raise AssertionError('Accepted changed source: '+name)
    for name,digest in json.loads((ROOT/'Tests/F87NewSourceHashes.json').read_text()).items():
        baseline=ROOT/'Tests/F91InheritedF87Baseline'/name
        assert hashlib.sha256((baseline if baseline.is_file() else ROOT/name).read_bytes()).hexdigest()==digest,name
    # F91's independent verifier checks preserved F87 snapshots and pinned current files.
    from check_f91_inherited_f87 import check as verify_f91_history
    verify_f91_history()
    current_app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    app=(ROOT/'Tests/F91InheritedF87Baseline/Sources/DebridChannelsTVOSApp.swift').read_text();old=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
    for marker in ['struct LiveTVScreen: View','struct GridOSFixedSlotCatalogRail: View','struct GlobalSearchScreen: View','struct MediaInfoPopup: View','struct FocusedSidewaysCardEffect:']:
        assert block(app,marker)==block(old,marker),marker
    current=block(app,'struct VODPlayerScreen: View');prior=block(old,'struct VODPlayerScreen: View')
    # The actual standard player owns controls, engine setup and timeshift unchanged.
    for marker in ['    private var liveTVControlChipRow:', '    private var liveTimeshiftCacheBar:', '    private func setupPlayer(', '    private func setupVerifiedPlayer(']:
        assert block(current,marker)==block(prior,marker),marker
    channel=block(current,'    private var liveOverlayCurrentChannel:')
    assert 'if isOnlineSportsPlayback' in channel and 'item.posterURL' in channel
    assert 'return currentLiveQuickGuideChannel ?? liveQuickGuideSelectedChannel' in channel
    assert 'guard !isOnlineSportsPlayback' in block(current,'    private var liveOverlayNextProgram:')
    catalog=block(app,'struct GridOSCatalogOverlay: View')
    assert '.mask(SignalUnityDashboardHeaderMask(height: geo.size.height))' in catalog
    assert 'SignalUnityDashboardShade(hero: true)' in catalog
    assert 'if useArtwork3Hero { return 0.08 }' in catalog and 'if useArtwork3Hero { return 0.14 }' in catalog
    sports=block(app,'struct SportsFoundationQuickPanelSurface: View')
    assert 'SignalUnityDashboardShade(hero: style == "Artwork 3 Hero")' in sports
    assert '.mask(SignalUnityDashboardHeaderMask(height: size.height))' in sports
    for token in ['restoreSportsSelection()', 'SignalSportsBrowseMemory.rowID = row.id', 'SignalSportsBrowseMemory.itemID = item.id']:
        assert token in sports,token
    player=(ROOT/'Tests/F91InheritedF87Baseline/Sources/SignalSportsOnlinePlayer.swift').read_text()
    for token in ['store.startPlayback(item: live, url: resolved.url','headers: resolved.headers','type: "live"','id: "live-sports-web:"','artwork: item.posterURL','handedOff = true; resourceClaimed = false','resourceClaimed && !handedOff','store.playbackPresentationID != previousSession']:
        assert token in player,token
    for token in ['PlaybackKitAetherHost(', 'AVPlayer(', 'onPlayPauseCommand','repeatForever','scoreRefreshKey']:
        assert token not in player,token
    assert player.count('MembershipEntitlementManager.isCurrentDeviceLocked()')>=3
    router=(ROOT/'Sources/MediaFlowProxyRouter.swift').read_text();routerOld=historical_source(ROOT/'Sources/MediaFlowProxyRouter.swift')
    m='    static func routingSnapshot('
    assert router.replace(block(router,m),block(routerOld,m),1)==routerOld,'Unrelated routing change'
    method=block(router,m)
    assert 'kind == .liveTV' in method and 'sourceURL.scheme == "https"' in method
    assert 'sourceURL.user == nil, sourceURL.password == nil, sourceURL.port == nil' in method
    assert 'enabled: false' in method
    registry=(ROOT/'Tests/F91InheritedF87Baseline/Sources/SignalPortableSettings.swift').read_text()
    assert '"sportsBackdropStyleV1": "Dimmed Dashboard"' in registry
    print('F87 scope/contracts PASS: shared dashboard header, static shades + portable Sports styles, standard Live TV Sports handoff/artwork, unchanged controls/timeshift/engine, scoped device egress, cancellation/membership/return focus')
if __name__=='__main__':check()
