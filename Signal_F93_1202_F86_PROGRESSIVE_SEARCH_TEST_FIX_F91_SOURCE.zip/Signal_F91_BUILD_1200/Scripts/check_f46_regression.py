#!/usr/bin/env python3
"""F46 source contracts and interval/focus geometry, not device-rendering claims."""
from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from f46_approved_deltas import previous_source
from f47_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    for name,record in json.loads((ROOT/'Tests/F46ApprovedSourceDeltas.json').read_text()).items():
        s=historical_source(ROOT/name);assert hashlib.sha256(s.encode()).hexdigest()==record['after_sha256'];previous_source(s,name)
    for name,sha in json.loads((ROOT/'Tests/F46UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==sha,name
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift');old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    assert block(app,'struct VODPlayerScreen: View')==block(old,'struct VODPlayerScreen: View'),'Up Next/VOD behavior scope'
    live=block(app,'struct LiveTVScreen: View')
    assert 'private var liveTVGridPageSize: Int { 12 }' in live
    grid=block(live,'    private func liveGridContent(')
    assert 'rows: 3' in grid and 'if liveTVGridRows != 3 { liveTVGridRows = 3 }' in grid
    assert 'liveTVGridPageSize == 16' not in grid
    preview=block(app,'private struct SignalLiveTVThemeConfirmationScreen: View')
    assert 'Rows:' not in preview and 'draftRows' not in preview and 'selectedRows' not in preview
    motion=block(app,'private struct LiveTVGridFocusMotionHost<Content: View>')
    assert 'previewPopOut ? 1.03 : 1.018' in motion and 'guard !reduceMotion, isFocused' in motion
    assert 'easeOut(duration: 0.14)' in motion and 'repeatForever' not in motion
    rail=block(live,'    private func rollbackGoogleGuideCategoryRail(')
    assert 'YOUR CHANNELS' not in rail
    category=block(live,'    private func rollbackGoogleGuideCategoryRow(')
    assert 'selected ? 0.16 : 0.09' in category
    guide=block(live,'    private func guideView(')
    assert '.frame(width: 2, height: availableHeight)' in guide and '.focused($guideRailHandoffFocused)' in guide
    assert '.animation(' not in guide and '.transaction { $0.animation = nil }' in guide
    handoff=block(live,'    private func handoffGuideCategoryToTimeline(')
    assert 'SignalGuideNavigation.targetIndex' in handoff and 'nativeRowIndex' not in handoff
    assert 'guideTimelineRequestedID = target.id' in handoff and 'guideTimelineFocusRequest = UUID()' in handoff
    focus=block(live,'    private func focusRequestedGuideChannel(')
    assert focus.index('proxy.scrollTo') < focus.index('guideFocus = target')
    assert 'guideTimelineFocusRequest == request' in focus and 'guideTimelineRequestedID = nil' in focus
    timeline=block(live,'    private func guideTimelineCanvas(')
    assert 'ScrollViewReader' in timeline and '.onChange(of: guideTimelineFocusRequest)' in timeline
    row=block(live,'    private func googleGuideTimelineRow(')
    assert 'ForEach(slots)' in row and 'ForEach(timed)' not in row and 'axis.slots(entries)' in row
    assert '.focusable(guideCategoryRailCollapsed)' in row and '.focusEffectDisabled()' in row
    backdrop=block(live,'    private func liveBackground(').split('} else {',1)[0]
    assert 'Color(white: 0.24)' in backdrop and 'if liveVisualWorkActive' in backdrop
    assert 'maxPixelSize: 640, blurRadius: 16' in backdrop and 'PlaybackKitAetherHost(' not in backdrop
    assert 'aliases[self.normalizeGuideKey(key)]' in app
    assert 'Sources/SignalGuideNavigation.swift' in (ROOT/'project.yml').read_text()
    assert 'guideFocusHandoffTask?.cancel()' in block(app,'private final class LiveTVGridInteractionRuntime:')
    # Popup growth remains smaller than ordinary 28pt/25pt gutters for card bounds.
    assert 600*(1.018-1) < 28 and 340*(1.018-1) < 25
    print('F46 PASS: fixed 12-card grid; small bounded focus popup; neutral underlay/shared glass; default gray categories; full-height focus landing/scroll-before-focus; canonical non-overlapping EPG slots; VOD/Up Next unchanged')
if __name__=='__main__':verify()
