from regression_manifest_cache import read_manifest
"""Reverse only exact reviewed F35 source changes for historical baseline checks.
The original F31/F32 hash fixtures are never rebaselined. Every new hunk is unique.
Current F35 behavior is checked separately by check_f35_regression.py.
"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    from f36_approved_deltas import previous_source as previous_f36
    source=previous_f36(source,path)
    data=read_manifest(ROOT/'Tests/F35ApprovedSourceDeltas.json')
    if path not in data:return source
    record=data[path]
    assert hashlib.sha256(source.encode()).hexdigest()==record['after_sha256'],'Unreviewed post-F35 source change: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1,'Ambiguous reviewed hunk: '+path
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256']
    return source
