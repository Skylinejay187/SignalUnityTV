#!/usr/bin/env python3
"""Current F39 source contracts and exact unchanged-playback scope.
This is source evidence only. Swift/Xcode and physical remote tests remain required.
"""
from f40_approved_deltas import historical_source as f39_source
from f41_approved_deltas import historical_source as f40_source
from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from f39_approved_deltas import previous_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    records=json.loads(f39_source((ROOT/'Tests/F39ApprovedSourceDeltas.json')))
    for name,record in records.items():
        current=f39_source((ROOT/name))
        assert hashlib.sha256(current.encode()).hexdigest()==record['after_sha256'],name
        previous_source(current,name)
    app=f39_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    store=f39_source((ROOT/'Sources/CatalogStore.swift'))
    prior=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    # No VOD/player/autoplay/cast or Live TV page/decoder behavior changes in F39.
    vod=block(app,'struct VODPlayerScreen: View')
    assert vod==block(prior,'struct VODPlayerScreen: View'),'VOD player scope changed'
    for marker in ('    private func advanceLiveTVGridPage(', '    private func scheduleLiveTVGridFocusPreview(',
                   '    private func cancelLiveTVGridFocusPreview(', '    private func liveCarouselCard(',
                   '    private func playPreparedUpNextEpisode('):
        assert block(app,marker)==block(prior,marker),marker
    oldstore=previous_source(store,'Sources/CatalogStore.swift')
    for marker in ('    func prepareUpNextEpisodeSources(', '    private func upNextManifestLinks(',
                   '    private func upNextPreparedSelection('):
        assert block(store,marker)==block(oldstore,marker),marker
    for name,sha in json.loads(f39_source((ROOT/'Tests/F38UnchangedSourceHashes.json'))).items():
        if name=='Sources/SignalFocusOrder.swift':continue # explicit 2.0s request below
        assert hashlib.sha256(f40_source((ROOT/name)).encode()).hexdigest()==sha,name
    ownership=block(app,'    private var unityTopNavigationOwnsFocus:')
    assert '!store.catalogRowsPresented' not in ownership # negates catalog branch as one predicate
    assert '!(store.catalogRowsPresented && UnitySurfaceSystem.catalogBranchActive' in ownership
    assert '!unityCatalogBranchTransitionActive' in ownership
    nav=block(app,'struct TopMenuBar: View')
    assert 'store.beginCatalogMenuEntry()' in nav
    assert 'guard shellVisible, !store.catalogRowsPresented' in nav
    entry=block(store,'    func beginCatalogMenuEntry(')
    assert 'catalogEntryFocusToken &+= 1' in entry and 'quickPanelRestoreRowID = nil' in entry
    focus=block(app,'    private func scheduleQuickPanelFocusRestore(')
    assert '!surfaceHandoffActive' in focus and 'consumedCatalogEntryFocusToken != store.catalogEntryFocusToken' in focus
    assert 'focusedRow = nil' in focus and 'focusedRow = 0' in focus
    assert 'consumedCatalogEntryFocusToken = store.catalogEntryFocusToken' in focus
    assert 'catalog transition enabled' in app
    assert nav.count('.frame(width: 42, height: 42)')==2
    assert 'mirrorSearchTitleFrame.minY - geo.frame(in: .global).minY - 35' in nav
    assert 'SignalMirrorCategoryFrameKey.self' in block(app,'private struct SignalLiveTVMirrorHeader<ModeChip: View>')
    glyph=f39_source((ROOT/'Sources/SignalSearchGlyph.swift'))
    assert 'TimelineView' not in glyph and 'CABasicAnimation' in glyph
    assert 'override var canBecomeFocused: Bool { false }' in glyph
    assert 'dismantleUIView' in glyph and 'if window == nil { stop() }' in glyph
    assert 'removeAllAnimations()' in glyph and 'scenePhase == .active && !reduceMotion' in glyph
    assert '.accessibilityLabel("Search")' in nav
    card=block(app,'struct SearchResultCard: View')
    assert 'height: 278, alignment: .topLeading' in card
    assert 'FocusedSidewaysCardEffect' not in card
    search=block(app,'struct GlobalSearchScreen: View')
    assert '@State private var liveResults:' in search and 'private var liveResults: [LiveTVChannel] {' not in search
    assert 'Task.detached(priority: .userInitiated)' in search
    assert 'channelMatches = await withTaskCancellationHandler' in search
    assert 'localResults: local' in search and 'token == unifiedSearchToken' in search
    assert '.focused($queryFieldFocused)' in search and 'guard !queryFieldFocused' in search
    assert 'store.selectedDetail == nil' in block(search,'    private func scheduleUnifiedSearch(')
    local=block(store,'    private func localUnifiedSearchResults(')
    assert 'Task.detached' in local and 'onCancel: { worker.cancel() }' in local
    for marker in ('    private func decodeBuiltInUnifiedSearchPayload(',
                   '    private func cinemetaUnifiedSearchResults(for query: String, type: String)',
                   '    func tmdbSearchResults('):
        assert 'Task.detached' in block(store,marker),marker
    bg=f39_source((ROOT/'Sources/SignalBackgroundVisuals.swift'))
    assert bg.index('Rectangle().fill(MainGridBackgroundStyle.glassColor') < bg.index('SignalGlassAtmosphere(')
    smoke=f39_source((ROOT/'Sources/SignalGlassAtmosphereVisuals.swift'))
    assert 'frameInterval' in smoke and 'billowTint' in smoke
    budget=block(app,'    private var liveDecorativeSurfacesOwnRenderBudget:')
    for guard in ('!store.catalogRowsPresented','!store.searchActive','!showGuide','store.playbackURL == nil','scenePhase == .active'):
        assert guard in budget,guard
    assert 'gridFocusPreviewChannelID == nil' not in budget
    assert '1.0 / 15.0 : 1.0 / 8.0' in app
    timing=f39_source((ROOT/'Sources/SignalFocusOrder.swift'))
    assert 'revealHoldSeconds: TimeInterval = 2.0' in timing
    assert 'dwellNanoseconds: UInt64 = 650_000_000' in timing
    assert 'frameReady && holdElapsed' in timing
    print('F39 current checks passed: catalog first-row ownership; post-transition focus; title-anchored 42pt Search; native-layer animation lifecycle; cancellable off-main matching/decoding; visible 15/8 FPS smoke; 2.0s frame-ready reveal')
    print('F39 unchanged scope: entire VODPlayerScreen, Up Next discovery/selection, Aether bridge/host, Carousel actions and page destination math')
if __name__=='__main__':verify()
