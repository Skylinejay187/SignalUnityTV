#!/usr/bin/env python3
"""Run production pause policy; SDK-check the actual view and VOD metadata mapping."""
from pathlib import Path
import argparse, re, shutil, subprocess, tempfile
from check_f31_top_menu_regression import block
ROOT = Path(__file__).resolve().parents[1]

def validate_fixture(source):
    """Reject missing standalone Boolean gate inputs before invoking the SDK."""
    mapping = block(source, '    private var pausedPlaybackInformation:')
    # Qualified members (store/runtime/scenePhase) are supplied by their test doubles.
    required = set(re.findall(r'!(\w+)\b(?!\.)', mapping))
    required.update(re.findall(r'&& (\w+)\s*(?=\n|&&)', mapping))
    declared = set(re.findall(r'\bvar (\w+)\s*=', source))
    missing = required - declared
    if missing:
        raise ValueError('Pause mapping fixture is missing gate state: ' + ', '.join(sorted(missing)))
    return source

def fixture():
    app = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    declarations = '''import SwiftUI
struct PauseMediaFixture {
    var title = "", description = ""
    var seasonNumber: Int?, episodeNumber: Int?
    var logoURL: String?
}
enum CatalogArtworkCacheManager { static func themedLogoURL(for item: PauseMediaFixture) -> String? { item.logoURL } }
struct Artwork4HeroLogoLayer: View {
    let item: PauseMediaFixture
    let logoURL: String?
    var publishDuringPlayback = false
    var body: some View { Text(item.title) }
}
struct PauseThemeFixture { var accent: Color { .orange } }

@MainActor final class PauseStoreFixture {
    var playbackPresentationID = UUID()
    var playbackURL: URL?
}
@MainActor final class PauseRuntimeFixture { var naturalEpisodeTransitionActive = false }
@MainActor struct VODPauseMappingFixture: View {
    @Environment(\\.scenePhase) var scenePhase
    let store = PauseStoreFixture(), vodAsyncRuntime = PauseRuntimeFixture()
    var playbackMetadataItem: PauseMediaFixture?
    var item = PauseMediaFixture()
    var overlayItem: PauseMediaFixture { playbackMetadataItem ?? item }
    var vodOverlayThemePreset = PauseThemeFixture()
    var playbackPresentationID = UUID()
    var url = URL(string: "https://example.invalid/video")!
    var activePlaybackURL: URL?
    var errorText: String?
    var playbackUnityCatalogDestination: String?, activePanel: String?, castExplorerMember: String?
    var pendingVODSwitchItem: PauseMediaFixture?
    var pauseRemoteActivity: UInt64 = 0
    var ksSurfaceToken = 1
    var resolvedDurationSeconds = 3600.0, remainingSeconds = 3000.0, authoritativeCurrentSeconds = 600.0
'''
    flags = ('isLivePlayback isFirstFrameReady isLoading ksLoadingCoverActive isDismissingPlayer '
             'protectedRouteStopped protectedRouteRecheckInProgress vodEpisodeBrowserVisible '
             'upNextVisible upNextCinematicVisible upNextPlaybackStarting resumeVODAfterTrailerExclusivePlayback '
             'liveQuickGuideVisible isScrubbingTimeline isSeekingInPlayer isPlaying episodeSettingsPresented stillWatchingPresented').split()
    declarations += '\n'.join('    var '+flag+' = false' for flag in flags)+'\n'
    return validate_fixture(declarations + block(app, '    private var pausedPlaybackTitle:') + '\n' + block(app, '    private var pausedPlaybackInformation:') + '\n    var body: some View { pausedPlaybackInformation }\n}\n')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--emit', type=Path);args=parser.parse_args()
    if args.emit:
        args.emit.write_text(fixture());return
    if not shutil.which('swiftc'):
        raise SystemExit('Swift compiler and Apple tvOS SDK required for F63 native checks')
    policy = ROOT/'Sources/SignalPauseInfoPolicy.swift'
    with tempfile.TemporaryDirectory(prefix='signal-f63-') as directory:
        directory=Path(directory);executable=directory/'pause-tests'
        subprocess.run(['swiftc','-swift-version','5',str(policy),str(ROOT/'Tests/SignalF63PauseInfoTests.swift'),'-o',str(executable)],check=True,timeout=60)
        subprocess.run([str(executable)],check=True,timeout=10)
        src=directory/'PauseMapping.swift';src.write_text(fixture())
        sdk=subprocess.check_output(['xcrun','--sdk','appletvos','--show-sdk-path'],text=True).strip()
        subprocess.run(['xcrun','--sdk','appletvos','swiftc','-typecheck','-swift-version','5','-sdk',sdk,
                        '-target','arm64-apple-tvos18.0',str(policy),str(ROOT/'Sources/SignalPausedPlaybackInfoOverlay.swift'),str(src)],check=True,timeout=90)
    print('F63 production pause policy executable and actual SwiftUI/VOD mapping SDK checks PASS; Apple TV behavior still requires a device')

if __name__=='__main__':main()
