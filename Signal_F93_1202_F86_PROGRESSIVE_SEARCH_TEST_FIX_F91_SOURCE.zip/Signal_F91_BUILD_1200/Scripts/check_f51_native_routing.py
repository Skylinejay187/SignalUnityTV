#!/usr/bin/env python3
"""Real router/home proof plus uniform projection tests; no real account requests."""
from pathlib import Path
import argparse,shutil,subprocess,tempfile
from check_f48_native_safety import fixture
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]
def ui_fixture():
    app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    return 'import SwiftUI\nimport QuartzCore\n'+block(app,'private struct SignalUniformAlignedCardGeometry:')+'\n'+block(app,'private struct SignalLiveTVCardPoseModifier:')+'\n'
def main():
    p=argparse.ArgumentParser();p.add_argument('--emit',type=Path);a=p.parse_args()
    if a.emit:a.emit.write_text(ui_fixture());return
    compiler=shutil.which('swiftc')
    if not compiler:raise SystemExit('Swift compiler required for F51 native checks')
    with tempfile.TemporaryDirectory(prefix='signal-f51-') as directory:
        d=Path(directory);interfaces=d/'Router.swift';interfaces.write_text(fixture());exe=d/'tests'
        sources=['SignalMediaFlowSafetyPolicy.swift','SignalProtectedNetworkState.swift','SignalLiveTVCardEffect.swift','SignalLiveTVCardAlignment.swift']
        subprocess.run([compiler,'-swift-version','5',str(interfaces)]+[str(ROOT/'Sources'/s) for s in sources]+
            [str(ROOT/'Tests/SignalF51RoutingAlignmentTests.swift'),'-o',str(exe)],check=True,timeout=60)
        subprocess.run([str(exe)],check=True,timeout=45)
        ui=d/'AlignedGeometry.swift';ui.write_text(ui_fixture())
        sdk=subprocess.check_output(['xcrun','--sdk','appletvos','--show-sdk-path'],text=True).strip()
        subprocess.run(['xcrun','--sdk','appletvos','swiftc','-typecheck','-swift-version','5','-sdk',sdk,
            '-target','arm64-apple-tvos17.0',str(ui),str(ROOT/'Sources/SignalLiveTVCardEffect.swift'),
            str(ROOT/'Sources/SignalLiveTVCardAlignment.swift')],check=True,timeout=60)
    print('F51 native and real tvOS geometry typecheck passed')
if __name__=='__main__':main()
