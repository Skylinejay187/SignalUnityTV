#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,re
from check_f31_top_menu_regression import block
from f72_approved_deltas import previous_source
from f73_approved_deltas import historical_source
from f73_approved_deltas import historical_source
from f73_approved_deltas import historical_source
from f73_approved_deltas import historical_source
from f73_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def audit(app,view,settings,policy,portable,store):
    chip=app[app.index('let selected = selectedSeasonNumber == season'):][:1400]
    assert 'selected ? .white :' in chip and 'selected ? Color(red: 0.82, green: 0.08, blue: 0.14)' in chip
    assert 'selected ? .white.opacity(0.94)' not in chip
    for key in ['pauseInfoShowDelayV1','pauseInfoHideDelayV1','pauseInfoThemeV1']:
        assert key in view and key in settings and key in portable,key
    for token in ('showDelay = 1.5','hideDelay = 1.5','.task(id: transitionKey)',
                  'nanoseconds: key.show','nanoseconds: key.hide','SignalPauseInfoPolicy.mayDismiss',
                  'SignalPauseInfoPolicy.sameOwner','if revealed, let owner = displayOwner',
                  'guard !Task.isCancelled else { return }','.easeInOut(duration: 0.65)',
                  'request.paused ? "PAUSED" : "NOW PLAYING"', '.allowsHitTesting(false)',
                  'if revealed {','TimelineView(.periodic(from: .now, by: 30))'):
        assert token in view,token
    for forbidden in ('AVPlayer','AetherEngine','URLSession','NotificationCenter','Button(','.blur('):assert forbidden not in view,forbidden
    assert '1_500_000_000' in policy and 'seconds.isFinite' in policy
    assert 'Signal Glass' in view and 'Cinema' in view and 'Minimal' in view and '.serif' in view
    assert 'details.synopsis' not in view
    # Follow MAIN-screen call paths, not just the playback catalog overlay.
    live=block(app,'struct LiveTVScreen: View')
    assert 'liveModel.currentProgram(for: channel)' in block(live,'    private func liveTile(')
    current=block(app,'    func currentProgram(for channel:')
    assert 'currentProgramCache[channel.id]' in current and 'programs(for: channel)' in current
    rows=block(app,'    func programs(for channel:')
    assert 'resolvedGuideRows.value(for: channel)' in rows
    assert 'SignalGuideMetadataCache<LiveTVChannel, [LiveProgram]>(limit: 192)' in app
    assert 'sharedBrowseSnapshot' in app
    assert 'SignalMetadataResponseCache.shared.data(for: request)' in store
    assert 'CatalogHeroMetadataCache.shared.metadata(' in app
    assert 'main Unity' in settings and 'main Live TV grid' in settings

def main():
    for path,record in json.loads((ROOT/'Tests/F72ApprovedSourceDeltas.json').read_text()).items():
        s=historical_source(ROOT/path);assert hashlib.sha256(s.encode()).hexdigest()==record['after_sha256'],path
        previous_source(s,path)
    for path,digest in json.loads((ROOT/'Tests/F72UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT/path).encode()).hexdigest()==digest,path
    paths=['Sources/DebridChannelsTVOSApp.swift','Sources/SignalPausedPlaybackInfoOverlay.swift','Sources/SignalEpisodeExperienceSettings.swift','Sources/SignalPauseInfoPolicy.swift','Sources/SignalPortableSettings.swift','Sources/CatalogStore.swift']
    args=[historical_source(ROOT/p) for p in paths];audit(*args)
    registry=args[4]
    registered=set(re.findall(r'"([^"\\]+)"\s*:',registry))
    excluded=set(re.findall(r'"([^"\\]+)"',registry.split('static let excludedKeys:')[1].split('static func snapshot')[0]))
    observed=set()
    for path in (ROOT/'Sources').rglob('*.swift'):
        observed.update(re.findall(r'@AppStorage\("([^"\\]+)"\)',historical_source(path)))
    assert observed <= registered | excluded, sorted(observed-registered-excluded)

    for i in [0,1,2,3,4]:
        bad=args.copy();bad[i]=previous_source(args[i],paths[i])
        try:audit(*bad)
        except (AssertionError,ValueError):pass
        else:raise AssertionError('Predecessor accepted: '+paths[i])
    prior=previous_source(args[0],paths[0])
    for marker in ['struct LiveTVScreen: View','final class LiveTVSourceModel:','    private var pausedPlaybackInformation:', '    private func requestPlayerDismissal(']:
        assert block(args[0],marker)==block(prior,marker),marker
    print('F72 PASS: solid red season selection; separately configurable 1.5-second show/hide; owned cancellable passive card with re-pause/eligibility gates; 3 themes; portable settings; MAIN Unity store and MAIN Live TV grid metadata call paths verified, unchanged. Five predecessor negative controls rejected. Native/device tests separate.')
if __name__=='__main__':main()
