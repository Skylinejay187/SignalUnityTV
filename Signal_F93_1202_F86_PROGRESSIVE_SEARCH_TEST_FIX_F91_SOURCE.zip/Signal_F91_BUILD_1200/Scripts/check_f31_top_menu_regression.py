#!/usr/bin/env python3
"""Check F31's scope and preserved navigation against the attached F30 foundation."""
from f39_approved_deltas import historical_source
from pathlib import Path
import hashlib, json, re
from f35_approved_deltas import previous_source
ROOT = Path(__file__).resolve().parents[1]
def digest(text): return hashlib.sha256(text.encode()).hexdigest()
def block(source, marker):
    start = source.index(marker)
    opening = source.index('{', start)
    depth = 0; i = opening; state = None
    while i < len(source):
        c = source[i]; pair = source[i:i+2]
        if state == 'line':
            if c == '\n': state = None
        elif state == 'comment':
            if pair == '*/': state = None; i += 1
        elif state == 'string':
            if c == '\\': i += 1
            elif c == '"': state = None
        elif pair == '//': state = 'line'; i += 1
        elif pair == '/*': state = 'comment'; i += 1
        elif c == '"': state = 'string'
        elif c == '{': depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0: return source[start:i+1]
        i += 1
    raise AssertionError('Unclosed block: ' + marker)

def verify():
    baseline = json.loads(historical_source((ROOT/'Tests/F31NavigationBaseline.json')))
    app = historical_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    nav = block(previous_source(app, 'Sources/DebridChannelsTVOSApp.swift'), 'struct TopMenuBar: View')
    for marker, expected in baseline['navigation_blocks'].items():
        assert digest(block(nav, marker)) == expected, 'Navigation behavior changed: '+marker
    selection = nav[nav.index('ForEach(visibleTabs)'):]
    assert digest(block(selection, '.onTapGesture {')) == baseline['destination_selection_sha256'], 'Destination activation changed'
    for name, expected in baseline['protected_files'].items():
        assert hashlib.sha256(previous_source(historical_source((ROOT/name)), name).encode()).hexdigest() == expected, 'Protected source changed: '+name
    model = historical_source((ROOT/'Sources/SignalTopMenuTheme.swift'))
    visual = historical_source((ROOT/'Sources/SignalTopMenuVisuals.swift'))
    # Every legacy setting from the real F30 input must have an explicit migration.
    for old, target in baseline['legacy_themes'].items():
        assert f'"{old.lower()}": .{target}' in model, 'Missing migration: '+old
    canonical = re.findall(r'^    case (\w+) = "([^"]+)"$', model.split('enum TopMenuThemeStyle:',1)[1], re.M)
    render = visual.split('@ViewBuilder var body: some View {',2)[2].split('    private var liquidIsland',1)[0]
    for key, _ in canonical:
        assert re.search(r'case \.'+key+r': \w+', render), 'No exact renderer for '+key
    assert len(canonical) == 30
    assert 'TopMenuVisualFamily' not in app and 'newThemeCases' not in app
    assert '.id("top-menu-theme|' not in nav
    assert 'private struct TopMenuTabVisual' not in app
    assert 'struct TopMenuThemePicker:' not in app
    assert 'selectedCategory =' not in visual and 'store.selectedTab =' not in visual
    assert 'UserDefaults.standard.set' not in visual
    for source in ('SignalTopMenuTheme.swift','SignalTopMenuVisuals.swift'):
        assert 'Sources/'+source in historical_source((ROOT/'project.yml'))
    print('F31 regression locks passed: all 48 migrations, 30 renderers, navigation and protected playback sources')
if __name__ == '__main__': verify()
