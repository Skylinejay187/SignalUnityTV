#!/usr/bin/env python3
"""Fail closed if remote video URLs become eligible for a second thumbnail decoder."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
source = (root / 'Sources/VODSeekFrameExtractor.swift').read_text()
assert re.search(r'guard\s+fileURL\.isFileURL\s*,', source), 'Local-only extraction guard missing'
assert 'AVAssetImageGenerator(asset: currentAsset)' in source
assert 'self.requestID == owner' in source, 'Stale request protection missing'
assert source.count('reset()\n            completion(nil)\n            return') >= 2, 'Invalid source must clear decoder and frame cache'
assert 'Self.fingerprint(for: fileURL) == fingerprint' in source
# Also protect the actual player call site and presentation gate. A file-only
# extractor is insufficient if a future UI path starts a different decoder.
ui = (root / 'Sources/DebridChannelsTVOSApp.swift').read_text()
start = ui.index('    private func updateLocalSeekPreview(')
end = ui.index('    private func vodTimelineProgressBar(', start)
preview = ui[start:end]
assert re.search(r'!isLivePlayback\s*,\s*url\.isFileURL', preview), \
    'Player scrub path must reject remote URLs before scheduling extraction'
assert 'vodSeekFrameExtractor.requestFrame(fileURL: sourceURL' in preview, \
    'Expected local extractor call site changed; review remote decoder safety'
assert 'store.playbackPresentationID == owner' in preview and 'store.playbackURL == sourceURL' in preview, \
    'Preview callback must remain tied to its playback session and source'
overlay = ui[ui.index('                let thumbnail = url.isFileURL', start-10000):start]
# The local AVAssetImageGenerator preview must be gated to local files and
# the owning playback session. AetherEngine's native remote thumbnail is a
# separate playback-owned image, not a second AVAssetImageGenerator decoder.
assert 'let thumbnail = url.isFileURL' in overlay and \
       '(vodSeekPreviewOwner == playbackPresentationID ? vodSeekPreviewImage : nil)' in overlay and \
       ': aetherScrubThumbnail' in overlay, \
    'Local thumbnail presentation must remain session-bound; remote must use Aether only'
# Catch accidental addition of network-enabled asset creation in this extractor.
assert source.count("AVURLAsset(url: fileURL)") == 1, "Unexpected asset creation path"
# The feature is intentionally gated until the provider exposes explicit image metadata
# or a verified non-destructive Aether frame snapshot API is integrated.
print('Remote thumbnail safety gate passed (local extractor gated; remote uses Aether-owned frames)')
