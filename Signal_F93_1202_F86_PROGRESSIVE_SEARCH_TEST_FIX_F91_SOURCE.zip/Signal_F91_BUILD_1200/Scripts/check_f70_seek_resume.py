#!/usr/bin/env python3
"""Current seek-resume contracts. Historical audits remain exact and separate."""
from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from f70_approved_deltas import previous_source
from f71_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def audit(source):
    seek=block(source,'    public func seek(to seconds:')
    assert seek.index('vodSeekTransportPending = false') < seek.index('seekSerial &+= 1')
    assert seek.count('self.seekSerial == localSeekSerial') == 2
    assert seek.count('self.engine === engine') == 2
    assert seek.index('await engine.seek') < seek.index('self.seekTask = nil') < seek.index('self.reconcileVODSeekTransport()')
    assert 'self.vodSeekTransportPending = self.loadedOptions?.isLive == false' in seek
    handoff=block(source,'    private func reconcileVODSeekTransport(')
    for token in ('vodSeekTransportPending','loadedOptions?.isLive == false','!backgrounded',
                  'UIApplication.shared.applicationState == .active','configuredAllowSessionRebuild',
                  'loadTask == nil','seekTask == nil','engine.isSessionReady','!engine.isSeeking',
                  '!failed, !endedPublished','case .error, .ended, .idle: return',
                  'position.isFinite','position >= max(0, total - 0.15)',
                  'if transportWantsPlay { engine.play() } else { engine.pause() }',
                  'engine.refreshSignalBufferFrontier()','engine.clock.bufferedPosition'):
        assert token in handoff,token
    assert handoff.index('vodSeekTransportPending = false') < handoff.index('engine.play()')
    for forbidden in ('reloadAtCurrentPosition','engine.load(', 'engine.stop(', 'seek(to:',
                      'Task {', 'Task.sleep', 'Timer', 'bufferedPosition =', 'engine.state ='):
        assert forbidden not in handoff,forbidden
    observers=block(source,'    private func installObservers(')
    assert 'Publishers.CombineLatest(engine.$isSessionReady, engine.$isSeeking)' in observers
    assert 'self.generation == observedGeneration, ready, !seeking' in observers
    assert 'self.reconcileVODSeekTransport()' in observers
    assert 'reconcileVODSeekTransport()' in block(source,'    @objc public func aetherReconcileSessionConfiguration(')
    assert 'reconcileVODSeekTransport()' in block(source,'    @objc public func aetherRecoverAfterBackground(')
    stop=block(source,'    private func stopSession(')
    assert 'vodSeekTransportPending = false' in stop and 'seekTask?.cancel()' in stop

def main():
    records=json.loads(historical_source(ROOT/'Tests/F70ApprovedSourceDeltas.json'))
    for path,record in records.items():
        s=historical_source(ROOT/path);assert hashlib.sha256(s.encode()).hexdigest()==record['after_sha256'],path
        previous_source(s,path)
    for path,digest in json.loads(historical_source(ROOT/'Tests/F70UnchangedSourceHashes.json')).items():
        assert hashlib.sha256(historical_source(ROOT/path).encode()).hexdigest()==digest,path
    path='Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift';s=historical_source(ROOT/path);audit(s)
    old=previous_source(s,path)
    for marker in ('    private static func vodForwardBufferSegments(', '    private func liveOptions(',
                   '    private func publishEndedIfNeeded(', '    private func applyPendingAudioGain('):
        assert block(s,marker)==block(old,marker),marker
    for broken in (old,s.replace('self.seekSerial == localSeekSerial','true'),
                   s.replace('if transportWantsPlay { engine.play() } else { engine.pause() }','engine.play()'),
                   s.replace('vodSeekTransportPending = false\n        guard !failed','vodSeekTransportPending = true\n        guard !failed')):
        try:audit(broken)
        except (AssertionError,ValueError):pass
        else:raise AssertionError('Broken seek/ownership/intent/one-shot handoff accepted')
    assert s==historical_source(ROOT/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift')
    assert 'python3 Scripts/check_f70_native_seek.py' in historical_source(ROOT/'Scripts/prepare_build_deps_vBRDC280.sh')
    print('F70 PASS: latest owned post-seek transport intent, one-shot readiness/config/background handoff, no stream reload/retry timer/cache fabrication; prior gain/live/cache/EOF contracts preserved; four negative controls rejected. Executable/native IO/device tests separate.')
if __name__=='__main__':main()
