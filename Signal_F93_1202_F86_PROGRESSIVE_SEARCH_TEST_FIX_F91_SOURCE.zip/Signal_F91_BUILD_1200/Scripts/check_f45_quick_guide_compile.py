#!/usr/bin/env python3
"""Typecheck the real Quick Guide method before the full tvOS compile.

Only surrounding channel/program/model interfaces are stubbed. The method and
48-channel window policy come directly from production source. A negative control
must reproduce the explicit-self diagnostic from the supplied F44 build log.
"""
from pathlib import Path
import argparse,shutil,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]

def fixture():
    source=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    start=source.index('    private func makePlaybackQuickGuidePrograms(')
    end=source.index('    private func currentAndNextPlaybackPrograms(',start)
    method=source[start:end]
    assert 'aliases[self.normalizeGuideKey(key)]' in method
    return '''import Foundation
struct LiveTVChannel { let id: Int; let isXtreamSource: Bool }
struct LiveProgram { let title: String }
@MainActor final class QuickGuideCompileFixture {
    var indexedChannelPositionByID: [Int: Int] = [:]
    static var sessionGuideAliases: [String: String] = [:]
    private func channelKey(_ channel: LiveTVChannel) -> String { String(channel.id) }
    private func xtreamGuideLookupKeys(for channel: LiveTVChannel) -> [String] { [] }
    private func channelMatchingKeys(_ channel: LiveTVChannel) -> [String] { [] }
    private func normalizeGuideKey(_ key: String) -> String { key.lowercased() }
    private func currentAndNextPlaybackPrograms(from programs: [LiveProgram], previous: [LiveProgram], now: Date) -> [LiveProgram] { programs.isEmpty ? previous : programs }
''' + method + '}\n'

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--emit',type=Path)
    args=parser.parse_args();text=fixture()
    if args.emit:
        args.emit.write_text(text);print('Extracted production Quick Guide compile fixture');return
    compiler=shutil.which('swiftc')
    if not compiler:raise SystemExit('swiftc is required for the F45 semantic compile check')
    policy=ROOT/'Sources/SignalLiveTVResourcePolicy.swift'
    with tempfile.TemporaryDirectory(prefix='signal-f45-compile-') as tmp:
        path=Path(tmp)/'QuickGuide.swift';path.write_text(text)
        def compile():
            return subprocess.run([compiler,'-typecheck','-swift-version','5',str(policy),str(path)],
                                  capture_output=True,text=True,timeout=60)
        corrected=compile()
        if corrected.returncode:raise SystemExit(corrected.stdout+corrected.stderr)
        path.write_text(text.replace('aliases[self.normalizeGuideKey(key)]','aliases[normalizeGuideKey(key)]'))
        broken=compile();diagnostic=broken.stdout+broken.stderr
        assert broken.returncode!=0 and "implicit use of 'self'" in diagnostic,diagnostic
    print('F45 compiler check passed: actual production method typechecks; negative control reproduces F44 implicit-self error')
if __name__=='__main__':main()
