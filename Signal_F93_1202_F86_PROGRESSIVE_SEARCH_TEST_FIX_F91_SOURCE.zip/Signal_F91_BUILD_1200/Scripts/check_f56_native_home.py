#!/usr/bin/env python3
"""Run actual router/home-session tests and type-check new player methods on tvOS."""
from pathlib import Path
import argparse
import shutil
import subprocess
import tempfile
from check_f31_top_menu_regression import block
from check_f48_native_safety import fixture

ROOT = Path(__file__).resolve().parents[1]


def ui_fixture():
    app = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
    player = block(app, 'struct VODPlayerScreen: View')
    route = block((ROOT / 'Sources/SignalProtectedNetworkState.swift').read_text(), 'struct SignalProtectedPlaybackRoute:')
    output = '''import SwiftUI
''' + route + '''
enum MediaFlowProxyRouteKind { case vod, liveTV }
enum MediaFlowProxyRouter {
    static func prepareSafetyError(for url: URL, kind: MediaFlowProxyRouteKind) async -> String? { nil }
    static func preparedPlaybackRoute(for url: URL, sessionID: UUID, kind: MediaFlowProxyRouteKind,
        upstreamHeaders: [String: String]) -> SignalProtectedPlaybackRoute? { nil }
    static func playbackURLIfAllowed(for url: URL, kind: MediaFlowProxyRouteKind,
        upstreamHeaders: [String: String]) -> URL? { nil }
    static func playerRequestHeaders(for kind: MediaFlowProxyRouteKind,
        upstreamHeaders: [String: String], sourceURL: URL?) -> [String: String] { [:] }
}
@MainActor final class PlaybackController {
    static let shared = PlaybackController()
    func releaseRenderSurfaceForEngineHandoff(sessionID: UUID) {}
}
final class NativePlayerFixture { func pause() {}; func play() {} }
enum SignalProtectedNetworkState { static func epoch() -> UInt64 { 1 } }
struct PlayerStoreFixture {
    var playbackPresentationID = UUID()
    var playbackURL: URL? = nil
    var playbackHTTPHeaders: [String: String] = [:]
    var status = ""
}
struct ProtectedRouteUIFixture: View {
    @Environment(\\.scenePhase) private var scenePhase
    @State private var store = PlayerStoreFixture()
    let url = URL(string: "https://fixture.invalid/show.mkv")!
    let playbackPresentationID = UUID()
    let isLivePlayback = false
    let usingInternalNonAVEngine = true
    let authoritativeCurrentSeconds: Double = 75
    let livePlaybackHTTPHeaders: [String: String] = [:]
    let mediaFlowRouteKind = MediaFlowProxyRouteKind.vod
    @State private var isDismissingPlayer = false
    @State private var protectedPlaybackRoute: SignalProtectedPlaybackRoute?
    @State private var protectedRouteRecheckInProgress = false
    @State private var protectedRouteRecheckID = UUID()
    @State private var protectedRouteStopped = false
    @State private var isPlaying = false
    @State private var isLoading = false
    @State private var isFirstFrameReady = false
    @State private var player: NativePlayerFixture?
    @State private var ksSurfaceToken = 0
    @State private var errorText: String?
    @State private var retryText: String?
    @State private var preparedPlaybackURL: URL?
    @State private var currentSeconds: Double = 0
    @State private var ksStartTimeSeconds: Double = 0
    @State private var ksSeekSeconds: Double = 0
    @State private var ksSeekIsAbsolute = false
    @State private var pendingAutomaticResumeSeconds: Double?
    @State private var didAttemptAutomaticResume = false
    @State private var didApplyAutomaticResumeSeek = false
    @State private var automaticResumeSeekAttempts = 0
    @State private var automaticResumeLastSeekRequestAt = Date.distantPast
    @State private var resumePersistenceFloorSeconds: Double = 0
'''
    for name in ('nativePrepareTask', 'renderWatchdogTask', 'startupLoadingTask', 'firstFrameProbeTask',
                 'automaticResumeTask', 'startupSameSourceRetryTask', 'aetherCompatibilityWatchdogTask',
                 'automaticSourceFailoverWatchdogTask'):
        output += '    @State private var ' + name + ': Task<Void, Never>?\n'
    output += '''
    var body: some View { Color.clear }
    private func forceControlsVisibleForNavigation() {}
    private func resetFirstFrameGate(message: String) {}
    private func armStartupLoadingGate(engine: String) {}
    private func scheduleAutomaticResumeAfterSurfaceStart() {}
    private func armAutomaticSourceFailoverWatchdog() {}
'''
    output += '\n@MainActor\n' + block(player, '    private func reconcileProtectedPlaybackRoute(')
    output += '\n@MainActor\n' + block(player, '    private func stopProtectedPlaybackRoute(')
    for marker in ('    private func mediaFlowPlaybackURL(', '    private var enginePlaybackHTTPHeaders:', '    private var activePlaybackURL:'):
        output += '\n' + block(player, marker)
    return output + '\n}\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--emit', type=Path)
    args = parser.parse_args()
    if args.emit:
        args.emit.write_text(ui_fixture())
        return
    compiler = shutil.which('swiftc')
    if not compiler:
        raise SystemExit('Swift compiler required for F56 native checks')
    with tempfile.TemporaryDirectory(prefix='signal-f56-') as directory:
        directory = Path(directory)
        router = directory / 'Router.swift'
        router.write_text(fixture())
        executable = directory / 'home-tests'
        subprocess.run([compiler, '-swift-version', '5', str(router),
                        str(ROOT / 'Sources/SignalMediaFlowSafetyPolicy.swift'),
                        str(ROOT / 'Sources/SignalProtectedNetworkState.swift'),
                        str(ROOT / 'Tests/SignalF56HomePlaybackTests.swift'), '-o', str(executable)], check=True, timeout=60)
        subprocess.run([str(executable)], check=True, timeout=45)
        source = directory / 'PlayerRoute.swift'
        source.write_text(ui_fixture())
        sdk = subprocess.check_output(['xcrun', '--sdk', 'appletvos', '--show-sdk-path'], text=True).strip()
        subprocess.run(['xcrun', '--sdk', 'appletvos', 'swiftc', '-typecheck', '-swift-version', '5',
                        '-sdk', sdk, '-target', 'arm64-apple-tvos17.0', str(source)], check=True, timeout=60)
    print('F56 actual home/router tests and new player-method SDK type-check passed')


if __name__ == '__main__':
    main()
