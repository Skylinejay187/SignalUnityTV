#!/usr/bin/env python3
"""Keep the F48 build-log fix restricted to the health-client request helper."""
from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from f49_approved_deltas import previous_source
from f50_approved_deltas import historical_source
from check_f49_native_health import negative_control
ROOT=Path(__file__).resolve().parents[1]
def verify():
    changes=json.loads(historical_source(ROOT/'Tests/F49ApprovedSourceDeltas.json'))
    assert set(changes)=={'Sources/ConnectedServicesHealthClient.swift'}
    for name,record in changes.items():
        source=historical_source(ROOT/name)
        assert hashlib.sha256(source.encode()).hexdigest()==record['after_sha256']
        previous_source(source,name)
    for name,sha in json.loads(historical_source(ROOT/'Tests/F49UnchangedSourceHashes.json')).items():
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==sha,name
    health=historical_source(ROOT/'Sources/ConnectedServicesHealthClient.swift')
    prior=previous_source(health,'Sources/ConnectedServicesHealthClient.swift')
    helper=block(health,'    private static func getJSON(')
    assert ') async throws -> Any {' in helper
    assert 'guard let routed = MediaFlowProxyRouter.forwardRequestIfAllowed(request)' in helper
    assert helper.index('forwardRequestIfAllowed')<helper.index('dataWithTransientRetry')
    offcloud=block(health,'    private static func verifyOffcloud(')
    assert 'MediaFlowSafety' not in offcloud and 'SignalMediaFlowSafetyPolicy' not in offcloud
    assert health.count('throw NSError(domain: "MediaFlowSafety"')==1
    # Negative compiler fixture recreates exactly the same placement as the supplied
    # failing source (only empty lines differ), not a synthetic unrelated type error.
    compact=lambda text:'\n'.join(line for line in text.splitlines() if line.strip())
    assert compact(negative_control(health))==compact(prior)
    # Public result handling and every unrelated provider remain byte-identical.
    for marker in ('    static func verifyRealDebrid(', '    private static func verifyBearerDebrid(',
                   '    private static func verifyPutio(', '    private static func dataWithTransientRetry(',
                   '    private static func safeMessage('):
        assert block(health,marker)==block(prior,marker),marker
    native=historical_source(ROOT/'Scripts/check_f49_native_health.py')
    assert "actual=ROOT/'Sources/ConnectedServicesHealthClient.swift'" in native
    assert "str(actual)" in native and "negative_control(actual.read_text())" in native
    assert "'error is not handled'" in native and 'not declared' in native
    assert 'check_f49_native_health.py' in historical_source(ROOT/'Scripts/check_f28_source_preflight.sh')
    print('F49 PASS: sole production delta moves RD guard into throwing getJSON helper; Offcloud restored; full-client compiler check/negative control wired; 133 prior Swift files unchanged')
if __name__=='__main__':verify()
