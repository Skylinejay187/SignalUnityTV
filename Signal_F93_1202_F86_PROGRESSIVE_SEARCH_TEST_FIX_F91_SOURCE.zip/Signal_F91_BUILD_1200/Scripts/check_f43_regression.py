#!/usr/bin/env python3
"""Current F43 ownership and work bounds. Source checks are not device profiling."""
from pathlib import Path
import re,json,hashlib
from check_f31_top_menu_regression import block
from f43_approved_deltas import previous_source
from f44_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    for name,record in json.loads(historical_source(ROOT/'Tests/F43ApprovedSourceDeltas.json')).items():
        s=historical_source(ROOT/name);assert hashlib.sha256(s.encode()).hexdigest()==record['after_sha256'],name
        previous_source(s,name)
    for name,sha in json.loads(historical_source(ROOT/'Tests/F43UnchangedSourceHashes.json')).items():
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==sha,name
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
    before=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    assert block(app,'struct VODPlayerScreen: View')==block(before,'struct VODPlayerScreen: View'),'VOD settings/Up Next/seek policy scope'
    live=block(app,'struct LiveTVScreen: View')
    assert 'liveTVGridPageSize: Int { SignalLiveTVResourcePolicy.pageSize' in live
    assert r'.environment(\.signalLiveTVVisualWorkActive, liveVisualWorkActive)' in live
    assert 'liveTVAsyncRuntime.cancelAll()' in live and 'gridInteractionRuntime.cancelGridWork()' in live
    page=block(live,'    private func liveGridContent(')
    assert 'rows: customizationPreview?.rows ?? liveTVGridRows' in page
    assert page.count('liveTVGridPageSize == 16 ? cardHeight * 16 / 9')==2
    assert '.frame(maxWidth: .infinity, alignment: .center)' in page
    model=block(app,'final class LiveTVSourceModel: ObservableObject')
    prepare=block(model,'    func prepareForFullScreenPlayback(')
    assert 'channels = []' not in prepare and 'guidePrograms = [:]' not in prepare
    indexes=block(model,'    private func rebuildChannelBrowseIndex(')
    assert 'Self.sharedBrowseSnapshot' in indexes and 'snapshot.channels == channels' in indexes
    retained=block(model,'    private func publishRetainedLiveTVSessionIfAvailable(')
    assert 'retainedSessionVersion == Self.sessionSnapshotVersion' in retained
    compact=block(model,'    private func makePlaybackQuickGuidePrograms(')
    assert 'SignalLiveTVResourcePolicy.window' in compact and 'let aliases = Self.sessionGuideAliases' in compact
    assert 'for channel in window' in compact and 'for channel in channels' not in compact
    assert 'for (storedKey, programs) in guide' not in model
    snapshot=block(model,'    func loadPlaybackQuickGuideSnapshot(')
    assert 'publishChannelsIfChanged(snapshot)' in snapshot
    programs=block(model,'    func programs(for channel:')
    assert 'Self.sessionGuidePrograms' in programs and 'Self.sessionGuideAliases' in programs
    for marker in ('    private func startLiveTVGuideRecoveryLoopIfNeeded(', '    private func armPersistentGuideRecovery('):
        scope=block(live,marker)
        assert 'store.selectedTab == .live' in scope and '!Task.isCancelled' in scope
    refresh=block(live,'    private func startLiveTVRefreshIfActive(')
    assert 'guard !Task.isCancelled, store.selectedTab == .live, store.playbackURL == nil else { return }' in refresh
    smoke=historical_source(ROOT/'Sources/SignalGlassAtmosphereVisuals.swift')
    assert 'TimelineView(' not in smoke and 'Canvas(' not in smoke
    for token in ('active && scenePhase == .active','CAKeyframeAnimation','smokeTexturePixels','sprite.removeAllAnimations()', 'sprite.contents = nil', 'cache.totalCostLimit = 2 * 1024 * 1024'):
        assert token in smoke,token
    background=historical_source(ROOT/'Sources/SignalBackgroundVisuals.swift')
    assert '.blur(radius:' not in block(background,'struct MainGridBackgroundView: View')
    assert 'if active && atmosphereActive' in background
    native=historical_source(ROOT/'Sources/SignalDashboardBackdrop.swift')
    for token in ('queue.maxConcurrentOperationCount = 1','cacheIntermediates: false','longestEdge: 192', 'generation == token','work.isCancelled','view.layer.removeAllAnimations()'):
        assert token in native,token
    assert 'RemoteImageFit(' not in native
    transport=historical_source(ROOT/'Sources/RemoteImageFit.swift')
    assert '.cacheOriginalImage' not in transport and '.loadDiskFileSynchronously' not in transport and '.waitForCache' not in transport
    for token in ('.targetCache(Self.processedTransportCache)','.processingQueue(.dispatch(Self.kingfisherProcessingQueue))','totalCostLimit = 8 * 1024 * 1024','networkLoadTokens[key] == networkToken','processedTransportCache.clearMemoryCache()'):
        assert token in transport,token
    host=historical_source(ROOT/'Sources/PlaybackKit/PlaybackKitAetherSurface.swift')
    for token in ('auxiliaryPlayback: Bool = false','auxiliaryPlayback && AuxiliaryVideoPlaybackCoordinator.shared.isAuxiliaryPlaybackSuppressed()','registerReleaseHandler','coordinator.auxiliaryReleased = true','!context.coordinator.auxiliaryReleased','unregisterReleaseHandler', 'SignalLiveTVResourceLedger.endHost'):
        assert token in host,token
    assert app.count('auxiliaryPlayback: true')==3
    bridge=historical_source(ROOT/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift')
    assert bridge==historical_source(ROOT/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift')
    assert 'engine?.unbind(view: playerView)' in bridge and 'scrubThumbnailTask?.cancel()' in block(bridge,'    private func stopSession(')
    assert 'engine.refreshSignalBufferFrontier()' in bridge
    portable=historical_source(ROOT/'Sources/SignalPortableSettings.swift')
    assert '"signalLiveTVGridRowsV1": 3' in portable
    observed=set()
    for p in (ROOT/'Sources').rglob('*.swift'):observed.update(re.findall(r'@AppStorage\("([^"\\]+)"\)',historical_source(p)))
    c=json.loads(historical_source(ROOT/'Tests/F42SettingsCoverage.json'))
    assert observed <= set(c['portable']) | set(c['excluded'])
    assert len(observed)==194
    preview=block(app,'private struct SignalLiveTVThemeConfirmationScreen: View')
    assert r'Button("Rows: \(draftRows)")' in preview and 'selectedRows = SignalLiveTVResourcePolicy.rows(draftRows)' in preview
    assert 'rows: draftRows' in preview
    audit=historical_source(ROOT/'Sources/LiveTVMemoryAuditManager.swift')
    assert 'getrusage(RUSAGE_SELF' in audit and 'intervalProcessCPU' in audit and 'SignalLiveTVResourceLedger.summary' in audit
    print('F43 current ownership/source contracts PASS: 16-card option; bounded guide and shared indexes; native smoke/prepared blur; guarded transport generations; explicit decoder release; covered leaves/recovery stopped; VOD and Up Next unchanged')
if __name__=='__main__':verify()
