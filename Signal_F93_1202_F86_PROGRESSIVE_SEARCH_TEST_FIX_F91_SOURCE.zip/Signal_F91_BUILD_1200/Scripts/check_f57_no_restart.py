#!/usr/bin/env python3
"""Reject F56's decoder rebuild path and verify same-player home revalidation."""
from pathlib import Path
import hashlib
import json
from check_f31_top_menu_regression import block
from f57_approved_deltas import previous_source
from f58_approved_deltas import historical_source

ROOT = Path(__file__).resolve().parents[1]


def audit_recheck(method):
    assert 'route.canContinue(with: verified)' in method
    assert '!protectedRouteStopped' in method
    for forbidden in ('ksSurfaceToken', 'ksSeek', 'ksStartTimeSeconds', 'currentSeconds =',
                      'resetFirstFrameGate(', 'setupVerifiedPlayer(', 'switchToAetherEngine(',
                      'scheduleAutomaticResumeAfterSurfaceStart('):
        assert forbidden not in method, forbidden
    accepted = block(method, '            if let verified, route.canContinue')
    assert 'protectedPlaybackRoute = verified' in accepted and 'protectedRouteRecheckInProgress = false' in accepted
    assert 'return' in accepted and 'releaseRenderSurfaceForEngineHandoff' not in accepted
    assert method.index('route.canContinue') < method.index('stopProtectedPlaybackRoute(')
    assert 'releaseRenderSurfaceForEngineHandoff' not in method
    assert 'currentEpoch == checkingEpoch' in method


def verify():
    for name, record in json.loads((ROOT / 'Tests/F57ApprovedSourceDeltas.json').read_text()).items():
        source = historical_source(ROOT / name)
        assert hashlib.sha256(source.encode()).hexdigest() == record['after_sha256'], name
        previous_source(source, name)
    for name, expected in json.loads((ROOT / 'Tests/F57UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT / name).encode()).hexdigest() == expected, name
    app = historical_source(ROOT / 'Sources/DebridChannelsTVOSApp.swift')
    old = previous_source(app, 'Sources/DebridChannelsTVOSApp.swift')
    method = block(app, '    private func reconcileProtectedPlaybackRoute(')
    audit_recheck(method)
    stopped = block(app, '    private func stopProtectedPlaybackRoute(')
    assert 'guard !protectedRouteStopped else { return }' in stopped
    assert stopped.index('protectedRouteStopped = true') < stopped.index('releaseRenderSurfaceForEngineHandoff')
    try:
        audit_recheck(block(old, '    private func reconcileProtectedPlaybackRoute('))
    except AssertionError:
        pass
    else:
        raise AssertionError('F56 restart logic must fail the current regression check')
    assert '!protectedRouteStopped' in block(app, '    private var activePlaybackURL:')
    assert '!protectedRouteRecheckInProgress' not in block(app, '    private var activePlaybackURL:')
    surface = block(app, '    private func playbackSurfaceLayer(')
    assert 'ksShouldPlay: isPlaying && !protectedRouteRecheckInProgress' in surface
    assert 'vlcShouldPlay: isPlaying && !protectedRouteRecheckInProgress' in surface
    failure = surface[surface.index('onAetherPlaybackFailure:'):surface.index('onAetherPlaybackEnded:')]
    assert failure.index('protectedRouteRecheckInProgress') < failure.index('attemptAutomaticSourceFailover')
    for marker in ('struct GlobalSearchScreen: View', 'struct LiveTVScreen: View', 'struct MediaInfoPopup: View',
                   '    private func handleNaturalEpisodeEnd(', '    private func playPreparedUpNextEpisode(',
                   '    private func seekAbsolute(', '    private func stopOwnedPlaybackKitSession('):
        assert block(app, marker) == block(old, marker), marker
    state = (ROOT / 'Sources/SignalProtectedNetworkState.swift').read_text()
    assert 'SignalProtectedPathDeduplicator<NWPath>()' in state and 'pathUpdates.changed(path)' in state
    assert 'if changed { invalidate(notify: true) }' in state
    host = (ROOT / 'Sources/PlaybackKit/PlaybackKitAetherSurface.swift').read_text()
    assert 'let needsLoad = coordinator.currentURL != url || coordinator.lastReloadToken != reloadToken' in host
    assert 'shouldPlay ? "aetherPlay" : "aetherPause"' in host
    assert 'check_f57_native_continuity.py' in (ROOT / 'Scripts/check_f28_source_preflight.sh').read_text()
    print('F57 PASS: F56 restart logic rejected; duplicate paths ignored; same-home checks keep URL/token/seek/decoder; failed routes stop once until Retry; launch/away guard and other features preserved')


if __name__ == '__main__':
    verify()
