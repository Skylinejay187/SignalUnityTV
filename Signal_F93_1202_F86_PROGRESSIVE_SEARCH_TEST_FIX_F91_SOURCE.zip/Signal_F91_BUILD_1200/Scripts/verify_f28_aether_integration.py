#!/usr/bin/env python3
"""Fail the F28 build early if the downloaded engine or packaged bridge drifted."""
from pathlib import Path
import sys

root = Path(__file__).resolve().parent.parent
engine = Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else root / "Vendor/AetherEngine"
if len(sys.argv) > 2:
    raise SystemExit("Usage: verify_f28_aether_integration.py [staged-engine-directory]")
source = engine / "Sources/AetherEngine"
bridge = root / "Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift"
mirror = root / "Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift"
checks = [
    (engine / "Package.swift", "swift-tools-version: 6.1"),
    (source / "Audio/AudioDecoder.swift", "func setGainDB(_ db: Double)"),
    (source / "Audio/AudioDecoder.swift", "decodedGainLinear"),
    (source / "Native/SoftwarePlaybackHost.swift", "aDec.setGainDB(signalAudioGainDB)"),
    (source / "AetherEngine+SignalAudioGain.swift", "public func setDecodedAudioGainDB"),
    (source / "AetherEngine+SignalCacheFrontier.swift", "public func refreshSignalBufferFrontier"),
    (source / "Native/NativeAVPlayerHost.swift", "func signalCachedBufferEnd() -> Double"),
    (bridge, "engine.refreshSignalBufferFrontier()"),
    (bridge, "engine.setDecodedAudioGainDB"),
    (mirror, "engine.setDecodedAudioGainDB"),
]
errors = []
version_marker = engine / ".signal-f28-version"
if not version_marker.is_file() or version_marker.read_text().strip() != "7.44.0":
    errors.append("AetherEngine pinned version must be exactly 7.44.0")
for path, expected in checks:
    if not path.is_file() or expected not in path.read_text():
        errors.append(f"Missing {expected!r} in {path}")
# Reject the accidental inclusion of multiple native engine implementations.
# The F28 playback bridge is the sole integration boundary; KSPlayer must not
# be pulled back into the build during the engine upgrade.
if (root / "Vendor/KSPlayer").exists():
    errors.append("Unexpected KSPlayer vendor tree in Aether-only F28 source")
if bridge.is_file() and mirror.is_file() and bridge.read_bytes() != mirror.read_bytes():
    errors.append("Packaged playback bridge and source mirror differ")
if errors:
    print("F28 integration preflight FAILED:", *errors, sep="\n - ", file=sys.stderr)
    sys.exit(1)
print("F28 integration preflight passed: engine tag, gain hook, decoder inheritance, bridge mirror")
