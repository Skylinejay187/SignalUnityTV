#!/usr/bin/env python3
"""F34 scope checks. Runtime visual/performance validation still requires Apple TV."""
from f39_approved_deltas import historical_source
from pathlib import Path
from check_f31_top_menu_regression import block
from check_f33_visual_regression import verify
ROOT=Path(__file__).resolve().parents[1]

def validate():
    verify()
    app=historical_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    visual=historical_source((ROOT/'Sources/UnityCatalogVisualSystem.swift'))
    background=historical_source((ROOT/'Sources/SignalBackgroundVisuals.swift'))
    policy=historical_source((ROOT/'Sources/SignalLiveTVCardEffect.swift'))
    glyph=historical_source((ROOT/'Sources/SignalSearchGlyph.swift'))
    nav=block(app,'struct TopMenuBar: View')
    assert 'SignalMirrorSearchPlacement.resolve(mirrorSearchPlacement) == .menu && !topMenuMembershipLocked' in nav
    assert 'SignalSearchGlyph(accent: topMenuSelectedAccentBase, focused: searchFocused' in nav
    assert 'private var outsideSearchButton:' in nav
    header=block(app,'private struct SignalLiveTVMirrorHeader<ModeChip: View>')
    assert 'SignalSearchGlyph' not in header
    wiring=block(app,'    private var mirrorLiveTVHeader: some View')
    assert 'searchAction:' not in wiring and 'showCornerClock: true' in wiring
    assert app.count('@AppStorage("signalMirrorSearchPlacementV1")')==2
    assert '"signalMirrorSearchPlacementV1": SignalMirrorSearchPlacement.resolve' in app
    assert 'SignalMirrorSearchPlacement.resolve(settings["signalMirrorSearchPlacementV1"]' in app
    assert 'mirrorSearchPlacement = SignalMirrorSearchPlacement.menu.rawValue' in app
    assert '"signalMirrorSearchPlacementV1"' in historical_source((ROOT/'Sources/ReleaseCandidateSecurityManager.swift'))
    assert 'Text("🔍")' in glyph and 'if active && scenePhase == .active && !reduceMotion' in glyph
    assert 'minimumInterval: 1.0 / 12.0' in glyph and 'repeatForever' not in glyph
    tile=block(app,'private struct LiveTVGridTileContent: View')
    assert tile.index('.compositingGroup() // Static artwork')<tile.index('if let previewURL, isFocused')
    assert tile.count('.compositingGroup()')==1
    assert '.drawingGroup' not in tile
    assert 'opaque: true' not in background
    for marker in ('private struct LiveTVGridTileArtwork: View','private struct LiveTVChannelLogoBackdrop: View'):
        content=block(app,marker)
        assert '.blur(' in content
        for part in content.split('.blur(')[1:]:
            before_opacity=part.split('.opacity(',1)[0]
            assert '.frame(width: size.width, height: size.height)' in before_opacity and '.clipped()' in before_opacity
    confirmation=block(app,'private struct SignalLiveTVThemeConfirmationScreen: View')
    assert '.buttonStyle(.bordered)' not in confirmation and '.buttonStyle(.borderedProminent)' not in confirmation
    assert confirmation.count('.buttonStyle(SignalCustomizationChipStyle())')==2
    assert 'previewURL: nil' in block(app,'private struct SignalLiveTVDashboardConfirmation: View')
    assert app.count('SignalLiveTVCardEffect.usesCenterGutter(')==2
    motion=block(app,'private struct LiveTVGridFocusMotionHost<Content: View>')
    assert 'SignalLiveTVCardEffect.pose(' in motion and 'accessibilityReduceMotion' in motion
    assert 'Dual Inward Max' in policy and 'Split Inward Max' in policy
    rail=block(app,'struct GridOSFixedSlotCatalogRail: View')
    assert 'value: selectedIndex)' not in rail
    commit=block(rail,'    private func commitPersistentHorizontalMove(')
    assert 'SignalCatalogMotionBudget.rapidRepeat' in commit
    assert 'browsingTransform(' in commit and 'browsingAnimation(' in commit
    assert 'guard generation == persistentRailMotionGeneration else' in commit
    assert '.id(' not in commit and 'Task {' not in commit
    assert '.onChange(of: catalogRowScrollingAnimationPreset)' in rail
    assert '.onChange(of: allowsFocus)' in rail
    assert 'resetCatalogRailMotion()' in rail
    picker=block(visual,'struct CatalogRowMotionPicker: View')
    assert 'UserDefaults.standard.set' not in picker and 'withTransaction(transaction)' in picker
    assert 'ViewModifier, Animatable' in visual and 'var animatableData: CGFloat' in visual
    assert 'if rapid { return .easeOut(duration: 0.10) }' in visual
    for name in ('SignalLiveTVCardEffect.swift','SignalSearchGlyph.swift'):
        assert 'Sources/'+name in historical_source((ROOT/'project.yml'))
    print('F34 checks passed: one Search target per placement; saved restore/reset; shared static filter isolation; no native customization platter; 23 card poses; one cancellable catalog arrival owner')
if __name__=='__main__':validate()
