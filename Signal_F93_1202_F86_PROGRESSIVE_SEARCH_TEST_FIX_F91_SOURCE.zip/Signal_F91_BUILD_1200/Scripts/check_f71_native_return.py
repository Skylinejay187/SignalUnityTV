#!/usr/bin/env python3
"""Actual store snapshot capture/consume methods; no network/decoder/UI emulation."""
from pathlib import Path
import argparse,shutil,subprocess,tempfile
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]
def fixture():
    store=(ROOT/'Sources/CatalogStore.swift').read_text()
    s='''import Foundation
struct MediaItem: Equatable { let id: String; let type: String }
struct StreamLink: Equatable { let id: String; let url: String? }
@MainActor final class ReturnFixture {
    var selectedDetail: MediaItem?, playbackURL: URL?
    var vodExclusivePlaybackActive = false, vodSourceReturnReady = false
    var vodSourceReturnSnapshot: VODSourceReturnSnapshot?
    var visibleStreamLinksItem: MediaItem?
    var selectedSourceProvider = "Other"
    var sourceProviderStatuses: [String] = []
    var streamPublications = 0
    var streamLinks: [StreamLink] = [] { didSet { streamPublications += 1 } }
    var lastStreamMessage = ""
    static func makePlayableURL(from raw: String?) -> URL? { raw.flatMap(URL.init(string:)) }
'''
    for marker in ['    private struct VODSourceReturnSnapshot {',
                   '    private func rememberVODReturnSources(', '    func consumeVODReturnSources(']:
        s+=block(store,marker).replace('private struct','struct').replace('private func','func')+'\n'
    return s+'}\n'+(ROOT/'Tests/SignalF71ReturnSourcesTests.swift').read_text()
def main():
    p=argparse.ArgumentParser();p.add_argument('--emit',type=Path);a=p.parse_args()
    if a.emit:a.emit.write_text(fixture());return
    if not shutil.which('swiftc'):raise SystemExit('Swift compiler required for executable F71 source-return tests')
    with tempfile.TemporaryDirectory(prefix='signal-f71-return-') as temp:
        temp=Path(temp);source=temp/'Fixture.swift';source.write_text(fixture());out=temp/'tests'
        subprocess.run(['swiftc','-parse-as-library','-swift-version','5',str(source),'-o',str(out)],check=True,timeout=90)
        subprocess.run([str(out)],check=True,timeout=15)
    print('F71 production source-return capture/consume executable passed; device/artwork/provider integration separate')
if __name__=='__main__':main()
