#!/usr/bin/env python3
"""Regression checks for private stream and account details in build artifacts."""
from sanitize_f28_build_logs import sanitize

samples = [
    'failed fetching https://example.com/video.m3u8?token=PRIVATE123&sig=PRIVATE456',
    'Authorization: Bearer PRIVATE123',
    '"authorization": "Bearer PRIVATE123"',
    '"access_token":"PRIVATE123"',
    'password=PRIVATE123',
    "'refresh_token': 'PRIVATE123'",
    'api_key: PRIVATE123',
]
for sample in samples:
    redacted = sanitize(sample)
    assert 'PRIVATE123' not in redacted and 'PRIVATE456' not in redacted, (sample, redacted)
    assert '[redacted' in redacted, (sample, redacted)
print(f'Diagnostic redaction regression passed ({len(samples)} cases)')
