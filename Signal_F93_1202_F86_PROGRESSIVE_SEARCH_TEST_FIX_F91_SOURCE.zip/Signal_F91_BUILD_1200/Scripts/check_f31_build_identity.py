#!/usr/bin/env python3
"""F31 entry point; shares the universal workflow's current-metadata validator."""
from check_build_identity import main
if __name__ == '__main__':
    main()
