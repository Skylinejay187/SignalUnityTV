#!/usr/bin/env python3
"""Visual wiring and preserved Live TV behavior, independent of a Swift toolchain."""
from f39_approved_deltas import historical_source
from pathlib import Path
import hashlib,json,re
from check_f31_top_menu_regression import block, verify
from f35_approved_deltas import previous_source
ROOT=Path(__file__).resolve().parents[1]

def validate():
    verify()
    app=historical_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    baseline_live=block(previous_source(app, 'Sources/DebridChannelsTVOSApp.swift'),'struct LiveTVScreen: View')
    live=block(app,'struct LiveTVScreen: View')
    baseline=json.loads(historical_source((ROOT/'Tests/F32LiveTVNavigationBaseline.json')))
    for marker,expected in baseline.items():
        candidate = block(baseline_live,marker)
        if marker == '    private func liveGridContent(size: CGSize) -> some View {':
            candidate = candidate.replace('SignalLiveTVCardEffect.usesCenterGutter(signalLiveTVCardEffect)',
                '["Split Inward", "Split Inward Strong"].contains(SignalLiveTVCardEffect.normalized(signalLiveTVCardEffect))')
        assert hashlib.sha256(candidate.encode()).hexdigest()==expected, 'Live TV function changed: '+marker
    bg=block(live,'    private func liveBackground(channel:')
    assert 'MainGridBackgroundView(' in bg
    assert 'LiveTVGridBackgroundThemeView' not in app
    assert 'artworkURL: focusedBackgroundArtworkURL' in bg
    assert 'active: liveBackgroundOwnsArtworkBudget' in bg
    art=block(live,'    private var focusedBackgroundArtworkURL:')
    assert art.index('guard liveBackgroundOwnsArtworkBudget') < art.index('currentProgram(for:')
    assert 'tileFocus.flatMap' in art and 'channel.iconURL' in art
    budget=block(live,'    private var liveBackgroundOwnsArtworkBudget:')
    for gate in ('scenePhase == .active','store.catalogRowsPresented','store.liveQuickPanelOpen','store.searchActive','store.selectedDetail != nil','store.playbackURL != nil','store.vodExclusivePlaybackActive','guideVisible: showGuide'):
        assert gate in budget, 'Missing background budget gate: '+gate
    visual=historical_source((ROOT/'Sources/SignalBackgroundVisuals.swift'))
    model=historical_source((ROOT/'Sources/SignalBackgroundTheme.swift'))
    assert len(re.findall(r'^    case \w+ = ',model,re.M))==12
    assert 'if theme == .pureBlack {\n                    Color.black\n                } else {' in visual
    assert 'maxPixelSize: treatment.artworkMaxPixelSize' in visual and 'Task.checkCancellation()' in visual
    assert '.task(id: requestKey)' in visual and '300_000_000' in visual
    assert '.onDisappear { settledArtworkURL = nil }' in visual
    assert 'if active {' in visual and 'SignalAbstractBackdrop(theme: theme).equatable()' in visual
    assert not any(x in visual for x in ('TimelineView','Timer.','AVPlayer(','repeatForever('))
    assert 'SignalGlassAtmosphere(' in visual and 'atmosphereActive: liveDecorativeSurfacesOwnRenderBudget' in bg
    assert 'spotlightRelatedTitle' not in app
    card=block(app,'    private func spotlightRelatedCard(')
    assert 'related.logoURL' not in card and '.frame(width: 74, height: 111)' in card
    project=historical_source((ROOT/'project.yml'))
    for name in ('SignalTopMenuTheme.swift','SignalTopMenuVisuals.swift','SignalBackgroundTheme.swift','SignalBackgroundVisuals.swift'):
        assert 'Sources/'+name in project
    print(f'F32 visual regression locks passed: {len(baseline)} Live TV baseline checks with explicit F35/F36 delta review; 24 menu renderers; 12 backgrounds; bounded artwork lifecycle; poster fix retained')

if __name__=='__main__':validate()
