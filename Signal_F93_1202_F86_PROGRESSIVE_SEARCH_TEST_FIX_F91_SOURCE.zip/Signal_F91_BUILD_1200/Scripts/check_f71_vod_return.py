#!/usr/bin/env python3
"""Current return wiring and resource contracts; reverse only reviewed earlier changes."""
from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from f71_approved_deltas import previous_source
from f72_approved_deltas import historical_source
from f72_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def artwork(app):
    bootstrap=block(app,'    private func beginForcedLiveTVArtworkBootstrap(')
    assert 'allowCoveredReturn: Bool = false' in bootstrap
    assert bootstrap.count('allowCoveredReturn && UnitySurfaceSystem.quickPanelBranchActive') == 3
    assert bootstrap.count('scenePhase == .active') == 3
    assert 'VODExclusivePlaybackGate.isActive' in bootstrap
    assert 'defer {' in bootstrap and 'liveTVForcedArtworkBootstrapActive = false' in bootstrap
    assert '8_000_000_000' in bootstrap and 'while ' not in bootstrap and 'Timer' not in bootstrap
    assert 'beginForcedLiveTVArtworkBootstrap(reason: "movie/show playback return", allowCoveredReturn: true)' in app
    repair=block(app,'    private func restoreCoveredGuideAfterVODIfNeeded(')
    for token in ('store.selectedTab != .live','store.playbackURL == nil','scenePhase == .active',
                  '!VODExclusivePlaybackGate.isActive','liveModel.guideRecoveryRequired',
                  'liveRefreshTask?.cancel()','VODExclusiveWorkRegistry.start',
                  'await liveModel.retryIncompleteGuideRecovery()', 'allowCoveredReturn: true'):
        assert token in repair,token
    assert 'while ' not in repair and 'Timer' not in repair and 'Task.sleep' not in repair

def links(store,app):
    capture=block(store,'    private func rememberVODReturnSources(')
    consume=block(store,'    func consumeVODReturnSources(')
    assert 'links.prefix(128)' in capture and 'selectedDetail?.id' in capture
    assert 'selectedURL' in capture and 'retained[retained.count - 1] = chosen' in capture
    for token in ('playbackURL == nil','!vodExclusivePlaybackActive','vodSourceReturnReady',
                  'snapshot.detailID == detail.id','vodSourceReturnSnapshot = nil',
                  'visibleStreamLinksItem = snapshot.item','selectedSourceProvider = "All Providers"'):
        assert token in consume,token
    for forbidden in ('findStreams','Task {','Timer','UserDefaults','UIImage','AetherEngine'):
        assert forbidden not in consume and forbidden not in capture,forbidden
    commit=block(store,'    private func commitVerifiedPlayback(')
    assert commit.index('MembershipEntitlementManager') < commit.index('rememberVODReturnSources(') < commit.index('beginVODExclusivePlaybackIfNeeded')
    assert 'visibleStreamLinksItem?.id == item.id' in commit
    launch=block(store,'    func startPlayback(item:')
    assert launch.count('returnSourceLinks: returnSourceLinks') == 2
    close=block(store,'    func closePlayer(')
    assert close.index('expectedPresentationID') < close.index('vodSourceReturnReady =') < close.index('playbackURL = nil')
    assert 'vodSourceReturnSnapshot?.item.id == playbackItem?.id' in close
    clear=block(store,'    private func clearStreamLinkState(')
    assert 'vodSourceReturnSnapshot = nil' in clear and 'visibleStreamLinksItem = nil' in clear
    popup=block(app,'struct MediaInfoPopup: View')
    restore=block(popup,'    private func restoreVODSourcePanelIfAvailable(')
    for token in ('store.consumeVODReturnSources(for: item)','sourceSearchItem = restored.item',
                  'sourcePanelVisible = true','isFindingLinks = false','focus = activeSourceLinks.isEmpty ? .findLinks : .stream(index)'):
        assert token in restore,token
    assert 'restoreVODSourcePanelIfAvailable()\n' in popup
    assert 'if value == nil, restoreVODSourcePanelIfAvailable() { return }' in popup
    assert 'returnSourceLinks: preparation.rankedLinks' in block(app,'    private func playPreparedUpNextEpisode(')

def main():
    for path,record in json.loads(historical_source(ROOT/'Tests/F71ApprovedSourceDeltas.json')).items():
        value=historical_source(ROOT/path);assert hashlib.sha256(value.encode()).hexdigest()==record['after_sha256'],path
        previous_source(value,path)
    for path,digest in json.loads(historical_source(ROOT/'Tests/F71UnchangedSourceHashes.json')).items():
        assert hashlib.sha256(historical_source(ROOT/path).encode()).hexdigest()==digest,path
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift');store=historical_source(ROOT/'Sources/CatalogStore.swift')
    artwork(app);links(store,app)
    old_app=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    old_store=previous_source(store,'Sources/CatalogStore.swift')
    for candidate in [old_app,app.replace('allowCoveredReturn && UnitySurfaceSystem.quickPanelBranchActive','false && UnitySurfaceSystem.quickPanelBranchActive')]:
        try:artwork(candidate)
        except (AssertionError,ValueError):pass
        else:raise AssertionError('Broken covered artwork recovery accepted')
    for candidate in [old_store,store.replace('links.prefix(128)','links.prefix(999999)'),store.replace('snapshot.detailID == detail.id','true')]:
        try:links(candidate,app)
        except (AssertionError,ValueError):pass
        else:raise AssertionError('Unbounded/unowned/missing source return accepted')
    for marker in ('    private var liveVisualWorkActive:', '    private var focusedBackgroundArtworkURL:',
                   '    private func prefetchLiveTVArtworkAroundFocusedChannel(',
                   '    func suspendForVODPlayback()', '    private func requestPlayerDismissal()',
                   '    private func reconcileProtectedPlaybackRoute('):
        assert block(app,marker)==block(old_app,marker),marker
    for marker in ('    private func sourceLinkCacheKey(', '    private func cachedStreamLinks('):
        assert block(store,marker)==block(old_store,marker),marker
    print('F71 PASS: bounded covered artwork recovery, single post-VOD stale-guide repair, exact title/episode source return through verified launch, one-shot restore/focus and five negative controls; hidden visual budgets, caches, protection and ordered teardown preserved. Native/device validation separate.')
if __name__=='__main__':main()
