#!/usr/bin/env python3
"""Current Search presentation contracts and preserved async/player behavior."""
from pathlib import Path
import hashlib
import json
from check_f31_top_menu_regression import block
from f55_approved_deltas import previous_source
from f56_approved_deltas import historical_source

ROOT = Path(__file__).resolve().parents[1]


def verify():
    name = 'Sources/DebridChannelsTVOSApp.swift'
    app = historical_source(ROOT / name)
    records = json.loads((ROOT / 'Tests/F55ApprovedSourceDeltas.json').read_text())
    assert hashlib.sha256(app.encode()).hexdigest() == records[name]['after_sha256']
    old = previous_source(app, name)
    search = block(app, 'struct GlobalSearchScreen: View')
    prior = block(old, 'struct GlobalSearchScreen: View')
    for marker in ('    private func scheduleUnifiedSearch(', '    private func openSearchResult(',
                   '    private func scheduleSearchProductionPrefetch(', '    private func prewarmSearchProductionDetails('):
        assert block(search, marker) == block(prior, marker), marker
    for marker in ('struct LiveTVScreen: View', 'struct VODPlayerScreen: View', 'struct MediaInfoPopup: View',
                   'struct GridOSFixedSlotCatalogRail: View', 'struct ManualEpisodesRow: View'):
        assert block(app, marker) == block(old, marker), marker
    assert 'GridOSFixedSlotCatalogRail(' not in search
    grid = block(search, '    private func searchResultsGrid(')
    for token in ('ScrollView(.vertical', 'LazyVGrid(', 'ForEach(displayedSearchResults)',
                  '.focused($focusedID, equals: item.id)', '.onTapGesture { openSearchResult(item) }',
                  'SignalSearchResultsLayout.make', '.task(id: resultFocusRequest)'):
        assert token in grid, token
    restore = block(search, '    private func restoreSearchGridFocus(')
    assert restore.index('proxy.scrollTo') < restore.index('await Task.yield()') < restore.index('focusedID = target')
    for token in ('Task.isCancelled', 'resultFocusRequest == request', 'resultFocusTargetID == target',
                  'scenePhase == .active', 'store.selectedDetail == nil', '!queryFieldFocused', 'focusedSearchHeader == nil'):
        assert token in restore, token
    assert '@FocusState private var focusedID: String?' in search
    assert 'queryFieldFocused = true' in search and '.onSubmit { focusResults() }' in search
    assert 'if playbackBrowseMode { SignalGuideChrome.panelFill' in search
    assert 'SignalPlaybackBrowsePolicy.searchAllowed' in search
    assert 'allowDuringExclusivePlayback: playbackBrowseMode' in search
    card = block(app, 'struct SearchResultCard: View')
    for token in ('cardWidth * 9 / 16', 'mode: .fit, maxPixelSize: 768',
                  'FocusedSidewaysCardEffect(isFocused: isFocused && !reduceMotion)',
                  'transaction.disablesAnimations = reduceMotion', '.frame(height: 54',
                  'publishDuringPlayback: playbackBrowseMode', 'forceVisiblePlaybackPublication: playbackBrowseMode'):
        assert token in card, token
    for token in ('@AppStorage', 'TimelineView', 'Canvas', 'PlaybackKitAetherHost', 'AVPlayer(',
                  'HomeGridThemeOverlay', 'repeatForever', 'Timer', 'Task.sleep'):
        assert token not in card, token
    tilt = block(app, 'struct FocusedSidewaysCardEffect:')
    assert tilt == block(old, 'struct FocusedSidewaysCardEffect:')
    assert 'focusTiltDegrees: Double = 10' in tilt and '.spring(response: 0.30, dampingFraction: 0.86)' in tilt
    layout = (ROOT / 'Sources/SignalSearchResultsLayout.swift').read_text()
    assert 'cardWidth: min(360, slot)' in layout and 'min(408,' in layout
    assert 'SignalSearchResultsLayout.swift' in (ROOT / 'project.yml').read_text()
    assert 'check_f55_native_search.py' in (ROOT / 'Scripts/check_f28_source_preflight.sh').read_text()
    print('F55 PASS: compact landscape lazy grid, native focus/scroll, retained sideways spring, scoped focus restore; unchanged query/hydration, Guide/player/Up Next, routing and season color')


if __name__ == '__main__':
    verify()
