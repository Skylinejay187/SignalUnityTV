#!/usr/bin/env python3
"""Current F38 contracts; source evidence does not replace Xcode/device testing."""
from f39_approved_deltas import historical_source
from pathlib import Path
import json,hashlib,re
from check_f31_top_menu_regression import block
from check_f37r1_regression import verify as historic_checks
from f38_approved_deltas import previous_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    historic_checks()
    app=historical_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    store=historical_source((ROOT/'Sources/CatalogStore.swift'))
    sources=historical_source((ROOT/'Sources/SourceIntelligenceManager.swift'))
    prep=block(app,'    private func prepareUpNextSourcesIfNeeded(')
    identity=block(app,'    private func startUpNextPreparationIfNeeded(')
    watchdog=block(app,'    private func startUpNextWatchdogIfNeeded(')
    discovery=block(store,'    func prepareUpNextEpisodeSources(')
    provider=block(store,'    private func upNextManifestLinks(')
    selection=block(store,'    private func upNextPreparedSelection(')
    assert 'remaining <= min(600, total * 0.90)' in prep
    assert 'remaining <= min(330, total * 0.75)' in prep and 'upNextSourcePreparationAttemptCount < 2' in prep
    assert 'upNextSourcePreparationAttemptCount < 3' in prep
    assert 'onReady: { ready in' in prep and 'upNextPreparation = ready' in prep
    assert 'store.playbackPresentationID == ownerPresentationID' in prep and 'store.playbackURL == ownerURL' in prep
    assert 'await store.playbackMetadata(for: next)' not in identity
    assert 'remaining <= min(660, total * 0.90)' in watchdog
    assert 'remaining <= 600 || upNextNaturalEndPending' in watchdog
    assert 'min(3, lanes.count)' in discovery and 'await group.next()' in discovery
    assert discovery.index('onReady?(ready)') < discovery.index('group.cancelAll()',discovery.index('onReady?(ready)'))
    assert 'if let firstReady { return firstReady }' in discovery
    assert 'Task.detached(priority: .utility)' in provider
    assert 'found.contains(where:' in provider and 'return found' in provider
    assert '> 1_000_000_000' in selection and '!upNextIsPreview' in selection
    assert 'declaredSizeBytes: stream.behaviorHints?.videoSize' in provider
    assert 'if let bytes = link.declaredSizeBytes, bytes > 0' in block(store,'    private func upNextSizeBytes(')
    assert 'requestHeaders: (stream.behaviorHints?.proxyHeaders?.request' in provider
    assert 'quickPlaybackPreflight' in selection and 'MediaFlowProxyRouter' in block(store,'    private func quickPlaybackPreflight(')
    assert 'streamLinks =' not in discovery and 'startPlayback(' not in discovery
    assert 'AetherEngine(' not in discovery and 'prewarm' not in discovery.lower()
    mix=block(sources,'    static func balancedProviderLinks(')
    assert 'SignalSourceMixingPolicy.interleaved' in mix and 'link.providerService' in mix and 'providerCanonical($0.source)' in mix
    assert 'return sortedStreamLinks(cappedOrdinary + usenetLinks' not in store
    assert 'self.sortedStreamLinks(ordinaryCapped + usenetVisible' not in store
    assert 'limit: cappedOrdinary.count + usenetLinks.count' in store
    assert 'limit: ordinaryCapped.count + usenetVisible.count' in store
    panel=block(app,'    private var activeSourceLinks:')
    assert panel.index('prioritizedLinks(') < panel.index('balancedProviderLinks(remembered')
    cast=block(app,'struct V1111FeaturedCastPosterCard: View')
    assert '.onChange(of: spotlightIndex)' in cast and 'if focusActive { castExplorerFocused = true }' in cast
    focus=block(app,'.onChange(of: focusedControl) { newFocus in')
    assert 'if focusedZone == .cast' in focus and 'featuredCastFocusRequestToken &+= 1' in focus
    assert 'focusedZone != .cast' in block(app,'    private func seedVODOverlayFocusIfNeeded(')
    assert block(app,'    private func scheduleOverlayAutoHideIfAllowed(').count('focusedZone != .cast')==2
    assert block(app,'    private func scheduleVODControlShelfAutoHide(').count('focusedZone != .cast')==2
    assert 'owner: "vod-cast"' in block(app,'    private func routePlayerMove(')
    menu=historical_source((ROOT/'Sources/SignalTopMenuTheme.swift'))
    visual=historical_source((ROOT/'Sources/SignalTopMenuVisuals.swift'))
    new_themes=('signalOriginal','floatingLens','graphiteCapsule','cinemaRail','crystalOutline','slimDock')
    render=visual.split('@ViewBuilder var body: some View {',2)[2].split('    private var signalOriginal:',1)[0]
    for name in new_themes:
        assert re.search(r'^    case '+name+r' = ',menu,re.M)
        assert re.search(r'case \.'+name+r': '+name,render)
    assert len(re.findall(r'^    case \w+ = ',menu.split('enum TopMenuThemeStyle:',1)[1].split('    var id:',1)[0],re.M))==30
    assert 'height: topMenuThemeStyle.itemHeight' in app
    nav=block(app,'struct TopMenuBar: View')
    assert '.focused($focusedTab, equals: tab)' in nav and 'routeMenuMove' not in nav
    assert 'height: theme.itemHeight' in block(visual,'struct TopMenuThemePreview:')
    background=historical_source((ROOT/'Sources/SignalBackgroundVisuals.swift'))
    smoke=historical_source((ROOT/'Sources/SignalGlassAtmosphereVisuals.swift'))
    options=historical_source((ROOT/'Sources/SignalVisualOptions.swift'))
    assert background.index('SignalGlassAtmosphere(') < background.index('Rectangle().fill(MainGridBackgroundStyle.glassColor')
    assert 'cloud.scaleBy(x: 1.7, y: 1)' in smoke and 'Gradient(stops:' in smoke
    assert 'context.stroke(p,' not in smoke and '.addCurve(' not in smoke
    assert 'if moving {' in smoke and '} else { light(at: frozenTime) }' in smoke
    assert '"Soft Caustics": Self.caustics' in options and '"Smoke · Cinematic"' in options
    assert 'Smoke Atmosphere:' in app
    for owner in ('catalog-rows','live-grid','settings-customization','vod-cast'):
        assert 'owner: "'+owner+'"' in app
    live_route=block(app,'    private func routeLiveSpecialMove(')
    assert 'edgeCommandGate.accept(' not in live_route and 'acceptSingleDpadStep()' not in live_route
    # Timing, reveal, paging destination math, fullscreen playback and Carousel
    # compile repair remain byte-identical to F37R1.
    for marker in ('    private func advanceLiveTVGridPage(', '    private func scheduleLiveTVGridFocusPreview(', '    private func cancelLiveTVGridFocusPreview(', '    private func liveCarouselCard(', '    private func playPreparedUpNextEpisode('):
        assert block(app,marker)==block(old,marker),'Changed preserved behavior: '+marker
    locks=json.loads(historical_source((ROOT/'Tests/F38UnchangedSourceHashes.json')))
    for name,sha in locks.items():assert hashlib.sha256(historical_source((ROOT/name)).encode()).hexdigest()==sha,'Changed protected source: '+name
    baseline=json.loads(historical_source((ROOT/'Tests/F32R1VODBehaviorBaseline.json')));vod=block(app,'struct VODPlayerScreen: View');prior=block(old,'struct VODPlayerScreen: View')
    changed=[m for m in baseline if block(vod,m)!=block(prior,m)]
    report={'checked_historical_vod_functions':len(baseline),'unchanged_from_f37r1':len(baseline)-len(changed),'intentional_changed_functions':changed}
    (ROOT/'F38_SCOPE.json').write_text(json.dumps(report,indent=2)+'\n')
    print('F38 checks passed: early first-ready links; service/addon alternation; manual cast ownership; 30 exact menu themes; smoke under shared glass; routed-repeat debounce')
    print('VOD scope:',report)
if __name__=='__main__':verify()
