#!/usr/bin/env python3
"""CURRENT artwork wiring and exact scope; historical contracts are checked separately."""
from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from source_hash_integrity import verify_unchanged_sources
from f78_approved_deltas import previous_source
from f79_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]

def audit(source):
    transport=block(source,'enum SignalArtworkTransport {')
    options=block(transport,'    static func options(')
    for required in ['.cacheOriginalImage','.originalCache(originalCache)','.targetCache(processedCache)',
                     '.asyncCacheTypeCheck','.waitForCache','.processingQueue(.dispatch(processingQueue))',
                     '.memoryCacheExpiration(.seconds(60))','.downloadPriority(speculative ? 0.1 : 0.8)']:
        assert required in options,required
    for token in ['KF.ImageResource(downloadURL: url, cacheKey: url.absoluteString)','func migrateProcessed()','func migrateOriginal()',
                  'if !request.cancelled','case .cacheError = error','maxPixelSize == 0',
                  'sourceWasLocal = true','missing.count >= 256','addingTimeInterval(60)']:
        assert token in transport,token
    assert '.forceRefresh' not in source and '.loadDiskFileSynchronously' not in source
    assert 'SignalArtworkFullSizeProcessor' in options
    assert 'SignalArtworkDownsamplingProcessor' in options
    downsample=block(source,'private struct SignalArtworkDownsamplingProcessor: ImageProcessor')
    assert 'var identifier: String { base.identifier }' in downsample
    assert 'base.process(item: .data(data), options: options)' in downsample
    assert 'cache.diskStorage.config.sizeLimit = 384 * 1024 * 1024' in transport
    assert 'cache.diskStorage.config.sizeLimit = 256 * 1024 * 1024' in transport
    assert 'url.query == nil' in transport and '.days(365) : .days(30)' in transport
    original=block(source,'enum PersistentArtworkSourceCache {')
    assert 'SignalArtworkTransport.originalCache.diskStorage.value(forKey: url.absoluteString)' in original
    assert 'validImageData(data)' in original and 'SignalArtworkTransport.originalCache.storeToDisk' in original
    pump=block(source,'    private static func pumpPrefetchQueue()')
    for token in ['permits(.backgroundPrefetch)','waitUntilPermittedDurably(.backgroundPrefetch)',
                  'SignalArtworkTransport.retrieve','speculative: true','prefetchOwnerTokens[url] == token']:
        assert token in pump,token
    assert 'maxActivePrefetchTasks = 2' in source
    prewarm=block(source,'    static func prewarm(')
    assert 'startSharedArtworkLoad' in prewarm
    load=block(source,'    func load(')
    assert 'startSharedArtworkLoad' in load
    shared=block(source,'    private static func startSharedArtworkLoad(')
    assert shared.count('networkLoadTokens[key] == token')>=2
    assert 'directOriginURL(from: key.url)' in shared and 'retrieve(origin, fallback: true)' in shared
    assert 'URLSession' not in shared and 'imageSession' not in source
    assert 'func imageDownloader(_ downloader: ImageDownloader, didDownload data: Data, with task: SessionDataTask)' in source
    assert 'networkTransfers' in source and 'networkBytes' in source and 'localLoadHitRatio' in source
    pressure=block(source,'    static func handleMemoryPressure()')
    assert 'clearMemoryCache()' in pressure and 'cancelIdlePrewarmsForNavigation()' in pressure
    assert 'clearDiskCache' not in pressure
    ui=block(source,'struct RemoteImageFit: View')
    assert '@StateObject private var loader' in ui and '.onDisappear { loader.cancel() }' in ui

def main():
    path='Sources/RemoteImageFit.swift';current=historical_source(ROOT/path);audit(current)
    baseline=previous_source(current,path)
    for marker in ['enum PremiumArtworkURL {','struct RemoteImageFit: View','private struct RemoteImageFitAspectModifier: ViewModifier']:
        assert block(current,marker)==block(baseline,marker),'UI/URL regression: '+marker
    oldLoad=block(baseline,'    func load(');oldPrefetch=block(baseline,'    private static func pumpPrefetchQueue()')
    assert 'KingfisherManager.shared.retrieveImage' in oldLoad and 'imageSession.dataTask' in oldPrefetch
    assert 'PersistentArtworkSourceCache' not in oldLoad and '.cacheOriginalImage' not in oldLoad
    assert 'cacheKey = key.cacheKey as String' in oldLoad
    verify_unchanged_sources(ROOT, json.loads((ROOT/'Tests/F78UnchangedSourceHashes.json').read_text()), historical_source)
    for old,new in [('.cacheOriginalImage,',''),('maxActivePrefetchTasks = 2','maxActivePrefetchTasks = 6'),
                    ('cacheKey: url.absoluteString','cacheKey: url.absoluteString + "|size"'),
                    ('.asyncCacheTypeCheck,','')]:
        try:audit(current.replace(old,new))
        except (AssertionError,ValueError):pass
        else:raise AssertionError('Bad artwork mutation accepted: '+old)
    print('F78 CURRENT artwork PASS: shared original bytes, stable URL/processor split, bounded navigation-aware prefetch, exact UI/URL preservation, lifecycle tokens, diagnostics, source hashes and four negative controls. Native transport/SDK/device checks separate.')
if __name__=='__main__':main()
