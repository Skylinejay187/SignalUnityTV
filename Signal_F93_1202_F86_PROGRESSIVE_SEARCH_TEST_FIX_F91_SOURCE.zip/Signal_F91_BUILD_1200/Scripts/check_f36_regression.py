#!/usr/bin/env python3
"""Current F36 contracts; physical tvOS validation still required."""
from f39_approved_deltas import historical_source
from pathlib import Path
import json,hashlib
from check_f31_top_menu_regression import block
from check_f34_visual_regression import validate
from f37_approved_deltas import previous_source as previous_f37
ROOT=Path(__file__).resolve().parents[1]
def verify():
    validate()
    app=previous_f37(historical_source((ROOT/'Sources/DebridChannelsTVOSApp.swift')),'Sources/DebridChannelsTVOSApp.swift')
    backdrop=historical_source((ROOT/'Sources/SignalGlassAtmosphereVisuals.swift'))
    bg=historical_source((ROOT/'Sources/SignalBackgroundVisuals.swift'))
    effects=historical_source((ROOT/'Sources/SignalLiveTVCardEffect.swift'))
    options=historical_source((ROOT/'Sources/SignalVisualOptions.swift'))
    glyph=historical_source((ROOT/'Sources/SignalSearchGlyph.swift'))
    nav=block(app,'struct TopMenuBar: View')
    assert '@FocusState private var focusedTab: AppTab?' in nav
    for removed in ('menuRowFocused','menuSearchHighlighted','routeMenuMove','SignalFocusOrder.step'):
        assert removed not in nav
    assert '.focused($focusedTab, equals: tab)' in nav
    assert 'private var outsideSearchButton:' in nav and '.focused($searchFocused)' in nav
    outside=block(nav,'    private var outsideSearchButton:')
    assert 'focusedTab =' not in outside and 'direction == .left' not in outside and 'direction == .right' not in outside
    assert 'lastTopMenuDownCommandAt = now' in outside
    category=block(app,'    private var categoryCardsRow: some View')
    assert '.focused($focused, equals: .category(category))' in category
    assert 'SignalFocusOrder.step' not in category and 'proxy.scrollTo' not in category
    assert 'categoryCursor' not in app
    leaf=block(app,'private struct LiveTVGridFocusPreviewSurface: View')
    assert 'onFirstFrameReady:' in leaf and '.opacity(ready ? 1 : 0)' in leaf
    assert 'Color.black' not in leaf
    assert 'fastLiveJoin: true' in leaf
    tile=block(app,'    private func liveTile(channel:')
    assert 'gridFocusPreviewReadyChannelID != nil' in tile
    assert 'previewPopOut: gridFocusPreviewReadyChannelID == channel.id' in tile
    assert 'guard gridFocusPreviewChannelID == channel.id, tileFocus == channel.id else' in tile
    assert 'SignalPreviewStartupPolicy.dwellNanoseconds' in block(app,'    private func scheduleLiveTVGridFocusPreview(')
    cancel=block(app,'    private func cancelLiveTVGridFocusPreview(')
    assert 'gridFocusPreviewReadyChannelID = nil' in cancel
    motion=block(app,'private struct LiveTVGridFocusMotionHost<Content: View>')
    assert '.opacity(dimmed ? 0.84 : 1.0)' in motion and '.opacity(dimmed ? 0.28' not in motion
    assert 'return containsLivePreview ? SignalLiveTVCardPose() : p' in motion
    assert 'SignalLiveTVCardTheme.surface(cardTheme, focused: isFocused)' in motion
    assert 'SignalCardDepthPlate(depth: surface.depth, bevel: surface.bevel' in motion
    assert 'SignalLiveTVCardTheme' not in block(effects,'enum SignalLiveTVCardEffect')
    assert 'SignalLiveTVCardEffect' not in block(effects,'    static func surface(')
    assert 'Curved Wall Max' in effects and 'Curved Wall Soft' in effects
    assert 'ClassicAmbientSmokeOverlay' not in app and 'LegacySignalSmokeLayer' not in app
    assert 'Ambient Classic Smoke:' not in app
    assert 'SignalGlassAtmosphere(' in bg and 'SignalBackdropArtwork(' in bg
    assert 'if moving {' in backdrop and '} else { light(at: frozenTime) }' in backdrop
    assert 'timeOffset += max(0, now - pausedAt)' in backdrop
    assert 'onDisplayedURLChange:' in backdrop and 'PremiumArtworkURL.url(url), displayed == target' in backdrop
    assert 'revealIfReady(incoming)' in backdrop and 'firstDisplayedURL = displayed' in backdrop
    assert 'index != front' in backdrop
    assert '.easeInOut(duration: 0.30)' in backdrop
    assert '@AppStorage("signalSearchEffectV1")' in glyph
    assert 'effect.animates(focused: focused)' in glyph
    for key in ('signalSearchEffectV1','signalGlassAtmosphereV1','signalCardSurfaceSchemaV1'):
        assert key in app and key in historical_source((ROOT/'Sources/ReleaseCandidateSecurityManager.swift'))
    for item in ('SignalVisualOptions.swift','SignalGlassAtmosphereVisuals.swift'):
        assert 'Sources/'+item in historical_source((ROOT/'project.yml'))
    assert 'edgeCommandGate.accept(' in block(app,'    private func routeLiveSpecialMove(')
    # F36 must not regress the fast Aether path confirmed by the user.
    lock=json.loads(historical_source((ROOT/'Tests/F36UnchangedSourceHashes.json')))
    for name,sha in lock.items():
        assert hashlib.sha256(previous_f37(historical_source((ROOT/name)),name).encode()).hexdigest()==sha,'Changed protected F35 source: '+name
    print('F36 checks passed: native focus restored; readiness-gated preview and gentle dim; independent shape/motion; retired smoke; glass light and Search choices; accepted fast-preview engine unchanged')
if __name__=='__main__':verify()
