#!/usr/bin/env python3
"""Scope checks for accent propagation, custom picker focus and bounded preview."""
from f39_approved_deltas import historical_source
from pathlib import Path
from check_f31_top_menu_regression import block
from check_f32r2_background_regression import validate
ROOT=Path(__file__).resolve().parents[1]

def verify():
    validate()
    app=historical_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    visual=historical_source((ROOT/'Sources/SignalTopMenuVisuals.swift'))
    background=historical_source((ROOT/'Sources/SignalBackgroundVisuals.swift'))
    for source, marker in ((visual,'struct TopMenuThemePicker:'),(background,'struct MainGridBackgroundPicker:')):
        picker=block(source,marker)
        assert 'SettingsRoundedFocusVisual' in picker
        assert '.buttonStyle(.plain)' not in picker
        assert '.focusEffectDisabled()' in picker
    chrome=block(visual,'private struct TopMenuChromeBackground:')
    assert 'private var barFill: LinearGradient' in chrome
    assert chrome.count('.fill(barFill)') >= 7
    assert 'accent.opacity(0.07)' in chrome
    lens=block(visual,'    @ViewBuilder private var lens:')
    assert 'accent.opacity(isFocused ? 0.25 : 0.14)' in lens and '.matchedGeometryEffect' not in lens
    assert 'private var selectionInk: Color { .white }' in visual
    assert 'SignalMenuContrast.prefersDarkInk(' in visual
    assert 'caseInsensitiveCompare(option.trimmingCharacters' in app
    preview=block(app,'private struct LiveTVGridFocusPreviewSurface:')
    assert 'GeometryReader { viewport in' in preview
    assert preview.count('.frame(width: viewport.size.width, height: viewport.size.height)') == 2
    assert preview.count('.clipped()') == 2
    assert '.brightness(' not in preview and '.contrast(' not in preview
    assert 'PlaybackKitAetherHost(' in preview and '.marksAuxiliaryVideoActivity(true)' in preview
    assert '.drawingGroup' not in preview and '.compositingGroup' not in preview
    motion=block(app,'private struct LiveTVGridFocusMotionHost<Content: View>')
    # F34 removes the outer shadow entirely after the same artifact was also
    # photographed in the static customization screen. Native video stays unfiltered.
    assert '.shadow(' not in motion and 'SignalCardDepthPlate(' in motion
    assert 'SignalLiveTVCardEffect.pose(' in motion
    print('F33 checks passed: 24 exact theme renderers; accent-tinted chrome/lens and readable ink; no native picker platter; bounded unfiltered Aether preview; bounded geometric card depth')

if __name__=='__main__':verify()
