#!/usr/bin/env python3
"""Pinned Aether 7.44 cache telemetry patch, applied before vendor checkout swap."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
def patch(engine):
    source=engine/'Sources/AetherEngine'
    host=source/'Native/NativeAVPlayerHost.swift'
    s=host.read_text()
    marker='    func signalCachedBufferEnd() -> Double {'
    if marker not in s:
        anchor='    private var loadedVideoRanges: [(Double, Double)] = []'
        assert s.count(anchor)==1, 'Pinned native cache-range storage changed'
        s=s.replace(anchor,anchor+'\n\n    func signalCachedBufferEnd() -> Double {\n        Self.contiguousBufferedEnd(ranges: loadedVideoRanges, now: currentTime)\n    }',1)
        host.write_text(s)
    for path,token in [('Native/SoftwarePlaybackHost.swift','var cachedVODSessionTime: Double?'),
                       ('Video/HLSVideoEngine.swift','func contiguousForwardReadAheadSeconds(playlistSeconds: Double)'),
                       ('Native/SoftwareBufferFrontier.swift','static func bufferedPosition(')]:
        assert token in (source/path).read_text(), 'Pinned cache API changed: '+path
    (source/'AetherEngine+SignalCacheFrontier.swift').write_bytes((ROOT/'EnginePatches/AetherEngine+SignalCacheFrontier.swift').read_bytes())
    print('F42 producer cache-frontier telemetry hook installed')
if __name__=='__main__':patch(Path(sys.argv[1]))
