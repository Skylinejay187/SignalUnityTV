#!/usr/bin/env python3
"""Search entry, mounted-cell handoff and offscreen row navigation contracts."""
from pathlib import Path
import hashlib
import json
from check_f31_top_menu_regression import block
from f58_approved_deltas import previous_source
from f59_approved_deltas import historical_source

ROOT = Path(__file__).resolve().parents[1]


def audit_focus(search):
    grid = block(search, '    private func searchResultsGrid(')
    assert 'Button { openSearchResult(item) } label:' in grid
    assert '.buttonStyle(.plain)' in grid and '.focusSection()' in grid
    assert '.focusable(' not in grid and '.onTapGesture' not in grid
    for token in ('case .down: moveSearchResults(from: item.id', 'case .up: moveSearchResults(from: item.id',
                  'case .left: moveSearchResults(from: item.id', 'case .right: moveSearchResults(from: item.id',
                  'await focusMountedSearchResult(item.id, request: resultFocusRequest)'):
        assert token in grid, token
    entry = block(search, '    private func focusResults(')
    assert entry.index('resultsFocusRequested = true') < entry.index('guard let index')
    assert 'case .down: focusResults()' in search
    scroll = block(search, '    private func restoreSearchGridFocus(')
    assert 'proxy.scrollTo' in scroll and 'focusedID =' not in scroll
    mounted = block(search, '    private func focusMountedSearchResult(')
    for token in ('Task.isCancelled', 'resultFocusRequest == request', 'resultFocusTargetID == id',
                  'searchSurfaceActive', 'scenePhase == .active', 'store.selectedDetail == nil',
                  '!queryFieldFocused', 'focusedID = id'):
        assert token in mounted, token
    assert mounted.index('await Task.yield()') < mounted.index('focusedID = id')
    move = block(search, '    private func moveSearchResults(')
    assert 'firstIndex(where: { $0.id == id })' in move and 'SignalSearchResultsLayout.movedIndex' in move
    assert 'focusSearchScope(searchScope, delta: 0)' in move
    assert 'resultsFocusRequested ||' in block(search, '    private func restoreSearchResultFocus(')


def verify():
    for name, record in json.loads((ROOT / 'Tests/F58ApprovedSourceDeltas.json').read_text()).items():
        source = historical_source(ROOT / name)
        assert hashlib.sha256(source.encode()).hexdigest() == record['after_sha256'], name
        previous_source(source, name)
    for name, expected in json.loads((ROOT / 'Tests/F58UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT / name).encode()).hexdigest() == expected, name
    app = historical_source(ROOT / 'Sources/DebridChannelsTVOSApp.swift')
    old = previous_source(app, 'Sources/DebridChannelsTVOSApp.swift')
    search = block(app, 'struct GlobalSearchScreen: View')
    prior = block(old, 'struct GlobalSearchScreen: View')
    audit_focus(search)
    try:
        audit_focus(prior)
    except AssertionError:
        pass
    else:
        raise AssertionError('F57 Search without mounted row routing must fail')
    for marker in ('    private func scheduleUnifiedSearch(', '    private func openSearchResult(',
                   '    private func scheduleSearchProductionPrefetch(', '    private func prewarmSearchProductionDetails('):
        assert block(search, marker) == block(prior, marker), marker
    for marker in ('struct VODPlayerScreen: View', 'struct LiveTVScreen: View', 'struct MediaInfoPopup: View',
                   'struct ManualEpisodesRow: View', 'struct SearchResultCard: View'):
        assert block(app, marker) == block(old, marker), marker
    assert 'check_f58_native_navigation.py' in (ROOT / 'Scripts/check_f28_source_preflight.sh').read_text()
    print('F58 PASS: native result Buttons, header Down entry, pending Done intent, mounted-cell focus, four-direction lazy row routing; F57 negative control rejected; playback/Guide/cards/query pipeline preserved')


if __name__ == '__main__':
    verify()
