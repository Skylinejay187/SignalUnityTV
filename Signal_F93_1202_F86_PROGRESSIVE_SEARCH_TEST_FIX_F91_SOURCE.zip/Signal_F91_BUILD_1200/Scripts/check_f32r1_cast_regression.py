#!/usr/bin/env python3
"""Scope and production wiring for manual cast browsing with presentation Off."""
from f39_approved_deltas import historical_source
from pathlib import Path
from f38_approved_deltas import previous_source as previous_f38
import hashlib,json
from check_f31_top_menu_regression import block
from check_f32_visual_regression import validate
ROOT=Path(__file__).resolve().parents[1]
def verify():
    validate()
    app=historical_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    vod=block(app,'struct VODPlayerScreen: View')
    historic_vod=block(previous_f38(app,'Sources/DebridChannelsTVOSApp.swift'),'struct VODPlayerScreen: View')
    baseline=json.loads(historical_source((ROOT/'Tests/F32R1VODBehaviorBaseline.json')))
    for marker,expected in baseline.items():
        assert hashlib.sha256(block(historic_vod,marker).encode()).hexdigest()==expected, 'Unrelated VOD behavior changed: '+marker
    route=block(vod,'    private func routePlayerMove(')
    cast_route=route.split('        case .cast:',1)[1].split('        case .video:',1)[0]
    assert 'case .left:\n                moveFeaturedCast(by: -1)' in cast_route
    assert 'case .right:\n                moveFeaturedCast(by: 1)' in cast_route
    assert 'focusedZone = .timeline' in cast_route and 'seekRelative' not in cast_route
    timeline_route=route.split('        case .timeline:',1)[1].split('        case .chips:',1)[0]
    assert 'vodFeaturedCastPresentationMode.permitsManualBrowse(' in timeline_route
    assert 'vodFeaturedCastPresentationMode != .off' not in timeline_route
    assert 'memberCount: manuallyNavigableFeaturedCast.count' in timeline_route
    card=block(app,'struct V1111FeaturedCastPosterCard: View')
    selectable=block(card,'    private var isCastSelectable:')
    assert 'mode.permitsManualBrowse(' in selectable and '.off' not in selectable
    assert 'mode.showsPortrait(' in block(card,'    private var shouldShowFullPosterCast:')
    assert '.focusable(isCastSelectable && focusActive)' in card
    assert 'mode.automaticallyRotates' in block(card,'    private func runRotationTask()')
    assert 'if mode == .fullPoster || (mode == .off && focusActive)' in card
    assert 'awake, mode != .off || focusActive' in card
    assert 'onCastSelected(member)' in block(card,'    private func handleCastSelection()')
    policy=historical_source((ROOT/'Sources/VODCastNavigationPolicy.swift'))
    assert 'case .off: return focusActive' in policy
    assert 'var automaticallyRotates: Bool { self != .off }' in policy
    assert 'enum VODFeaturedCastPresentationMode:' not in app
    assert 'Sources/VODCastNavigationPolicy.swift' in historical_source((ROOT/'project.yml'))
    print(f'F32R1 cast wiring passed; {len(baseline)} historical VOD function locks checked through reviewed deltas; Off supports manual focus, Left/Right, Select and Down without automatic rotation')
if __name__=='__main__': verify()
