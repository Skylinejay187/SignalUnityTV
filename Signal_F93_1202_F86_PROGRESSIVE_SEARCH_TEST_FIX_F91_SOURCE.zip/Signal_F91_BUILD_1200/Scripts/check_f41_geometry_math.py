#!/usr/bin/env python3
"""Numerically audit the production Swift coefficient expressions against a
separate rotated-corner reference. This does not compile/type-check Swift or
prove tvOS rendering; the macOS Swift executable tests cover that boundary.
"""
from pathlib import Path
import ast,math,re
ROOT=Path(__file__).resolve().parents[1]
def split_top(text):
    result=[];start=0;depth=0
    for i,ch in enumerate(text):
        if ch in '([':depth+=1
        elif ch in ')]':depth-=1
        elif ch==',' and depth==0:result.append(text[start:i].strip());start=i+1
    result.append(text[start:].strip());return result

def evaluate(expr,values):
    expr=re.sub(r'\.pi\b','pi',expr)
    expr=re.sub(r'pose\.(yaw|pitch|roll)',r'pose_\1',expr)
    expr=re.sub(r'focused\s*\?\s*([^:]+):\s*([^)]*)',r'\1 if focused else \2',expr)
    # The current fit helper selects uniform or independent axis scales.
    # Keep parsing restricted to the production subset; never bypass the audit.
    ternary=re.fullmatch(r'\s*uniform\s*\?\s*(.+?)\s*:\s*(.+)\s*',expr)
    if ternary:expr=f'({ternary[1]}) if uniform else ({ternary[2]})'
    # Swift ternaries inside arithmetic parentheses now use Python's matching form.
    node=ast.parse(expr.strip(),mode='eval')
    allowed=(ast.Expression,ast.Constant,ast.Name,ast.Load,ast.BinOp,ast.Add,ast.Sub,ast.Mult,ast.Div,
             ast.UnaryOp,ast.USub,ast.UAdd,ast.IfExp,ast.Call)
    assert all(isinstance(n,allowed) for n in ast.walk(node)),expr
    context={'pi':math.pi,'cos':math.cos,'sin':math.sin,'max':max,'min':min,**values}
    return eval(compile(node,'<Swift numeric expression>','eval'),{'__builtins__':{}},context)

def audit():
    effect=(ROOT/'Sources/SignalLiveTVCardEffect.swift').read_text()
    source=(ROOT/'Sources/SignalLiveTVCardAlignment.swift').read_text()
    bases=ast.literal_eval(effect.split('static let baseNames = ',1)[1].split('\n    static let alignedSuffix',1)[0])
    default=""
    effect_body=effect.split('    private static func basePose(',1)[1].split('\n}\n',1)[0]
    cases={}
    for line in effect_body.splitlines():
        match=re.search(r'(case .*?|default): return \.init\((.*)\)',line)
        if not match:continue
        if match[1]=='default':default=match[2]
        else:
            for name in re.findall(r'"([^"]+)"',match[1]):cases[name]=match[2]
    expressions={}
    desired={'yaw','pitch','roll','cy','sy','cp','sp','cr','sr','aa','cc','bb','dd','camera','pp','qq','cx','centerY','fitX','fitY','sx','ssY','padX','padY','a','b','c','d'}
    for line in source.splitlines():
        line=line.strip()
        if not line.startswith('let '):continue
        for assignment in split_top(line[4:]):
            if '=' not in assignment:continue
            name,expr=map(str.strip,assignment.split('=',1))
            if name in desired:expressions[name]=expr
    args=re.search(r'return \.init\(a: a,(.*?)\)\n    }',source,re.S)
    assert args
    coefficients=dict(piece.split(':',1) for piece in split_top('a: a,'+args[1]))
    coefficients={name.strip():expr.strip() for name,expr in coefficients.items()}
    assert set(coefficients)=={'a','b','c','d','tx','ty','p','q','r'}
    order=['yaw','pitch','roll','cy','sy','cp','sp','cr','sr','aa','cc','bb','dd','camera','pp','qq','cx','centerY']
    count=0
    for name in bases:
        for col in range(4):
            for focused in [False,True]:
                pose={'yaw':0.0,'pitch':0.0,'roll':0.0,'x':0.0,'y':0.0}
                for arg in split_top(cases.get(name,default)):
                    if not arg:continue
                    key,value=arg.split(':',1)
                    pose[key.strip()]=evaluate(value,{'focused':focused,'side':1.0 if col<2 else -1.0,'lane':col-1.5})
                for width,height in [(480.0,270.0),(320.0,183.0),(360.0,210.0)]:
                    v={'width':width,'height':height,**{'pose_'+k:pose[k] for k in ['yaw','pitch','roll']}}
                    for key in order:v[key]=evaluate(expressions[key],v)
                    # Reference: rotate centered corner vectors in three dimensions,
                    # project them, then use their desired cell-space bounds.
                    reference=[]
                    for x,y in [(0,0),(width,0),(0,height),(width,height)]:
                        u=x-width/2;vv=y-height/2
                        xx=math.cos(v['yaw'])*u;zz=-math.sin(v['yaw'])*u
                        yy=math.cos(v['pitch'])*vv-math.sin(v['pitch'])*zz
                        zz=math.sin(v['pitch'])*vv+math.cos(v['pitch'])*zz
                        rx=math.cos(v['roll'])*xx-math.sin(v['roll'])*yy
                        ry=math.sin(v['roll'])*xx+math.cos(v['roll'])*yy
                        divisor=1-zz/(max(width,height)*2.4)
                        reference.append((rx/divisor,ry/divisor))
                    v.update(minX=min(p[0] for p in reference),maxX=max(p[0] for p in reference),minY=min(p[1] for p in reference),maxY=max(p[1] for p in reference))
                    for uniform in [False,True]:
                        v['uniform']=uniform
                        for key in ['fitX','fitY','sx','ssY','padX','padY','a','c','b','d']:
                            v[key]=evaluate(expressions[key],v)
                        m={k:evaluate(expr,v) for k,expr in coefficients.items()}
                        projected=[]
                        for x,y in [(0,0),(width,0),(0,height),(width,height)]:
                            divisor=m['p']*x+m['q']*y+m['r'];assert divisor>0
                            projected.append(((m['a']*x+m['c']*y+m['tx'])/divisor,(m['b']*x+m['d']*y+m['ty'])/divisor))
                        # Independent reference fit: one scale preserves the contour;
                        # legacy fit fills both axes. Compare every corner, not just bounds.
                        loX=min(p[0] for p in reference);hiX=max(p[0] for p in reference)
                        loY=min(p[1] for p in reference);hiY=max(p[1] for p in reference)
                        refX=width/(hiX-loX);refY=height/(hiY-loY)
                        if uniform:refX=refY=min(refX,refY)
                        insetX=(width-(hiX-loX)*refX)/2
                        insetY=(height-(hiY-loY)*refY)/2
                        expected=[((x-loX)*refX+insetX,(y-loY)*refY+insetY) for x,y in reference]
                        details=(name,col,focused,uniform,width,height)
                        assert all(math.isfinite(c) for point in projected for c in point),details
                        assert all(abs(a-b)<1e-6 for actual,want in zip(projected,expected) for a,b in zip(actual,want)),details
                        bounds=[min(p[0] for p in projected),max(p[0] for p in projected),min(p[1] for p in projected),max(p[1] for p in projected)]
                        assert bounds[0]>=-1e-6 and bounds[1]<=width+1e-6 and bounds[2]>=-1e-6 and bounds[3]<=height+1e-6,details
                        assert abs(bounds[0]+bounds[1]-width)<1e-6 and abs(bounds[2]+bounds[3]-height)<1e-6,details
                        for row in range(3):
                            assert abs(min(p[1]+row*(height+23) for p in projected)-(insetY+row*(height+23)))<1e-6,details
                        count+=1
    print(f'F41 numeric coefficient audit passed: {count} fitted quads, finite positive projection, independent corner agreement, centered bounded uniform/legacy fits and repeated row gutters')
if __name__=='__main__':audit()
