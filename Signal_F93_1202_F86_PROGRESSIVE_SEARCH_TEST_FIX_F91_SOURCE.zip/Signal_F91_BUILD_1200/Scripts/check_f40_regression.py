#!/usr/bin/env python3
"""Current F40 build repair, UI exit routes, cancellation ownership and scope."""
from f41_approved_deltas import historical_source as f40_source
from pathlib import Path
import hashlib,json,re
from check_f31_top_menu_regression import block
from f40_approved_deltas import previous_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    for name,record in json.loads(f40_source((ROOT/'Tests/F40ApprovedSourceDeltas.json'))).items():
        current=f40_source((ROOT/name))
        assert hashlib.sha256(current.encode()).hexdigest()==record['after_sha256'],name
        previous_source(current,name)
    for name,sha in json.loads(f40_source((ROOT/'Tests/F40UnchangedSourceHashes.json'))).items():
        assert hashlib.sha256(f40_source((ROOT/name)).encode()).hexdigest()==sha,name
    glyph=f40_source((ROOT/'Sources/SignalSearchGlyph.swift'))
    native=block(glyph,'private final class SignalSearchLayerView: UIView')
    assert not re.search(r'\bvar\s+focused\b',native),'UIKit inherited property collision'
    assert 'private var glyphHasFocus = false' in native
    old=previous_source(glyph,'Sources/SignalSearchGlyph.swift')
    a=old.index('private final class SignalSearchLayerView: UIView')
    expected=old[:a]+old[a:].replace('private var focused = false','private var glyphHasFocus = false').replace('self.focused','self.glyphHasFocus').replace('effect != .focusOnly || focused else','effect != .focusOnly || glyphHasFocus else')
    assert glyph==expected,'Search renderer changed beyond the build repair'
    app=f40_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    prior=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    assert block(app,'struct LiveTVScreen: View')==block(prior,'struct LiveTVScreen: View')
    button=block(app,'    private var upNextDismissButton:')
    assert 'Button("Dismiss")' in button and 'cancelUpNextCountdown()' in button
    assert '.disabled' not in button and 'sourceReady' not in button and 'upNextFocusedAction' in button
    fallback=block(app,'    private var upNextUnavailableOverlay:')
    assert 'upNextDismissButton' in fallback
    for marker in ('    private var upNextEpisodeOverlay:', '    private var upNextCinematicOverlay:'):
        panel=block(app,marker)
        assert 'upNextDismissButton' in panel and '} else {\n            upNextUnavailableOverlay' in panel
    visual=block(app,'    private var playerVisualTree:')
    assert visual.count('.onExitCommand { cancelUpNextCountdown() }')==2
    assert visual.count('.onMoveCommand { routeUpNextMove($0) }')==2
    assert '&& !upNextVisible && !upNextCinematicVisible {' in visual
    assert 'guard !Task.isCancelled, upNextVisible, !upNextDismissed, !isDismissingPlayer' in visual
    command=block(app,'    private var playerCommandTree:')
    assert 'else if upNextCinematicVisible || upNextVisible {\n                cancelUpNextCountdown()' in command
    dismiss=block(app,'    private func cancelUpNextCountdown(')
    assert 'upNextDismissal.dismiss(episodeEnded: episodeEnded)' in dismiss
    for token in ('upNextVisible = false','upNextCinematicVisible = false','upNextAutoAdvanceArmed = false',
                  'upNextSourcePreparationTask?.cancel()','upNextEOFSourceRetryTask?.cancel()',
                  'showControlsWithoutChangingFocus()','seedVODOverlayFocusIfNeeded()'):
        assert token in dismiss,token
    assert 'upNextPostEOFTask?.cancel()' not in dismiss,'Natural-end bookkeeping must still finish'
    source=block(app,'    private func prepareUpNextSourcesIfNeeded(')
    assert source.count('!upNextAutoNextCancelled')>=3
    assert 'upNextFocusedAction = .play' not in source
    for marker in ('    private func playPreparedUpNextEpisode(', '    private func armUpNextAutoAdvanceIfNeeded(',
                   '    private func evaluateCinematicAutoNext(', '    private func evaluateUpNextPresentation(',
                   '    private func scheduleUpNextEOFSourceRetryIfNeeded('):
        assert '!upNextAutoNextCancelled' in block(app,marker),marker
    # The handoff remains byte-preserved after the additional cancellation guard.
    marker='    private func playPreparedUpNextEpisode('
    play=block(app,marker);oldplay=block(prior,marker)
    assert play==oldplay.replace('guard !upNextPlaybackStarting,','guard !upNextPlaybackStarting, !upNextAutoNextCancelled, !isDismissingPlayer,')
    eof=block(app,'    private func schedulePostEOFUpNextWork(')
    assert '!vodAsyncRuntime.naturalEpisodeBookkeepingCompleted' in eof
    assert eof.index('TraktSyncManager.shared.markCompleted(')<eof.index('upNextDismissal.reachedEnd()')<eof.index('guard !upNextAutoNextCancelled else')
    assert 'naturalEpisodeBookkeepingCompleted = true' in eof
    identity=block(app,'    private func startUpNextPreparationIfNeeded(')
    no_next=block(identity,'            guard let next = nextEpisode(')
    assert 'upNextVisible = false' in no_next and 'upNextCinematicVisible = false' in no_next
    assert 'controlsVisible = true' in no_next
    route=block(app,'    private func routeUpNextMove(')
    assert 'case .up:' in route and 'case .down:' in route
    assert 'DispatchQueue.main.asyncAfter' not in block(app,'    private func evaluateUpNextPresentation(')
    assert 'upNextDismissed = false' not in app and 'upNextAutoNextCancelled = false' not in app
    assert 'Sources/SignalUpNextDismissalState.swift' in f40_source((ROOT/'project.yml'))
    oldvod=block(prior,'struct VODPlayerScreen: View');newvod=block(app,'struct VODPlayerScreen: View')
    tracked=json.loads(f40_source((ROOT/'Tests/F32R1VODBehaviorBaseline.json')))
    changed=[m for m in tracked if block(oldvod,m)!=block(newvod,m)]
    allowed=('cancelUpNextCountdown','playPreparedUpNextEpisode','routeUpNextMove','handlePlayerSelectPress',
             'startUpNextPreparationIfNeeded','loadUpNextDecorationAfterCurrentEpisodeEndsIfNeeded',
             'scheduleUpNextEOFSourceRetryIfNeeded','prepareUpNextSourcesIfNeeded','evaluateUpNextPresentation',
             'evaluateCinematicAutoNext','armUpNextAutoAdvanceIfNeeded','handleNaturalEpisodeEnd',
             'schedulePostEOFUpNextWork','seedVODOverlayFocusIfNeeded')
    assert all(any('func '+name+'(' in marker for name in allowed) for marker in changed),changed
    scope={'tracked_VOD_functions':len(tracked),'unchanged_from_F39':len(tracked)-len(changed),'intentional_dismissal_changes':changed}
    (ROOT/'F40_SCOPE.json').write_text(json.dumps(scope,indent=2)+'\n')
    print('F40 current checks passed: UIKit property repair; shared always-enabled Dismiss; nil-metadata fallback; Back and DPAD; no canvas focus theft; sticky EOF cancellation; source/commit guards; watched-history bookkeeping preserved')
    print('F40 scope:',scope)
if __name__=='__main__':verify()
