#!/usr/bin/env python3
from pathlib import Path
import hashlib, json
from check_f31_top_menu_regression import block
from f65_approved_deltas import previous_source
from f66_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    records=json.loads(historical_source(ROOT/'Tests/F65ApprovedSourceDeltas.json'))
    for path,record in records.items():
        value=historical_source(ROOT/path)
        assert hashlib.sha256(value.encode()).hexdigest()==record['after_sha256'],path
        previous_source(value,path)
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
    lookup=block(app,'    private func startEpisodeSegmentsIfNeeded(')
    for token in ('episodeSegmentsTask == nil','episodeSegmentsAttempts < 3','Date() >= episodeSegmentsRetryAfter','forceRefresh: retry','store.playbackPresentationID == owner','store.playbackURL == source'):
        assert token in lookup,token
    assert 'playableEpisodeSegments' in block(app,'    private func evaluateEpisodeExperience(')
    select=block(app,'    private func handlePlayerSelectPress(')
    assert select.index('performSkipRecap()') < select.index('if !controlsVisible')
    seek=block(app,'    private func performSkipRecap(')
    assert 'seekAbsolute(segment.end' in seek and 'episodeSegmentActions.insert' in seek
    prompt=block(app,'    private var manualRecapSegment:')
    for token in ('!episodeSettingsPresented','!isSeekingInPlayer','!protectedRouteStopped','scenePhase == .active','!episodeSegmentActions.contains','store.playbackURL == url'):assert token in prompt,token
    assert 'if manualRecapSegment != nil' in block(app,'    private var playerVisualTree:')
    fetch=block(app,'    private func fetchText(_ urlString:')
    assert 'providerRefreshIsForced' in fetch and '.reloadIgnoringLocalAndRemoteCacheData' in fetch
    short=block(app,'    private func loadXtreamShortGuidePrograms(')
    assert 'if providerRefreshIsForced' in short and 'maxWait: 0.80' in short
    refresh=block(app,'    private func runQuickPanelForceRefresh(')
    assert 'while liveModel.guideRecoveryRequired' not in refresh
    assert 'await liveModel.forceRefreshGuide()' in refresh and 'liveTVArtworkRefreshToken &+= 1' in refresh
    provider=block(app,'    private func performConfiguredSourceRefresh(')
    assert 'xmlGuideFragments.joined' not in provider
    assert 'for document in guideDocuments' in provider
    assert 'parseXMLTV(document, channels: finalized)' in provider
    assert 'Text(liveModel.status)' in block(app,'    private var quickPanelRefreshLabel:')
    # Cache is genuinely called on focused catalog, search and detail paths.
    catalog=historical_source(ROOT/'Sources/CatalogStore.swift')
    assert catalog.count('SignalMetadataResponseCache.shared.data(for:') >= 8
    assert 'CatalogHeroMetadataCache.shared.metadata(' in app
    assert hashlib.sha256(historical_source(ROOT/'Sources/SignalMetadataResponseCache.swift').encode()).hexdigest()=="68adf552ba7deeb8208746df328dc715ea7238758a9e444413c73adde31a0410"
    print('F65 current-source recap Select/seek, retry ownership, EPG reload/publication/documents, and metadata call-path checks PASS')
if __name__=='__main__':verify()
