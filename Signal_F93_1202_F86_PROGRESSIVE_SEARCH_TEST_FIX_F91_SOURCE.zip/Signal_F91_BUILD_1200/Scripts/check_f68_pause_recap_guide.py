#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from f68_approved_deltas import previous_source
from f69_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    records=json.loads(historical_source(ROOT/'Tests/F68ApprovedSourceDeltas.json'))
    for path,record in records.items():
        value=historical_source(ROOT/path);assert hashlib.sha256(value.encode()).hexdigest()==record['after_sha256'],path
        previous_source(value,path)
    for path,digest in json.loads(historical_source(ROOT/'Tests/F68UnchangedSourceHashes.json')).items():assert hashlib.sha256(historical_source(ROOT/path).encode()).hexdigest()==digest,path
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
    pause=historical_source(ROOT/'Sources/SignalPausedPlaybackInfoOverlay.swift')
    assert 'details.synopsis' not in pause
    title=block(app,'    private var pausedPlaybackTitle:')
    for token in ('Artwork4HeroLogoLayer','CatalogArtworkCacheManager.themedLogoURL','publishDuringPlayback: true','SignalPauseInfoPolicy.metadata'):assert token in title,token
    mapping=block(app,'    private var pausedPlaybackInformation:')
    for token in ('synopsis: ""','titleArtwork: AnyView(pausedPlaybackTitle)','accent: vodOverlayThemePreset.accent'):assert token in mapping,token
    assert 'Text(details.episode)' in pause and 'SignalPauseInfoPolicy.estimatedEnd(' in pause
    gate=historical_source(ROOT/'Sources/SignalEpisodeClockGate.swift');assert 'precision ? 0.15 : 0.5' in gate
    processor=block(app,'    private func processEpisodePlaybackClock(')
    assert 'precision: playableEpisodeSegments.contains' in processor and 'lead: 1' in processor
    assert 'processEpisodePlaybackClock(force: true)' in block(app,'    private func startEpisodeSegmentsIfNeeded(')
    assert 'processEpisodePlaybackClock(force: true)' in block(app,'    private var playerPlaybackStateTree:')
    service=historical_source(ROOT/'Sources/SignalEpisodeSegments.swift')
    auto=block(service,'    static func action(')
    assert 'position >= $0.start' in auto and 'lead:' not in auto
    model=block(app,'final class LiveTVSourceModel:')
    for name in ('channels:','guidePrograms:','playbackQuickGuidePrograms:'):
        index=model.index(name);assert 'invalidateGuideDerivedMetadata()' in model[index:index+500],name
    for name in ('suspendForVODPlayback','suspendForSurfaceExit','prepareForFullScreenPlayback'):
        assert 'invalidateGuideDerivedMetadata()' in block(model,'    func '+name+'(')
    rows=block(model,'    func programs(for channel:')
    assert 'resolvedGuideRows.value(for: channel)' in rows and 'synchronizeGuideDerivedMetadata()' in rows
    timeline=block(model,'    func timelineMetadata(')
    for token in ('axis.start','axis.scheduleWidth','guideTimelineMetadataCache.value','axis.slots(entries)','prefix(10)'):assert token in timeline,token
    sync=block(model,'    private func synchronizeGuideDerivedMetadata(')
    for token in ('Self.sessionSnapshotVersion','SignalGuideMetadataCacheControl.revision','metadataCacheEnabledV1'):assert token in sync,token
    row=block(app,'    private func googleGuideTimelineRow(')
    assert 'liveModel.timelineMetadata(for: channel, axis: axis)' in row
    assert 'axis.slots(' not in row and '.sorted' not in row
    assert 'axis.x(at: now)' in row
    settings=historical_source(ROOT/'Sources/SignalEpisodeExperienceSettings.swift')
    assert 'episode and Guide metadata' in settings and 'SignalGuideMetadataCacheControl.clear()' in settings
    assert 'python3 Scripts/check_f68_native_guide.py' in historical_source(ROOT/'Scripts/prepare_build_deps_vBRDC280.sh')
    print('F68 current pause branding/no plot, earlier manual recap/exact auto start, bounded EPG projection wiring/clear/disable/freshness PASS')
if __name__=='__main__':verify()
