#!/usr/bin/env python3
"""Validate current app/extension/project identity without a historical build pin."""
from pathlib import Path
import plistlib
import re
import sys

class BuildIdentityError(ValueError):
    pass

def validate(root: Path) -> dict:
    app = plistlib.loads((root / 'Sources/Info.plist').read_bytes())
    extension = plistlib.loads((root / 'TopShelfExtension/Info.plist').read_bytes())
    project = (root / 'project.yml').read_text()
    keys = ('CFBundleShortVersionString', 'CFBundleVersion', 'DebridChannelsReleaseID')
    for key in keys:
        value = app.get(key)
        if not isinstance(value, str) or not value.strip():
            raise BuildIdentityError(f'App metadata missing {key}')
        if extension.get(key) != value:
            raise BuildIdentityError(f'Top Shelf {key}: {extension.get(key)!r}; expected {value!r}')
    version = app['CFBundleShortVersionString']
    build = app['CFBundleVersion']
    if not re.fullmatch(r'\d+\.\d+(?:\.\d+)?', version):
        raise BuildIdentityError(f'Invalid app version: {version!r}')
    if not build.isdigit() or int(build) < 1:
        raise BuildIdentityError(f'Invalid app build: {build!r}')
    for setting, expected in [('MARKETING_VERSION', version), ('CURRENT_PROJECT_VERSION', build)]:
        values = re.findall(r'^\s*' + setting + r''':\s*["']?([^\s"'#]+)''', project, re.M)
        if not values:
            raise BuildIdentityError(f'project.yml has no {setting}')
        if any(value != expected for value in values):
            raise BuildIdentityError(f'project.yml {setting}: {values!r}; every value must be {expected!r}')
    return {'release': app['DebridChannelsReleaseID'], 'version': version, 'build': build}

def main() -> None:
    try:
        identity = validate(Path(__file__).resolve().parents[1])
    except (BuildIdentityError, OSError, plistlib.InvalidFileException) as error:
        raise SystemExit('Build identity check failed: ' + str(error))
    print(f"{identity['release']} / {identity['version']} / build {identity['build']}: app, Top Shelf and project identity aligned")

if __name__ == '__main__':
    main()
