#!/usr/bin/env python3
from pathlib import Path
import shutil,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
def main():
    if not shutil.which('swiftc'):raise SystemExit('Swift compiler required for preview policy execution')
    with tempfile.TemporaryDirectory(prefix='signal-f73-preview-') as folder:
        out=Path(folder)/'tests'
        subprocess.run(['swiftc','-swift-version','5',str(ROOT/'Sources/SignalLiveTVResourcePolicy.swift'),str(ROOT/'Tests/SignalF73PreviewPolicyTests.swift'),'-o',str(out)],check=True,timeout=60)
        subprocess.run([str(out)],check=True,timeout=10)
if __name__=='__main__':main()
