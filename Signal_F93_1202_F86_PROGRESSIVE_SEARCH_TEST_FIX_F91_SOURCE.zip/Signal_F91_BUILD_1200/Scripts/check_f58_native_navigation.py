#!/usr/bin/env python3
"""Compile and run real Search D-pad indexing across complete/partial lazy rows."""
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    compiler = shutil.which('swiftc')
    if not compiler:
        raise SystemExit('Swift compiler required for F58 native navigation checks')
    with tempfile.TemporaryDirectory(prefix='signal-f58-') as directory:
        executable = Path(directory) / 'search-tests'
        subprocess.run([compiler, '-swift-version', '5', str(ROOT / 'Sources/SignalSearchResultsLayout.swift'),
                        str(ROOT / 'Tests/SignalF58SearchNavigationTests.swift'), '-o', str(executable)], check=True, timeout=60)
        subprocess.run([str(executable)], check=True, timeout=30)


if __name__ == '__main__':
    main()
