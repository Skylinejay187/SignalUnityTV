#!/bin/bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
# F67: reject unlisted app Swift files before dependency downloads or compilation.
python3 Scripts/check_app_source_membership.py
python3 Scripts/check_f91_inherited_f87.py
python3 Scripts/check_f87_native_unity_sports.py
python3 Scripts/check_f86_search_build.py
python3 Scripts/check_f86_native_search.py
python3 Scripts/check_f85_sports.py
python3 Scripts/check_f85_native_sports.py
python3 Scripts/check_f84_settings_history.py
python3 -m unittest discover -s Tests -p test_f80_engine_hash_lifecycle.py
python3 -m unittest discover -s Tests -p test_f81_build_test_independence.py
python3 Scripts/check_f83_widgets.py
python3 Scripts/check_f83_native_widgets.py
python3 Scripts/check_f82_iptv_sports.py
python3 Scripts/check_f82_native_iptv.py
python3 Scripts/check_f79_playback_artwork.py
python3 Scripts/check_f78_artwork.py
python3 Scripts/check_f78_native_artwork.py
# Exercise the actual EPG cache orchestration before any engine download.
python3 Scripts/check_f68_native_guide.py
# F69: run actual gain/recovery methods against transport-counting test doubles.
python3 Scripts/check_f77_audio_gain.py
python3 Scripts/check_f62_native_playback_guide.py
# F70: actual seek completion must preserve transport without manual pause/play.
python3 Scripts/check_f70_native_seek.py
# F71: bounded exact-title links survive VOD without retaining a view/player.
python3 Scripts/check_f71_native_return.py
# F72: execute pause timing policies and type-check the real card with the tvOS SDK.
python3 Tests/test_f75_pause_fixture.py
python3 Tests/test_f76_settings_compile_inputs.py
python3 Scripts/check_f63_native_pause_info.py
python3 Scripts/check_f73_native_preview.py
echo "============================================================"
echo "SIGNAL F38 / BUILD 1147 PREFLIGHT + AETHER 7.44.0 DEPENDENCIES"
echo "============================================================"
# Fail fast on local source/asset mistakes before spending minutes downloading/building dependencies.
mkdir -p .build-cache/actool-preflight
echo "Fast preflight: Swift syntax..."
xcrun swiftc -parse Sources/PlaybackKit/PlaybackKitAetherSurface.swift Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift Sources/DebridChannelsTVOSApp.swift TopShelfExtension/ContentProvider.swift
echo "Fast preflight: tvOS asset catalog/AppIcon..."
rm -rf .build-cache/actool-preflight/*
xcrun actool Resources/Assets.xcassets \
  --compile .build-cache/actool-preflight \
  --platform appletvos \
  --minimum-deployment-target 18.0 \
  --target-device tv \
  --app-icon AppIcon \
  --output-partial-info-plist .build-cache/actool-preflight/asset-info.plist >/dev/null
echo "Fast preflight passed. Preparing AetherEngine-only dependency graph."
bash Scripts/fetch_aether_f28_744.sh
# Do not allow the Xcode build to proceed with an unpatched engine or stale bridge.
python3 Scripts/verify_f28_aether_integration.py

echo "AetherEngine 7.44.0 dependency and Signal audio-gain integration verified."
