#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,re
from check_f31_top_menu_regression import block
from f73_approved_deltas import previous_source
from f74_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def audit(app,host,bridge,universal,settings,portable,policy,card):
    assert '.frame(width: 284, height: 46, alignment: .leading)' in block(app,'    private var pausedPlaybackTitle:')
    assert '.frame(width: 390, alignment: .leading)' in card and '.frame(width: 600' not in card
    for key in ['quickGuideFocusPreviewEnabledV1','quickGuideFocusPreviewModeV1']:
        assert key in app and key in settings and key in portable
    assert 'quickGuideFocusPreviewEnabled = false' in app
    assert policy.count('case pauseMain =')==1 and 'case silentPreview =' in policy and 'case previewAudio =' in policy
    eligibility=block(app,'    private var quickGuidePreviewKey:')
    for token in ['quickGuideFocusPreviewEnabled','liveQuickGuideVisible','scenePhase == .active',
                  '!isDismissingPlayer','!episodeSettingsPresented','!stillWatchingPresented',
                  '!protectedRouteStopped','!protectedRouteRecheckInProgress',
                  'store.playbackPresentationID == playbackPresentationID','store.playbackURL == url']:
        assert token in eligibility,token
    prepare=block(app,'    private func prepareQuickGuidePreview(')
    for token in ['3_000_000_000','key == quickGuidePreviewKey','!Task.isCancelled',
                  'isAuxiliaryPlaybackSuppressed()','MediaFlowProxyRouter.playbackURLIfAllowed',
                  'controlPrimaryForQuickGuide("pause")','controlPrimaryForQuickGuide("mute")']:
        assert token in prepare,token
    assert prepare.count('!usingInternalNonAVEngine && player != nil') == 2
    assert 'isFirstFrameReady' in eligibility and '!isLoading' in prepare
    assert prepare.index('controlPrimaryForQuickGuide("pause")') < prepare.index('quickGuidePreviewURL = preview')
    assert prepare.index('controlPrimaryForQuickGuide("mute")') < prepare.index('quickGuidePreviewURL = preview')
    assert 'while ' not in prepare and 'Timer' not in prepare
    stop=block(app,'    private func stopQuickGuidePreview(')
    assert stop.index('releaseRegisteredPlayers()') < stop.index('controlPrimaryForQuickGuide("restore")') < stop.index('isPlaying = true')
    assert 'if owns {' in stop and '!protectedRouteRecheckInProgress' in stop and 'preserveIntent' in stop
    rail=block(app,'    private var liveQuickGuideChannelRail:')
    assert 'isSelected, quickGuidePreviewChannelID == channel.id' in rail
    assert rail.count('quickGuidePreviewSurface(previewURL)')==1
    assert '.task(id: quickGuidePreviewKey)' in rail
    preview=block(app,'    private func quickGuidePreviewSurface(')
    for token in ['PlaybackKitAetherHost(','playbackMuted: mode.mutesPreview','auxiliaryPlayback: true',
                  'enableDisplayMatch: false','inheritCurrentDisplayMode: true','quickGuidePreviewOwner == owner',
                  'stopQuickGuidePreview(resumeMain: true)']: assert token in preview,token
    for marker in ['    private func teardownPlayer(', '    private func playLiveQuickGuideSelection(', '    private func togglePlay()']:
        assert 'stopQuickGuidePreview(resumeMain: false)' in block(app,marker)
    assert 'if !visible { stopQuickGuidePreview(resumeMain: true) }' in app
    assert '!liveQuickGuideVisible' in block(app,'    private var pausedPlaybackInformation:')
    assert '!self.isAuxiliarySurface' in host and 'self.isAetherHost' in host
    assert 'Signal.QuickGuide.primaryAudioControl' in host and 'let ack: () -> Void' in host
    for token in ['"aetherPause"','"aetherApplyMute"','quickGuideSavedMuted','"ack"']:assert token in host
    assert 'aetherPlaybackMuted: quickGuideMainMuted' in app and 'playbackMuted: aetherPlaybackMuted' in universal
    assert 'configuredAuxiliaryPreview ? 30 : 1800' in bridge
    assert 'if configuredAuxiliaryPreview { options.sharedOutputRole = .secondary }' in bridge
    assert 'forKey: "configuredAuxiliaryPreview"' in host
    artwork=block(app,'private struct LiveTVQuickGuideContainedArtworkFrame:')
    assert 'maxPixelSize: 512' in artwork and 'maxPixelSize: 768' not in artwork

def main():
    paths=['Sources/DebridChannelsTVOSApp.swift','Sources/PlaybackKit/PlaybackKitAetherSurface.swift','Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift','Sources/UniversalCodecSupport.swift','Sources/SignalEpisodeExperienceSettings.swift','Sources/SignalPortableSettings.swift','Sources/SignalLiveTVResourcePolicy.swift','Sources/SignalPausedPlaybackInfoOverlay.swift']
    args=[historical_source(ROOT/p) for p in paths];audit(*args)
    for path,rec in json.loads((ROOT/'Tests/F73ApprovedSourceDeltas.json').read_text()).items():
        text=historical_source(ROOT/path);assert hashlib.sha256(text.encode()).hexdigest()==rec['after_sha256'],path
        previous_source(text,path)
    for path,digest in json.loads((ROOT/'Tests/F73UnchangedSourceHashes.json').read_text()).items():assert hashlib.sha256(historical_source(ROOT/path).encode()).hexdigest()==digest,path
    for i in range(8):
        bad=args.copy();bad[i]=previous_source(args[i],paths[i])
        try:audit(*bad)
        except (AssertionError,ValueError):pass
        else:raise AssertionError('Predecessor accepted: '+paths[i])
    registry=args[5];registered=set(re.findall(r'"([^"\\]+)"\s*:',registry));excluded=set(re.findall(r'"([^"\\]+)"',registry.split('static let excludedKeys:')[1].split('static func snapshot')[0]));observed=set()
    for p in (ROOT/'Sources').rglob('*.swift'):observed.update(re.findall(r'@AppStorage\("([^"\\]+)"\)',historical_source(p)))
    assert observed <= registered | excluded,sorted(observed-registered-excluded)
    prior=previous_source(args[0],paths[0])
    for marker in ['    private var liveVisualWorkActive:', '    func currentProgram(for channel:', '    func programs(for channel:']:
        assert block(args[0],marker)==block(prior,marker),marker
    assert '} else if isFirstFrameReady, !liveQuickGuideVisible {' in args[0]
    assert args[2]==historical_source(ROOT/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift')
    print('F73 PASS: compact card, opt-in shared Live/VOD dwell preview, 3 one-audio modes, synchronous primary ACK and auxiliary-stop-before-restore, cancellation/source/proof/modal guards, secondary role/30s preview ring/512px Quick Guide assets, portable settings. Eight predecessor negative controls rejected. Device/real audio integration remains separate.')
if __name__=='__main__':main()
