from pathlib import Path
import hashlib,json
from source_hash_integrity import verify_unchanged_sources
from f85_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
view=(ROOT/'Sources/SignalIPTVImportView.swift').read_text()
widgets=historical_source(ROOT/'Sources/SignalSportsScoreboard.swift')
feed=historical_source(ROOT/'Sources/SportsScoresScheduleProvider.swift')
assert '.task(id: categoryTaskKey) { await loadCategories() }' in view
assert '.task(id: titleTaskKey) { await loadTitles() }' in view
for name in ['providerSection','destinationSection','categorySection','titleSection','actionSection']:assert 'private var '+name+': some View' in view
assert 'sourceID + "|"' not in view
assert 'scoreboard: SignalSportsGame.espn(event, league: league)' in feed
assert 'widgetGames: liveZone.widgetGames' in app and 'SignalSportsScoreboard(games: widgetGames)' in app
assert '60_000_000_000' in app and 'func refreshScoreWidgets()' in app and 'widgetGames.removeAll' in app
for label in ['LIVE SCORES','NEXT GAMES','FINAL RESULTS']:assert label in widgets
assert 'case "in": state = .live' in widgets and 'completed' in widgets and 'POSTPONED' in widgets
assert '"sportsWidgetStyleV1": "Glass"' in (ROOT/'Sources/SignalPortableSettings.swift').read_text()
for path,rec in json.loads((ROOT/'Tests/F83ApprovedSourceDeltas.json').read_text()).items():assert hashlib.sha256(historical_source(ROOT/path).encode()).hexdigest()==rec['after_sha256'],path
for path,digest in json.loads((ROOT/'Tests/F83NewSourceHashes.json').read_text()).items():assert hashlib.sha256(historical_source(ROOT/path).encode()).hexdigest()==digest,path
verify_unchanged_sources(ROOT,json.loads((ROOT/'Tests/F83UnchangedSourceHashes.json').read_text()),historical_source)
print('F83 organizer decomposition, mounted scoreboard feed/style/lifecycle and exact source scope PASS. Native/device checks separate.')
