#!/usr/bin/env python3
"""Exact F63 source scope and lifecycle wiring; preserves the full F62 player."""
from pathlib import Path
import hashlib, json
from check_f31_top_menu_regression import block
from f63_approved_deltas import previous_source
from f64_approved_deltas import historical_source
from f72_approved_deltas import historical_source as before_f72
from f72_approved_deltas import historical_source as before_f72
ROOT = Path(__file__).resolve().parents[1]

def verify():
    for name, record in json.loads((ROOT/'Tests/F63ApprovedSourceDeltas.json').read_text()).items():
        source=historical_source(ROOT/name)
        assert hashlib.sha256(source.encode()).hexdigest()==record['after_sha256'],name
        previous_source(source,name)
    for name,digest in json.loads((ROOT/'Tests/F63UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==digest,name
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
    old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    mapping=block(app,'    private var pausedPlaybackInformation:')
    for token in ('playbackMetadataItem ?? item', 'scenePhase == .active', '!isLoading', 'isFirstFrameReady',
                  '!protectedRouteStopped', '!protectedRouteRecheckInProgress', 'activePanel == nil',
                  '!upNextVisible', '!upNextCinematicVisible', '!isSeekingInPlayer', '!isScrubbingTimeline',
                  '!vodAsyncRuntime.naturalEpisodeTransitionActive', 'store.playbackPresentationID == playbackPresentationID',
                  'sourceID: activePlaybackURL?.absoluteString', 'renderGeneration: ksSurfaceToken',
                  'paused: !isPlaying', 'synopsis: source.description',
                  'elapsed: authoritativeCurrentSeconds, duration: resolvedDurationSeconds'):
        assert token in mapping,token
    assert 'pausedPlaybackInformation' not in old
    layer=block(app,'    private var playerVisualTree:')
    assert 'if !isLivePlayback {\n                pausedPlaybackInformation\n                    .zIndex(15)' in layer
    assert '.zIndex(400)' in layer # existing show alert remains above this passive text
    view=before_f72(ROOT/'Sources/SignalPausedPlaybackInfoOverlay.swift')
    for token in ('.task(id: request)', 'guard !Task.isCancelled', 'await SignalPauseInfoPolicy.waitForReveal()',
                  'SignalPauseInfoPolicy.mayReveal(lease, current: revealLease, request: request)',
                  'if revealLease?.request != newRequest', '.onDisappear', '.allowsHitTesting(false)',
                  'if revealed {', 'TimelineView(.periodic(from: .now, by: 30))', '.transition(.opacity)',
                  '.easeInOut(duration: 0.30)', '.easeInOut(duration: 0.40)',
                  '.padding(.top, 64)', '.padding(.leading, 64)', 'Text("PAUSED")', 'Text("Ends at")'):
        assert token in view,token
    for token in ('Button(', '.focusable(', '.focused(', 'NotificationCenter', 'Timer.', 'URLSession', '.blur(', 'AVPlayer', 'AetherEngine'):
        assert token not in mapping+view,token
    policy=before_f72(ROOT/'Sources/SignalPauseInfoPolicy.swift')
    assert 'revealDelayNanoseconds: UInt64 = 3_000_000_000' in policy
    assert 'catch { return false }' in policy and 'return !Task.isCancelled' in policy
    assert 'lease == current && lease.request == request' in policy
    for source in ('Sources/SignalPauseInfoPolicy.swift','Sources/SignalPausedPlaybackInfoOverlay.swift'):
        assert (ROOT/'project.yml').read_text().count('- path: '+source+'\n')==1
    assert 'python3 Scripts/check_f63_native_pause_info.py' in (ROOT/'Scripts/check_f28_source_preflight.sh').read_text()
    print('F63 source scope/lifecycle PASS: cancellable 3-second reveal, 0.4/0.3-second fades, passive top-left text, existing metadata/clock, scoped low-frequency ETA. 113 other prior Swift files unchanged; only two additive VOD view insertions; complete F62 transport and other features preserved. Native/device checks pending.')

if __name__=='__main__':verify()
