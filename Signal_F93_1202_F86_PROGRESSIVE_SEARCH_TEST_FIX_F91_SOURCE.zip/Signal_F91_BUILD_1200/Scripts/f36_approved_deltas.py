from regression_manifest_cache import read_manifest
"""Reverse exact reviewed F36 changes only when running historical F31/F32 hash checks."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    from f37_approved_deltas import previous_source as previous_f37
    source=previous_f37(source,path)
    records=read_manifest(ROOT/'Tests/F36ApprovedSourceDeltas.json')
    if path not in records:return source
    record=records[path]
    assert hashlib.sha256(source.encode()).hexdigest()==record['after_sha256'], 'Unreviewed F36 source change: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256']
    return source
