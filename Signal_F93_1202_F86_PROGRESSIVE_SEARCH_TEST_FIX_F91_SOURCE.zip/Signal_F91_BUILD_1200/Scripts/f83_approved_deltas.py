from regression_manifest_cache import read_manifest
"""Reverse only reviewed F83 source hunks for exact F60/historical checks."""
from pathlib import Path
import hashlib,json,re
from functools import lru_cache
ROOT=Path(__file__).resolve().parents[1]
@lru_cache(maxsize=1)
def approved_records():return read_manifest(ROOT/'Tests/F83ApprovedSourceDeltas.json')

@lru_cache(maxsize=1)
def new_source_hashes():return read_manifest(ROOT/'Tests/F83NewSourceHashes.json')

def previous_source(source,path):
    from f85_approved_deltas import previous_source as previous_f85
    source=previous_f85(source,path)
    # F83-only files did not exist in the F82/historical source tree. Preserve
    # strict current-byte validation before omitting them from an older view.
    new_digest=new_source_hashes().get(path)
    if new_digest is not None:
        # Older adapters can apply this chain repeatedly to an already reversed
        # string. Accept absence only while the real current file stays exact.
        current=previous_f85((ROOT/path).read_text(),path).encode() if source=='' else source.encode()
        assert hashlib.sha256(current).hexdigest()==new_digest,'Unreviewed F83 new source change: '+path
        return ''
    record=approved_records().get(path)
    if record is None:return source
    digest=hashlib.sha256(source.encode()).hexdigest()
    accepted={record['before_sha256']}
    for previous in ROOT.glob('Tests/F*ApprovedSourceDeltas.json'):
        release=re.match(r'F(\d+)',previous.name)
        if not release or int(release[1])>=83:continue
        prior=read_manifest(previous).get(path)
        if prior:accepted.update((prior['before_sha256'],prior['after_sha256']))
    if digest in accepted:return source
    assert digest==record['after_sha256'],'Unreviewed F83 source change: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1,'Ambiguous F83 delta: '+path
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256']
    return source

def historical_source(path):
    from f86_approved_deltas import historical_source as pre_f86
    return previous_source(pre_f86(path),path.relative_to(ROOT).as_posix())
