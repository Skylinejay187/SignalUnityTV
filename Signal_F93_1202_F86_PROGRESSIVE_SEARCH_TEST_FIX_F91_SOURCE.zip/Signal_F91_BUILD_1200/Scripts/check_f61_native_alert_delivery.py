#!/usr/bin/env python3
"""Run production cancellation tests and type-check actual Root alert lifecycle methods."""
from pathlib import Path
import argparse
import shutil
import subprocess
import tempfile
from check_f31_top_menu_regression import block

ROOT = Path(__file__).resolve().parents[1]


def fixture():
    app = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
    methods = ('confirmEpisodeAlertPresentation', 'prepareAlertPresentation',
               'invalidatePassiveEpisodeAlertDismiss', 'schedulePassiveEpisodeAlertDismiss')
    source = '''import SwiftUI
struct NewEpisodeAlertHit { let id: String }
enum NewEpisodeAlertStyle { case banner, interactivePopup }
struct NewEpisodeAlertBannerDuration { let seconds: Int }
@MainActor final class AlertStoreFixture {
    var playbackURL: URL?
    var playbackPresentationID = UUID()
    var playbackLaunchCoverActive = false
    var playbackLaunchCoverItem: String?
    var playbackLaunchCoverPresentationID: UUID?
    func markEpisodeAlertPresented(_ alert: NewEpisodeAlertHit) {}
}
enum NewEpisodeAlertsManager { static func removePendingAlert(id: String) {} }
@MainActor final class RootAlertRuntimeFixture {
    var episodeAlertRenderedReceipt: SignalEpisodeAlertDeliveryPolicy.Receipt?
    var episodeAlertDismissLease: SignalEpisodeAlertDeliveryPolicy.Lease?
}
@MainActor struct RootAlertTypecheckFixture: View {
    @Environment(\\.scenePhase) private var scenePhase
    @FocusState private var activeNewEpisodeAlertFocused: Bool
    @State private var activeNewEpisodeAlertFocus = 0
    @State private var activeNewEpisodeAlert: NewEpisodeAlertHit?
    @State private var confirmedPresentedEpisodeAlertIDs: Set<String> = []
    @State private var activeNewEpisodeAlertDismissTask: Task<Void,Never>?
    let rootAsyncRuntime = RootAlertRuntimeFixture()
    let store = AlertStoreFixture()
    let episodeAlertPresentationAllowedOnCurrentSurface = true
    let effectiveNewEpisodeAlertStyle = NewEpisodeAlertStyle.banner
    let newEpisodeAlertBannerDuration = NewEpisodeAlertBannerDuration(seconds: 15)
    var body: some View { Color.clear }
    private func dismissRealEpisodeAlert(consume: Bool) {}
'''
    for name in ('episodeAlertSurfaceID', 'episodeAlertPlaybackCoverVisible', 'episodeAlertVisibleSurfaceID'):
        source += '\n' + block(app, '    private var ' + name + ':') + '\n'
    for name in methods:
        source += '\n' + block(app, '    private func ' + name + '(') + '\n'
    return source + '\n}\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--emit', type=Path)
    args = parser.parse_args()
    if args.emit:
        args.emit.write_text(fixture())
        return
    if not shutil.which('swiftc'):
        raise SystemExit('Swift compiler/Apple SDK required for F61 native delivery checks')
    with tempfile.TemporaryDirectory(prefix='signal-f61-') as folder:
        folder = Path(folder)
        helper = ROOT / 'Sources/SignalEpisodeAlertDeliveryPolicy.swift'
        executable = folder / 'alert-tests'
        subprocess.run(['swiftc', '-swift-version', '5', str(helper),
                        str(ROOT / 'Tests/SignalF61EpisodeAlertDeliveryTests.swift'), '-o', str(executable)], check=True, timeout=60)
        subprocess.run([str(executable)], check=True, timeout=10)
        source = folder / 'AlertFixture.swift'
        source.write_text(fixture())
        sdk = subprocess.check_output(['xcrun', '--sdk', 'appletvos', '--show-sdk-path'], text=True).strip()
        subprocess.run(['xcrun', '--sdk', 'appletvos', 'swiftc', '-typecheck', '-swift-version', '5',
                        '-sdk', sdk, '-target', 'arm64-apple-tvos18.0', str(helper), str(source)], check=True, timeout=60)
    print('F61 production cancellation executable and actual Root alert methods SDK type-check passed')


if __name__ == '__main__':
    main()
