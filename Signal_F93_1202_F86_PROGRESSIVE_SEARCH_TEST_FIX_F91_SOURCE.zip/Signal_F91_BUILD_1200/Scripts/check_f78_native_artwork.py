#!/usr/bin/env python3
"""Real Kingfisher 8.11 + production transport over local HTTP; actual UIKit SDK builds.
No provider/CDN/account URLs are contacted. Requires macOS, Xcode, XcodeGen and Swift.
"""
from pathlib import Path
import argparse,http.server,json,platform,shutil,subprocess,tempfile,threading,time
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]

def shared_source():
    source=(ROOT/'Sources/RemoteImageFit.swift').read_text()
    helper=source[source.index('// F78 shared Kingfisher transport.'):source.index('// End F78 shared transport.')]
    return 'import Foundation\nimport AppKit\nimport ImageIO\nimport Kingfisher\n'+helper+'\n'+block(source,'enum PersistentArtworkSourceCache {')+'\n'

def main():
    p=argparse.ArgumentParser();p.add_argument('--emit',type=Path);a=p.parse_args()
    if a.emit:a.emit.write_text(shared_source());return
    if platform.system()!='Darwin' or not all(shutil.which(x) for x in ['swift','xcodebuild','xcodegen']):
        raise SystemExit('F78 native checks require macOS, Swift, Xcode/tvOS+iOS SDKs and XcodeGen; not executed')
    body=(ROOT/'Tests/F78Artwork/Poster.webp').read_bytes()
    counts={};gate=threading.Lock();state={'offline':False}
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            with gate:
                counts[self.path]=counts.get(self.path,0)+1
                offline=state['offline']
            if self.path=='/slow.png':time.sleep(.35)
            else:time.sleep(.04) # let truly simultaneous sizes join the same transfer
            status=503 if offline else 404 if self.path=='/missing.png' else 200
            self.send_response(status);self.send_header('Content-Type','image/webp')
            self.send_header('Cache-Control','public, max-age=31536000, immutable')
            self.send_header('CF-Cache-Status','HIT');self.end_headers()
            try:self.wfile.write(body if status==200 else b'not available')
            except (BrokenPipeError,ConnectionResetError):pass
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    report={'test':'Real production transport + Kingfisher 8.11 with loopback HTTP, not Apple TV app profiling','phases':[]}
    try:
        with tempfile.TemporaryDirectory(prefix='signal-f78-') as tmp:
            folder=Path(tmp);sources=folder/'Sources/ArtworkChecks';sources.mkdir(parents=True)
            (sources/'Shared.swift').write_text(shared_source())
            shutil.copy(ROOT/'Tests/F78Artwork/Integration.swift',sources/'Integration.swift')
            (folder/'Package.swift').write_text('''// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "ArtworkChecks", platforms: [.macOS(.v13)],
    dependencies: [.package(url: "https://github.com/onevcat/Kingfisher.git", exact: "8.11.0")],
    targets: [.executableTarget(name: "ArtworkChecks", dependencies: [.product(name: "Kingfisher", package: "Kingfisher")])],
    swiftLanguageVersions: [.v5])
''')
            scratch=ROOT/'.build-cache/f78-native-artwork'
            subprocess.run(['swift','build','--package-path',str(folder),'--scratch-path',str(scratch),'-c','release'],check=True,timeout=600)
            executable=scratch/'release/ArtworkChecks';base=f'http://127.0.0.1:{server.server_port}'
            for phase in ['cold','warm','edge']:
                with gate:before=sum(counts.values());state['offline']=phase=='warm'
                start=time.monotonic()
                result=subprocess.run([str(executable),base,phase],check=True,text=True,capture_output=True,timeout=90)
                metrics=json.loads(result.stdout.strip().splitlines()[-1])
                with gate:requests=sum(counts.values())-before
                if phase=='cold':assert requests==2,counts
                if phase=='warm':assert requests==0,counts
                if phase=='edge':assert counts.get('/missing.png',0)==1,counts
                report['phases'].append({'phase':phase,'httpRequests':requests,'elapsedSeconds':time.monotonic()-start,'result':metrics})
            # Build the FULL unmodified production file against both real SDKs. Only app-global
            # frame/playback gate dependencies are replaced; all image code/options are actual.
            sdk=folder/'sdk';sdk.mkdir();shutil.copy(ROOT/'Sources/RemoteImageFit.swift',sdk/'RemoteImageFit.swift')
            shutil.copy(ROOT/'Tests/F78Artwork/SDKStubs.swift',sdk/'SDKStubs.swift')
            (sdk/'project.yml').write_text('''name: F78ArtworkSDK
packages:
  Kingfisher:
    url: https://github.com/onevcat/Kingfisher.git
    exactVersion: 8.11.0
settings:
  SWIFT_VERSION: "5.0"
  GENERATE_INFOPLIST_FILE: YES
  CODE_SIGNING_ALLOWED: NO
targets:
  ArtworkTV:
    type: framework
    platform: tvOS
    deploymentTarget: "18.0"
    sources: [RemoteImageFit.swift, SDKStubs.swift]
    dependencies:
      - package: Kingfisher
  ArtworkIOS:
    type: framework
    platform: iOS
    deploymentTarget: "17.0"
    sources: [RemoteImageFit.swift, SDKStubs.swift]
    dependencies:
      - package: Kingfisher
''')
            subprocess.run(['xcodegen','generate'],cwd=sdk,check=True,timeout=60)
            for scheme,device in [('ArtworkTV','tvOS'),('ArtworkIOS','iOS')]:
                subprocess.run(['xcodebuild','-project','F78ArtworkSDK.xcodeproj','-scheme',scheme,
                    '-destination','generic/platform='+device,'-derivedDataPath',str(ROOT/'.build-cache/f78-sdk'),
                    'CODE_SIGNING_ALLOWED=NO','build'],cwd=sdk,check=True,timeout=600)
            report['SDK']='Full production RemoteImageFit.swift built for tvOS and iOS with real pinned Kingfisher'
    finally:server.shutdown();server.server_close()
    out=ROOT/'.build-cache/F78_NATIVE_ARTWORK_RESULTS.json';out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
    print('F78 native artwork transport HTTP/restart/repair/cancellation tests and actual tvOS+iOS SDK compilation PASS; Apple TV UI profiling remains separate')
if __name__=='__main__':main()
