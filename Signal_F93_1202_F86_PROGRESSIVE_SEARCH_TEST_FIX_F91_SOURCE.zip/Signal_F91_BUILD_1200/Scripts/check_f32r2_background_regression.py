#!/usr/bin/env python3
"""Wiring, cleanup, composition order and lifecycle for shared glass/smoke."""
from f39_approved_deltas import historical_source
from pathlib import Path
from check_f31_top_menu_regression import block
from check_f32r1_cast_regression import verify
ROOT=Path(__file__).resolve().parents[1]
def validate():
    verify()
    app=historical_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    visual=historical_source((ROOT/'Sources/SignalBackgroundVisuals.swift'))
    model=historical_source((ROOT/'Sources/SignalBackgroundTheme.swift'))
    security=historical_source((ROOT/'Sources/ReleaseCandidateSecurityManager.swift'))
    for old in ('DynamicMainGridWallpaperStyle','DynamicWallpaperAssetCache','DynamicWallpaperLoopVideoView','DynamicWallpaperAnimatedImageView','DynamicSmokeWallpaper','DynamicMainGridWallpaperPicker','LiveTVUnityDynamicWallpaperSurface','liveWallpaperOwnsRenderBudget','dynamicMainGridWallpaper'):
        assert old not in app,'Retired wallpaper reference: '+old
    assert 'Dynamic Live TV Wallpaper' not in app and 'Custom Animated Wallpaper URL' not in app
    for key in ('liveTVBackgroundBlurPercentV1','liveTVBackgroundGlassTransparencyV1'):
        assert key in visual and key in app and key in security
        assert f'settings["{key}"] as? Int' in app
    assert 'SignalBackgroundTreatment.retireStandaloneWallpaper()' in app
    assert 'for key in retiredWallpaperKeys' in model
    assert 'backgroundBlurPercent = SignalBackgroundTreatment.defaultBlur' in app
    assert 'backgroundGlassTransparency = SignalBackgroundTreatment.defaultTransparency' in app
    selection=app.split('if mainGridBackgroundListOpen {',1)[1].split('title: "Ambient Classic Smoke:',1)[0]
    assert 'ambientClassicSmokeMode =' not in selection
    assert 'ClassicAmbientSmokeOverlay' not in app
    assert 'Ambient Classic Smoke:' not in app
    assert 'signalGlassAtmosphereV1' in app and 'signalGlassAtmosphereV1' in security
    assert visual.count('SignalGlassAtmosphere(')==1
    assert 'SignalGlassAtmosphereStyle.migrateRetiredSmoke()' in app
    assert visual.index('if theme == .pureBlack') < visual.index('if active {')
    assert visual.index('SignalBackdropArtwork(') < visual.index('SignalGlassAtmosphere(') < visual.index('Rectangle().fill(MainGridBackgroundStyle.glassColor')
    assert 'treatment.blurRadius' in visual and 'treatment.glassOpacity' in visual
    budget=block(app,'    private var liveDecorativeSurfacesOwnRenderBudget:')
    for gate in ('scenePhase == .active','!store.catalogRowsPresented','!store.liveQuickPanelOpen','!showGuide','!store.searchActive','store.selectedDetail == nil','store.playbackURL == nil','!store.vodExclusivePlaybackActive','previewChannelID == nil','gridFocusPreviewChannelID == nil'):
        assert gate in budget,'Smoke lifecycle gate missing: '+gate
    assert '.usesChannelArtwork' not in budget
    print('F32R2 background checks passed: wallpaper removed; saved blur/transparency; retired smoke replaced by glass light; Pure Black and inactive-surface exclusions; cast/menu/playback locks retained')
if __name__=='__main__':validate()
