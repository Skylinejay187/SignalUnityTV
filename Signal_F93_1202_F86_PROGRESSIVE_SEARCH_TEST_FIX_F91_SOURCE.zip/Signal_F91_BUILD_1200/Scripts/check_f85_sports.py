from f87_approved_deltas import historical_source as pre_f87
from pathlib import Path
import hashlib,json
from f85_approved_deltas import historical_source
from source_hash_integrity import verify_unchanged_sources
from f86_approved_deltas import historical_source as f85_source
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]
def check():
    for name,record in json.loads((ROOT/'Tests/F85ApprovedSourceDeltas.json').read_text()).items():
        assert hashlib.sha256(f85_source(ROOT/name).encode()).hexdigest()==record['after_sha256'],name
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==record['before_sha256'],name
    for name,digest in json.loads((ROOT/'Tests/F85NewSourceHashes.json').read_text()).items():
        assert hashlib.sha256(pre_f87(ROOT/name).encode()).hexdigest()==digest,name
    verify_unchanged_sources(ROOT,json.loads((ROOT/'Tests/F85UnchangedSourceHashes.json').read_text()),read_source=f85_source)
    app=pre_f87(ROOT/'Sources/DebridChannelsTVOSApp.swift'); old=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
    for marker in ['struct VODPlayerScreen: View','struct LiveTVScreen: View','struct GridOSFixedSlotCatalogRail: View']:
        assert block(app,marker)==block(old,marker),marker
    source=pre_f87(ROOT/'Sources/SignalSportsWebSource.swift');player=pre_f87(ROOT/'Sources/SignalSportsOnlinePlayer.swift')
    for marker in ['URLSessionConfiguration.ephemeral','session.bytes(for: request)','bytes.task.cancel()','client.invalidateAndCancel()','Task.checkCancellation()','order.prefix(5)','cachedCatalog','identityMatches','America/New_York']:
        assert marker in source,marker
    for forbidden in ['WKWebView','JavaScriptCore','MediaFlowProxyRouter','KSPlayer','AVPlayer(']:
        assert forbidden not in source+player,forbidden
    assert player.count('MembershipEntitlementManager.isCurrentDeviceLocked()') >= 3
    assert 'unityCore.effectiveSurface == .sports' in player and 'surface != .sports { close() }' in player
    assert 'PlaybackKitAetherHost(url: playback.url' in player and 'httpHeaders: playback.headers' in player
    assert '.onExitCommand { close() }' in player and 'firstFrame = false; controlsVisible = true; hostFailed = true' in player
    assert 'beginExclusivePlayback' in player and 'endExclusivePlayback' in player and 'lifecycleReady = false' in player
    assert 'rows: onlineSports.rows + sportsFoundationRows()' in app
    assert 'SignalSportsOnlinePlayer(item: item, games: widgetGames)' in app
    assert 'womens-college-basketball/scoreboard' in pre_f87(ROOT/'Sources/SportsScoresScheduleProvider.swift')
    print('F85 source scope/wiring PASS: device-only resolver, native Aether handoff, cancellation/exit hooks, strict event identity, women’s scores; VOD/LiveTV/shared rail and all other Swift preserved. Native/device checks separate.')
if __name__=='__main__':check()
