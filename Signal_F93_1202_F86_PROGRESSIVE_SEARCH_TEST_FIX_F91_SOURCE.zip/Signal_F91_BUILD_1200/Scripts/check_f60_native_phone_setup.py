#!/usr/bin/env python3
"""Run pure production tests and type-check actual server, UI and Settings handler on tvOS."""
from pathlib import Path
import argparse
import shutil
import subprocess
import tempfile
from check_f31_top_menu_regression import block

ROOT = Path(__file__).resolve().parents[1]


def fixture():
    app = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
    return '''import SwiftUI
@MainActor final class PhoneSetupStoreFixture {
    var status = ""
    func addManifestURL(_ url: String) {}
}
@MainActor final class LiveTVSourceModel {
    var isLoading = false
    var isGuideRefreshing = false
    static func invalidatePersistedLineupCacheForSourceModeChange() {}
    func refreshFromConfiguredSources(showLoadingIndicator: Bool, userInitiatedForce: Bool) async {}
}
struct QRCodeImage: View { let text: String; var body: some View { Color.white } }
struct SettingsButton: View {
    let title: String
    let focus: SettingsScreen.SettingsFocus
    var focused: FocusState<SettingsScreen.SettingsFocus?>.Binding
    let action: () -> Void
    var body: some View { Button(title, action: action).focused(focused, equals: focus) }
}
@MainActor struct SettingsScreen: View {
    enum SettingsFocus: Hashable { case phoneSetup }
    @FocusState private var focused: SettingsFocus?
    @State private var liveM3UURL = ""
    @State private var liveXMLTVURL = ""
    @State private var liveChannelsDvrBaseURL = ""
    @State private var liveHDHomeRunManualURL = ""
    @State private var liveHDHomeRunManualGuideURL = ""
    @State private var liveXtreamServer = ""
    @State private var liveXtreamUsername = ""
    @State private var liveXtreamPassword = ""
    @State private var tmdbApiKey = ""
    @State private var omdbApiKey = ""
    @State private var fanartTvApiKey = ""
    @State private var tvdbApiToken = ""
    @State private var realDebridApiKey = ""
    @State private var torBoxApiKey = ""
    @State private var premiumizeApiKey = ""
    @State private var allDebridApiKey = ""
    @State private var debridLinkApiKey = ""
    @State private var easyDebridApiKey = ""
    @State private var offcloudApiKey = ""
    @State private var putioClientID = ""
    @State private var putioToken = ""
    @State private var backendProfileBackupCode = ""
    @State private var backendProfileBackupBusy = false
    @State private var backendProfileBackupMessage = ""
    let store = PhoneSetupStoreFixture()
    let liveImportModel = LiveTVSourceModel()
    private func runBackendProfileBackup() {}
    private func runBackendProfileRestore() {}
    private func saveXtreamAccountToList(server: String, username: String, password: String) {}
    var body: some View {
        SignalPhoneSetupSection(handler: { action, payload in
            try self.handlePhoneSetup(action, payload: payload)
        }, focused: $focused)
    }
    @MainActor
''' + block(app, '    private func handlePhoneSetup(') + '\n}\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--emit', type=Path)
    args = parser.parse_args()
    if args.emit:
        args.emit.write_text(fixture())
        return
    if not shutil.which('swiftc'):
        raise SystemExit('Swift compiler and Apple SDK required for F60 native checks')
    with tempfile.TemporaryDirectory(prefix='signal-f60-') as directory:
        directory = Path(directory)
        sources = [ROOT / 'Sources/SignalPhoneSetupSchema.swift', ROOT / 'Sources/SignalPhoneSetupHTTP.swift']
        executable = directory / 'phone-setup-tests'
        subprocess.run(['swiftc', '-swift-version', '5', *map(str, sources),
                        str(ROOT / 'Tests/SignalF60PhoneSetupTests.swift'), '-o', str(executable)], check=True, timeout=60)
        subprocess.run([str(executable)], check=True, timeout=30)
        source = directory / 'PhoneSetupFixture.swift'
        source.write_text(fixture())
        sdk = subprocess.check_output(['xcrun', '--sdk', 'appletvos', '--show-sdk-path'], text=True).strip()
        subprocess.run(['xcrun', '--sdk', 'appletvos', 'swiftc', '-typecheck', '-swift-version', '5',
                        '-sdk', sdk, '-target', 'arm64-apple-tvos18.0', *map(str, sources),
                        str(ROOT / 'Sources/SignalPhoneSetupPage.swift'), str(ROOT / 'Sources/SignalPhoneSetupServer.swift'),
                        str(ROOT / 'Sources/SignalPhoneSetupSection.swift'), str(source)], check=True, timeout=90)
    print('F60 production protocol tests and actual local-server/UI/Settings-handler SDK type-check passed')


if __name__ == '__main__':
    main()
