#!/usr/bin/env python3
"""Compile the complete real health client; reproduce the supplied F48 error as a negative control."""
from pathlib import Path
import argparse,shutil,subprocess,tempfile
from check_f31_top_menu_regression import block
from check_f48_native_safety import fixture as router_fixture
ROOT=Path(__file__).resolve().parents[1]
def interfaces():
    credential=(ROOT/'Sources/DebridCredentialBridge.swift').read_text()
    addon=(ROOT/'Sources/ManagedAddonBridge.swift').read_text()
    return '\n'.join([router_fixture(),block(credential,'enum DebridServiceID:'),
        block(credential,'struct DebridCredentialSnapshot:'),block(addon,'struct ManagedAddonManifest:')])+'''
// Only credentials/addon-registration/redaction interfaces are isolated here.
// Health request construction, routing, error propagation and every health method
// compile unchanged from the actual production file.
enum DebridCredentialBridge {
    static func migrateLegacyOverridesIfNeeded(defaults: UserDefaults) {}
    static func credential(for service: DebridServiceID, defaults: UserDefaults) -> DebridCredentialSnapshot? {
        let value = defaults.string(forKey: service.primaryCredentialKey) ?? ""
        return value.isEmpty ? nil : .init(service: service, credential: value, sourceDescription: "fixture")
    }
    static func effectiveTorBoxAPIKey(defaults: UserDefaults) -> String {
        credential(for: .torBox, defaults: defaults)?.credential ?? ""
    }
    static func effectiveRealDebridAPIKey(defaults: UserDefaults) -> String {
        credential(for: .realDebrid, defaults: defaults)?.credential ?? ""
    }
    static func torrentioEnabled(for service: DebridServiceID, defaults: UserDefaults) -> Bool { false }
}
enum ManagedAddonBridge {
    static func coreDebridStreamManifests(defaults: UserDefaults) -> [ManagedAddonManifest] { [] }
}
enum ReleaseCandidateSecurityManager {
    static func redactedText(_ value: String?) -> String { value ?? "" }
}
'''
def negative_control(text):
    marker='        // The account health check must honor the same lock as RD resolving and'
    start=text.index(marker);end=text.index('        let (data, response)',start)
    guard=text[start:end]
    assert text.count(marker)==1 and 'throw NSError(domain: "MediaFlowSafety"' in guard
    text=text[:start]+text[end:]
    offcloud=text.index('    private static func verifyOffcloud(')
    position=text.index('        do {',offcloud)
    return text[:position]+guard+text[position:]
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--emit',type=Path);args=parser.parse_args()
    text=interfaces()
    if args.emit:args.emit.write_text(text);return
    compiler=shutil.which('swiftc')
    if not compiler:raise SystemExit('Swift compiler required for F49 full health-client check')
    actual=ROOT/'Sources/ConnectedServicesHealthClient.swift'
    with tempfile.TemporaryDirectory(prefix='signal-f49-health-') as directory:
        root=Path(directory);dependencies=root/'Interfaces.swift';dependencies.write_text(text)
        policy=ROOT/'Sources/SignalMediaFlowSafetyPolicy.swift';network=ROOT/'Sources/SignalProtectedNetworkState.swift';tests=ROOT/'Tests/SignalF49HealthTests.swift'
        executable=root/'health-tests'
        subprocess.run([compiler,'-swift-version','5',str(dependencies),str(policy),str(network),str(actual),
                        str(tests),'-o',str(executable)],check=True,timeout=60)
        subprocess.run([str(executable)],check=True,timeout=30)
        negative=root/'ConnectedServicesHealthClientNegative.swift'
        negative.write_text(negative_control(actual.read_text()))
        result=subprocess.run([compiler,'-typecheck','-swift-version','5',str(dependencies),str(policy),str(network),
                               str(negative),str(tests)],capture_output=True,text=True,timeout=60)
        diagnostic=result.stdout+result.stderr
        assert result.returncode!=0 and 'error is not handled' in diagnostic and "not declared 'throws'" in diagnostic,diagnostic
    print('F49 native PASS: complete real health client compiled; RD fail-closed/proxy/opt-out/HTTP failure and Offcloud isolation passed; negative control reproduced supplied F48 throw error')
if __name__=='__main__':main()
