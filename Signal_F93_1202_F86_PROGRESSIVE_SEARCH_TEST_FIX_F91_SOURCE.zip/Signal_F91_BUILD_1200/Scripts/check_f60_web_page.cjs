/* Execute the actual bundled client against a small DOM/transport fixture.
 * This does not render a browser or exercise the native NWListener. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert/strict');
const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'Sources/SignalPhoneSetupPage.swift'), 'utf8');
const html = source.split('static let html = """')[1].split('"""')[0].replace(/\\\\/g, '\\');
const script = html.split('<script>')[1].split('</script>')[0];
const schema = fs.readFileSync(path.join(root, 'Sources/SignalPhoneSetupSchema.swift'), 'utf8');
const fields = [...schema.matchAll(/Field\(key: "([^"]+)", label: "([^"]+)", group: "([^"]+)", kind: "([^"]+)", secret: (true|false)\)/g)]
  .map(m => ({key:m[1], label:m[2], group:m[3], kind:m[4], secret:m[5]==='true', configured:true}));

function fixture(hash) {
  const elements = new Set(), ids = new Map(), requests = [], timers = new Map();
  let nextTimer = 0, backupBusy = false, failNetwork = false;
  class Element {
    constructor(tag) { this.tagName=tag.toUpperCase(); this.value=''; this.checked=false; this.disabled=false; this.textContent=''; this.listeners={}; this.children=[]; this.type=''; this.classes=new Set(); this.classList={add:x=>this.classes.add(x), remove:x=>this.classes.delete(x), contains:x=>this.classes.has(x)}; elements.add(this); }
    set id(value) { this._id=value; ids.set(value,this); }
    get id() { return this._id; }
    appendChild(child) { this.children.push(child); return child; }
    append(...children) { this.children.push(...children); }
    addEventListener(name, callback) { this.listeners[name]=callback; }
    setAttribute(name,value) { this[name]=value; }
    focus() {} select() {} setSelectionRange() {} remove() { elements.delete(this); }
  }
  for(const match of html.matchAll(/<(\w+)[^>]*\bid="([^"]+)"[^>]*>/g)) {
    const element=new Element(match[1]); element.id=match[2];
    if(match[0].includes('class="hidden"'))element.classes.add('hidden');
  }
  const document={getElementById:id=>ids.get(id),createElement:tag=>new Element(tag),createTextNode:text=>({textContent:text}),
    querySelectorAll:selector=>[...elements].filter(e=>selector.split(',').includes(e.tagName.toLowerCase())),body:new Element('body'),execCommand:()=>true};
  const context={document,location:{hash,pathname:'/'},history:{replaceState(){context.location.hash='';}},navigator:{},confirm:()=>true,
    AbortController, console, setTimeout:fn=>{timers.set(++nextTimer,fn);return nextTimer;},clearTimeout:id=>timers.delete(id),addEventListener(){},isSecureContext:false,
    fetch:async(url,options)=>{
      if(failNetwork)throw new TypeError('Network closed');
      const body=options.body===undefined?undefined:JSON.parse(options.body); requests.push({url,body,options});
      let status=200,result={message:'Action accepted'};
      if(url==='/api/pair') {status=body.pin==='123456'?200:401;result=status===200?{token:'paired-token'}:{message:'Wrong PIN'};}
      else if(!['Bearer qr-token','Bearer paired-token'].includes(options.headers.Authorization)) {status=401;result={message:'Pair with TV'};}
      else if(url==='/api/state') result={fields,restoreCode:'ABC-123',backupBusy,backupMessage:backupBusy?'Downloading…':'Ready',liveBusy:false,remainingSeconds:570};
      else if(url==='/api/restore')backupBusy=true;
      return {ok:status===200,status,json:async()=>result};
    }};
  context.window=context; vm.runInNewContext(script,context,{filename:'actual-SignalPhoneSetupPage.js'});
  return {ids,requests,context,timers,setFail:()=>{failNetwork=true;},tick:async()=>{for(let i=0;i<20;i++)await Promise.resolve();}};
}

(async()=>{
  const f=fixture('#qr-token'); await f.tick();
  assert.equal(f.context.location.hash,'');
  assert.equal(f.ids.get('setup').classes.has('hidden'),false);
  assert.equal(fields.length,21);
  assert.equal(f.ids.get('realDebridApiKey').type,'password');
  assert.equal(f.ids.get('realDebridApiKey').value,'');
  f.ids.get('liveM3UURL').value='https://example.test/list.m3u';
  f.ids.get('clear-omdbApiKey').checked=true;
  await f.ids.get('saveButton').listeners.click(); await f.tick();
  assert.deepEqual(f.requests.find(r=>r.url==='/api/settings').body,{values:{liveM3UURL:'https://example.test/list.m3u'},clear:['omdbApiKey']});
  assert.equal(f.ids.get('liveM3UURL').value,'');
  assert.equal(f.ids.get('clear-omdbApiKey').checked,false);
  f.ids.get('manifest').value='https://example.test/manifest.json';
  await f.ids.get('addonButton').listeners.click();await f.tick();
  assert.equal(f.requests.find(r=>r.url==='/api/addon').body.url,'https://example.test/manifest.json');
  await f.ids.get('copyButton').listeners.click();await f.tick();
  assert.equal(f.ids.get('status').textContent,'Restore code copied.');
  f.ids.get('restore').value='OLD-123';f.ids.get('restoreButton').listeners.click();await f.tick();
  assert.deepEqual(f.requests.find(r=>r.url==='/api/restore').body,{code:'OLD-123'});
  assert.equal(f.ids.get('restoreButton').disabled,true);
  assert.equal(f.ids.get('backupButton').disabled,true);
  await f.ids.get('stopButton').listeners.click();await f.tick();
  assert.equal(f.ids.get('saveButton').disabled,true);
  assert.equal(f.ids.get('currentCode').textContent,'');
  const manual=fixture('');await manual.tick();manual.ids.get('pin').value='000000';
  await manual.ids.get('pairButton').listeners.click();await manual.tick();
  assert.equal(manual.ids.get('setup').classes.has('hidden'),true);
  manual.ids.get('pin').value='123456';await manual.ids.get('pairButton').listeners.click();await manual.tick();
  assert.equal(manual.ids.get('setup').classes.has('hidden'),false);
  assert(manual.requests.some(r=>r.url==='/api/state'&&r.options.headers.Authorization==='Bearer paired-token'));
  manual.setFail();for(const task of [...manual.timers.values()])task();await manual.tick();
  assert.equal(manual.ids.get('saveButton').disabled,true);
  console.log('F60 actual bundled JS PASS: QR/manual pairing, bad PIN, scoped save/clear, blank secret fields, addon, HTTP copy fallback, restore busy state, finish and lost connection. DOM/transport mocked; native transport and visual rendering untested.');
})().catch(error=>{console.error(error);process.exit(1);});
