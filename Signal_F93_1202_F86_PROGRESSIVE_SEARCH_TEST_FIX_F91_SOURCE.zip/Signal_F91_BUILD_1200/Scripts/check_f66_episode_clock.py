#!/usr/bin/env python3
"""Current mounted callback wiring; historical source reconstruction is not used here."""
from pathlib import Path
import json,hashlib
from check_f31_top_menu_regression import block
from f66_approved_deltas import previous_source
from f68_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    records=json.loads(historical_source(ROOT/'Tests/F66ApprovedSourceDeltas.json'))
    for path,record in records.items():
        value=historical_source(ROOT/path)
        assert hashlib.sha256(value.encode()).hexdigest()==record['after_sha256'],path
        previous_source(value,path)
    for path,digest in json.loads(historical_source(ROOT/'Tests/F66UnchangedSourceHashes.json')).items():
        assert hashlib.sha256(historical_source(ROOT/path).encode()).hexdigest()==digest,path
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
    callback=app[app.index('                onPlaybackTimeUpdate: { current, total in'):]
    callback=callback[:callback.index('                onPlaybackFailure:') ] if '                onPlaybackFailure:' in callback else callback[:12000]
    assert callback.index('PlaybackController.shared.ingestClock(') < callback.index('processEpisodePlaybackClock()')
    processor=block(app,'    private func processEpisodePlaybackClock(')
    for value in ('scenePhase == .active','store.playbackPresentationID == playbackPresentationID',
                  'store.playbackURL == url','episodeClockGate.shouldEvaluate','resetEpisodeSegmentsForOwnerIfNeeded()',
                  'evaluateEpisodeExperience()', 'if activeRecapPrompt != candidate'):
        assert value in processor,value
    for forbidden in ('controlsVisible','currentSeconds =','Timer','Task.sleep','URLSession'):
        assert forbidden not in processor,forbidden
    # Original quiet UI publication is retained, rather than waking the whole playback UI.
    foundation=historical_source(ROOT/'Sources/PlaybackKit/PlaybackKitFoundation.swift')
    assert 'guard overlayVisible else { return }' in foundation
    lookup=block(app,'    private func startEpisodeSegmentsIfNeeded(')
    for value in ('defer {','if episodeSegmentsRequestID == requestID','episodeSegmentsAttempts < 3',
                  'onUpdate: { report in','await MainActor.run','store.playbackPresentationID == owner',
                  'episodeSegmentsKey == key','SignalEpisodeSegmentService.identityKey(lookupItem)',
                  'vodAsyncRuntime.episodeSegmentsTask?.cancel()'):
        assert value in lookup,value
    reset=block(app,'    private func resetEpisodeSegmentsForOwnerIfNeeded(')
    for value in ('episodeSegmentActions = []','activeRecapPrompt = nil','episodeSegmentsAttempts = 0',
                  'episodeSegmentsRequestID = nil','playbackChapterMarkers = []'):
        assert value in reset,value
    assert 'SignalEpisodeExperienceSettings(playbackStatus: episodeSkipDiagnostic)' in app
    service=historical_source(ROOT/'Sources/SignalEpisodeSegments.swift')
    requests=block(service,'    static func requests(')
    assert 'guard let imdb' not in requests
    for value in ('tvdb_id','tmdb_id','imdb_id','coordinates(item)'):
        assert value in requests,value
    stream=block(service,'    func lookup(')
    assert 'for await (provider, segments, message)' in stream and 'await onUpdate(report)' in stream
    assert stream.index('await onUpdate(report)',stream.index('for await')) < stream.index('report.complete = true')
    settings=historical_source(ROOT/'Sources/SignalEpisodeExperienceSettings.swift')
    cache=historical_source(ROOT/'Sources/SignalMetadataResponseCache.swift')
    assert 'SignalMetadataResponseCache.shared.diagnostics()' in settings
    assert 'func counters()' in cache and 'cacheHits += 1' in cache and 'networkStarts += 1' in cache
    assert 'SignalEpisodeSegmentService' not in cache
    assert 'SignalMetadataResponseCache' not in service
    assert 'active < 4' in cache and 'waiters.count < 32' in cache
    print('F66 current-source decoder-clock path, quiet UI, owner reset/deferred cleanup, progressive lookup, alternate identities and independent cache diagnostics PASS')
if __name__=='__main__':verify()
