from regression_manifest_cache import read_manifest
"""Reconstruct exact F37R1 snapshots for historical locks, without resetting fixtures."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    records=read_manifest(ROOT/'Tests/F38ApprovedSourceDeltas.json')
    if path not in records:return source
    record=records[path];digest=hashlib.sha256(source.encode()).hexdigest()
    if digest==record['before_sha256']:return source
    assert digest==record['after_sha256'],'Unreviewed F38 source change: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256']
    return source
