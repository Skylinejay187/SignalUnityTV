#!/usr/bin/env python3
"""Guard every preview initializer and the behavior-preserving Carousel extraction."""
from f39_approved_deltas import historical_source
from pathlib import Path
from f38_approved_deltas import previous_source as previous_f38
import re,textwrap,json,hashlib
from check_f31_top_menu_regression import block
from check_f37_regression import verify as verify_f37
from f37r1_approved_deltas import previous_source
ROOT=Path(__file__).resolve().parents[1]
def calls(source,name):
    for match in re.finditer(r'\b'+re.escape(name)+r'\s*\(',source):
        start=match.end();i=start;depth=1;quoted=False;escaped=False
        while depth:
            c=source[i];i+=1
            if quoted:
                if escaped:escaped=False
                elif c=='\\':escaped=True
                elif c=='"':quoted=False
            elif c=='"':quoted=True
            elif c=='(':depth+=1
            elif c==')':depth-=1
        yield source[start:i-1]
def verify():
    verify_f37()
    app=previous_f38(historical_source((ROOT/'Sources/DebridChannelsTVOSApp.swift')),'Sources/DebridChannelsTVOSApp.swift')
    old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    preview_calls=list(calls(app,'LiveTVGridFocusPreviewSurface'))
    assert len(preview_calls)==2
    for call in preview_calls:
        for argument in ('url:', 'sourceHint:', 'revealAllowed:', 'onReady:'):
            assert argument in call,'Preview initializer missing '+argument
    card=block(app,'    private func liveCarouselCard(')
    old_card=block(old,'    private func liveCarouselCard(')
    stage=block(app,'    private func liveCarouselCardStage(')
    captions=block(app,'    private func liveCarouselCardCaptions(')
    assert 'let card = liveCarouselCardStage(' in card
    assert 'let presentedCard = card' in card and 'let focusableCard = presentedCard' in card
    assert 'return focusableCard' in card
    assert 'LiveTVGridFocusPreviewSurface(' not in card and 'liveCarouselCardCaptions(' in stage
    # Preserve exact remote action blocks, transform values and modifier order.
    for marker in ('.onTapGesture {','.onPlayPauseCommand {','.onLongPressGesture(minimumDuration: 0.62) {','.onMoveCommand {'):
        assert block(card,marker)==block(old_card,marker),'Changed Carousel remote action: '+marker
    old_style=old_card[old_card.index('        .frame(width: 286, height: 332)\n        .background'):old_card.index('        .onTapGesture {')]
    new_style=card[card.index('        .frame(width: 286, height: 332)\n        .background'):card.index('        .onTapGesture {')]
    for inserted in ('        let presentedCard = card\n','        let focusableCard = presentedCard\n','        return focusableCard\n'):
        new_style=new_style.replace(inserted,'')
    assert new_style==old_style,'Carousel visual modifier order changed'
    old_caption=old_card[old_card.index('            VStack(alignment: .leading, spacing: 7) {'):old_card.index('\n        }\n        .frame(width: 286, height: 332)')]
    assert old_caption.strip() in captions,'Carousel caption content changed'
    reveal=block(app,'    private func liveCarouselPreviewDidReveal(')
    for term in ('tileFocus == channelID','gridFocusPreviewRevealChannelID == channelID','gridFocusPreviewReadyChannelID != channelID','armLiveTVGridPreviewStop(channelID: channelID'):
        assert term in reveal
    assert '.id(previewURL)' in stage
    # All F37 state, navigation, playback and timing outside this extraction is identical.
    def without_carousel(s):
        a=s.index('    private func liveCarouselCard(');b=s.index('    // vBRDC284: Mockup #9',a)
        return s[:a]+s[b:]
    assert without_carousel(app)==without_carousel(old)
    for name,sha in json.loads(historical_source((ROOT/'Tests/F37R1UnchangedSourceHashes.json'))).items():
        assert hashlib.sha256(previous_f38(historical_source((ROOT/name)),name).encode()).hexdigest()==sha,'Changed F37 protected source: '+name
    print('F37R1 checks passed: both preview initializers complete; Carousel expression split; exact remote actions, visual modifiers and captions retained; all other F37 app behavior unchanged')
if __name__=='__main__':verify()
