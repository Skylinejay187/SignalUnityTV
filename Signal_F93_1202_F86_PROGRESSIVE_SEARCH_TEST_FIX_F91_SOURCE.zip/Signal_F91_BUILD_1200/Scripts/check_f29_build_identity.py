#!/usr/bin/env python3
"""Compatibility entry point for the existing universal ZIP build workflow."""
from check_build_identity import main
if __name__ == '__main__':
    main()
