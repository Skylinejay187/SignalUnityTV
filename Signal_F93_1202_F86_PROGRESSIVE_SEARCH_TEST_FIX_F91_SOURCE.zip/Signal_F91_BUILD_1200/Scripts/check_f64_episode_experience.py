#!/usr/bin/env python3
"""Current F64 wiring and exact scope; native executable tests are a separate gate."""
from pathlib import Path
import hashlib,json,re
from check_f31_top_menu_regression import block
from f64_approved_deltas import previous_source
from f65_approved_deltas import historical_source
from f65_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]

def verify():
    records=json.loads(historical_source(ROOT/'Tests/F64ApprovedSourceDeltas.json'))
    for name,record in records.items():
        source=historical_source(ROOT/name)
        assert hashlib.sha256(source.encode()).hexdigest()==record['after_sha256'],name
        previous_source(source,name)
    unchanged=json.loads(historical_source(ROOT/'Tests/F64UnchangedSourceHashes.json'))
    for name,digest in unchanged.items():assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==digest,name
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift');old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    for marker in ('struct GlobalSearchScreen: View','struct LiveTVScreen: View','struct MediaInfoPopup: View',
                   '    private func reconcileProtectedPlaybackRoute(', '    private func stopProtectedPlaybackRoute(',
                   '    private func handleNaturalEpisodeEnd(', '    private func schedulePostEOFUpNextWork(',
                   '    private var upNextDismissButton:'):
        assert block(app,marker)==block(old,marker),marker
    visual=block(app,'    private var playerVisualTree:')
    # Sheets and session lifetime belong to the whole player, not the transient Up Next branch.
    tail=visual[visual.rindex('        .contentShape(Rectangle())'):]
    assert 'SignalContinuousPlaybackSession.shared.begin(' in tail
    assert '.sheet(isPresented: $episodeSettingsPresented, onDismiss:' in tail
    assert '.sheet(isPresented: $stillWatchingPresented' in tail
    assert 'if !stillWatchingContinued { stopEpisodeAutomaticPlayback() }' in tail
    assert 'SignalContinuousPlaybackSession.shared.acknowledge()' in tail
    lifecycle=block(app,'    private var playerLifecycleTree:')
    assert 'if episodeModalCoveredPlayer {' in lifecycle and 'episodeModalCoveredPlayer = true' in lifecycle
    assert 'store.playbackPresentationID == playbackPresentationID, store.playbackURL == url' in lifecycle
    assert 'if let episodeAlert, !episodeSettingsPresented, !stillWatchingPresented {' in visual
    assert 'if !episodeSettingsPresented && !stillWatchingPresented && playbackUnityCatalogDestination == nil' in visual
    stop=block(app,'    private func stopEpisodeAutomaticPlayback(')
    assert 'upNextDismissal.dismiss(episodeEnded: true)' in stop
    auto=block(app,'    private var episodeAutomaticNextAllowed:')
    for token in ('upNextAutomaticPlaybackEnabled','nextStyle == "countdown"','allowsNext(currentSeason:') :assert token in auto
    play=block(app,'    private func playPreparedUpNextEpisode(')
    assert 'automatic: Bool = false' in play and 'if automatic {' in play
    for token in ('needsPrompt(episodeExperience)', '!episodeSettingsPresented', 'scenePhase == .active',
                  'preparation.sourceReady', 'let primaryURL', '!protectedRouteStopped') :assert token in play,token
    cancellation=block(app,'    private func cancelUpNextCountdown(')
    assert cancellation.replace('cancelUpNextCountdown(force: Bool = false)', 'cancelUpNextCountdown()').replace('guard force || upNextVisible', 'guard upNextVisible') == block(old,'    private func cancelUpNextCountdown(')
    lookup=block(app,'    private func startEpisodeSegmentsIfNeeded(')
    for token in ('store.playbackPresentationID == owner','store.playbackURL == source','!Task.isCancelled','episodeSegmentsKey == key','episodeSegmentsTask?.cancel()') :assert token in lookup,token
    decisions=block(app,'    private func evaluateEpisodeExperience(')
    assert 'SignalEpisodeSkipPlan.action(' in decisions and '!isScrubbingTimeline' in decisions
    assert 'seekAbsolute(' in decisions and 'playPreparedUpNextEpisode(automatic: true)' in decisions
    intro=block(app,'    private func evaluateSkipIntroPresentation(')
    for token in ('episodeExperience.autoIntro','now >= marker.startSeconds','marker.authorityRank >= 425','resolvedDurationSeconds > marker.endSeconds','performSkipIntro()'):assert token in intro,token
    assert 'Double(episodeExperience.appearance)' in block(app,'    private func evaluateUpNextPresentation(')
    assert 'upNextCountdownSeconds = episodeExperience.countdown' in block(app,'    private func armUpNextAutoAdvanceIfNeeded(')
    assert 'upNextDismissButton' in block(app,'    private var manualNextEpisodeOverlay:')
    # New network tasks are cancelled on runtime teardown, player exit, background and replacement.
    assert app.count('episodeSegmentsTask?.cancel()') >= 5 and app.count('introSubmissionTask?.cancel()') >= 4
    assert 'supplementalOnly: SignalEpisodeSegmentService.imdb(lookupItem) != nil' in app
    bridge=historical_source(ROOT/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift')
    assert bridge == historical_source(ROOT/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift')
    for token in ('engine.$mediaChapters', '.removeDuplicates()', 'self.generation == observedGeneration', '!self.configuredIsLiveStream', 'chapters.prefix(512)', 'AetherBridgeNotification.chapters'):
        assert token in bridge,token
    host=historical_source(ROOT/'Sources/PlaybackKit/PlaybackKitAetherSurface.swift')
    assert 'DebridAetherRuntimeEvent.chapters, object: view' in host and 'coordinator.onChaptersDiscovered = nil' in host
    assert host.count('context.coordinator.onChaptersDiscovered = onChaptersDiscovered')==2
    universal=historical_source(ROOT/'Sources/UniversalCodecSupport.swift')
    assert 'guard let callback = onKSChaptersDiscovered else { return }' in universal and 'callback(chapters)' in universal
    hero=historical_source(ROOT/'Sources/CatalogHeroMetadataCache.swift')
    assert 'guard generation == owner else { return nil }' in hero and 'value == nil ? 60 : ttl' in hero
    registry=historical_source(ROOT/'Sources/SignalPortableSettings.swift')
    keys=set(re.findall(r'"((?:episode|metadataCache)[^"]+)"\s*:',registry))
    options=historical_source(ROOT/'Sources/SignalEpisodeExperience.swift')
    settings=historical_source(ROOT/'Sources/SignalEpisodeExperienceSettings.swift')
    observed=set(re.findall(r'@AppStorage\("([^"]+)"\)',settings))
    assert observed==keys,(observed-keys,keys-observed)
    registered=set(re.findall(r'"([^"]+)"\s*:',registry))
    excluded=set(re.findall(r'"([^"]+)"',registry.split('static let excludedKeys:')[1].split('static func snapshot')[0]))
    app_storage=set()
    for path in (ROOT/'Sources').rglob('*.swift'):
        app_storage.update(re.findall(r'@AppStorage\("([^"\\]+)"\)',historical_source(path)))
    assert app_storage <= registered | excluded, sorted(app_storage-registered-excluded)
    assert '"introDBAPIKey": 4096' in historical_source(ROOT/'Sources/ReleaseCandidateSecurityManager.swift')
    assert app.count('"introDBAPIKey": SignalIntroDBCredential.read()')==2
    assert 'credentialVault["introDBAPIKey"]' in app and 'settings["episodeIntroDBKeyPresentV1"] as? Bool == false' in app
    assert 'import Security' in options and 'SecItemCopyMatching' in options
    segments=historical_source(ROOT/'Sources/SignalEpisodeSegments.swift')
    for token in ('introhater.com/api/segments/','api.theintrodb.org/v4/media','api.introdb.app/segments',
                  'api.skipdb.tv/api/segments','out-of-range','value["label"]','value["end_ms"] is NSNull',
                  'marker.chapterIndex != nil','!Task.isCancelled, options.submit','submissions.insert(id)',
                  'attempted[id]','X-API-Key','/submit','sent.suffix(256)','cache.count >= 64') :assert token in segments,token
    submission=block(segments,'    func submitDiscoveredIntro(')
    for forbidden in ('playbackURL','streamURL','debrid','Authorization'):assert forbidden not in submission
    planner=block(segments,'enum SignalEpisodeSkipPlan')
    for token in ('kind == .postCredits','position >= $0.start && position < $0.end','options.credits != "keep"',
                  'consumed.contains(segment.id)','segment.start >= duration * 0.5'):assert token in planner
    cache=historical_source(ROOT/'Sources/SignalMetadataResponseCache.swift')
    for token in ('active < 4','waiters.count < 32','memoryLimit = 8 * 1024 * 1024','diskLimit = 32 * 1024 * 1024',
                  'memory.count > 192','index >= 256','SHA256.hash','request.allHTTPHeaderFields',
                  'generation == callGeneration','generation == owner','withTaskCancellationHandler','pending.forEach',
                  'func clear()', 'cachePolicy = .reloadIgnoringLocalCacheData') :assert token in cache,token
    assert 'Timer' not in cache and 'MainActor' not in cache.replace('SwiftUI/MainActor','')
    assert 'SignalMetadataResponseCache.shared.data(for:' in historical_source(ROOT/'Sources/CatalogHeroMetadataCache.swift')
    store=historical_source(ROOT/'Sources/CatalogStore.swift')
    for marker in ('    private func searchBuiltInCatalogDatabase(', '    private func searchSingleCatalogAddonProviderNetworkOnly(',
                   '    private func tmdbExactEpisodeMetadata(',):
        assert 'SignalMetadataResponseCache.shared.data(for:' in block(store,marker),marker
    old_store=previous_source(store,'Sources/CatalogStore.swift')
    for marker in ('    private func fetchTVMazeEpisodesForAlerts(', '    func fetchSeriesEpisodes('):
        assert block(store,marker)==block(old_store,marker), 'Episode discovery freshness changed: '+marker
    for name in ('SignalEpisodeExperience','SignalEpisodeExperienceSettings','SignalEpisodeSegments','SignalMetadataResponseCache'):
        assert historical_source(ROOT/'project.yml').count('- path: Sources/'+name+'.swift\n')==1
    print(f'F64 current source contracts PASS: {len(keys)} new portable settings, secure key vault, provider gates, exact source/cancellation ownership, bounded cache and skips, manual/countdown modes, Still Watching stop latch; {len(unchanged)} prior Swift files unchanged. Existing Search/Guide, protection, EOF settle and Dismiss blocks byte-identical. Native/device checks separate.')

if __name__=='__main__':verify()
