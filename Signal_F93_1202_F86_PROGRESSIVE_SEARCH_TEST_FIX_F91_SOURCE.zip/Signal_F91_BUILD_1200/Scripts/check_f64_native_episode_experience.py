#!/usr/bin/env python3
"""Actual production policies/provider parsers/cache with local-only URLProtocol traffic.

Requires macOS Swift and tvOS SDK. No debrid service or timing submissions are contacted.
"""
from pathlib import Path
import argparse,shutil,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]

def chapter_fixture():
    bridge=(ROOT/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
    start=bridge.index('        engine.$mediaChapters')
    end=bridge.index('        engine.$duration',start)
    return 'import Foundation\nimport Combine\nstruct F64ChapterInfo: Equatable { let name: String; let startSeconds: Double; let durationSeconds: Double }\n@MainActor final class F64ChapterEngine { @Published var mediaChapters: [F64ChapterInfo] = [] }\nenum AetherBridgeNotification { static let chapters = Notification.Name("Signal.F64.fixture.chapters") }\n@MainActor final class F64ChapterHost {\n    var engine: F64ChapterEngine?\n    var generation: UInt64 = 0\n    var configuredIsLiveStream = false\n    var cancellables = Set<AnyCancellable>()\n    func install(engine: F64ChapterEngine, generation observedGeneration: UInt64) {\n' + bridge[start:end] + '\n    }\n}\n'

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--emit',type=Path);args=parser.parse_args()
    sources=['Sources/SignalPortableSettings.swift','Sources/SignalEpisodeExperience.swift',
             'Sources/SignalLiveTVResourcePolicy.swift',
             'Sources/SignalEpisodeSegments.swift','Sources/SignalMetadataResponseCache.swift','Sources/CatalogHeroMetadataCache.swift',
             'Sources/SignalEpisodeClockGate.swift','Tests/SignalF66EpisodeClockTests.swift',
             'Sources/SignalGuideMetadataCache.swift','Sources/SignalGuideTimeline.swift','Tests/SignalF68GuideMetadataTests.swift',
             'Tests/SignalF64EpisodeExperienceTests.swift']
    if args.emit:
        args.emit.write_text('\n'.join((ROOT/path).read_text() for path in sources)+'\n'+chapter_fixture());return
    if not shutil.which('swiftc'):raise SystemExit('Swift compiler and Apple SDK required for F64 executable/native checks')
    with tempfile.TemporaryDirectory(prefix='signal-f64-') as directory:
        directory=Path(directory);exe=directory/'episode-tests'
        subprocess.run(['swiftc','-swift-version','5',*[str(ROOT/x) for x in sources],'-o',str(exe)],check=True,timeout=120)
        subprocess.run([str(exe),str(ROOT/'Tests/F64ProviderFixtures')],check=True,timeout=45)
        chapter=directory/'ChapterFixture.swift';chapter.write_text(chapter_fixture())
        backup=directory/'backup-tests'
        subprocess.run(['swiftc','-swift-version','5',*[str(ROOT/x) for x in ['Sources/SignalPortableSettings.swift','Sources/ReleaseCandidateSecurityManager.swift','Sources/SignalLiveTVCardEffect.swift','Tests/SignalF64BackupTests.swift']],'-o',str(backup)],check=True,timeout=90)
        subprocess.run([str(backup)],check=True,timeout=15)
        sdk=subprocess.check_output(['xcrun','--sdk','appletvos','--show-sdk-path'],text=True).strip()
        subprocess.run(['xcrun','--sdk','appletvos','swiftc','-typecheck','-swift-version','5','-sdk',sdk,
                        '-target','arm64-apple-tvos18.0',*[str(ROOT/x) for x in sources],
                        str(ROOT/'Sources/SignalEpisodeExperienceSettings.swift'),str(chapter)],check=True,timeout=120)
    print('F64 production policies, provider fixture parsing, real cache coalescing/concurrency/cancellation/disk tests and settings tvOS SDK check PASS. Full app/device checks remain separate.')

if __name__=='__main__':main()
