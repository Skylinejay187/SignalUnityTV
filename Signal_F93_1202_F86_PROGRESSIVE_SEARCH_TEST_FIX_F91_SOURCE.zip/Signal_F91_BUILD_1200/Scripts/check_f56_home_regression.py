#!/usr/bin/env python3
"""Current home-session ownership, safe recheck and preserved playback contracts."""
from pathlib import Path
import hashlib
import json
from check_f31_top_menu_regression import block
from f56_approved_deltas import previous_source
from f57_approved_deltas import historical_source

ROOT = Path(__file__).resolve().parents[1]


def verify():
    for name, record in json.loads((ROOT / 'Tests/F56ApprovedSourceDeltas.json').read_text()).items():
        source = historical_source(ROOT / name)
        assert hashlib.sha256(source.encode()).hexdigest() == record['after_sha256'], name
        previous_source(source, name)
    for name, expected in json.loads((ROOT / 'Tests/F56UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT / name).encode()).hexdigest() == expected, name
    app = historical_source(ROOT / 'Sources/DebridChannelsTVOSApp.swift')
    old = previous_source(app, 'Sources/DebridChannelsTVOSApp.swift')
    for marker in ('struct GlobalSearchScreen: View', 'struct SearchResultCard: View', 'struct LiveTVScreen: View',
                   'struct MediaInfoPopup: View', 'struct ManualEpisodesRow: View'):
        assert block(app, marker) == block(old, marker), marker
    player = block(app, 'struct VODPlayerScreen: View')
    prior = block(old, 'struct VODPlayerScreen: View')
    for marker in ('    private func startUpNextPreparationIfNeeded(', '    private func prepareUpNextSourcesIfNeeded(',
                   '    private func handleNaturalEpisodeEnd(', '    private func reconcileUpNextAfterEOF(',
                   '    private func cancelUpNextCountdown(', '    private func playPreparedUpNextEpisode(',
                   '    private func seekAbsolute(', '    private func stopOwnedPlaybackKitSession(', '    private func setupPlayer('):
        assert block(player, marker) == block(prior, marker), marker
    assert 'return route.networkURL' in block(player, '    private func mediaFlowPlaybackURL(')
    assert 'return route.headers' in block(player, '    private var enginePlaybackHTTPHeaders:')
    assert '!protectedRouteRecheckInProgress' in block(player, '    private var activePlaybackURL:')
    method = block(player, '    private func reconcileProtectedPlaybackRoute(')
    assert method.index('releaseRenderSurfaceForEngineHandoff') < method.index('await MediaFlowProxyRouter.prepareSafetyError')
    for token in ('route.requiresRecheck', 'protectedRouteRecheckID == request', 'Task.isCancelled',
                  'store.playbackPresentationID == playbackPresentationID', 'store.playbackURL == url',
                  'scenePhase == .active', 'protectedRecheckResumeSeconds', 'ksStartTimeSeconds = seconds',
                  'protectedPlaybackRoute = verified'):
        assert token in method, token
    assert 'teardownPlayer(' not in method and 'stopOwnedPlaybackKitSession(' not in method
    assert method.count('isPlaying = false') == 1  # only the genuine failed-route branch
    assert 'networkChangedMessage' not in block(player, '    private var playerInputTree:')
    assert 'protectedRouteRecheckInProgress = false' in block(player, '    private func teardownPlayer(')
    router = (ROOT / 'Sources/MediaFlowProxyRouter.swift').read_text()
    prepare = block(router, '    static func prepareSafetyError(')
    assert prepare.index('if !raw.enabled, SignalProtectedNetworkState.isHome') < prepare.index('await SignalPublicIPVerifier')
    assert 'clearHomeProofForNewRequests()' in prepare and 'epoch = SignalProtectedNetworkState.revokeHomeProof()' in prepare
    captured = block(router, '    static func preparedPlaybackRoute(')
    assert 'config: config)' in captured and 'config.enabled ? [:] : upstreamHeaders' in captured
    assert 'SignalProtectedNetworkState.epoch() == epoch' in captured and 'snapshot() == raw' in captured
    state = (ROOT / 'Sources/SignalProtectedNetworkState.swift').read_text()
    assert 'let current = generation == epoch' in state and 'userInfo: ["epoch": epoch]' in state
    assert 'homeVerifiedInEpoch = true' in state and 'if notify { notifyRevoked(epoch: epoch) }' in state
    oldstate = previous_source(state, 'Sources/SignalProtectedNetworkState.swift')
    assert block(state, 'actor SignalPublicIPVerifier {') == block(oldstate, 'actor SignalPublicIPVerifier {')
    assert 'check_f56_native_home.py' in (ROOT / 'Scripts/check_f28_source_preflight.sh').read_text()
    print('F56 PASS: live home proof reuse; stable session URL/headers; epoch/session-filtered quiet recheck with transport release and resume; away protection retained; Search/Guide/Up Next/cache/engine unchanged')


if __name__ == '__main__':
    verify()
