#!/usr/bin/env python3
"""Compile/execute the actual mounted clock-processing method with bounded orchestration doubles."""
from pathlib import Path
import subprocess,tempfile,shutil,argparse
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]
def fixture():
    app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    segment=(ROOT/'Sources/SignalEpisodeSegments.swift').read_text()
    source='import Foundation\n'+block(segment,'struct SignalEpisodeSegment:')+'\n'
    # The complete production recap selector; all parser/network/cache tests use the real service separately.
    source+='enum SignalEpisodeSkipPlan {\n'+block(segment,'    static func recap(')+'\n}\n'
    source+='''
enum Phase { case active, background }
final class Store { var playbackPresentationID: UUID; var playbackURL: URL?; init(_ id: UUID,_ url: URL) { playbackPresentationID=id;playbackURL=url } }
final class Runtime { var episodeClockGate = SignalEpisodeClockGate() }
final class AppFixture {
    var playbackPresentationID = UUID()
    let url = URL(string:"https://fixture.invalid/media")!
    lazy var store = Store(playbackPresentationID,url)
    var isLivePlayback = false, isDismissingPlayer = false
    var scenePhase = Phase.active
    var vodAsyncRuntime = Runtime()
    var episodeSegmentActions: Set<String> = []
    var authoritativeCurrentSeconds = 0.0, resolvedDurationSeconds = 100.0
    var playableEpisodeSegments = [SignalEpisodeSegment(kind:.recap,start:2,end:8,provider:"fixture")]
    var activeRecapPrompt: SignalEpisodeSegment?
    var evaluations = 0, resets = 0
    func resetEpisodeSegmentsForOwnerIfNeeded() { resets += 1 }
    func evaluateEpisodeExperience() { evaluations += 1 }
'''
    source+=block(app,'    private func processEpisodePlaybackClock(').replace('private func','func')+'\n}\n'
    source+='''
@main struct F66MountedClockTest {
    static func main() {
        let fixture = AppFixture()
        fixture.authoritativeCurrentSeconds = 3
        fixture.processEpisodePlaybackClock(force:true)
        precondition(fixture.activeRecapPrompt != nil && fixture.evaluations==1)
        fixture.authoritativeCurrentSeconds = 9
        fixture.processEpisodePlaybackClock(force:true)
        precondition(fixture.activeRecapPrompt == nil && fixture.evaluations==2)
        fixture.scenePhase = .background
        fixture.processEpisodePlaybackClock(force:true)
        precondition(fixture.evaluations==2)
        fixture.scenePhase = .active
        fixture.store.playbackPresentationID = UUID()
        fixture.processEpisodePlaybackClock(force:true)
        precondition(fixture.evaluations==2,"Retired decoder cannot evaluate new presentation")
        fixture.store.playbackPresentationID = fixture.playbackPresentationID
        fixture.store.playbackURL = nil
        fixture.processEpisodePlaybackClock(force:true)
        precondition(fixture.evaluations==2)
        print("F66 actual mounted clock method: hidden-control entry/exit, throttle, background and stale-owner guards PASS")
    }
}
'''
    return source

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--emit',type=Path);args=parser.parse_args()
    if args.emit:args.emit.write_text(fixture());return
    if not shutil.which('swiftc'):raise SystemExit('Swift compiler required for executable mounted-clock check')
    with tempfile.TemporaryDirectory(prefix='signal-f66-') as directory:
        path=Path(directory)/'Fixture.swift';path.write_text(fixture());exe=Path(directory)/'clock-tests'
        subprocess.run(['swiftc','-swift-version','5',str(ROOT/'Sources/SignalEpisodeClockGate.swift'),str(path),'-o',str(exe)],check=True,timeout=90)
        subprocess.run([str(exe)],check=True,timeout=15)
if __name__=='__main__':main()
