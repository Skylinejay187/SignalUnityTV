#!/usr/bin/env python3
"""F42 source contracts; actual tvOS compilation/device tests remain separate."""
from f43_approved_deltas import historical_source as f42_source
from pathlib import Path
import re,json,hashlib
from check_f31_top_menu_regression import block
from f42_approved_deltas import previous_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    for name,record in json.loads(f42_source((ROOT/'Tests/F42ApprovedSourceDeltas.json'))).items():
        source=f42_source((ROOT/name))
        assert hashlib.sha256(source.encode()).hexdigest()==record['after_sha256'],name
        previous_source(source,name)
    for name,sha in json.loads(f42_source((ROOT/'Tests/F42UnchangedSourceHashes.json'))).items():
        assert hashlib.sha256(f42_source((ROOT/name)).encode()).hexdigest()==sha,name
    app=f42_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    assert block(app,'struct VODPlayerScreen: View')==block(old,'struct VODPlayerScreen: View'),'VOD UI/Up Next changed'
    live=block(app,'struct LiveTVScreen: View');oldlive=block(old,'struct LiveTVScreen: View')
    for marker in ('    private func advanceLiveTVGridPage(', '    private func scheduleLiveTVGridFocusPreview(',
                   '    private func cancelLiveTVGridFocusPreview(', '    private func play(channel:',
                   '    private func liveCarouselCard('):
        assert block(live,marker)==block(oldlive,marker),marker
    registry=f42_source((ROOT/'Sources/SignalPortableSettings.swift'))
    portable=set(re.findall(r'^        "([^"]+)":',registry,re.M))
    excluded=set(re.findall(r'^        "([^"]+)",',registry,re.M))
    observed=set()
    symbolic={
        'TraktSyncManager.enabledDefaultsKey': 'traktResumeSyncEnabledV1',
        'DebridNowShowingDirectPushManager.serverURLDefaultsKey': 'debridNowShowingServerURLV1',
        'DebridNowShowingDirectPushManager.pushTokenDefaultsKey': 'debridNowShowingPushTokenV1',
        'DebridNowShowingDirectPushManager.statusDefaultsKey': 'debridNowShowingPushStatusV1'
    }
    for p in (ROOT/'Sources').rglob('*.swift'):
        text=f42_source(p)
        observed.update(re.findall(r'@AppStorage\("([^"\\]+)"\)',text))
        for expression in re.findall(r'@AppStorage\(([^)\n]+)\)',text):
            assert expression.startswith('"') or expression in symbolic, 'Classify new symbolic AppStorage key: '+expression
            if expression in symbolic: observed.add(symbolic[expression])
    assert not portable & excluded
    assert observed <= portable | excluded,sorted(observed-portable-excluded)
    assert len(observed)==197,len(observed)
    for key in ('vodDiskCachePolicyV1','signalAutoNextEnabledV393','vodAudioAmplificationDBV1',
                'vodSubtitleTextColorV1','vodVideoFitModeV1','mediaInformationGlassTransparencyV393',
                'vodFeaturedCastPresentationModeV1','traktResumeSyncEnabledV1','perTitlePlaybackMemoryBackupV1'):
        assert key in portable,key
    coverage=json.loads(f42_source((ROOT/'Tests/F42SettingsCoverage.json')))
    assert portable==set(coverage['portable']) and excluded==set(coverage['excluded'])
    assert app.count('SignalPortableSettings.snapshot(defaults)')==2
    assert app.count('PerTitlePlaybackMemoryManager.shared.exportBackupBlob()')==2
    assert 'PerTitlePlaybackMemoryManager.shared.restoreBackupBlob(memory)' in app
    assert 'mediaFlowLightAPIPassword": 32_768' in f42_source((ROOT/'Sources/ReleaseCandidateSecurityManager.swift'))
    nav=block(app,'struct TopMenuBar: View')
    position=nav.split('outsideSearchButton.position(',1)[1].split(')',1)[0]
    assert 'mirrorSearchTitleFrame' not in position and 'geo.size.width - 140' in position
    assert 'fixedCenterY' in position
    host=block(app,'private struct LiveTVGridFocusMotionHost<Content: View>')
    assert 'SignalLiveTVAlignedCardGeometry' not in host
    assert 'private var legacyPose: SignalLiveTVCardPose { pose }' in host
    assert 'focused: isFocused' in host and 'guard !aligned else { return 1 }' in host
    assert 'x: aligned ? 0' in host and 'y: aligned ? 0' in host
    preview=block(app,'private struct SignalLiveTVThemeConfirmationScreen: View')
    assert 'LiveTVScreen(liveModel: previewModel, customizationPreview:' in preview
    assert 'SignalLiveTVDashboardConfirmation(' not in preview
    assert '.onPlayPauseCommand' in preview and 'Hide Controls' in preview
    assert 'previewModel.loadCachedOrDemo()' in preview
    assert 'selectedTheme =' in preview and 'Apply to Live TV' in preview
    branch=live.split('    private var interactiveBody:',1)[0]
    assert 'liveTVUnifiedBrowseSurface(size: geo.size)' in branch
    assert '.disabled(true)' in branch and '.allowsHitTesting(false)' in branch
    assert 'customizationPreview != nil { return Set(mountedChannels.map' in live
    bridge=f42_source((ROOT/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift'))
    assert bridge==f42_source((ROOT/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift'))
    assert 'engine.refreshSignalBufferFrontier()' in bridge
    assert 'Timer.publish(every: 0.25, on: .main, in: .common)' in bridge
    hook=f42_source((ROOT/'EnginePatches/AetherEngine+SignalCacheFrontier.swift'))
    for token in ('guard !isLive','host.cachedVODSessionTime','contiguousForwardReadAheadSeconds','signalCachedBufferEnd()', 'endpoint.isFinite'):
        assert token in hook,token
    assert 'engine.play()' not in hook and 'engine.pause()' not in hook
    print(f'F42 current source checks passed: {len(portable)} portable preferences, all {len(observed)} AppStorage keys classified; live cache-frontier refresh; fixed Search; original perspective; real full-screen dashboard; VOD/Up Next unchanged')
if __name__=='__main__':verify()
