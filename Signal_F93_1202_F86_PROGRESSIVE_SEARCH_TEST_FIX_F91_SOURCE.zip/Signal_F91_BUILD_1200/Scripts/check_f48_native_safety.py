#!/usr/bin/env python3
"""Compile actual production router with fake credentials and a local-only proxy fixture."""
from pathlib import Path
import argparse, os, shutil, subprocess, tempfile, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]
def fixture():
    text=(ROOT/'Sources/MediaFlowProxyRouter.swift').read_text()
    return 'import Foundation\n'+ '\n'.join(block(text,marker) for marker in (
        'enum MediaFlowProxyRouteKind:', 'struct MediaFlowProxySnapshot:',
        'struct MediaFlowConnectionTestResult:', 'enum MediaFlowProxyRouter {'))+'''
enum MediaFlowCredentialStore {
    static func readPassword() -> String { "fixture-password" }
    static func readLightPassword() -> String { "fixture-password" }
    static func saveLightPassword(_ value: String) -> Bool { true }
}
'''
class ProxyFixture(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_GET(self):
        if self.path == '/prefix/health': code,body=200,b'{}'
        elif self.path == '/prefix/metrics?api_password=fixture-password': code,body=200,b'{}'
        elif self.path == '/prefix/proxy/ip?api_password=fixture-password': code,body=200,b'{"ip":"203.0.113.8"}'
        else: code,body=503,b'{}'
        self.send_response(code);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(body)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--emit',type=Path);args=parser.parse_args()
    source=fixture()
    if args.emit: args.emit.write_text(source);return
    compiler=shutil.which('swiftc')
    if not compiler: raise SystemExit('Swift compiler required for F48 native tests')
    server=ThreadingHTTPServer(('127.0.0.1',0),ProxyFixture)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        with tempfile.TemporaryDirectory(prefix='signal-f48-') as directory:
            root=Path(directory);swift=root/'RouterFixture.swift';swift.write_text(source);exe=root/'tests'
            subprocess.run([compiler,'-swift-version','5',str(swift),
                str(ROOT/'Sources/SignalMediaFlowSafetyPolicy.swift'),str(ROOT/'Sources/SignalProtectedNetworkState.swift'),str(ROOT/'Sources/SignalLiveTVCardEffect.swift'),
                str(ROOT/'Sources/SignalPortableSettings.swift'),
                str(ROOT/'Tests/SignalF48SafetyTests.swift'),'-o',str(exe)],check=True)
            env=dict(os.environ,SIGNAL_F48_TEST_PROXY=f'http://127.0.0.1:{server.server_port}/prefix')
            subprocess.run([str(exe)],env=env,check=True,timeout=45)
    finally: server.shutdown();server.server_close();thread.join(timeout=2)
if __name__=='__main__':main()
