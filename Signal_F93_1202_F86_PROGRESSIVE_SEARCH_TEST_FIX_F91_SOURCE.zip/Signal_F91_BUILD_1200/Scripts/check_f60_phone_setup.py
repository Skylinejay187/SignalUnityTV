#!/usr/bin/env python3
"""Reviewed scope, lifecycle/authentication and existing-action integration contracts."""
from pathlib import Path
import hashlib
import json
import plistlib
import re
from check_f31_top_menu_regression import block
from f60_approved_deltas import previous_source
from f61_approved_deltas import historical_source

ROOT = Path(__file__).resolve().parents[1]


def verify():
    app = historical_source(ROOT / 'Sources/DebridChannelsTVOSApp.swift')
    record = json.loads((ROOT / 'Tests/F60ApprovedSourceDeltas.json').read_text())['Sources/DebridChannelsTVOSApp.swift']
    assert hashlib.sha256(app.encode()).hexdigest() == record['after_sha256']
    old = previous_source(app, 'Sources/DebridChannelsTVOSApp.swift')
    for name, digest in json.loads((ROOT / 'Tests/F60UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT / name).encode()).hexdigest() == digest, name
    for marker in ('struct GlobalSearchScreen: View', 'struct SearchResultCard: View', 'struct VODPlayerScreen: View',
                   'struct LiveTVScreen: View', 'struct MediaInfoPopup: View', 'struct ManualEpisodesRow: View',
                   '    private func runBackendProfileBackup(', '    private func runBackendProfileRestore(',
                   '    private func signalRestorePreflight(', '    private func applyBackendProfilePayload('):
        assert block(app, marker) == block(old, marker), marker
    settings = block(app, 'struct SettingsScreen: View')
    handle = block(settings, '    private func handlePhoneSetup(')
    assert handle.index('try SignalPhoneSetupSchema.changes(payload)') < handle.index('switch key')
    assert 'runBackendProfileRestore()' in handle and 'runBackendProfileBackup()' in handle
    assert 'try SignalPhoneSetupSchema.restoreCode(raw)' in handle
    assert 'guard !backendProfileBackupBusy' in handle
    state = handle[:handle.index('guard !backendProfileBackupBusy')]
    assert '"configured":' in state and '"value":' not in state
    assert '"restoreCode": backendProfileBackupCode' in state
    assert 'saveXtreamAccountToList(server: server, username: username, password: password)' in handle
    server = (ROOT / 'Sources/SignalPhoneSetupServer.swift').read_text()
    assert server.count('systemUptime + 600') == 1
    route = block(server, '    private func route(')
    assert route.index('deadline > ProcessInfo.processInfo.systemUptime') < route.index('handler(action, payload)')
    assert route.index('equalSecret(request.headers["authorization"]') < route.index('handler(action, payload)')
    assert 'request.headers["host"] == authority' in route and 'request.headers["origin"]' in route
    assert 'pairFailures < 8' in route and 'requestCount <= 1200' in route
    stop = block(server, '    func stop(')
    for token in ('generation = UUID()', 'clock?.cancel()', 'listener?.cancel()', 'peer.timeout.cancel()',
                  'peer.connection.cancel()', 'peers.removeAll()', 'handler = nil', 'token = ""', 'pin = ""'):
        assert token in stop, token
    assert 'peers.count < 6' in server and '.now() + 8' in server
    assert 'requiredLocalEndpoint = .hostPort(host: NWEndpoint.Host(host)' in server
    assert 'SignalPhoneSetupHTTP.isPrivateIPv4' in server
    for token in ('UserDefaults', 'AVPlayer', 'PlaybackKit', 'repeatForever'):
        assert token not in server
    ui = (ROOT / 'Sources/SignalPhoneSetupSection.swift').read_text()
    assert '.onDisappear { server.stop() }' in ui and 'phase != .active' in ui
    assert 'SignalPhoneSetupQR(text: server.qrURL).equatable()' in ui
    schema = (ROOT / 'Sources/SignalPhoneSetupSchema.swift').read_text()
    keys = re.findall(r'Field\(key: "([^"]+)"', schema)
    assert len(keys) == 21 and len(set(keys)) == 21
    for key in keys:
        assert 'case \"' + key + '\": ' + key + ' = value' in handle
    for key in keys:
        assert not any(x in key.lower() for x in ('theme', 'icon', 'enabled', 'safety', 'membership', 'profilecode'))
    assert 'Set(values.keys).isSubset(of: allowed)' in schema and 'Set(clear).isSubset(of: allowed)' in schema
    page = (ROOT / 'Sources/SignalPhoneSetupPage.swift').read_text()
    for token in ('localStorage', 'sessionStorage', 'innerHTML', '<script src=', '<link '):
        assert token not in page
    assert "history.replaceState(null, '', location.pathname)" in page
    assert 'document.execCommand(\'copy\')' in page and "credentials:'omit'" in page
    plist = plistlib.loads((ROOT / 'Sources/Info.plist').read_bytes())
    assert 'NSLocalNetworkUsageDescription' in plist
    project = (ROOT / 'project.yml').read_text()
    for source in ROOT.glob('Sources/SignalPhoneSetup*.swift'):
        assert source.relative_to(ROOT).as_posix() in project
    print('F60 PASS: bounded authenticated 600-second foreground server; allowlisted text settings; existing validated backup/restore/import actions; no credential readback except paired restore code; isolated countdown/QR; exact prior Search/playback/Guide and restore functions preserved. Native transport and Apple TV validation pending.')


if __name__ == '__main__':
    verify()
