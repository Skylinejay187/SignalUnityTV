from regression_manifest_cache import read_manifest
"""Reverse only reviewed F41 hunks for the exact historical F40 source checks."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    from f42_approved_deltas import previous_source as previous_f42
    source=previous_f42(source,path)
    record=read_manifest(ROOT/'Tests/F41ApprovedSourceDeltas.json').get(path)
    if record is None:return source
    digest=hashlib.sha256(source.encode()).hexdigest()
    if digest==record['before_sha256']:return source
    older=read_manifest(ROOT/'Tests/F40ApprovedSourceDeltas.json').get(path)
    if older and digest==older['before_sha256']:return source
    assert digest==record['after_sha256'],'Unreviewed F41 source change: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1,'Ambiguous F41 delta: '+path
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256']
    return source

def historical_source(path):
    return previous_source(path.read_text(),path.relative_to(ROOT).as_posix())
