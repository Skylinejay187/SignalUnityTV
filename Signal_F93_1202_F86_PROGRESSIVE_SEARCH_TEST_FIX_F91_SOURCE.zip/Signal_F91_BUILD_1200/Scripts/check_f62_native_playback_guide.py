#!/usr/bin/env python3
"""Execute production policy and actual recovery/refresh methods against bounded test doubles.

This is an orchestration test, not a decoder/device or Apple SDK integration test.
The complete tvOS app still needs its normal Xcode build and device smoke test.
"""
from pathlib import Path
import argparse,shutil,subprocess,tempfile
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]

def fixture():
    bridge=(ROOT/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
    app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    s='''import Foundation
enum DecodePath { case automatic, software }
struct LoadOptions { var isLive = false; var preferredDecodePath = DecodePath.automatic }
enum TestFailure: Error { case refused }
@MainActor final class UIApplication {
    enum State { case active, background }
    static let shared = UIApplication()
    var applicationState = State.active
}
@MainActor final class AetherEngine {
    var isSessionReady = true
    var playbackBackend = DecodePath.automatic
    var volume: Float = 1
    var reloads = 0, corrections = 0, plays = 0, pauses = 0
    var gain = 0.0, refuseCorrection = false
    var holdCorrection = false
    var correctionHold: CheckedContinuation<Void,Never>?
    func reloadAtCurrentPosition() async throws {
        reloads += 1; await Task.yield(); try Task.checkCancellation(); isSessionReady = true
    }
    func reloadAtCurrentPosition(applying change: (inout LoadOptions)->Void) async throws -> Bool {
        if refuseCorrection { throw TestFailure.refused }
        corrections += 1
        var options = LoadOptions(); change(&options)
        if holdCorrection { await withCheckedContinuation { correctionHold = $0 } }
        await Task.yield(); try Task.checkCancellation()
        playbackBackend = options.preferredDecodePath; isSessionReady = true; return true
    }
    func setDecodedAudioGainDB(_ value: Double) { gain = value }
    func bind(view: Int) {}
    func play() { plays += 1 }
    func pause() { pauses += 1 }
}
@MainActor final class PlaybackFixture {
    var engine: AetherEngine? = AetherEngine()
    var generation: UInt64 = 1
    var adjustmentID = UUID()
    var sessionAdjustmentTask: Task<Void,Never>?, loadTask: Task<Void,Never>?
    var foregroundRecoveryPending = false, audioGainUpdatePending = false, backgrounded = false
    var configuredAllowSessionRebuild = true, endedPublished = false, firstFramePublished = true
    var configuredAudioGainDB = 0.0, configuredMuted = false, gainForcedSoftwareDecode = false
    var transportWantsPlay = true
    var loadedOptions: LoadOptions? = LoadOptions(), liveBaseOptions: LoadOptions? = LoadOptions()
    var loadedURL: URL? = URL(string:"https://example.invalid/video")
    var liveRoute = 0, playerView = 0, retunes = 0
    var notices: [Double] = [], failures: [String] = []
    func setNeedsLayout() {}
    func layoutIfNeeded() {}
    func reconcileVODSeekTransport() {}
    func postAudioGainStatus(applied: Double, message: String) { notices.append(applied) }
    func publishFailure(_ message: String) { failures.append(message) }
    func startLiveAttempt(engine: AetherEngine, url: URL, baseOptions: LoadOptions, route: Int, generation: UInt64, reason: String) { retunes += 1 }
'''
    for marker in ('    private func reconcileSessionAdjustments(',
                   '    @objc public func aetherPrepareForBackground(',
                   '    @objc public func aetherRecoverAfterBackground(',
                   '    @objc public func aetherApplyAudioGain(',
                   '    private func applyPendingAudioGain('):
        s+=block(bridge,marker).replace('@objc public','').replace('private func','func')+'\n'
    s+='''}
@MainActor enum VODExclusivePlaybackGate { static var isActive = false }
@MainActor enum VODExclusiveWorkRegistry {
    static func start(_ operation: @escaping @MainActor () async -> Void) -> Task<Void,Never> {
        Task { @MainActor in await operation() }
    }
}
@MainActor final class GuideFixture {
    var providerRefreshTask: Task<Void,Never>?
    var providerRefreshID = UUID()
    var providerRefreshIsForced = false, isGuideRefreshing = false
    var starts: [Bool] = [], completions = 0
    var releases: [CheckedContinuation<Void,Never>] = []
    func performConfiguredSourceRefresh(showLoadingIndicator: Bool, userInitiatedForce: Bool) async {
        starts.append(userInitiatedForce)
        await withCheckedContinuation { releases.append($0) }
        guard !Task.isCancelled else { return }
        completions += 1
    }
'''
    s+=block(app,'    func refreshFromConfiguredSources(')+'\n}\n'
    return s+(ROOT/'Tests/SignalF62PlaybackGuideTests.swift').read_text()

def main():
    p=argparse.ArgumentParser();p.add_argument('--emit',type=Path);args=p.parse_args()
    if args.emit:args.emit.write_text(fixture());return
    if not shutil.which('swiftc'):raise SystemExit('Swift compiler required for F62 executable orchestration tests')
    with tempfile.TemporaryDirectory(prefix='signal-f62-') as folder:
        folder=Path(folder);src=folder/'Fixture.swift';src.write_text(fixture());out=folder/'tests'
        subprocess.run(['swiftc','-swift-version','5',str(ROOT/'Sources/SignalPlaybackRefreshPolicy.swift'),str(src),'-o',str(out)],check=True,timeout=90)
        subprocess.run([str(out)],check=True,timeout=15)
    print('F62 production policy and extracted session/refresh orchestration executable passed; decoder/device validation separate')
if __name__=='__main__':main()
