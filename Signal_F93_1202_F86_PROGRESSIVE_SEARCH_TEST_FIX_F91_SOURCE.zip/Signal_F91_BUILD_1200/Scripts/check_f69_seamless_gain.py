#!/usr/bin/env python3
"""Current production gain contracts plus negative controls for the F68 decoder reload."""
from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from f69_approved_deltas import previous_source
from f70_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def audit(s):
    request=block(s,'    @objc public func aetherApplyAudioGain(')
    apply=block(s,'    private func applyPendingAudioGain(')
    assert 'applyPendingAudioGain()' in request and 'audioGainUpdatePending = true' in request
    for body in (request,apply):
        for forbidden in ('reloadAtCurrentPosition','preferredDecodePath','engine.play(', 'engine.pause(', 'reconcileSessionAdjustments(', 'Task {', 'engine.bind('):
            assert forbidden not in body,forbidden
    for required in ('loadTask == nil','!backgrounded','!endedPublished','engine.isSessionReady',
                     'loadedOptions?.isLive == false','SignalPlaybackRefreshPolicy.gain(',
                     'engine.playbackBackend != .software','engine.setDecodedAudioGainDB(gain)',
                     'postAudioGainStatus(applied: 0'):
        assert required in apply,required
    recovery=block(s,'    private func reconcileSessionAdjustments(')
    assert 'foregroundRecoveryPending else' in recovery
    assert 'while self.foregroundRecoveryPending {' in recovery
    assert 'engine.reloadAtCurrentPosition()' in recovery and 'reloadAtCurrentPosition(applying:' not in recovery
    assert 'self.audioGainUpdatePending = true' in recovery and 'self.applyPendingAudioGain()' in recovery
    load=block(s,'    public func load(')
    assert 'self.loadTask = nil\n                            self.applyPendingAudioGain()' in load
    assert 'gainForcedSoftwareDecode' not in s

def main():
    for path,record in json.loads(historical_source(ROOT/'Tests/F69ApprovedSourceDeltas.json')).items():
        value=historical_source(ROOT/path);assert hashlib.sha256(value.encode()).hexdigest()==record['after_sha256'],path
        previous_source(value,path)
    for path,digest in json.loads(historical_source(ROOT/'Tests/F69UnchangedSourceHashes.json')).items():
        assert hashlib.sha256(historical_source(ROOT/path).encode()).hexdigest()==digest,path
    path='Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift';s=historical_source(ROOT/path);audit(s)
    try:audit(previous_source(s,path))
    except (AssertionError,ValueError):pass
    else:raise AssertionError('Previous gain reload accepted')
    mutated=s.replace('        engine.setDecodedAudioGainDB(gain)','        engine.play()\n        engine.setDecodedAudioGainDB(gain)',1)
    try:audit(mutated)
    except AssertionError:pass
    else:raise AssertionError('Gain changing transport accepted')
    assert s==historical_source(ROOT/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift')
    print('F69 PASS: in-place decoded gain, no gain-triggered decoder reload or transport command; foreground recovery retained; native capability refusal; old implementation and transport mutation rejected. Native/SDK/device execution still required.')
if __name__=='__main__':main()
