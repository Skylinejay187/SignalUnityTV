#!/usr/bin/env python3
"""One reviewed production-line build fix; preserve all F44 behavior."""
from pathlib import Path
import hashlib,json
from f45_approved_deltas import previous_source
from f46_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    records=json.loads((ROOT/'Tests/F45ApprovedSourceDeltas.json').read_text())
    assert list(records)==['Sources/DebridChannelsTVOSApp.swift']
    path='Sources/DebridChannelsTVOSApp.swift';current=historical_source(ROOT/path);old=previous_source(current,path)
    assert current==old.replace('aliases[normalizeGuideKey(key)]','aliases[self.normalizeGuideKey(key)]',1)
    for name,sha in json.loads((ROOT/'Tests/F45UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==sha,name
    preflight=(ROOT/'Scripts/check_f28_source_preflight.sh').read_text()
    assert 'python3 Scripts/check_f45_quick_guide_compile.py' in preflight
    print('F45 scope PASS: one explicit-self correction; every other prior Swift file unchanged; semantic compiler gate enabled')
if __name__=='__main__':verify()
