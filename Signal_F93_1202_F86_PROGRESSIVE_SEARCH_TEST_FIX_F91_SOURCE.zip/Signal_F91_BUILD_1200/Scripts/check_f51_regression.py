#!/usr/bin/env python3
"""Current F51 safety/ownership checks, independent of historical projections."""
from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from f51_approved_deltas import previous_source
from f52_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    records=json.loads((ROOT/'Tests/F51ApprovedSourceDeltas.json').read_text())
    for name,record in records.items():
        text=historical_source(ROOT/name);assert hashlib.sha256(text.encode()).hexdigest()==record['after_sha256'],name;previous_source(text,name)
    for name,sha in json.loads((ROOT/'Tests/F51UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==sha,name
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift');prior=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    host=block(app,'private struct LiveTVGridFocusMotionHost<Content: View>')
    assert '.modifier(SignalLiveTVCardPoseModifier(aligned: aligned, pose: legacyPose))' in host
    modifier=block(app,'private struct SignalLiveTVCardPoseModifier:')
    assert 'if aligned' in modifier and 'SignalUniformAlignedCardGeometry(pose: pose)' in modifier
    assert '.rotation3DEffect' in modifier
    geometry=block(app,'private struct SignalUniformAlignedCardGeometry:')
    assert 'SignalLiveTVCardProjection.uniformlyFitted' in geometry and 'GeometryReader' not in geometry
    math=(ROOT/'Sources/SignalLiveTVCardAlignment.swift').read_text()
    assert 'let sx = uniform ? min(fitX, fitY) : fitX' in math
    assert 'let ssY = uniform ? min(fitX, fitY) : fitY' in math
    # Dashboard geometry, preview lifecycle/timing and catalog/Search rendering stay intact.
    assert block(app,'struct LiveTVScreen: View')==block(prior,'struct LiveTVScreen: View')
    assert block(app,'struct GlobalSearchScreen: View')==block(prior,'struct GlobalSearchScreen: View')
    for marker in ('    private func playPreparedUpNextEpisode(', '    private func handleNaturalEpisodeEnd(',
                   '    private func reconcileUpNextAfterEOF(', '    private func cancelUpNextCountdown(',
                   '    private func seekAbsolute(', '    private func stopOwnedPlaybackKitSession('):
        assert block(app,marker)==block(prior,marker),marker
    assert '.onReceive(NotificationCenter.default.publisher(for: SignalProtectedNetworkState.revoked))' in app
    assert 'setupVerifiedPlayer()' in block(app,'    private func setupPlayer(')
    restore=block(app,'    private func applyBackendProfilePayload(')
    assert restore.index('SignalMediaFlowSafetyPolicy.settingsForThisDevice')<restore.index('for (key, value) in settings')
    policy=(ROOT/'Sources/SignalMediaFlowSafetyPolicy.swift').read_text()
    assert 'A synced legacy Off value can never disable' in policy
    assert 'host.hasSuffix(".torbox.app")' in policy and 'if vod { return true }' in policy
    router=(ROOT/'Sources/MediaFlowProxyRouter.swift').read_text()
    route=block(router,'    static func routingSnapshot(')
    assert 'SignalProtectedNetworkState.isHome' in route and 'return enabledCopy(config)' in route
    prepare=block(router,'    static func prepareSafetyError(')
    for token in ('SignalPublicIPVerifier.shared.currentIP','SignalProtectedNetworkState.authorizeHome',
                  'snapshot() == raw','SignalProtectedNetworkState.epoch() == epoch','testConnection(',
                  'guard result.success','learnProxyIP','recentEgressProof'):
        assert token in prepare,token
    assert 'URLSession.shared' not in block(router,'    private static func performConnectionTest(')
    state=(ROOT/'Sources/SignalProtectedNetworkState.swift').read_text()
    for token in ('NWPathMonitor','invalidate(notify: true)','api.ipify.org','api64.ipify.org','sameIP(first, second)',
                  'request.httpShouldHandleCookies = false','Date().timeIntervalSince(date) < 15'):
        assert token in state,token
    assert 'Bearer' not in state and 'api_password' not in state
    catalog=(ROOT/'Sources/CatalogStore.swift').read_text()
    start=block(catalog,'    func startPlayback(')
    assert start.index('await MediaFlowProxyRouter.prepareSafetyError')<start.rindex('self.commitVerifiedPlayback')
    assert 'self.protectedLaunchGeneration == generation' in start and 'protectedRouteError = error' in start
    close=block(catalog,'    func closePlayer(')
    assert close.index('if let expectedURL')<close.index('protectedLaunchTask?.cancel()')
    assert catalog.count('await MediaFlowProxyRouter.prepareSafetyError')>=6
    assert 'nativePrepareTask = nil' in block(app,'    private func setupPlayer(')
    health=(ROOT/'Sources/ConnectedServicesHealthClient.swift').read_text()
    assert 'await MediaFlowProxyRouter.prepareSafetyError(for: url, session: session)' in block(health,'    private static func getJSON(')
    portable=(ROOT/'Sources/SignalPortableSettings.swift').read_text()
    assert 'result["signalRequireMediaFlowForVODV1"] = true' in portable
    coverage=json.loads((ROOT/'Tests/F42SettingsCoverage.json').read_text())
    for key in ('signalVerifiedProxyHomeIPV1','signalVerifiedProxyHomeIdentityV1','mediaFlowPreferredLocalProfileV1'):
        assert key in coverage['portable']
    assert 'check_f51_native_routing.py' in (ROOT/'Scripts/check_f28_source_preflight.sh').read_text()
    print('F51 PASS: real uniform aligned renderer; per-device restore protection; home-IP proof/away proxy/unknown fail-closed; cancellable source and player preparation; network-change stop; unchanged Up Next/grid/Search/engine scope')
if __name__=='__main__':verify()
