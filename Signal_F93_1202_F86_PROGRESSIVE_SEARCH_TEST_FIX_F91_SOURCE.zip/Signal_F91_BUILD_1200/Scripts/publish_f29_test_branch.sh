#!/usr/bin/env bash
# Run on a machine with GitHub access. Publish this complete source snapshot to
# the existing test branch without writing to main.
set -euo pipefail
SOURCE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_URL="${SIGNAL_REPO_URL:-https://github.com/Skylinejay187/DebridChannelsTvos.git}"
BRANCH="signal/f28-test"
if [[ "${1:-}" != "--publish" ]]; then
  echo "Dry run only. To publish, run: bash Scripts/publish_f29_test_branch.sh --publish"
  echo "Target: $REPO_URL / $BRANCH (main will not be modified)"
  python3 "$SOURCE_ROOT/Scripts/check_f29_build_identity.py"
  exit 0
fi
python3 "$SOURCE_ROOT/Scripts/check_f29_build_identity.py"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
git clone --branch "$BRANCH" --single-branch "$REPO_URL" "$WORK/repo"
# Preserve remote history and unrelated tracked files. Copy F29 source into the
# test branch without deleting anything that may exist only in the repository.
# Do not include local caches, nested Git metadata, or generated build products.
python3 - "$SOURCE_ROOT" "$WORK/repo" <<'PY'
from pathlib import Path
import shutil, sys
src, dst = map(Path, sys.argv[1:])
exclude_dirs = {'.git', '.build', '.build-cache', 'DerivedData', '__pycache__', '.DS_Store', '.swiftpm'}
exclude_suffix = {'.pyc', '.swp', '.p12', '.p8', '.mobileprovision', '.key', '.pem'}
exclude_names = {'.env', '.env.local', '.env.production', '.netrc', '.git-credentials'}
source_files = sorted(
    p.relative_to(src) for p in src.rglob('*')
    if p.is_file() and not p.is_symlink()
    and p.name not in exclude_names
    and not any(part in exclude_dirs for part in p.relative_to(src).parts)
    and p.suffix not in exclude_suffix
)
if not source_files:
    raise SystemExit('Refusing to publish empty source tree')
print(f'Copying {len(source_files)} source files into isolated test-branch checkout')
# Never remove tracked repository files merely because they are absent from the
# local source archive. Such deletions could destroy unrelated project content.
for rel in source_files:
    target = dst / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src / rel, target)
PY
cd "$WORK/repo"
git add -A
# Guard against accidental deletions (including changes caused by an unusual
# source layout). F29 publishing is additive/updated files only.
if git diff --cached --name-only --diff-filter=D | grep -q .; then
  echo 'Refusing to publish: staged deletions detected' >&2
  exit 1
fi
if git diff --cached --quiet; then
  echo "Test branch already matches F29 snapshot; nothing to push"
  exit 0
fi
printf '\nChange summary for %s:\n' "$BRANCH"
git diff --cached --stat | tail -25
# Never push to main; non-forced push fails safely if branch moved.
git commit -m 'Signal F29 build 1135 tvOS test source'
git push origin "HEAD:refs/heads/$BRANCH"
echo "Published F29 to $BRANCH; main was not modified"
