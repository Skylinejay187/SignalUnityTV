from regression_manifest_cache import read_manifest
"""Exact F38 projection for historical checks; current behavior is checked by F39.
Original fixtures remain immutable. Any unreviewed source edit fails the digest.
"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    from f40_approved_deltas import previous_source as previous_f40
    source=previous_f40(source,path)
    record=read_manifest(ROOT/'Tests/F39ApprovedSourceDeltas.json').get(path)
    if record is None:return source
    digest=hashlib.sha256(source.encode()).hexdigest()
    if digest==record['before_sha256']:return source
    assert digest==record['after_sha256'],'Unreviewed F39 source change: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1,'Ambiguous F39 delta: '+path
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256']
    return source

def historical_source(path):
    return previous_source(path.read_text(),path.relative_to(ROOT).as_posix())
