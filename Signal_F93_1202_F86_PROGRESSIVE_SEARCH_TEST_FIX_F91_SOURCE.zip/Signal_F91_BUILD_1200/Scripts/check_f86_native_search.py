"""Compile real search orchestration and artwork policy; reject the reported access error early."""
from pathlib import Path
import platform,re,shutil,subprocess,tempfile
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]

def fixture():
    store=(ROOT/'Sources/CatalogStore.swift').read_text()
    production=block(store,'    func unifiedSearchResults(')
    return '''import Foundation
struct MediaItem: Sendable, Equatable { let id: String }
actor Providers {
    var continuations: [String: CheckedContinuation<[MediaItem], Never>] = [:]
    var completed: [String: [MediaItem]] = [:]
    func result(_ name: String) async -> [MediaItem] {
        if let ready = completed[name] { return ready }
        return await withCheckedContinuation { continuations[name] = $0 }
    }
    func finish(_ name: String, _ ids: [String]) {
        let items = ids.map { MediaItem(id: $0) }; completed[name] = items
        continuations.removeValue(forKey: name)?.resume(returning: items)
    }
}
@MainActor final class CatalogStore {
    let providers = Providers()
    var cache: [MediaItem]? = nil
    private func localUnifiedSearchResults(for query: String) async -> [MediaItem] { [MediaItem(id: "local")] }
    private func cachedUnifiedSearchResults(for query: String) -> [MediaItem]? { cache }
    private func rememberUnifiedSearchResults(_ items: [MediaItem], for query: String) { cache = items }
    private func searchBuiltInCatalogDatabase(for query: String) async -> [MediaItem] { await providers.result("builtIn") }
    // F90 added this production search provider; model it in the native orchestration fixture.
    private func searchConfiguredCatalogAddons(for query: String) async -> [MediaItem] { await providers.result("addons") }
    private func cinemetaUnifiedSearchResults(for query: String, type: String) async -> [MediaItem] { await providers.result(type) }
    private func tmdbSearchResults(for query: String, apiKey: String) async -> [MediaItem] { await providers.result("tmdb") }
    // Canonical merge is unchanged production code and guarded byte-for-byte separately.
    private func mergeUnifiedSearchSources(_ sources: [[MediaItem]], limit: Int) -> [MediaItem] {
        var seen = Set<String>(); return Array(sources.flatMap { $0 }.filter { seen.insert($0.id).inserted }.prefix(limit))
    }
''' + production + '''
}
@main struct Checks {
    @MainActor static func main() async {
        let store = CatalogStore()
        var updates: [[String]] = []
        let first = AsyncStream<Void>.makeStream()
        let task = Task { await store.unifiedSearchResults(for: "Matrix", tmdbApiKey: "test") { items in
            updates.append(items.map(\\.id)); _ = first.continuation.yield(Void())
        } }
        await store.providers.finish("tmdb", ["fast", "local"])
        // The production coordinator publishes local results immediately, then merges
        // a fast remote provider without waiting for slower providers. Validate both
        // updates rather than incorrectly expecting the first update to be remote.
        var iterator = first.stream.makeAsyncIterator()
        _ = await iterator.next() // immediate local first paint
        _ = await iterator.next() // TMDB completes independently of slow providers
        precondition(updates == [["local"], ["local", "fast"]],
                     "Fast result waited for slow providers or local first paint was lost")
        precondition(store.cache == nil, "Incomplete results poisoned query cache")
        await store.providers.finish("series", ["series"])
        await store.providers.finish("movie", ["fast", "movie"])
        await store.providers.finish("builtIn", ["official"])
        await store.providers.finish("addons", ["addon"])
        let result = await task.value
        precondition(result.prefix(2).map(\\.id) == ["local", "fast"])
        precondition(Set(result.map(\\.id)) == Set(["local", "fast", "series", "movie", "official", "addon"]))
        let cached = await store.unifiedSearchResults(for: "Matrix", tmdbApiKey: "test")
        precondition(cached == result)
        let cancelled = CatalogStore(); var stalePublished = false
        let stopped = Task { await cancelled.unifiedSearchResults(for: "old", tmdbApiKey: "") { _ in stalePublished = true } }
        // Cancel before yielding the MainActor: otherwise the search can
        // legitimately publish local results before cancellation, making
        // this a scheduler-dependent test rather than a cancellation check.
        stopped.cancel()
        await cancelled.providers.finish("movie", ["stale"])
        await cancelled.providers.finish("series", [])
        await cancelled.providers.finish("builtIn", [])
        await cancelled.providers.finish("addons", [])
        let discarded = await stopped.value
        precondition(discarded.isEmpty && !stalePublished && cancelled.cache == nil)
        precondition(SignalSearchArtwork.cardURL(for: "https://image.tmdb.org/t/p/original/a.jpg") == "https://image.tmdb.org/t/p/w780/a.jpg")
        for url in ["https://nas.example/posters/abc.webp", "https://image.tmdb.org/t/p/original/a.jpg?token=private", "https://image.tmdb.org/t/p/original/a.svg", "https://image.tmdb.org.evil/t/p/original/a.jpg", "https://image.tmdb.org/t/p/w780/a.jpg"] {
            precondition(SignalSearchArtwork.cardURL(for: url) == url)
        }
        precondition(SignalSearchArtwork.cardURL(for: nil) == nil)
        print("F86 production search orchestration PASS: first provider, stable IDs/order, completion-only cache, cache reuse, cancelled publication; card-only TMDB sizing and unchanged NAS/signed/vector URLs")
    }
}
'''

def main():
    if platform.system()!='Darwin' or not shutil.which('swiftc'):
        raise SystemExit('F86 native Search/access checks require Xcode; not run')
    source=(ROOT/'Sources/CatalogStore.swift').read_text()
    declaration=re.search(r'^    .*var fullScreenPlaybackResourceSuspended: Bool = false$',source,re.M).group().strip()
    app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    access=re.search(r'!store\.fullScreenPlaybackResourceSuspended',block(app,'struct SportsHubScreen: View')).group()
    with tempfile.TemporaryDirectory(prefix='signal-f86-') as tmp:
        folder=Path(tmp);a=folder/'State.swift';b=folder/'Access.swift';test=folder/'Search.swift';exe=folder/'tests'
        a.write_text('final class State { '+declaration+' }\n')
        b.write_text('func sportsRefreshAllowed(_ store: State) -> Bool { '+access+' }\n')
        command=['swiftc','-swift-version','5','-typecheck',str(a),str(b)]
        subprocess.run(command,check=True,timeout=30)
        a.write_text('final class State { '+declaration.replace('private(set)','private')+' }\n')
        negative=subprocess.run(command,capture_output=True,text=True,timeout=30)
        assert negative.returncode and "inaccessible due to 'private' protection level" in negative.stderr,'Reported F85 build failure was not reproduced'
        test.write_text(fixture())
        subprocess.run(['swiftc','-swift-version','5','-target',platform.machine()+'-apple-macos14.0','-parse-as-library',str(ROOT/'Sources/SignalSearchResultsLayout.swift'),str(test),'-o',str(exe)],check=True,timeout=120)
        subprocess.run([str(exe)],check=True,timeout=20)
    print('F86 production getter/access typecheck PASS; old private getter negative control rejected. Full app/device validation separate.')
if __name__=='__main__':main()
