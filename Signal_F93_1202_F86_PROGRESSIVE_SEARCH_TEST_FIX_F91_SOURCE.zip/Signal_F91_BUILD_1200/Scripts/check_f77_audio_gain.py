#!/usr/bin/env python3
"""Audit current gain wiring; historical contracts do not substitute for this check."""
from pathlib import Path
from check_f31_top_menu_regression import block
ROOT = Path(__file__).resolve().parents[1]
bridge = (ROOT/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
assert bridge == (ROOT/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
apply = block(bridge, '    private func applyPendingAudioGain(')
assert 'reconcileSessionAdjustments()' in apply
assert 'postAudioGainStatus(applied: 0' not in apply, 'Pending native request must not reset UI to Off'
assert 'engine.setDecodedAudioGainDB(gain)' in apply
adjust = block(bridge, '    private func reconcileSessionAdjustments(')
assert adjust.count('reloadAtCurrentPosition(applying:') == 1
assert 'requestedGain > 0.01 && engine.playbackBackend != .software' in adjust
assert 'let latestGain = SignalPlaybackRefreshPolicy.gain(self.configuredAudioGainDB)' in adjust
assert 'self.generation == owner' in adjust and 'self.engine === engine' in adjust
assert 'preferredDecodePath = .automatic' not in adjust, 'Off must not rebuild back to native'
assert 'engine.setDecodedAudioGainDB(latestGain)' in adjust
assert 'self.transportWantsPlay' in adjust and 'self.configuredAllowSessionRebuild' in adjust
print('F77 current gain wiring PASS: one guarded native-to-decoded correction; latest gain; unchanged decoded route on Off; bridge parity. Compiler/device checks separate.')
