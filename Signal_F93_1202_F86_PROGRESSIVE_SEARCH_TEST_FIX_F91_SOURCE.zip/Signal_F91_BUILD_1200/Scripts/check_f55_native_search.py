#!/usr/bin/env python3
"""Compile/run real layout tests and type-check actual Search grid/card methods on tvOS."""
from pathlib import Path
import argparse
import shutil
import subprocess
import tempfile
from check_f31_top_menu_regression import block

ROOT = Path(__file__).resolve().parents[1]


def ui_fixture():
    app = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
    search = block(app, 'struct GlobalSearchScreen: View')
    output = '''import SwiftUI
struct MediaItem: Identifiable {
    let id: String
    let title: String
    let year: String
    let catalog: String
    var landscapeURL: String? = nil
    var posterURL: String? = nil
}
struct RemoteImageFit: View {
    enum Mode { case fit }
    let url: String?
    var mode: Mode = .fit
    var maxPixelSize: Int? = nil
    var publishDuringSurfaceHandoff = false
    var publishDuringPlayback = false
    var forceVisiblePlaybackPublication = false
    var body: some View { Color.clear }
}
struct SearchStoreFixture { var selectedDetail: MediaItem? = nil }
''' + block(app, 'struct FocusedSidewaysCardEffect:') + '\n' + block(app, 'struct SearchResultCard:') + '\n' + block(app, 'struct SportsNoPlatterButtonStyle:') + '\n'
    output += 'struct SearchGridTypecheckFixture: View {\n'
    output += block(search, '    private enum SearchScope:') + '\n'
    output += block(search, '    private enum SearchFocusTarget:') + '\n'
    output += r'''
    @State private var resultFocusRequest = UUID()
    @State private var resultFocusTargetID: String?
    @State private var resultsFocusRequested = false
    @State private var selectedResultIndex = 0
    @State private var rememberedFocusedMediaID = ""
    @State private var searchScope: SearchScope = .all
    @FocusState private var searchFocus: SearchFocusTarget?
    private var focusedID: String? {
        if case .result(let id)? = searchFocus { return id }
        return nil
    }
    private var queryFieldFocused: Bool { searchFocus == .query }
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceSearchMotion
    let store = SearchStoreFixture()
    let displayedSearchResults: [MediaItem] = []
    let playbackBrowseMode = false
    let searchSurfaceActive = true
    @State private var query = ""
    @State private var isSearchingUnified = false
    private func closeSearch() {}
    private func scheduleUnifiedSearch() {}
    var body: some View { VStack { searchHeaderFixture; searchResultsGrid(width: 1792) } }
    private func openSearchResult(_ item: MediaItem) {}
'''
    # Type-check the actual query/filter modifiers as well as the result grid.
    header_start = search.index('                    HStack(spacing: 16) {')
    header_end = search.index('                    if query.trimmingCharacters', header_start)
    output += '\n    private var searchHeaderFixture: some View { VStack {\n' + search[header_start:header_end] + '\n} }\n'
    methods = ['searchResultsGrid', 'restoreSearchGridFocus', 'focusMountedSearchResult',
               'cancelSearchResultFocus', 'requestSearchResultFocus', 'moveSearchResults',
               'focusSearchQuery', 'focusSearchScope', 'focusResults', 'restoreSearchResultFocus']
    for method in methods:
        output += '\n'
        if method in ('restoreSearchGridFocus', 'focusMountedSearchResult'): output += '@MainActor\n'
        output += block(search, '    private func ' + method + '(') + '\n'
    return output + '\n}\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--emit', type=Path)
    args = parser.parse_args()
    if args.emit:
        args.emit.write_text(ui_fixture())
        return
    compiler = shutil.which('swiftc')
    if not compiler:
        raise SystemExit('Swift compiler required for F55 native checks')
    with tempfile.TemporaryDirectory(prefix='signal-f55-') as folder:
        folder = Path(folder)
        executable = folder / 'layout-tests'
        layout = ROOT / 'Sources/SignalSearchResultsLayout.swift'
        subprocess.run([compiler, '-swift-version', '5', str(layout),
                        str(ROOT / 'Tests/SignalF55SearchLayoutTests.swift'), '-o', str(executable)], check=True, timeout=60)
        subprocess.run([str(executable)], check=True, timeout=30)
        source = folder / 'SearchGrid.swift'
        source.write_text(ui_fixture())
        sdk = subprocess.check_output(['xcrun', '--sdk', 'appletvos', '--show-sdk-path'], text=True).strip()
        subprocess.run(['xcrun', '--sdk', 'appletvos', 'swiftc', '-typecheck', '-swift-version', '5',
                        '-sdk', sdk, '-target', 'arm64-apple-tvos17.0', str(source), str(layout)], check=True, timeout=60)
    print('F55 real Search layout tests and actual grid/card SDK type-check passed')


if __name__ == '__main__':
    main()
