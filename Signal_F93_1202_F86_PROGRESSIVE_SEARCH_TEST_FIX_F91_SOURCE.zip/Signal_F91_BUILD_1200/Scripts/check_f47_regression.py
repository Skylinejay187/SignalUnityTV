#!/usr/bin/env python3
"""F47 foreground ownership and preserved playback contracts; no device-runtime claims."""
from pathlib import Path
import hashlib,json,re
from check_f31_top_menu_regression import block
from f47_approved_deltas import previous_source
from f48_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    for name,record in json.loads((ROOT/'Tests/F47ApprovedSourceDeltas.json').read_text()).items():
        s=historical_source(ROOT/name);assert hashlib.sha256(s.encode()).hexdigest()==record['after_sha256'],name;previous_source(s,name)
    for name,sha in json.loads((ROOT/'Tests/F47UnchangedSourceHashes.json').read_text()).items():
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==sha,name
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift');old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    player=block(app,'struct VODPlayerScreen: View');prior=block(old,'struct VODPlayerScreen: View')
    # UI browsing must not alter playback, Up Next, seek/cache policy or engine teardown.
    for marker in ('    private func startUpNextPreparationIfNeeded(', '    private func prepareUpNextSourcesIfNeeded(',
                   '    private func handleNaturalEpisodeEnd(', '    private func schedulePostEOFUpNextWork(',
                   '    private func reconcileUpNextAfterEOF(', '    private func startUpNextCountdown(',
                   '    private func cancelUpNextCountdown(', '    private func playPreparedUpNextEpisode(',
                   '    private func seekAbsolute(', '    private func stopOwnedPlaybackKitSession('):
        assert block(player,marker)==block(prior,marker),marker
    assert 'liveQuickGuideCategories: [String] { liveQuickGuideBrowseCategories }' in player
    assert 'liveQuickGuideChannels: [LiveTVChannel] { liveQuickGuideBrowseChannels }' in player
    assert 'catalogHome' not in player
    assert 'case .television: openPlaybackTVGuide()' in player and 'case .playerSearch: openPlaybackUnityCatalog(.search)' in player
    for marker in ('    private func openPlaybackTVGuide(', '    private func openPlaybackUnityCatalog(', '    private func closePlaybackUnityCatalog('):
        scope=block(player,marker)
        for forbidden in ('togglePlay(', 'seekAbsolute(', 'store.startPlayback(', 'VODExclusivePlaybackGate.end(', 'aetherStop'):
            assert forbidden not in scope,(marker,forbidden)
    guide=block(player,'    private var vodTVGuideOverlay:')
    assert 'SignalGuideChrome.panelFill' in guide and 'liveQuickGuideChannelRail' in guide
    for forbidden in ('PlaybackKitAetherHost(', 'AVPlayer(', 'loadCachedOrDemo(', 'Task.sleep('):assert forbidden not in guide
    overlay=block(player,'    private var playbackUnityCatalogLayer:')
    assert 'GlobalSearchScreen(liveModel: liveQuickGuideModel, playbackBrowseMode: true' in overlay
    assert '.disabled(store.selectedDetail != nil)' in overlay and 'playbackBrowseMode: true' in overlay
    assert 'if liveQuickGuideVisible {' in player and 'if isLivePlayback && liveQuickGuideVisible {' not in player
    search=block(app,'struct GlobalSearchScreen: View')
    assert 'GridOSFixedSlotCatalogRail(' in search and 'LazyVGrid' not in search
    assert 'SearchResultCard(' not in app and 'struct SearchResultCard:' not in app
    assert 'if playbackBrowseMode { SignalGuideChrome.panelFill' in search and 'UnitySurfaceBackdrop()' not in search
    assert '@State private var focusedID: String?' in search and 'focusedSearchHeader == nil' in search
    assert 'queryFieldFocused = true' in search and '.onSubmit { focusResults() }' in search
    assert '@State private var liveSearchItems: [MediaItem] = []' in search
    task=block(search,'    private func scheduleUnifiedSearch(')
    for token in ('250_000_000','Task.detached','withTaskCancellationHandler','token == unifiedSearchToken','searchSurfaceActive','channel.streamURL.isEmpty','matches.count == 80'):
        assert token in task,token
    assert 'allowDuringExclusivePlayback: playbackBrowseMode' in task
    prefetch=block(search,'    private func scheduleSearchProductionPrefetch(')
    assert 'guard !playbackBrowseMode' in prefetch
    assert 'SignalPlaybackBrowsePolicy.searchAllowed' in search and 'VODExclusivePlaybackGate.end()' not in search
    assert 'if !playbackBrowseMode { store.recoverCatalogInteractivity(reason: "Search appeared") }' in search
    assert 'guard !playbackBrowseMode, activePlaybackURL == nil' in search
    rail=block(app,'struct GridOSFixedSlotCatalogRail: View')
    assert 'var onSelectItem: ((MediaItem) -> Void)? = nil' in rail
    assert 'if let onSelectItem { onSelectItem(selectedItem); return }' in block(rail,'    private func openSelected(')
    assert 'allowsLazyRefresh: false, playbackBrowseMode: playbackBrowseMode' in search
    assert 'SignalLiveTVDashboardStyle' not in app and 'Live TV Dashboard:' not in app and '"Golden"' not in app
    mode=(ROOT/'Sources/SignalDashboardMode.swift').read_text();assert 'static let name = "Preview Mirror"' in mode
    assert 'SignalDashboardMode.migrate()' in app
    live=block(app,'struct LiveTVScreen: View')
    assert block(live,'    private var mirrorDashboardActive:').endswith('!showGuide\n    }')
    assert 'private var liveTVGridPageSize: Int { 12 }' in live
    surface=(ROOT/'Sources/UnitySurfaceSystem.swift').read_text()
    assert 'case .liveRoot, .catalogBranch, .sportsBranch:\n            return true' in surface
    sports=block(app,'struct SportsFoundationQuickPanelSurface: View')
    backdrop=block(sports,'    private func sportsUnityThemeBackdrop(')
    assert 'Color.clear' in backdrop and 'RemoteImageFit(' not in backdrop and 'Color.black' not in backdrop
    portable=historical_source(ROOT/'Sources/SignalPortableSettings.swift');assert '"liveTVDashboardStyleV348": "Preview Mirror"' in portable
    # No new stored preference can fall outside the backup registry.
    observed=set()
    for p in (ROOT/'Sources').rglob('*.swift'):observed.update(re.findall(r'@AppStorage\("([^"\\]+)"\)',historical_source(p)))
    coverage=json.loads((ROOT/'Tests/F42SettingsCoverage.json').read_text())
    assert observed<=set(coverage['portable'])|set(coverage['excluded'])
    print('F47 PASS: TV/Search playback chips; single cached-data TV overlay; scoped cancellable Search; real catalog results rail; shared Sports backdrop; Golden renderer/selector removed; existing Up Next/seek/engine policies preserved')
if __name__=='__main__':verify()
