"""Keep source locks strict across the deliberate Aether placeholder installation.

Only the two packaged engine placeholders have two valid lifecycle states.
All app, bridge, other vendor and test entries retain exact hash validation.
"""
from pathlib import Path
import hashlib
import subprocess
import sys

ENGINE_PLACEHOLDERS = frozenset({
    'Vendor/AetherEngine/Package.swift',
    'Vendor/AetherEngine/Sources/AetherEngine/Placeholder.swift',
})


def verify_unchanged_sources(root, hashes, read_source=None):
    root = Path(root).resolve()
    engine_entries = set(hashes) & ENGINE_PLACEHOLDERS
    installed = False
    for name in engine_entries:
        path = root / name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != hashes[name]:
            installed = True
    if installed:
        engine = root / 'Vendor/AetherEngine'
        marker = engine / '.signal-f28-version'
        assert marker.is_file() and marker.read_text().strip() == '7.44.0', 'Unverified engine replacement'
        assert (engine / '.git').exists(), 'Installed engine must retain its pinned Git checkout'
        top = subprocess.check_output(['git', '-C', str(engine), 'rev-parse', '--show-toplevel'], text=True).strip()
        assert Path(top).resolve() == engine.resolve(), 'Engine verification must not use the parent repository'
        tag = subprocess.check_output(['git', '-C', str(engine), 'describe', '--tags', '--exact-match'], text=True).strip()
        assert tag == '7.44.0', 'Installed engine must be pinned to 7.44.0'
        assert not (root / 'Vendor/AetherEngine/Sources/AetherEngine/Placeholder.swift').exists(), 'Installed engine still contains the package placeholder'
        subprocess.run([sys.executable, str(root / 'Scripts/verify_f28_aether_integration.py'), str(engine)], check=True)
    for name, expected in hashes.items():
        if installed and name in ENGINE_PLACEHOLDERS:
            continue
        path = root / name
        data = read_source(path).encode() if read_source else path.read_bytes()
        assert hashlib.sha256(data).hexdigest() == expected, 'Changed protected source: ' + name
    return 'verified-installed-7.44.0' if installed else 'packaged-exact-hashes'
