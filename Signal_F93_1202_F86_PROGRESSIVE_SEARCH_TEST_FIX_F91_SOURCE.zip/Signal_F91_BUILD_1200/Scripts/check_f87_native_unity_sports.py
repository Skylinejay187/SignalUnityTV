"""Compile real shade views, live event metadata and scoped device-egress policy early."""
from pathlib import Path
import platform,shutil,subprocess,tempfile,argparse
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]
def metadata_fixture():
    app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    store=(ROOT/'Sources/CatalogStore.swift').read_text()
    player=block(app,'struct VODPlayerScreen: View')
    text='import SwiftUI\nimport Foundation\n'+block(store,'struct CastMember:')+'\n'+block(store,'struct MediaItem:')+'\n'
    text+=block(app,'struct LiveTVChannel:')+'\n'+block(app,'struct LiveProgram:')+'\n'
    text+='''struct GuideFixture {
    func currentProgram(for channel: LiveTVChannel) -> LiveProgram? { nil }
    func programs(for channel: LiveTVChannel) -> [LiveProgram] { [] }
    func nextProgram(for channel: LiveTVChannel, after program: LiveProgram?) -> LiveProgram? { nil }
}
struct SportsMetadataFixture: View {
    let item: MediaItem
    let url = URL(string: "https://chatgpt.hereisman.net/playlist/1/load-playlist")!
    var currentLiveQuickGuideChannel: LiveTVChannel? = nil
    var liveQuickGuideSelectedChannel: LiveTVChannel? = nil
    let liveQuickGuideModel = GuideFixture()
    var body: some View { EmptyView() }
'''
    for marker in ['    private var isOnlineSportsPlayback:', '    private var liveOverlayCurrentChannel:', '    private var liveOverlayCurrentProgram:', '    private var liveOverlayNextProgram:']:
        text+=block(player,marker)+'\n'
    text+='''    func auditSports() {
        precondition(isOnlineSportsPlayback)
        precondition(liveOverlayCurrentChannel?.name == item.title)
        precondition(liveOverlayCurrentProgram?.title == item.title)
        precondition(liveOverlayCurrentProgram?.imageURL == item.posterURL)
        precondition(liveOverlayNextProgram == nil)
        precondition(liveOverlayCurrentProgram?.endDate == nil, "No fabricated EPG end time")
    }
}\n'''
    return text

def route_fixture():
    router=(ROOT/'Sources/MediaFlowProxyRouter.swift').read_text()
    return 'import Foundation\n'+block(router,'enum MediaFlowProxyRouteKind:')+'\n'+block(router,'struct MediaFlowProxySnapshot:')+'''
enum SignalMediaFlowSafetyPolicy {
    static func protects(vod: Bool, url: URL?, enabled: Bool) -> Bool { vod && enabled }
}
enum SignalProtectedNetworkState {
    static func isHome(_ config: MediaFlowProxySnapshot, light: Bool) -> Bool { false }
}
enum MediaFlowProxyRouter {
    static let usesLight = false
    static let config = MediaFlowProxySnapshot(enabled: true, proxyURLString: "https://proxy.example", apiPassword: "fixture", publicIPOverride: "203.0.113.1", webBrowserPlayback: false)
    static func snapshot() -> MediaFlowProxySnapshot { config }
    static func enabledCopy(_ config: MediaFlowProxySnapshot) -> MediaFlowProxySnapshot { config }
'''+block(router,'    static func routingSnapshot(')+'\n}\n'

def main():
    args=argparse.ArgumentParser();args.add_argument('--emit',type=Path);a=args.parse_args()
    if a.emit:
        a.emit.mkdir(parents=True,exist_ok=True)
        (a.emit/'Metadata.swift').write_text(metadata_fixture());(a.emit/'Routing.swift').write_text(route_fixture());return
    if platform.system()!='Darwin' or not shutil.which('xcrun'):
        raise SystemExit('F87 native Unity/Sports checks require Xcode; not run')
    with tempfile.TemporaryDirectory(prefix='signal-f87-') as tmp:
        folder=Path(tmp);meta=folder/'Metadata.swift';route=folder/'Routing.swift';checks=folder/'Checks.swift';exe=folder/'tests'
        meta.write_text(metadata_fixture());route.write_text(route_fixture())
        checks.write_text('''import Foundation
@main struct Checks {
    @MainActor static func main() {
        for height in [1.0, 720, 1080, 2160, Double.nan, Double.infinity] {
            let stops = SignalUnityDashboardShadePolicy.headerStops(height: height)
            precondition(stops.clear.isFinite && stops.opaque.isFinite && stops.clear >= 0 && stops.opaque > stops.clear && stops.opaque <= 1)
        }
        precondition(SignalUnityDashboardShadePolicy.normalizedSportsStyle("invalid") == "Dimmed Dashboard")
        for host in ["chatgpt.hereisman.net", "red.malek5.space", "pl.playlist5.space", "pl.whywelove1.space", "a.newvegan3.space"] {
            let url = URL(string: "https://" + host + "/playlist/1/load-playlist")!
            precondition(!MediaFlowProxyRouter.routingSnapshot(kind: .liveTV, sourceURL: url).enabled)
            precondition(MediaFlowProxyRouter.routingSnapshot(kind: .vod, sourceURL: url).enabled, "No VOD/debrid exemption")
        }
        for raw in ["http://chatgpt.hereisman.net/playlist/1", "https://hereisman.net.evil/playlist/1", "https://u:p@chatgpt.hereisman.net/playlist/1", "https://chatgpt.hereisman.net:8443/playlist/1", "https://real-debrid.com/file", "https://iptv.example/channel"] {
            precondition(MediaFlowProxyRouter.routingSnapshot(kind: .liveTV, sourceURL: URL(string: raw)!).enabled)
        }
        let item = MediaItem(id: "live-sports-web:/watch/test/1", title: "Away vs Home", year: "In Progress", type: "live", catalog: "iSportsurge", description: "NCAA", genres: ["Sports"], rating: "Live", posterURL: "https://cdn.example/team.webp", landscapeURL: nil, logoURL: nil)
        SportsMetadataFixture(item: item).auditSports()
        print("F87 native actual policy/metadata PASS: clear header geometry, known media live-only device egress, no VOD/ordinary IPTV bypass, real event artwork and no unrelated station/EPG data")
    }
}
''')
        shade=ROOT/'Sources/SignalUnityDashboardShade.swift'
        subprocess.run(['swiftc','-swift-version','5','-parse-as-library','-target',platform.machine()+'-apple-macos14.0',str(shade),str(meta),str(route),str(checks),'-o',str(exe)],check=True,timeout=120)
        subprocess.run([str(exe)],check=True,timeout=20)
        sdk=subprocess.check_output(['xcrun','--sdk','appletvos','--show-sdk-path'],text=True).strip()
        subprocess.run(['xcrun','--sdk','appletvos','swiftc','-swift-version','5','-typecheck','-sdk',sdk,'-target','arm64-apple-tvos18.0',str(shade),str(meta)],check=True,timeout=60)
    print('F87 actual shade/live metadata tvOS SDK typecheck PASS. Full app/device playback separate.')
if __name__=='__main__':main()
