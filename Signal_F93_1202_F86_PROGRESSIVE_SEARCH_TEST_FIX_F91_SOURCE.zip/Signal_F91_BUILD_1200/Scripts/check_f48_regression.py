#!/usr/bin/env python3
"""F48 scope/safety guards. Native router tests and device validation are separate."""
from pathlib import Path
import hashlib,json,re
from check_f31_top_menu_regression import block
from f48_approved_deltas import previous_source
from f49_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def verify():
    for name,record in json.loads(historical_source(ROOT/'Tests/F48ApprovedSourceDeltas.json')).items():
        text=historical_source(ROOT/name)
        assert hashlib.sha256(text.encode()).hexdigest()==record['after_sha256'],name
        previous_source(text,name)
    for name,sha in json.loads(historical_source(ROOT/'Tests/F48UnchangedSourceHashes.json')).items():
        assert hashlib.sha256(historical_source(ROOT/name).encode()).hexdigest()==sha,name
    app=historical_source(ROOT/'Sources/DebridChannelsTVOSApp.swift')
    old=previous_source(app,'Sources/DebridChannelsTVOSApp.swift')
    # Search/TV overlays, Up Next and all existing engine ownership stay intact.
    assert block(app,'struct VODPlayerScreen: View')==block(old,'struct VODPlayerScreen: View')
    assert block(app,'struct GlobalSearchScreen: View')==block(old,'struct GlobalSearchScreen: View')
    host=block(app,'private struct LiveTVGridFocusMotionHost<Content: View>')
    assert 'SignalLiveTVCardMotion.scale(focused: isFocused' in host
    assert 'SignalLiveTVCardMotion.lift(focused: isFocused' in host
    assert 'focused: isFocused || showsStylePose' in host
    assert 'transaction.disablesAnimations = reduceMotion' in host
    assert 'transaction.animation = nil' in host
    assert host.index('transaction.animation = nil')<host.index('.scaleEffect(')
    assert host.index('transaction.disablesAnimations = reduceMotion')>host.index('.animation(')
    for forbidden in ('Timer(', 'Task.sleep', 'repeatForever', '.spring(', '.blur(', '.drawingGroup('):
        assert forbidden not in host
    live=block(app,'struct LiveTVScreen: View')
    tile=block(live,'    private func liveTile(')
    assert 'showsStylePose: customizationPreview != nil' in tile
    assert 'isFocused: isFocused' in tile and 'previewURL: gridPreviewURL' in tile
    assert 'customizationPreview != nil && channel.id == liveTVGridPageChannels.first?.id' in tile
    assert 'private var liveTVGridPageSize: Int { 12 }' in live
    effect=historical_source(ROOT/'Sources/SignalLiveTVCardEffect.swift')
    pose=block(effect,'    static func pose(')
    assert 'basePose(baseName(raw), column: column, focused: true)' in pose
    assert 'fixed.x = 0; fixed.y = 0' in pose
    assert 'preview ? 1.03 : 1.018' in effect
    policy=historical_source(ROOT/'Sources/SignalMediaFlowSafetyPolicy.swift')
    assert 'as? Bool ?? true' in policy and 'if vod { return true }' in policy
    router=historical_source(ROOT/'Sources/MediaFlowProxyRouter.swift')
    for marker in ('    static func playbackURLIfAllowed(', '    static func forwardRequestIfAllowed(', '    static func liveTVBootstrapRequestsIfAllowed('):
        body=block(router,marker)
        assert body.index('safetyError(')<body.index('guard shouldProxy('),marker
    proof=block(router,'    static func testConnection(')
    assert 'if snapshot() == tested, usesLight == testingLight' in proof
    assert 'success: result.success' in proof
    assert 'requireVerifiedEgress: false' in block(router,'    func refresh(')
    assert 'clearEgressProof()' in block(router,'    func markConfigurationChanged(')
    assert 'clearEgressProof()' in block(router,'    private func setDisabled(')
    assert 'url.scheme?.lowercased() == baseURL.scheme?.lowercased()' in router
    assert 'url.port ??' in router and 'path == prefix + $0' in router
    catalog=historical_source(ROOT/'Sources/CatalogStore.swift')
    start=block(catalog,'    func startPlayback(')
    assert start.index('MediaFlowProxyRouter.configurationError')<start.index('let nextPresentationID')
    assert start.index('MediaFlowProxyRouter.playbackURLIfAllowed')<start.index('releaseAll(reason:')
    preflight=block(catalog,'    private func quickPlaybackPreflight(')
    assert 'MediaFlowProxyRouter.playbackURLIfAllowed' in preflight
    assert catalog.count('MediaFlowProxyRouter.forwardRequestIfAllowed(')==4
    health=historical_source(ROOT/'Sources/ConnectedServicesHealthClient.swift')
    assert 'guard let routed = MediaFlowProxyRouter.forwardRequestIfAllowed(request)' in health
    registry=historical_source(ROOT/'Sources/SignalPortableSettings.swift')
    assert '"signalRequireMediaFlowForVODV1": true' in registry
    coverage=json.loads(historical_source(ROOT/'Tests/F42SettingsCoverage.json'))
    assert 'signalRequireMediaFlowForVODV1' in coverage['portable']
    observed=set()
    for p in (ROOT/'Sources').rglob('*.swift'):
        observed.update(re.findall(r'@AppStorage\("([^"\\]+)"\)',historical_source(p)))
    assert observed<=set(coverage['portable'])|set(coverage['excluded'])
    assert 'Sources/SignalMediaFlowSafetyPolicy.swift' in historical_source(ROOT/'project.yml')
    assert 'check_f48_native_safety.py' in historical_source(ROOT/'Scripts/check_f28_source_preflight.sh')
    print('F48 PASS: independent default-on VOD lock; exact proxy identity/IP proof; pre-launch rejection; backup coverage; aligned focus pop; all-card customization pose; player/Search/Up Next unchanged')
if __name__=='__main__':verify()
