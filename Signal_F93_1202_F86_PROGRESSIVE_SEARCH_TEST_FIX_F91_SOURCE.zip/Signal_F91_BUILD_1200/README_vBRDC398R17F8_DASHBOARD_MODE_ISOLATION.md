# vBRDC398R17F8 — Live TV dashboard mutual-exclusion hardening

Based strictly on vBRDC398R17F7. Both Golden and Preview Mirror remain selectable.

Source audit: `liveTVUnifiedBrowseSurface` already uses exclusive conditional branches for Golden vs Mirror header, footer, and Golden quick rail. Thus two full chrome trees are not intentionally mounted together in the normal grid mode. Shared LiveTVScreen, guide, provider model, and channel art are common infrastructure, not duplicate dashboard engines.

Fixes:
- Switching in either direction cancels Preview Mirror's delayed menu hint task, clears its hint and category/footer focus, and closes Golden quick rail and its focus handoff state.
- Explicitly cancels the grid focus preview during mode change to prevent outgoing-mode preview work from lingering.
- When Mirror header unmounts (switch to Golden or Guide), cancels its menu-hint task and clears the hint.
- Scheduling the hint now clears the previous task handle after cancellation.

Regression locks: Do not remove either dashboard; preserve shared provider refresh, guide, favorites, channel focus, Preview Mirror top navigation, and Golden quick rail when selected.

Validation: Swift frontend parse succeeds. No tvOS Xcode build or device Instruments profile was available. Remaining performance work: profile artwork loaders, preview session ownership, and shared asynchronous tasks with Instruments during repeated Golden↔Mirror switches. No claim that all background resource usage is eliminated.
