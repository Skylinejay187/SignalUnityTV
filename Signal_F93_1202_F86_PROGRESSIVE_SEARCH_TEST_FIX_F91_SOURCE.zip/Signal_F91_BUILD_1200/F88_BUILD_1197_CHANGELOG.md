# Signal F88 / Build 1197 — targeted patch on F87 1196

Source is based on `Signal_F87_1196_UNITY_SHARED_DASHBOARD_SPORTS_LIVE_PLAYER_SOURCE.zip`. The entire source and build workflow are retained.

1. Remove the synthetic `Sports Playback Test` from the actual Sports catalog. Keep the legacy USC resolution test fixture solely inside `Tests/SignalF85SportsTests.swift`. Reset the browsing surface to row one on a fresh entry, while retaining playback dismissal selection restoration.
2. Add Sports-only `Regular Catalog` (default) / `3D Cover Flow` setting. Regular mode uses existing fixed-preview rail bypass and does not alter Movies/Shows `vodCatalogLayoutV399`. Add the new setting to the portable backup registry.
3. Replace the multi-layer shared Unity shade with one *static* gradient. Artwork 3 Hero uses 0.075–0.135 black opacity and no blur/material/animation. Existing backdrop artwork and transparent UI remain untouched. This explicitly avoids rebuilding an expensive multi-layer shader tree on scrolling or trailer playback.
4. Show optional top-left Signal wordmark only in Settings. Existing Preview Mirror header branding is unchanged.
5. Expand IPTV organizer into two independently scrollable columns within a wider sheet; distinguish titles not loaded from zero matches; save selection and dismiss immediately instead of keeping the dialog disabled while provider refresh completes. No stored credentials are altered.
6. Preserve the last-known-good lineup during cold restore. A missing initial IPTV revision stamp is no longer treated as a real provider-scope edit that clears cached Live TV lineup.

## Verification and limitations

`swiftc -frontend -parse Sources/*.swift` passes; available Linux environment cannot compile or launch the actual Apple tvOS app. F88 tests and portable-settings registry tests pass. Final device verification is required for Live TV cold start, organizer provider refresh, Sports focus, dimming and GPU frame pacing.

## Build/restore caution

No forced reset of saved Xtream accounts, M3U credentials or guide caches is introduced. Test with existing configuration first. If a source disappears, inspect logs and saved provider selections before clearing or restoring backup.
