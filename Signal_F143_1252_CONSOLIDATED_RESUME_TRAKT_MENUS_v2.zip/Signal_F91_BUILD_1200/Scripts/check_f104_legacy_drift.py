#!/usr/bin/env python3
"""Run immutable vBRDC075 contracts and classify only known obsolete assertions.
Never converts legacy failures to passing results; unexpected failures are fatal.
"""
from pathlib import Path
import subprocess, re, sys
root=Path(__file__).resolve().parents[1]
p=subprocess.run([sys.executable,'validation_vBRDC075/test_vBRDC075_contract.py'],cwd=root,text=True,capture_output=True,timeout=60)
output=p.stdout+'\n'+p.stderr
failed=set(re.findall(r'^FAIL: (test_\d+_[^ ]+)',output,re.M))
errors=set(re.findall(r'^ERROR: (test_\d+_[^ ]+)',output,re.M))
expected={'test_01_version','test_15_top_left_logo_toggle_is_persistent_and_controls_wordmark','test_22_resume_and_ksplayer_locked_donor_hashes'}
report=['F104 LEGACY CONTRACT DRIFT AUDIT','Legacy vBRDC075 remains unchanged; no historical checks were disabled.','',f'Legacy exit status: {p.returncode}',f'Observed failures: {len(failed)}; errors: {len(errors)}']
for test in sorted(failed):
    report.append(('KNOWN HISTORICAL DRIFT: ' if test in expected else 'UNEXPECTED FAILURE: ')+test)
report.append('')
report.append('Known drift is NOT a pass and does NOT establish runtime compatibility.')
report.append('Modern F104 contracts and F103 protected-file baseline are checked separately.')
report.append('Any unexpected failure/error is a hard release gate.')
report.append('')
report.append('Legacy suite summary: '+next((s for s in output.splitlines() if s.startswith('Ran ')),'not found'))
(root/'F104_LEGACY_DRIFT_AUDIT.txt').write_text('\n'.join(report)+'\n')
print('\n'.join(report))
sys.exit(0 if failed==expected and not errors else 1)
