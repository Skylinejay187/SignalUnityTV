#!/usr/bin/env python3
"""Execute the actual model cache/projection methods using small schedule/channel doubles."""
from pathlib import Path
import argparse,subprocess,tempfile,shutil
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]
def fixture():
    app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    fields=app[app.index('    private let resolvedGuideRows ='):app.index('    private let liveGuideDurationSeconds =')]
    source='''import Foundation
struct LiveTVChannel: Hashable {
    let id: Int
    var number = ""
    var name = ""
}
struct LiveProgram {
    let id: UInt64
    let startDate: Date?
    let endDate: Date?
    var hasRealTiming: Bool { startDate != nil && endDate != nil }
}
@MainActor final class GuideFixture {
    static var sessionSnapshotVersion: UInt64 = 0
    var currentProgramCache: [Int: Int] = [:]
    var rows: [LiveProgram] = []
    var indexedRows: [LiveProgram]?
    var resolutions = 0
    func resolveProgramsUncached(for channel: LiveTVChannel) -> [LiveProgram] { resolutions += 1; return rows }
    private func cachedIndexedGuide(for channel: LiveTVChannel) -> [LiveProgram]? { indexedRows }
'''+fields+block(app,'    func programs(for channel:')+'\n'
    source+=block(app,'    private func sortedLineup(').replace('private func','func',1)+'\n'
    source+=block(app,'    private func channelSortKey(')+'''

    func replace(_ programs: [LiveProgram]) { rows = programs; invalidateGuideDerivedMetadata() }
}
@main struct F68GuideTest {
    @MainActor static func main() {
        let global = UserDefaults.standard, saved = global.object(forKey:"metadataCacheEnabledV1")
        global.set(true,forKey:"metadataCacheEnabledV1")
        defer { if let saved { global.set(saved,forKey:"metadataCacheEnabledV1") } else { global.removeObject(forKey:"metadataCacheEnabledV1") } }
        let model = GuideFixture(), channel = LiveTVChannel(id: 1)
        let unsorted = [
            LiveTVChannel(id: 1, number: "10", name: "Ten"),
            LiveTVChannel(id: 2, number: "2.1", name: "Zulu"),
            LiveTVChannel(id: 3, number: "Unknown", name: "Unnumbered"),
            LiveTVChannel(id: 4, number: "2.1", name: "Alpha"),
            LiveTVChannel(id: 5, number: "2", name: "Two")
        ]
        let sortedIDs = model.sortedLineup(unsorted).map { $0.id }
        precondition(sortedIDs == [5,4,2,1,3], "Lineup order must use numeric channel and then station name")
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        let axis = SignalGuideTimeline(now: now, width: 1400)
        model.rows = [LiveProgram(id:1,startDate:axis.start,endDate:axis.start.addingTimeInterval(1800))]
        for _ in 0..<100 {
            let row = model.timelineMetadata(for:channel,axis:axis)
            precondition(row.programs.count==1 && row.hasRealTiming && row.slots.first?.id==1)
        }
        precondition(model.resolutions==1,"Repeated focus/redraw must reuse resolved guide metadata")
        let wide = SignalGuideTimeline(now: now,width:1800)
        let before = model.timelineMetadata(for:channel,axis:axis)
        let after = model.timelineMetadata(for:channel,axis:wide)
        precondition(before.slots != after.slots && model.resolutions==1,"Width changes must reproject existing rows")
        model.replace([LiveProgram(id:2,startDate:axis.start,endDate:axis.start.addingTimeInterval(2400))])
        precondition(model.timelineMetadata(for:channel,axis:axis).slots.first?.id==2 && model.resolutions==2)
        model.rows = [LiveProgram(id:3,startDate:axis.start,endDate:axis.start.addingTimeInterval(3000))]
        GuideFixture.sessionSnapshotVersion &+= 1
        precondition(model.timelineMetadata(for:channel,axis:axis).slots.first?.id==3 && model.resolutions==3,"Retained-session guide changes must invalidate derived rows")
        SignalGuideMetadataCacheControl.clear()
        _ = model.timelineMetadata(for:channel,axis:axis)
        precondition(model.resolutions==4,"Clear metadata must release retained guide projections")
        global.set(false,forKey:"metadataCacheEnabledV1")
        _ = model.timelineMetadata(for:channel,axis:axis); _ = model.timelineMetadata(for:channel,axis:axis)
        precondition(model.resolutions==6,"Disabled metadata caching must bypass Guide reuse")
        global.set(true,forKey:"metadataCacheEnabledV1")
        model.indexedRows = [LiveProgram(id:4,startDate:axis.start,endDate:axis.start.addingTimeInterval(3600))]
        precondition(model.programs(for:channel).first?.id==3,"Timed in-memory listings take priority")
        model.replace([LiveProgram(id:5,startDate:nil,endDate:nil)])
        precondition(model.programs(for:channel).first?.id==4,"Indexed listings must replace untimed placeholders")
        print("F68 actual EPG model methods PASS: scrolling reuse, resized axis, fresh listings, retained-session invalidation and indexed fallback")
    }
}
'''
    return source

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--emit',type=Path);args=parser.parse_args()
    if args.emit:args.emit.write_text(fixture());return
    if not shutil.which('swiftc'):raise SystemExit('Swift compiler required for actual EPG model cache tests')
    with tempfile.TemporaryDirectory(prefix='signal-f68-') as directory:
        path=Path(directory)/'GuideFixture.swift';path.write_text(fixture());exe=Path(directory)/'guide-tests'
        subprocess.run(['swiftc','-swift-version','5',str(ROOT/'Sources/SignalGuideMetadataCache.swift'),str(ROOT/'Sources/SignalGuideTimeline.swift'),str(path),'-o',str(exe)],check=True,timeout=90)
        subprocess.run([str(exe)],check=True,timeout=15)
if __name__=='__main__':main()
