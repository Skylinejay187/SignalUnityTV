from pathlib import Path
import hashlib,json
from check_f31_top_menu_regression import block
from source_hash_integrity import verify_unchanged_sources
from f83_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
def audit(app,store,core,view,model):
 for marker, method in [
  ('    private func loadXtream(server:', 'entries'),
  ('    private func loadM3U(url:', 'livePlaylist')
 ]:
  source=block(app,marker)
  assert 'selection.mode.includesLive' in source and 'SignalIPTVRepository.shared.'+method in source
  assert 'selection: selection, forceRefresh: forceRefresh' in source
 playlist=block(core,'    func livePlaylist(')
 assert 'selection.allows(kind: .live, category: $0.categoryID, id: $0.id)' in playlist
 assert 'Self.playlistGuideURLs(text, base: url)' in playlist
 assert 'forceRefresh: forceRefresh' in playlist
 sports=block(app,'struct SportsHubScreen: View')
 assert 'rows: onlineSports.rows' in sports
 assert 'sportsFoundationRows' not in sports and 'allowImportedSports: true' not in sports
 legacy_sports=block(app,'    private func loadSportsOnlyXtreamChannels(')
 assert 'selection.mode.includesSports' in legacy_sports and 'selection.sports(row)' in legacy_sports
 assert 'streamURL: row.url' in legacy_sports
 assert 'allowImportedSports: Bool = false' in app and 'guard enabled else { return [] }' in legacy_sports
 assert 'cachedRealAmbientChannels(limit: 600)' not in app
 assert 'for channel in channels.prefix(600)' not in model
 assert 'Task.detached' in model and 'filterTask.cancel()' in model and 'owner == refreshGeneration' in model
 assert '"ON AIR"' in model and 'streamURL.hashValue' not in model
 assert 'SignalIPTVImportView {' in app and 'await liveImportModel.applyIPTVImportSelectionChange()' in app
 assert 'SignalIPTVImport.save(draft, for: source)' in view and 'await onApply()' in view
 assert 'selection.mode.includesVOD' in block(store,'    private func findXtreamVODLinks(')
 assert 'SignalIPTVRepository.shared.episodes' in block(store,'    func fetchSeriesEpisodes(')
 assert 'iptvImportedRows' in block(store,'    private func prioritizedRowsForDisplay(')
 assert 'scheduleIPTVCatalogRefresh()' in block(store,'    func loadAllManifests(')
 for text in ['explicitly empty array means none', 'percentEncodedQuery', 'Task.checkCancellation()', 'data.count <= 48', '.atomic', '64 * 1024 * 1024']:
  # Byte limit applies to result/attributes, not the old data buffer spelling.
  if text=='data.count <= 48':assert 'result.count <= 48' in core
  else:assert text in core,text
 assert 'row.tmdb' in core and 'titleKey(row.name) == titleKey(title)' in core
 assert 'sources == SignalIPTVImport.sources()' in store
app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text();store=(ROOT/'Sources/CatalogStore.swift').read_text()
core=(ROOT/'Sources/SignalIPTVImport.swift').read_text();view=historical_source(ROOT/'Sources/SignalIPTVImportView.swift');model=(ROOT/'Sources/SportsCenterViewModel.swift').read_text()
audit(app,store,core,view,model)
for old,new in [('selection.mode.includesLive','true'),('selection.mode.includesSports','false'),('selection.sports(row)','true'),('rows: onlineSports.rows','rows: sportsFoundationRows()')]:
 try:audit(app.replace(old,new),store,core,view,model)
 except (AssertionError,ValueError):pass
 else:raise AssertionError('Disabled extraction mutation was accepted: '+old)
try:
 audit(app,store,core.replace('selection.allows(kind: .live, category: $0.categoryID, id: $0.id)', 'true'),view,model)
except AssertionError:pass
else:raise AssertionError('M3U selection bypass was accepted')
for path,record in json.loads((ROOT/'Tests/F82ApprovedSourceDeltas.json').read_text()).items():
 assert hashlib.sha256(historical_source(ROOT/path).encode()).hexdigest()==record['after_sha256'],path
for path,digest in json.loads((ROOT/'Tests/F82NewSourceHashes.json').read_text()).items():
 assert hashlib.sha256(historical_source(ROOT/path).encode()).hexdigest()==digest,path
verify_unchanged_sources(ROOT,json.loads((ROOT/'Tests/F82UnchangedSourceHashes.json').read_text()),historical_source)
assert '"iptvImportSelectionsV1": "{}"' in (ROOT/'Sources/SignalPortableSettings.swift').read_text()
print('F82 current extraction/organizer/catalog/Sports wiring and source scope PASS; five routing mutations rejected. Native/SDK/device checks separate.')
