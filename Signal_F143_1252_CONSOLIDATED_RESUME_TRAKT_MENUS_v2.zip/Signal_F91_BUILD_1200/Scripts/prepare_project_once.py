#!/usr/bin/env python3
"""Reuse only successful validation of unchanged local inputs and bound preparation."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,tempfile,time
root=Path(__file__).resolve().parents[1]
stamp=root/'.build-cache'/'successful-source-preflight.json'
def fingerprint():
    digest=hashlib.sha256()
    for directory in ('Sources','Tests','Scripts','Resources','EnginePatches','TopShelfExtension'):
        for path in sorted((root/directory).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                digest.update(path.relative_to(root).as_posix().encode())
                digest.update(path.read_bytes())
    digest.update((root/'project.yml').read_bytes())
    return digest.hexdigest()
if sys.argv[1:] == ['--record']:
    stamp.parent.mkdir(parents=True,exist_ok=True)
    stamp.write_text(json.dumps({'fingerprint':fingerprint(),'time':time.time()}))
    sys.exit(0)
valid=False
try:
    receipt=json.loads(stamp.read_text())
    valid=0 <= time.time()-receipt['time'] < 3600 and receipt['fingerprint']==fingerprint()
except (OSError,ValueError,KeyError):
    pass
preflight=(root/'Scripts/check_f28_source_preflight.sh').read_text().splitlines()
completed={line.strip() for line in preflight if line.strip().startswith('python3 ')} if valid else set()
script=(root/'Scripts/prepare_build_deps_vBRDC280.sh').read_text().splitlines()
# The validated path already parsed these Swift sources. Xcode compiles
# Assets.xcassets in the target's normal resource phase. Keep the standalone
# syntax/asset probes for local generation without a matching receipt.
if valid:
    begin = script.index('mkdir -p .build-cache/actool-preflight')
    end = script.index('bash Scripts/fetch_aether_f28_744.sh')
    if begin >= end:
        raise SystemExit('Unexpected project preparation script layout')
    script[begin:end] = [
        'echo "Source syntax already checked. Xcode will compile the asset catalog during the app build."'
    ]

lines=[];seen=set();reused=0
for line in script:
    command=line.strip()
    if command.startswith('python3 ') and (command in completed or command in seen):
        reused+=1
        continue
    if command.startswith('python3 '):
        seen.add(command)
    lines.append(line)

# Remaining SDK regression checks may build macOS, tvOS and iOS fixtures.
# Give a cold runner time for those checks while keeping a hard upper bound.
timeout_seconds = 20 * 60
print(f'Project preparation. Reused {reused} completed checks. Limit 20 minutes.',flush=True)
# Inherit the workflow log streams so Bash prints each command when it starts.
with tempfile.NamedTemporaryFile(mode='w',suffix='.sh',prefix='.prepare-',
                                 dir=root/'Scripts',delete=False) as temporary:
    temporary.write(chr(10).join(lines) + chr(10))
try:
    process=subprocess.Popen(['bash','-ex',temporary.name],cwd=root,start_new_session=True)
    try:
        status=process.wait(timeout=timeout_seconds)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait()
        print('Project preparation exceeded 20 minutes. See the last traced command above.',flush=True)
        status=124
finally:
    Path(temporary.name).unlink(missing_ok=True)
sys.exit(status)
