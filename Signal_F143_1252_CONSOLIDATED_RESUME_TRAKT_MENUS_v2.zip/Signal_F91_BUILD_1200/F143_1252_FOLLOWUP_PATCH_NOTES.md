# F143 / 1252 follow-up patch

Based on Signal_F143_1252_Guide_Artwork_SourceMemory_PATCH.zip.

## Implemented
- VOD amplification resets to Off on real player exit. Internal failover handoffs retain the current gain until actual exit. Live TV unaffected.
- Pure Black/artwork-free catalog background gets a lightweight static cinema accent for Media Information and title contrast, with no masking/video/timer work.
- Full Guide gains a static midnight broadcast backdrop and a framed information area to the right of the existing left video preview.
- Removed duplicate sports score badges from the guide schedule header, retaining the logo-enhanced hero scoreboard and reducing duplicated image views.

## Diagnostics and remaining work
- Aether currently represents VOD cache selection with forwardBufferSegments. It refreshes the producer frontier at 4 Hz; this reports progress but does not prove disk write/read reliability. The engine internals are not included as editable source in this ZIP. Cache stalls need Aether logs and real-device tests; no unverified cache fix is claimed.
- A complete multi-actor trailer/preview playback audit needs tvOS runtime profiling and further source-level regression testing; no wholesale preview changes were made to avoid regressions.
- Swift syntax parsed on Linux; full tvOS compilation and playback tests require Xcode/GitHub Actions.
