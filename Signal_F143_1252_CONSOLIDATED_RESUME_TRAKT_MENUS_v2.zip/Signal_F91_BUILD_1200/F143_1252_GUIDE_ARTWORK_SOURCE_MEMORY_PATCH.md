# Signal F143 / build 1252 — targeted tvOS patch (2026-11-22)

## Applied source changes
- Removed the legacy hidden-VOD-overlay cancellation of cast, Spotlight, and poster network requests. Resource caps and true background/navigation cancellation remain.
- Fixed source-memory order at the VOD source panel: an exactly remembered playable link stays at the top instead of being rebalanced away by Source Intelligence. Stored source preference remains episode-specific for television, with per-series audio/subtitle language preferences unchanged.
- Corrected autoplay fast-start: when a remembered exact source exists, do not launch the first random partial search result before that source has had time to arrive. Once completed, unavailable remembered sources still fall back to playable links. Up Next also preserves exact episode source priority ahead of provider balancing.
- Moved Full Guide's **existing** live player surface from upper-right to upper-left; kept a single decoder rather than adding a second preview player.
- Reworked Full Guide live/final/upcoming scoreboard cards to show provider-supplied team logos, scores, league/status and gradient-glass chrome. Does not synthesize scores/logos if absent.
- Added **Open Channel in Full Guide** setting under Live TV Sources (default OFF). Selecting a live-grid card starts its stream as normal; player opens its built-in Full Guide on launch if enabled. OFF preserves fullscreen startup. This is distinct from Launch App in Guide.
- Added backup/restore persistence for the new guide-launch setting.

## Static checks
- `swiftc -frontend -parse` PASS for all modified Swift files (including CatalogStore.swift).
- No tvOS/Xcode build or Apple TV runtime test available in this Linux environment.

## Not yet resolved / needs targeted runtime validation
- VOD cache progress stalls or bursts: app hands `configuredVODCachePolicy` to Aether; this package does not alter Aether's buffering/range-cache engine. Collect player progress and native cache logs on affected links before claiming a fix.
- Full app-wide decoder concurrency audit and theme-specific Pure Black media-info/title art enhancement require profiling/visual tests. Changes here are limited to verified, localized defects.
- Exact remembered link persists only while returned by the source provider. When links expire or disappear, existing fallback logic still selects an available source; it cannot replay an expired signed URL.

## Regression locks
- Existing Unity architecture, Aether single playback, Live TV timeshift, video cache controls, subtitle behavior, 3D Cover Flow, and trailer display-mode policies untouched.
