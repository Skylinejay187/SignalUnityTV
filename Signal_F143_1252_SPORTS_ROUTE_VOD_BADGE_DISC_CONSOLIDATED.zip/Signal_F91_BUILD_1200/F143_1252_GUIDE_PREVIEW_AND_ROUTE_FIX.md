# F143 / 1252 — Full Guide preview and channel-switch regression

## Corrected
- The guide's opaque gradient background was rendered above its only live video surface and hid the video slot. The background now has an even-odd transparent cutout over the scaled live player, preserving one decoder.
- Auto-open Full Guide now applies only to a fresh grid launch. Channel changes initiated from Quick Guide or Full Guide carry an explicit `guide selection` playback label, so their replacement playback remains fullscreen.

## Static verification
- F143 exact reviewed-source hash manifest updated for the changed app file.
- `Scripts/check_f28_source_preflight.sh` passes (Swift parse, membership, bridge parity and current F143 manifest).

## Important remaining runtime investigation
- The package contains only the Aether 7.44 placeholder/install bootstrap, not the engine runtime source or on-device cache telemetry. No cache-stall root cause or verified fix is claimed.
- Decoder release coordination remains in place; exhaustive simultaneous trailer/catalog/Live preview validation requires tvOS instrumentation and real playback sessions.
- The visual video cutout and route behavior still require an actual Apple TV run for layout and focus verification.
