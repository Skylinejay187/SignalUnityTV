# Signal F143 — Live TV aligned row reference correction

- Based on the tested Settings-lifecycle/Ethernet Apple TV crash-fix source, without modifying Settings.
- Existing ` · Aligned` preference remains valid, now labeled **Aligned — Top Row**.
- New selectable **Aligned — Bottom Row** is stored as ` · Aligned Bottom` in the existing effect setting. No migrations or backup changes needed.
- Full-screen customization preview cycles Original → Aligned Top → Aligned Bottom → Original.
- The 4-column card pose repeats unaltered in all three grid rows; the top and bottom variants use matching ±2.5° perspective pitch rather than changing direction by row or focus.
- Kept existing nonaligned layouts, split/outward/inward yaw strength, card focus/scrolling, settings, and playback behavior.
- Previously selected Aligned effects remain accepted; unrecognized saved effects still default to Original.

## Validation
`swiftc -frontend -parse` on changed Swift sources; both existing pose / geometry unit programs and new 28-style/top-bottom consistency program; `Scripts/check_f143_reviewed_source.py` with exact updated hashes.

## Device verification pending
GitHub/Xcode tvOS build; Live TV screenshot inspection and focus behavior on both 2022 Apple TV 4K models. No device-level tests were performed here.
