# Signal F143 / 1252 – Sports route and optional VOD visual options

- Automatic Full Guide opening now requires: user setting enabled, a fresh `Live TV route` playback label, originating `.live` Unity tab, and not an online Sports stream. Changing channels from quick/full guide already uses a distinct `guide selection` label; Sports launches must not auto-open Full Guide.
- New optional VOD technical badges: Off (default), Signal Neon, Cinema Silver. Selection in Settings > VOD Overlay; metadata shown only when reported in active source information. Lightweight static typography, no image loads.
- New optional VOD disc peek: Off (default). Static SwiftUI disc behind the left side of the hero poster, rendered only with the VOD overlay. No animation, timer, network fetch, or decoder.
- Both options included in settings export and restore.
- Existing guide video layout setting and preceding consolidated playback fixes retained.

## Verified in this environment
- Swift syntax parse of Sources tree: PASS
- F143 exact reviewed-source hash integrity: PASS (131 files)
- Local source-membership/bridge build preflight: PASS
- No tvOS SDK/Xcode compiler or physical Apple TV tests available in this environment.

## Unresolved / cannot honestly mark fixed
- Intermittent Aether VOD cache progress/download stalls require Aether runtime logging and tests while stalled. Source-level polling does not demonstrate download progress.
- Comprehensive device-level audit of all preview/trailer decoder lifecycle sequences still requires runtime observation.
- Some VOD artwork behavior needs device verification despite past source changes.
