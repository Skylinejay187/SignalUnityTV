from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
app=(root/'Sources/DebridChannelsTVOSApp.swift').read_text()
portable=(root/'Sources/SignalPortableSettings.swift').read_text()
keys=['signalCableBoxModeV1','signalCableBoxMenuBehaviorV1','signalCableBoxMenuDelayV1','signalCableBoxLastPlayedChannelIDV1']
for key in keys:
 assert key in app, f'AppStorage/export/restore missing {key}'
 assert f'"{key}":' in portable, f'Portable backup missing {key}'
 assert app.count(f'"{key}"') >= 2, f'Backup/restore coverage insufficient {key}'
assert '@State private var cableBoxLaunchClaimed = false' in app
assert 'LiveTVScreen(liveModel: liveTVModel, cableBoxLaunchClaimed: $cableBoxLaunchClaimed)' in app
assert 'cableBoxLaunchClaimed.wrappedValue = true' in app
assert 'SignalCableBoxPreferences.eligible(channel)' in app
assert 'store.playbackURL == nil' in app
assert 'private func cableBoxNavigate(to tab: AppTab)' in app
assert 'requestPlayerDismissal()' in app
assert 'unityCore.select(tab, store: store, reason: "Cable Box Unity navigation")' in app
assert 'if isLivePlayback && cableBoxMenuVisible && cableBoxEnabled' in app
assert 'if direction == .up && !livePlaybackFullGuideVisible' in app
assert 'openLivePlaybackFullGuide()' in app
assert 'Press Down for Quick Guide' in app
assert 'signalCableBoxLastPlayedChannelIDV1' in app
assert 'SignalCableBoxPreferences.normalizedMode(rootCableBoxMode) != SignalCableBoxPreferences.cable' in app
print('Cable Box source/backup/Unity regression PASS:',len(keys),'persisted fields')
