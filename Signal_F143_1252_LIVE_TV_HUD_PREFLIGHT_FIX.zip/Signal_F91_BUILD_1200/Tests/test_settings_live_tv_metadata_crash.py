#!/usr/bin/env python3
"""Regression for Apple TV14,1 SIGSEGV in Live TV Settings generic instantiation."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'Sources/DebridChannelsTVOSApp.swift'
s=p.read_text()
a=s.index('    private var liveTVSourcesSection: some View {')
b=s.index('    private var nativeUsenetConnectionSettings:', a)
t=s[a:b]
assert 'LazyVStack(alignment: .leading, spacing: 10)' in t
assert t.count('private var liveTVSourcesChunk')==5
assert t.count('AnyView(VStack(alignment: .leading, spacing: 10)')==5
for i in range(1,6):
    assert f'liveTVSourcesChunk{i}\n' in t
assert 'guideStartupPreferenceCard' in t
assert 'liveTextField("Channels DVR connection"' in t
assert 'xtreamFields' in t
assert 'liveToggleButton(title: "Live TV Card Progress Bar"' in t
assert 'Live TV Card Shape' in t
assert 'Live TV Channel Numbers' in t
assert 'Live TV Grid Layout' in t
assert 'EmptyView() // v436' in t
print('Live TV Settings view segmentation PASS')
