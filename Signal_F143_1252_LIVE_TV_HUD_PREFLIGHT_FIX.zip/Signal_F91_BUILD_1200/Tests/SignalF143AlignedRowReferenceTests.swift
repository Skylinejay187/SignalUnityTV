import Foundation

@main struct SignalF143AlignedRowReferenceTests {
    static func main() {
        for base in SignalLiveTVCardEffect.baseNames {
            let top = base + SignalLiveTVCardEffect.alignedSuffix
            let bottom = base + SignalLiveTVCardEffect.bottomAlignedSuffix
            precondition(SignalLiveTVCardEffect.normalized(top) == top)
            precondition(SignalLiveTVCardEffect.normalized(bottom) == bottom)
            precondition(SignalLiveTVCardEffect.isAligned(top) && SignalLiveTVCardEffect.isAligned(bottom))
            precondition(SignalLiveTVCardEffect.isBottomAligned(bottom) && !SignalLiveTVCardEffect.isBottomAligned(top))
            precondition(SignalLiveTVCardEffect.baseName(top) == base)
            precondition(SignalLiveTVCardEffect.baseName(bottom) == base)
            precondition(SignalLiveTVCardEffect.cyclingLayout(base) == top)
            precondition(SignalLiveTVCardEffect.cyclingLayout(top) == bottom)
            precondition(SignalLiveTVCardEffect.cyclingLayout(bottom) == base)
            for col in 0..<4 {
                let t = SignalLiveTVCardEffect.pose(top, column: col, focused: false)
                let b = SignalLiveTVCardEffect.pose(bottom, column: col, focused: false)
                precondition(t == SignalLiveTVCardEffect.pose(top,column:col,focused:true))
                precondition(b == SignalLiveTVCardEffect.pose(bottom,column:col,focused:true))
                precondition(t.pitch == -2.5 && b.pitch == 2.5)
                precondition(t.yaw == b.yaw)
                precondition(t.x == 0 && t.y == 0 && b.x == 0 && b.y == 0)
                for (w,h) in [(306.0,202.0),(320,210),(480,270)] {
                    for variant in [t,b] {
                        let m = SignalLiveTVCardProjection.uniformlyFitted(pose:variant,width:w,height:h)
                        let corners = [(0.0,0.0),(w,0.0),(0.0,h),(w,h)].map { m.project(x:$0.0,y:$0.1) }
                        precondition(corners.allSatisfy { $0.x.isFinite && $0.y.isFinite })
                        // Identical per-column geometry in each of the 3 rows;
                        // the row is a translation, never a different pitch/yaw.
                        for row in 0..<3 {
                            let dy = Double(row) * (h+23)
                            for (i,corner) in corners.enumerated() {
                                let repeated = m.project(x:[0.0,w,0.0,w][i],y:[0.0,0.0,h,h][i])
                                precondition(abs((corner.y+dy)-(repeated.y+dy)) < 0.00000001)
                            }
                        }
                    }
                }
            }
        }
        precondition(SignalLiveTVCardEffect.normalized("bogus · Aligned Bottom") == "Original")
        print("F143 aligned top/bottom modes PASS: 28 effects; 4 columns; 3 rows; focus invariant; saved values")
    }
}
