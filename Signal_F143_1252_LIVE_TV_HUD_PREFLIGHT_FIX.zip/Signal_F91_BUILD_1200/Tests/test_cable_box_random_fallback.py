from pathlib import Path
s = (Path(__file__).resolve().parents[1]/'Sources/DebridChannelsTVOSApp.swift').read_text()
assert 'let providerChannels = liveModel.channels.filter' in s
assert 'let channel = remembered ?? providerChannels.randomElement()!' in s
assert '!demoIDs.contains(channel.id)' in s
assert 'cableBoxLaunchClaimed.wrappedValue = true' in s
assert 'Awaiting a playable provider lineup' in s
print('Cable Box fallback source regression PASS')
