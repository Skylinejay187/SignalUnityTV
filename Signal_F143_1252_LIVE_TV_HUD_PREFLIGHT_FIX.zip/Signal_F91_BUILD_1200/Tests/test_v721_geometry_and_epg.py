from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'Sources/DebridChannelsTVOSApp.swift').read_text()
checks=[
('left ticket exposure', 'seasonTicketExtended ? -64 : 24'),
('right ticket exposure','seasonTicketExtended ? 112 : 0'),
('disc exposure','discExtended ? -78 : 2'),
('ticket metadata clearance','isSeries && seasonPassStyle == "horizontalRight" ? 122 : 0'),
('DVR coverage','Channels DVR guide verified for'),
('Xtream coverage','Xtream XMLTV guide verified for'),
('M3U coverage','XMLTV #\\(index + 1) guide verified'),
('mirror bypass','if !userInitiatedForce, index == 0'),
('guide retention','saved programs retained')]
for name, fragment in checks:
    assert fragment in s, f'Failed: {name}'
print('v721 geometry + EPG coverage regression assertions PASS:', len(checks))
