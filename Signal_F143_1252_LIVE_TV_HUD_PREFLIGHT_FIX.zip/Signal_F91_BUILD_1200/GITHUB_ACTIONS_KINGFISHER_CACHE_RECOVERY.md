# GitHub Actions Kingfisher SwiftPM cache failure (run 122738816583)

The uploaded build log failed **before app compilation** during Swift Package resolution:

    fatal: cannot change to .../Kingfisher-adb94c78: No such file or directory

The workflow restored a 659 MB cache using a broad `restore-keys` prefix, but the restored SwiftPM metadata expects a repository checkout that is missing. The subsequent artifact-upload errors are secondary.

## Fix in the GitHub repository's universal build workflow (not inside the source ZIP)

Locate `Restore Swift package download cache` and change the cache strategy:

1. Stop using the broad `restore-keys: signal-spm-macos26-intel-` fallback (or rotate to a new cache namespace) so a stale incomplete cache cannot be reused.
2. If recovery is needed, *before* `xcodebuild`, clear just SwiftPM's invalid metadata/checkout on the runner and let Xcode resolve packages cleanly, for example:

```bash
rm -rf "$HOME/Library/Caches/org.swift.swiftpm/repositories/Kingfisher-adb94c78"
rm -rf "$HOME/Library/Caches/org.swift.swiftpm/repositories/Kingfisher-adb94c78.lock"
# Prefer a clean clonedSourcePackagesDirPath per build or a key derived from Package.resolved.
```

Deleting those paths is runner-only cache cleanup; it does not touch Signal's source or NAS.

Recommended robust solution: remove broad restore keys, use an exact cache keyed to OS/Xcode and Package.resolved, and run `xcodebuild -resolvePackageDependencies -project ... -scheme ... -clonedSourcePackagesDirPath ...` before full compile. If an incomplete cache causes a resolution error, retry once with a clean clone directory.

**Important:** The repository's universal workflow runs *before* extracting the uploaded source ZIP; adding changes to `.github/workflows` inside this ZIP alone cannot fix its external cache-restore step.
