# Extended Cache — F143 safe handoff

- Existing `vodDiskCachePolicyV1 = unlimited` is retained for preferences and backup compatibility; Settings displays **Extended Cache (10 GB target)**.
- Auto stays at 160–200 segments, 1 GB = 180, 2 GB = 270, 3 GB = 360.
- Aether 7.44 still receives 10,800 forward-buffer segments in Extended mode. **This does not enforce 10,000,000,000 cached bytes.**
- Avoided an independent side download: the vendor Aether internal cache reader is not included in this source ZIP, so independently downloaded bytes could not be reused by the active player. Duplicate 10GB fetches would waste bandwidth and disk.
- The Diagnostics recorder captures the 10 GB target at selection and the available volume capacity at playback start. No URLs or credentials are logged.
- Complete byte-counted caching requires an Aether-compatible producer/reader protocol: range map, disk reservation, low-space guard, verified bytes, pause/seek priority, session cancellation and eviction. Do not route Aether through an untested HTTP proxy.
- No claim of full-file caching, exact 10 GB downloaded bytes or successful tvOS runtime verification is made by this source change.
