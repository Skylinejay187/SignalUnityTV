# F143/1252 Fanart.tv disc artwork key wiring correction

Root cause: active VODProductionMetadataService.fetch invocation omitted `fanartApiKey`, so its default `""` caused fanartSpecialtyArtwork to return an empty result without making a Fanart.tv request, regardless of configured key.

Changes: pass the existing stored `vodFanartTvApiKey` into both the active VOD and Up Next metadata fetch call sites. The service already handles TMDB movie ID -> Fanart.tv /v3/movies/{tmdbID}, `moviedisc` response decoding, and authentic artwork priority. Alternate TMDB posters and Signal disc fallback remain unchanged.

Verification: static Swift parser, F143 reviewed-source integrity, source preflight. NOT verified: online Fanart.tv calls with user's private key or Apple TV rendering; availability still varies by title and service.
