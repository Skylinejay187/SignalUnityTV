# F143 1252 — Signal TV Season Pass Ticket (tvOS)

Adds a TV-only Season Pass behind the actual VOD Media Info poster. Styles:
- `portraitLeft` (default) — 78×166pt ticket exposed to the left; poster overlays 29pt of the ticket at full extension.
- `horizontalRight` — 148×92pt ticket extends to the right with 35pt of its width beneath the poster.
- `off` — no TV ticket.

The visual is drawn behind the poster using the existing poster `.background(alignment: .leading)`, so there is no extra HStack spacing and the ticket remains visually attached. The artwork in the ticket is drawn from the poster for the selected media item, when present; a dark ticket fallback is always drawn if none is provided. Season numbering tracks `item.seasonNumber`; scene and ticket regenerate/reanimate on a season change.

Settings: Settings > VOD > artwork/disc section > `TV Season Pass`, cycles Portrait Left / Original Horizontal Right / Off. Stored under `signalVODSeasonPassStyleV1`, included in backup/restore settings.

Movies preserve the original `SignalDiscPeekVisual` path unchanged, guarded by `!isSeries`. TV ticket uses separate state and remains independent of movie disc toggle.

Validation: Linux `swiftc -frontend -parse` of full modified app source passed. This does NOT substitute for macOS/Xcode tvOS build and real-device display validation.
