# Signal F37 — Build 1145

Version **1.0.1145**. Patched forward from the complete F36 / 1144 source. Older release notes and reports are retained as history; this document describes the current delivery.

This is a source package. Local source checks passed; **Xcode compilation, installation and physical Siri Remote testing have not been performed** in this Linux workspace. The macOS workflow includes the Swift model tests and unsigned tvOS Release build.

## Quiet preparation, delayed preview reveal

The preview has two separate gates:

1. After the focused card settles for the existing **650 ms**, one Aether decoder loads behind the card's artwork. It is silent and invisible. This keeps quick fly-by cards from opening network/decoder sessions.
2. Only after the same focus has lasted **at least 2.5 seconds**, and Aether has reported a first frame, can the video and audio become visible/audible. The card's preview-specific turn to a front-facing plane, optional Pop Out and optional dimming wait for this reveal too. Normal remote focus styling remains available immediately.

The 2.5 seconds are measured from the focus request using monotonic uptime, not added after loading finishes. A slow source stays on the artwork until it is ready. A fast source remains hidden until the minimum focus hold has elapsed. Reveal reuses the already loaded decoder; it does not reload the source or introduce another player.

The existing first-attempt FastZap and Standard recovery logic are unchanged. The bridge gains a per-instance mute flag through Aether 7.44's public `volume` API, seeded before load/autoplay. Every other playback surface defaults to unmuted. No system volume, track, gain, timeshift or display-match preference is modified.

Moving focus, changing page, opening Guide/Tools or playback, leaving Live TV, or backgrounding the app cancels the preparation/reveal through the existing lifecycle path. The selected finite preview duration bounds preparation; after a successful reveal it restarts once, giving the visible preview its full 15/30/60 seconds. Unlimited retains the existing focus-lifetime behavior.

The mute API was checked against the pinned [AetherEngine 7.44.0 source](https://github.com/superuser404notfound/AetherEngine/blob/7.44.0/Sources/AetherEngine/AetherEngine.swift). Its public volume property retains a pre-session value for the active transport. Both bridge source copies remain identical.

## Easier page edges

When the edge card is focused, **one further outward press** changes to the adjacent page, in either direction. The move that first reaches the edge card remains the stop; there is no additional arming click or 650 ms delay at the edge.

The existing 120 ms duplicate-delivery guard remains. No extra page debounce is stacked on top of it. The 4×3 layout, native interior navigation and row-preserving page destination math are unchanged. First/last page boundaries still clamp. Page-one legacy Live Controls behavior outside Preview Mirror is unchanged.

## Search Focus Spotlight

Appearance now has **Search Focus Spotlight: On / Off**, default On. Focusing Search dims the surrounding screen and lights the real 🔍 icon with an accent rim and broad light pool. It works in either Search placement and independently of the eleven icon effect choices.

The overlay measures the actual icon anchor, including menu size transforms. It does not add another icon, focus target, remote handler or player. It cannot receive input, owns no timer, and disappears when Search loses focus or another screen takes ownership. Reduce Motion disables the short appearance transition; inactive scenes do not show it. The preference is exported, restored, reset and accepted by backup validation.

## Preserved from F36

Native top-menu and Settings focus; fast Aether preview startup; retained artwork and decoded-wallpaper crossfades; flat visible native preview; gentle readiness-gated dimming; 14 independent shapes and 23 motion effects; five Curved Wall strengths; five Glass Atmosphere styles plus Off; eleven Search effects; Pure Black; manual VOD cast navigation; existing playback and Guide behavior.

## Checks and next build

Local checks passed: aligned app/project/Top Shelf identity; six build-identity unit tests; F31–F37 source regression checks; 220 unrelated VOD function locks; reviewed exact source deltas for historical checks; seven redaction cases; remote-thumbnail safety gate; 22 FastZap wiring checks; no new Swift grammar diagnostics relative to F36; workflow/source entries; archive CRC and all-entry source byte comparison.

The new Swift policy test covers fast-ready/hold-pending, hold-elapsed/frame-pending, both-ready, deadline arithmetic, invalid clocks and edge duplicate delivery. It is included in macOS CI but **was not executed locally**. Syntax parsing is not Swift type checking or Xcode compilation.

After the macOS build, test on Apple TV:

1. Move quickly across cards. Artwork and normal focus should remain, with no preview sound, turn, Pop Out or preview dimming before 2.5 seconds.
2. Hold one card. Confirm one smooth reveal at or after 2.5 seconds when ready, without a second tune. Try a slow/buffering source: artwork must remain until a first frame exists.
3. Move away during silent loading, just before reveal and while visible. Open Guide, Tools, catalogs or full-screen playback; background/return. No old preview may reveal or speak afterward.
4. Compare fast Right and Left page changes, partial final pages, row preservation and holding the remote. One press beyond an already focused edge should be sufficient; interior moves and native top-menu scrolling must remain normal.
5. Focus Search in both placements, toggle Search Focus Spotlight Off/On, change icon effects, resize the menu and open/close Search. The dimming must not trap focus or remain over another screen.
6. Confirm full-screen Live TV/VOD still starts with sound, volume amplification is unchanged, and the spotlight setting survives backup/restore.

Runtime smoothness and exact physical remote behavior remain unverified until these device tests are completed.
