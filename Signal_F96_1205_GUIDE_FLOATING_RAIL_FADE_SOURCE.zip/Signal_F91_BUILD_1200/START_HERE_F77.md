# F77 / build 1186

Fixes volume amplification immediately reverting to Off on native VOD routes. The bridge now attempts one guarded transition to decoded audio, applies the latest selected gain, and preserves play/pause intent. Subsequent gain changes and Off remain on the same decoded session. No Live TV or app UI changes.

First enable from native playback may briefly interrupt video/audio and loses Atmos passthrough. Unsupported native-only sources can still refuse the correction with a message. This is not a claim of seamless native gain.

Local source/grammar/identity checks passed. Actual-method native tests were extended and remain required on the macOS build runner; no compiler/SDK or device is available here. See F77_VALIDATION.json. On Apple TV: test Off to +3/+6/+9/+12 during play and pause, Off then re-enable, rapid clicks, seek/exit during correction, native-only refusal, background return, subtitles and protected sources. Verify audible gain and position continuity.
