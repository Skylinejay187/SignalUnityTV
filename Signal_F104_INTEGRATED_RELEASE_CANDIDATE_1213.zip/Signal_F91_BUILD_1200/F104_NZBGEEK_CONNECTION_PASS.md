# F104 NZBGeek connection pass

- Adds an optional NZBGeek API-key field and Newznab `t=caps` connection test in existing AIOStreams/Usenet settings.
- Adds settings backup/restore and fresh-install credential cleanup for the new field.
- Does not automatically configure AIOStreams, perform NZBGeek searches, or resolve NZBs for playback.
- Source-level Swift parsing passed. Xcode compilation and live authentication tests not performed.
- SECURITY FOLLOW-UP: Like existing debrid credentials, this key currently uses AppStorage/UserDefaults; migrate credentials to Keychain before a production release. Existing backup/restore includes the key; audit encryption and export policy.
