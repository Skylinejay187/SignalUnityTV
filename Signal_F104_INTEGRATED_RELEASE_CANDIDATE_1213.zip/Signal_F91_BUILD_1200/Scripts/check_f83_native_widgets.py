from pathlib import Path
import platform,shutil,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
if platform.system()!='Darwin' or not shutil.which('xcrun'):raise SystemExit('F83 native widget checks require Xcode; not run')
with tempfile.TemporaryDirectory(prefix='signal-f83-') as tmp:
 exe=Path(tmp)/'widgets'
 files=[str(ROOT/'Sources/SignalSportsScoreboard.swift'),str(ROOT/'Tests/SignalF83ScoreboardTests.swift')]
 subprocess.run(['swiftc','-swift-version','5','-parse-as-library','-target',platform.machine()+'-apple-macos14.0',*files,'-o',str(exe)],check=True,timeout=90)
 subprocess.run([str(exe)],check=True,timeout=10)
 sdk=subprocess.check_output(['xcrun','--sdk','appletvos','--show-sdk-path'],text=True).strip()
 subprocess.run(['xcrun','--sdk','appletvos','swiftc','-swift-version','5','-parse-as-library','-typecheck','-sdk',sdk,'-target','arm64-apple-tvos18.0',*files],check=True,timeout=90)
print('F83 widget native and tvOS typecheck PASS; full app/device checks separate')
