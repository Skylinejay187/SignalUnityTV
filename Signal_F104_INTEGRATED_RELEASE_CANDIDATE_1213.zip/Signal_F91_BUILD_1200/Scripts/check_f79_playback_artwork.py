from pathlib import Path
import hashlib,json,re
from check_f31_top_menu_regression import block
from source_hash_integrity import verify_unchanged_sources
from f82_approved_deltas import historical_source
ROOT=Path(__file__).resolve().parents[1]
a=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
restore=block(a,'    func restoreCachedOnly(')
for token in ['PersistentArtworkSourceCache.data(for: url)','LiveTVArtworkDecodeGate.shared.acquire()','self.requestGeneration == owner','Task.detached','self.image = restored','defer {']:
 assert token in restore,token
assert 'URLSession' not in restore and 'data(for: request)' not in restore
for name in ['    private func scheduleOverlayAutoHideIfAllowed(','    private func scheduleVODControlShelfAutoHide()']:
 assert block(a,name).count('!liveQuickGuideVisible')>=2,name
assert 'guard isLivePlayback, liveQuickGuideVisible' in block(a,'    private func scheduleLiveQuickGuideAutoDismiss()')
assert 'isLivePlayback ? 3_000_000_000 : 1_500_000_000' in block(a,'    private func prepareQuickGuidePreview(')
assert 'fastLiveJoin: true' in block(a,'    private func quickGuidePreviewSurface(')
v=(ROOT/'Sources/SignalPausedPlaybackInfoOverlay.swift').read_text()
assert '60_000_000_000' in v and '.task(id: idleKey)' in v and 'catch { return }' in v
assert v.index('Color.black.opacity(0.72)')<v.index('information(at: context.date)')
assert 'idleDimEnabled = false' in v and 'remoteActivity' in v
assert '"pauseInfoIdleDimV1": false' in (ROOT/'Sources/SignalPortableSettings.swift').read_text()
registry=(ROOT/'Sources/SignalPortableSettings.swift').read_text()
registered=set(re.findall(r'"([^"\\]+)"\s*:',registry))
excluded=set(re.findall(r'"([^"\\]+)"',registry.split('static let excludedKeys:')[1].split('static func snapshot')[0]))
observed=set()
for p in (ROOT/'Sources').rglob('*.swift'):
 observed.update(re.findall(r'@AppStorage\("([^"\\]+)"\)',p.read_text()))
assert observed <= registered | excluded,sorted(observed-registered-excluded)
verify_unchanged_sources(ROOT, json.loads((ROOT/'Tests/F79UnchangedSourceHashes.json').read_text()), historical_source)
print('F79 current wiring/scope PASS: disk-only covered artwork, guide timeout exclusions, 1.5s FastZap dwell, owned opt-in idle dimmer. Native/device verification separate.')
