#!/usr/bin/env python3
"""Extract actual bridge seek/handoff methods and execute against controllable engine awaits.
Transport orchestration only; not an AVPlayer, disk IO, Apple SDK or device test.
"""
from pathlib import Path
import argparse,shutil,subprocess,tempfile
from check_f31_top_menu_regression import block
ROOT=Path(__file__).resolve().parents[1]
def fixture():
    bridge=(ROOT/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
    s='''import Foundation
struct Options { var isLive = false }
enum State { case idle, playing, paused, seeking, ended, error(String) }
@MainActor final class UIApplication {
    enum State { case active, background }
    static let shared = UIApplication()
    var applicationState = State.active
}
@MainActor final class Clock { var bufferedPosition = 0.0 }
@MainActor final class AetherEngine {
    var isSessionReady = true, isSeeking = false
    var state = State.playing
    var duration = 600.0, currentTime = 10.0
    var clock = Clock()
    var plays = 0, pauses = 0, refreshes = 0
    var availableEnd = 90.0
    var targets: [Double] = []
    var releases: [Int: CheckedContinuation<Void,Never>] = [:]
    func seek(to seconds: Double) async {
        let index=targets.count;targets.append(seconds)
        await withCheckedContinuation { releases[index] = $0 }
    }
    func complete(_ index: Int, position: Double? = nil) {
        currentTime = position ?? targets[index]
        state = .paused // reproduce a seek landing whose transport is parked
        releases.removeValue(forKey: index)!.resume()
    }
    func play() { plays += 1;state = .playing }
    func pause() { pauses += 1;state = .paused }
    func refreshSignalBufferFrontier() { refreshes += 1;clock.bufferedPosition = max(currentTime, availableEnd) }
}
@MainActor final class SeekFixture {
    var engine: AetherEngine? = AetherEngine()
    var generation: UInt64 = 1, seekSerial: UInt64 = 0
    var seekTask: Task<Void,Never>?, loadTask: Task<Void,Never>?, sessionAdjustmentTask: Task<Void,Never>?
    var pendingVODSeekAfterLoadSeconds: Double?
    var vodSeekTransportPending = false, transportWantsPlay = true
    var backgrounded = false, failed = false, endedPublished = false, configuredAllowSessionRebuild = true
    var loadedOptions: Options? = Options()
    var buffered: [Double] = []
    func publishBufferNotification(position: Double) { buffered.append(position) }
'''
    for marker in ['    public func seek(to seconds:', '    private func reconcileVODSeekTransport(',
                   '    public func play()', '    public func pause()']:
        s+=block(bridge,marker).replace('public func','func').replace('private func','func')+'\n'
    return s+'}\n'+(ROOT/'Tests/SignalF70SeekTransportTests.swift').read_text()
def main():
    p=argparse.ArgumentParser();p.add_argument('--emit',type=Path);args=p.parse_args()
    if args.emit:args.emit.write_text(fixture());return
    if not shutil.which('swiftc'):raise SystemExit('Swift compiler required for executable F70 seek orchestration tests')
    with tempfile.TemporaryDirectory(prefix='signal-f70-seek-') as folder:
        folder=Path(folder);src=folder/'Fixture.swift';src.write_text(fixture());out=folder/'tests'
        subprocess.run(['swiftc','-parse-as-library','-swift-version','5',str(src),'-o',str(out)],check=True,timeout=90)
        subprocess.run([str(out)],check=True,timeout=15)
    print('F70 actual seek/handoff orchestration executable passed; real cache IO/AVPlayer/device validation separate')
if __name__=='__main__':main()
