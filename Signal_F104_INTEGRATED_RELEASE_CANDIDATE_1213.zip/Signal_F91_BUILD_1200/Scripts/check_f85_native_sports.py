from pathlib import Path
import platform, shutil, subprocess, tempfile
ROOT = Path(__file__).resolve().parents[1]
if platform.system() != 'Darwin' or not shutil.which('xcrun'):
    raise SystemExit('F85 native Sports checks require Xcode; not run')
with tempfile.TemporaryDirectory(prefix='signal-f85-') as temporary:
    executable = str(Path(temporary)/'sports-tests')
    core = str(ROOT/'Sources/SignalSportsWebSource.swift')
    subprocess.run(['swiftc','-swift-version','5','-parse-as-library','-target',platform.machine()+'-apple-macos14.0',core,str(ROOT/'Tests/SignalF85SportsTests.swift'),'-o',executable],check=True,timeout=120)
    subprocess.run([executable],check=True,timeout=30)
    sdk = subprocess.check_output(['xcrun','--sdk','appletvos','--show-sdk-path'],text=True).strip()
    files = [core,str(ROOT/'Sources/SignalSportsScoreboard.swift'),str(ROOT/'Sources/SportsScoresScheduleProvider.swift'),str(ROOT/'Sources/SignalSportsOnlinePlayer.swift'),str(ROOT/'Tests/SignalF85SportsSDKStubs.swift')]
    subprocess.run(['xcrun','--sdk','appletvos','swiftc','-swift-version','5','-parse-as-library','-typecheck','-sdk',sdk,'-target','arm64-apple-tvos18.0',*files],check=True,timeout=120)
print('F85 native production Sports parser/transport and isolated tvOS UI typecheck PASS; full app/device playback separate')
