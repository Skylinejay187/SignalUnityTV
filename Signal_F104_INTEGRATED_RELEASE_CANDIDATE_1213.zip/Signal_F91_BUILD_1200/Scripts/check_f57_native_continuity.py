#!/usr/bin/env python3
"""Compile the actual continuity/deduplication helpers with repeated-event cases."""
from pathlib import Path
import shutil
import subprocess
import tempfile
from check_f31_top_menu_regression import block

ROOT = Path(__file__).resolve().parents[1]


def main():
    compiler = shutil.which('swiftc')
    if not compiler:
        raise SystemExit('Swift compiler required for F57 native checks')
    source = (ROOT / 'Sources/SignalProtectedNetworkState.swift').read_text()
    with tempfile.TemporaryDirectory(prefix='signal-f57-') as directory:
        directory = Path(directory)
        helpers = directory / 'Continuity.swift'
        helpers.write_text('import Foundation\n' + block(source, 'struct SignalProtectedPathDeduplicator<') + '\n'
                           + block(source, 'struct SignalProtectedPlaybackRoute:') + '\n')
        executable = directory / 'tests'
        subprocess.run([compiler, '-swift-version', '5', str(helpers),
                        str(ROOT / 'Tests/SignalF57NetworkContinuityTests.swift'), '-o', str(executable)], check=True, timeout=60)
        subprocess.run([str(executable)], check=True, timeout=30)


if __name__ == '__main__':
    main()
