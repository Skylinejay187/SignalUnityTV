#!/usr/bin/env python3
"""Audit the actual explicit XcodeGen app source list, not merely ZIP file presence."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
class MembershipError(ValueError):pass

def validate(root=ROOT, project=None):
    text=project if project is not None else (root/'project.yml').read_text()
    try:
        app=text.split('  DebridChannelsTVOS:',1)[1]
        sources=app.split('    sources:',1)[1].split('    resources:',1)[0]
    except IndexError:raise MembershipError('Cannot identify DebridChannelsTVOS app sources')
    listed=set()
    for value in re.findall(r'^\s*- path:\s*(.+?)\s*$',sources,re.M):
        value=value.strip('"\'')
        path=root/value
        if not path.exists():raise MembershipError('Listed app source does not exist: '+value)
        if path.is_dir():listed.update(p.relative_to(root).as_posix() for p in path.rglob('*.swift'))
        elif path.suffix=='.swift':listed.add(value)
    packaged_bridge='Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift'
    vendor=root/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift'
    if (root/packaged_bridge).read_bytes()!=vendor.read_bytes():raise MembershipError('App and packaged bridge copies differ')
    if not re.search(r'package: AetherPlaybackKit\s+product: AetherPlaybackBridge',app):
        raise MembershipError('Separately compiled AetherPlaybackBridge dependency missing')
    expected={p.relative_to(root).as_posix() for p in (root/'Sources').rglob('*.swift')} - {packaged_bridge}
    missing=expected-listed
    if missing:raise MembershipError('Swift file(s) missing from app target: '+', '.join(sorted(missing)))
    if packaged_bridge in listed:raise MembershipError('Separate bridge module must not also compile into app target')
    return len(expected)

def main():
    count=validate()
    # Reproduce the exact F66 failure as a negative control.
    original=(ROOT/'project.yml').read_text()
    broken=original.replace('      - path: Sources/SignalEpisodeClockGate.swift\n','',1)
    if broken==original:raise MembershipError('Clock gate source-list entry is missing')
    try:validate(project=broken)
    except MembershipError as error:
        if 'Sources/SignalEpisodeClockGate.swift' not in str(error):raise
    else:raise MembershipError('Negative control did not catch the supplied missing-clock-gate build failure')
    print(f'App target source membership PASS: {count} Swift files; packaged bridge dependency/parity; exact missing-clock-gate negative control rejected')
if __name__=='__main__':main()
