from regression_manifest_cache import read_manifest
"""Reverse only reviewed F52 source hunks for exact F51/historical checks."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[1]
def previous_source(source,path):
    from f54_approved_deltas import previous_source as previous_f54
    source=previous_f54(source,path)
    record=read_manifest(ROOT/'Tests/F52ApprovedSourceDeltas.json').get(path)
    if record is None:return source
    digest=hashlib.sha256(source.encode()).hexdigest()
    accepted={record['before_sha256']}
    for previous in ROOT.glob('Tests/F*ApprovedSourceDeltas.json'):
        release=re.match(r'F(\d+)',previous.name)
        if not release or int(release[1])>=52:continue
        prior=read_manifest(previous).get(path)
        if prior:accepted.update((prior['before_sha256'],prior['after_sha256']))
    if digest in accepted:return source
    assert digest==record['after_sha256'],'Unreviewed F52 source change: '+path
    for h in reversed(record['hunks']):
        assert source.count(h['after'])==1,'Ambiguous F52 delta: '+path
        source=source.replace(h['after'],h['before'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==record['before_sha256']
    return source

def historical_source(path):
    # Historical tests read a SHA-pinned F87 Guide snapshot, not F103's edited file.
    # The helper rejects unapproved edits to either the live file or snapshot.
    from f87_approved_deltas import f103_approved_guide_history
    guide = f103_approved_guide_history(path)
    return previous_source(guide if guide is not None else path.read_text(), path.relative_to(ROOT).as_posix())
