#!/usr/bin/env python3
"""Reviewed F35 source contracts. Device focus/render/timing verification is still required."""
from f39_approved_deltas import historical_source
from pathlib import Path
import hashlib,json,re
from check_f31_top_menu_regression import block
from check_f34_visual_regression import validate
ROOT=Path(__file__).resolve().parents[1]

def verify():
    validate()
    app=historical_source((ROOT/'Sources/DebridChannelsTVOSApp.swift'))
    bridge=historical_source((ROOT/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift'))
    host=historical_source((ROOT/'Sources/PlaybackKit/PlaybackKitAetherSurface.swift'))
    visual=historical_source((ROOT/'Sources/SignalTopMenuVisuals.swift'))
    model=historical_source((ROOT/'Sources/SignalTopMenuTheme.swift'))
    background=historical_source((ROOT/'Sources/SignalBackgroundVisuals.swift'))
    policy=historical_source((ROOT/'Sources/SignalLiveTVCardEffect.swift'))
    nav=block(app,'struct TopMenuBar: View')
    assert '@State private var focusedTab: AppTab?' in nav
    assert nav.count('.focused($menuRowFocused)')==1
    assert '.focused($focusedTab' not in nav
    assert nav.count('.onMoveCommand(perform: routeMenuMove)')==1
    route=block(nav,'    private func routeMenuMove(')
    assert 'SignalFocusOrder.step(' in route and 'visibleTabs.count + (inside ? 1 : 0)' in route
    assert 'searchFocused = true' in route
    assert route.count('handleTopMenuDownCommand()')==1
    assert 'Task' not in route and 'async' not in route and 'Date(' not in route
    assert 'SignalSearchGlyph' not in block(app,'private struct SignalLiveTVMirrorHeader<ModeChip: View>')
    assert 'contentOwnsFocus' not in block(app,'    private var unityTopNavigationOwnsFocus: Bool')
    assert 'store.selectedDetail == nil' in block(app,'    private var unityTopNavigationOwnsFocus: Bool')
    outside=block(nav,'    private var outsideSearchButton: some View')
    assert 'contentFocusToken &+= 1' in outside and 'store.catalogRowsPresented' in outside
    assert 'focusedTab = visibleTabs.last' in outside
    assert '.frame(width: topMenuThemeStyle.itemWidth(for: tab), height: 60)' in nav
    assert nav.index('.focused($menuRowFocused)') < nav.index('.position(x: isPreviewMirrorNavigationChrome')
    category=block(app,'    private var categoryCardsRow: some View')
    assert category.count('.focusable(true)')==1 and category.count('.focused(')==1
    assert 'SignalFocusOrder.step(' in category and 'transaction.disablesAnimations = true' in category
    assert '.disabled(!isFocusable)' not in category
    for marker in ('struct SettingsCategoryCard: View, Equatable','private struct SettingsButtonVisual: View, Equatable'):
        part=block(app,marker)
        assert '.scaleEffect' not in part and '.shadow(' not in part
    preview=block(app,'private struct LiveTVGridFocusPreviewSurface: View')
    assert 'isLiveStream: true, fastLiveJoin: true' in preview
    assert 'SignalPreviewStartupPolicy.dwellNanoseconds' in block(app,'    private func scheduleLiveTVGridFocusPreview(')
    assert 'liveJoinProfile: isLiveStream && configuredFastLiveJoin ? .fastZap : .standard' in bridge
    assert 'options.liveJoinProfile = attempt == 1 ? baseOptions.liveJoinProfile : .standard' in bridge
    assert 'options.liveJoinStartsImmediately = attempt == 1 && baseOptions.liveJoinStartsImmediately' in bridge
    assert 'movingPicture route=' in bridge and 'liveMotionStartedAt = liveAttemptStartedAt' in bridge
    assert 'fastLiveJoin: isLiveStream && fastZapFullScreen' in historical_source((ROOT/'Sources/UniversalCodecSupport.swift'))
    assert bridge==historical_source((ROOT/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift'))
    assert '.matchedGeometryEffect' not in visual
    assert 'accent.opacity(0.09)' in block(visual,'    private var barFill:')
    assert 'Color(white: 0.19)' in visual and 'Color(white: 0.055)' in visual
    for name in ('Luminous Glass','Cinema Pearl','Opal Glass','Slate Atelier','Satin Rail','Frosted Ribbon'):
        assert '= "'+name+'"' in model
    assert '= "Retro Wave Reborn"' not in model
    assert background.index('Rectangle().fill(MainGridBackgroundStyle.glassColor') < background.index('ClassicAmbientSmokeOverlay(')
    assert '.opacity(0.95)' in background and '.blur(radius: CGFloat(treatment.smokeSoftness))' not in background
    smoke=block(app,'struct ClassicAmbientSmokeOverlay: View')
    assert smoke.index('.frame(width: viewport.size.width') < smoke.index('.drawingGroup(opaque: false')
    budget=block(app,'    private var liveDecorativeSurfacesOwnRenderBudget: Bool')
    assert 'previewChannelID == nil' in budget and 'gridFocusPreviewChannelID == nil' in budget
    assert '.modifier(SignalGPUComposition())' not in app
    assert 'coordinatedRailAnimations && focusedPreviewURL == nil' in app
    motion=block(app,'private struct LiveTVGridFocusMotionHost<Content: View>')
    assert 'containsLivePreview ? SignalLiveTVCardPose(depth: p.depth, bevel: p.bevel) : p' in motion
    assert 'containsLivePreview: gridPreviewURL != nil' in app
    assert 'return ZStack {\n        LiveTVGridFocusMotionHost(' in block(app,'    private func liveTile(channel: LiveTVChannel, loadArtwork: Bool, cardHeight: CGFloat = 278)')
    assert 'SignalCardDepthPlate(' in motion and '.shadow(' not in motion and '.drawingGroup(' not in motion
    for option in ('Raised Glass','Deep Float','Beveled Cinema','Layered Slate','Curved Wall','Tilted Pedestal','Inset Lens','Gallery Lift','Prism Bevel'):
        assert 'case "'+option+'"' in policy
    print('F35 source checks passed: ordered focus, global Search, 650 ms preview arm, true FastZap + Standard recovery, neutral chrome, smoke over glass, bounded raised cards and native-video exclusions')
if __name__=='__main__':
    from check_f36_regression import verify as verify_current
    verify_current()
