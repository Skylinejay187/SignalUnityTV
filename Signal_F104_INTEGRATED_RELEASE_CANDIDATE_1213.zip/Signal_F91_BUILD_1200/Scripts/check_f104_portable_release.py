from pathlib import Path
import subprocess, hashlib, json, sys
root=Path(__file__).resolve().parents[1]
checks=[('Build identity',['python3','Scripts/check_f29_build_identity.py']),('F104 integration contracts',['python3','F104_INTEGRATION_CHECK.py']),('NZBGeek search fallback',['python3','Scripts/check_f104_nzbgeek_search_fallback.py']),('F91/F87 source integrity',['python3','Scripts/check_f91_inherited_f87.py']),('F104 playback baseline',['python3','F104_VALIDATION/F104_PLAYBACK_BASELINE_AUDIT.py']),('Historical drift classification',['python3','Scripts/check_f104_legacy_drift.py'])]
results=[]
for name,cmd in checks:
    p=subprocess.run(cmd,cwd=root,text=True,capture_output=True,timeout=90)
    results.append((name,p.returncode,p.stdout[-2000:],p.stderr[-500:]))
files=[str(p) for p in (root/'Sources').rglob('*.swift')]+[str(p) for p in (root/'TopShelfExtension').rglob('*.swift')]+[str(p) for p in (root/'Vendor/AetherPlaybackKit/Sources').rglob('*.swift')]
p=subprocess.run(['swiftc','-frontend','-parse',*files],cwd=root,text=True,capture_output=True,timeout=120)
results.append(('All packaged Swift syntax ('+str(len(files))+' files)',p.returncode,p.stdout[-1000:],p.stderr[-1000:]))
report=['F104 PORTABLE RELEASE PREFLIGHT','', 'This report does NOT certify Xcode/tvOS compilation or live playback.','']
for name,rc,out,err in results:
    report.append(('PASS' if rc==0 else 'FAIL')+' | '+name)
    if rc: report.append((out+'\n'+err)[-1200:])
report+=['','BLOCKED (requires macOS/Xcode): tvOS SDK typechecks, XcodeGen build, signing/IPA','NOT VERIFIED: live NZBGeek/TorBox Cache & Play, AIOStreams, Siri Remote, RD/VOD resume','LEGACY: vBRDC075 includes 3 outdated F103-relative assertions; do not remove or bypass them.','']
(root/'F104_RELEASE_PREFLIGHT_REPORT.txt').write_text('\n'.join(report))
print('\n'.join(report))
sys.exit(0 if all(rc==0 for _,rc,_,_ in results) else 1)
