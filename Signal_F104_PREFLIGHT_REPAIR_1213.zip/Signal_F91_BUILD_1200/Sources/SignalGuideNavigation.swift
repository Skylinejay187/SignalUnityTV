import Foundation

/// A category's vertical screen position never determines its destination channel.
/// Keep the selected channel if it belongs to that category, otherwise enter row one.
enum SignalGuideNavigation {
    static func targetIndex(ids: [Int], selectedID: Int) -> Int? {
        guard !ids.isEmpty else { return nil }
        return ids.firstIndex(of: selectedID) ?? 0
    }
}

/// F103: deterministic focus ownership for the full-screen Guide.
/// The Guide owns directional input while presented; the quick-guide and
/// playback surfaces must not consume those same remote events.
struct SignalFullGuideFocusController {
    enum Region: Equatable { case categories, timeline, controls }
    enum Direction { case up, down, left, right }
    private(set) var region: Region = .categories
    private(set) var selectedChannelID: Int?
    private(set) var selectedCategoryIndex: Int = 0

    mutating func enter(categoryIndex: Int, selectedChannelID: Int?) {
        selectedCategoryIndex = max(0, categoryIndex)
        self.selectedChannelID = selectedChannelID
        region = .categories
    }

    /// Commit the same destination used by the SwiftUI timeline handoff.
    /// A category change must not leave the controller pointing at a channel
    /// from the previous category.
    mutating func handoffToTimeline(categoryIndex: Int, categoryCount: Int, channelID: Int) {
        guard categoryCount > 0 else { return }
        selectedCategoryIndex = min(max(categoryIndex, 0), categoryCount - 1)
        selectTimelineChannel(channelID)
    }

    mutating func selectTimelineChannel(_ channelID: Int) {
        selectedChannelID = channelID
        region = .timeline
    }

    mutating func returnToCategories(categoryIndex: Int, count: Int) {
        selectCategory(categoryIndex, count: count)
    }

    mutating func selectCategory(_ index: Int, count: Int) {
        guard count > 0 else { return }
        selectedCategoryIndex = min(max(index, 0), count - 1)
        region = .categories
    }

    /// Return true only when the full Guide handled the movement.
    @discardableResult
    mutating func move(_ direction: Direction, channelIDs: [Int], categoryCount: Int) -> Bool {
        switch (region, direction) {
        case (.categories, .up):
            selectCategory(selectedCategoryIndex - 1, count: categoryCount)
        case (.categories, .down):
            selectCategory(selectedCategoryIndex + 1, count: categoryCount)
        case (.categories, .right):
            guard let index = SignalGuideNavigation.targetIndex(ids: channelIDs,
                selectedID: selectedChannelID ?? -1) else { return true }
            selectedChannelID = channelIDs[index]
            region = .timeline
        case (.timeline, .left):
            region = .categories
        case (.timeline, .up), (.timeline, .down):
            guard !channelIDs.isEmpty else { return true }
            let index = SignalGuideNavigation.targetIndex(ids: channelIDs,
                selectedID: selectedChannelID ?? -1) ?? 0
            let next = direction == .up ? max(0, index - 1) : min(channelIDs.count - 1, index + 1)
            selectedChannelID = channelIDs[next]
        case (.controls, .down):
            region = .timeline
        default:
            break
        }
        return true
    }
}
