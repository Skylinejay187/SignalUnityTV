# F104 preflight repair checkpoint

- Reconciled the F103 Guide pin to the existing F104-approved source digest (240f8975...). No Guide source edits.
- F86 historical hash baseline retained unchanged; F86 preflight now checks explicitly pinned F91 and F104 later source versions instead of incorrectly demanding F86 bytes.
- Added exact digest pins for MediaFlowProxyRouter.swift and SignalF85SportsSDKStubs.swift, which were absent from the later pin manifests. These are integrity pins, **not** a security or functional review of those changes.
- Confirmed F86 preflight PASS, F91 inherited F87 PASS, F86 tooling unit tests PASS, and mutation negative control rejects unauthorized MediaFlow source edits.
- Full macOS/Xcode tvOS compilation and physical Apple TV runtime validation NOT performed in this Linux environment.
