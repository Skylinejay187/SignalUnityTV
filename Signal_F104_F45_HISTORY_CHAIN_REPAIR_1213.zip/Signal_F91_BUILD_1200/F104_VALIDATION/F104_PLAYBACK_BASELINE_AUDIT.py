#!/usr/bin/env python3
"""Compare F104 protected playback sources with the last full F103 baseline.
Historical vBRDC075 hashes are NOT release baselines and are deliberately left unchanged.
"""
import hashlib, sys, zipfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]
archive = Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/Signal_F103_1212_HISTORICAL_F47_PLUS_AUDIT_FIX.zip')
protected = ['Sources/PlaybackResumeCache.swift', 'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift', 'Sources/UnityCatalogVisualSystem.swift']
with zipfile.ZipFile(archive) as z:
    for rel in protected:
        matches=[name for name in z.namelist() if name.endswith('/'+rel)]
        if len(matches)==0 and not (root/rel).exists():
            print(f'SKIP {rel}: absent from both F103 and F104 source trees')
            continue
        if len(matches)!=1: raise SystemExit(f'ERROR: missing or ambiguous baseline {rel}')
        old=hashlib.sha256(z.read(matches[0])).hexdigest()
        new=hashlib.sha256((root/rel).read_bytes()).hexdigest()
        print(f'{"PASS" if old==new else "REVIEW"} {rel}\n  F103: {old}\n  F104: {new}')
        if old!=new: raise SystemExit('Protected playback file changed; manual regression review required')
print('PASS: all present protected playback files match F103 byte-for-byte')
