# F24 GPU Composition A/B test

GPU Enhancement OFF preserves F23 render paths. ON adds offscreen GPU composition to the Live TV dynamic wallpaper presentation and Cover Flow reflection visuals. Existing Canvas/Metal-backed drawing groups, native tvOS GPU composition, and Aether hardware decoding are present in both modes. This is not a global CPU/GPU switch. Extra offscreen passes can be slower; measure rather than assume a gain. The performance trace labels the mode at report time; do not switch during a recording. Restart between test runs.
