# Signal F39 — Build 1148

Version **1.0.1148**, patched forward from the supplied F38 / 1147 source ZIP.
Build this package using the included macOS tvOS workflow. This delivery contains source, not a compiled IPA.

## Changes requested in this patch

- **Visible smoke:** billows now sit above the glass tint, with fewer, more distinct light/dark clouds and stronger movement. The existing five Smoke Atmosphere choices remain. The visible Live dashboard animates at up to 15 FPS, reduced to 8 FPS during a grid preview instead of freezing almost immediately. Catalogs, Search, Guide, Settings, details and full-screen playback still exclude this work. Pure Black and Smoke Off remain effect-free; Reduce Motion is static.
- **Catalog focus:** selecting Home, Movies or TV Shows disables the menu's focus targets until Back/Exit closes the catalog. A fresh menu selection consumes a separate first-row entry token and clears stale detail restore anchors. The focus handoff runs after the catalog becomes interactive, fixing the early request that could be ignored during its opening transition. Detail/player returns retain their own restoration path.
- **Search icon placement:** the icon viewport grows from 30 to 42 points, with a 25-point magnifier. In the outside/clock placement, its position follows the actual channel-heading bounds, near the ALL / CHANNELS boundary. Its bottom edge sits 14 points above the text, with no focus scale enlargement. Menu placement remains in its existing menu slot.
- **Search effects:** all existing effect choices use bounded native Core Animation layers instead of a SwiftUI TimelineView. Updates no longer rebuild the glyph/view preferences on every animation frame. Style changes, inactive scenes and removal stop old layer animations; Reduce Motion uses static decoration. The native effect view cannot take focus or intercept input.
- **Search responsiveness:** channel filtering and local title/metadata matching run in cancellable workers after the existing 250 ms query debounce. Channel results are retained rather than recomputed on every focus-driven body update. Provider JSON decoding also runs off the main actor. The same local result snapshot is reused for remote merging. Publication rejects stale queries and covered screens; metadata prefetch is cancelled on new queries. Results cannot pull focus from the search field. Result cards have a fixed vertical slot and no overlapping native/spring/3D focus transforms.
- **Live TV preview:** reveal changes from 2.5 to **2.0 seconds** of focus dwell. Quiet preparation still starts after 650 ms. Actual video and audio still wait for a decoded frame; a slow source may take longer than 2.0 seconds. Moving away cancels the same single Aether preview.

The complete VODPlayerScreen, Up Next discovery/selection, Aether bridge/host, Carousel actions, Live TV page math and full-screen FastZap wiring are preserved. App, Top Shelf and project version numbers are aligned. The existing workflow is included, with F39 validation and a signal/f39-* push trigger added.

## Verification performed here

- Current F39 source contracts passed, including exact VOD/Up Next/playback scope checks.
- F31–F38 historical regression checks passed against the exact F38 projection. Historical fixtures were not reset: the reviewed F39 hunks and before/after digests are recorded in Tests/F39ApprovedSourceDeltas.json. Scripts/check_f39_regression.py checks the actual F39 behavior separately.
- Six build-identity tests, seven redaction cases, remote-thumbnail safety and 22 FastZap wiring checks passed.
- No new tree-sitter Swift grammar diagnostics across the six changed Swift files. The parser retains the same two existing app-file diagnostics; this is not Swift type checking.
- Workflow YAML parsed; all source entries and existing build steps retained.
- ZIP CRC and source-byte verification are recorded in F39_VALIDATION.json after packaging.

**Not performed:** Swift compiler/type checks, Xcode build, executable Swift model tests and physical Apple TV testing. This Linux workspace has no Xcode/Apple SDK. The included macOS workflow performs compilation and executable model checks.

## Apple TV checks after a successful build

1. Select each smoke style with a non-black background. Watch the open dashboard before and during a preview; open/close catalogs, Search, Guide and Settings and verify clean suspension/resumption.
2. Select Home, Movies and TV Shows from the menu, including same-tab re-entry. Confirm first-row focus, Up-boundary containment, and Back restoring the selected menu item. Open/close details and playback to check their exact-item restoration.
3. Check Search in both placements, including long category names and menu sizes. In outside placement verify the text gap and clock clearance.
4. Cycle every Search effect, select Search, type/delete quickly, scroll both result types and return from details. Check for stalls and focus loss; repeat with Reduce Motion.
5. Check a fast and a slow Live TV source: no reveal/audio before 2.0 seconds and a real frame; cancellation when changing cards; paging and full-screen playback still behave normally.
