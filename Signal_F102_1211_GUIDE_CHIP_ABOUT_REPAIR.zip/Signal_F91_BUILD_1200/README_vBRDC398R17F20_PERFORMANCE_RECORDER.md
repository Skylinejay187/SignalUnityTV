# Signal tvOS vBRDC398R17F20 — opt-in performance recording

Based strictly on F19. Version 1.0.1125 / build 1125, including Top Shelf extension.

Settings > Stable Protection: enable Performance HUD, select Start Performance Recording, navigate Live TV pages/catalogs/Settings/Up Next for 5–15 minutes, then select Stop Performance Recording and View Performance Recording. Photograph the trace or capture screenshots; it records one aggregate per second, bounded to 30 minutes, and does not include titles, URLs, tokens, or accounts.

Measures CADisplayLink presentation cadence, frame hitch count and worst interval, process memory footprint, and bounded Live TV artwork loader active jobs. This is NOT a replacement for Xcode Instruments; it cannot enumerate all tasks/players or attribute CPU/GPU call stacks. These require targeted instrumentation in later releases. No runtime device validation was possible in this Linux environment. Keep diagnostic HUD disabled for normal viewing.

Existing F19 features, including MediaFlow and Up Next, preserved. The previously stale Top Shelf extension plist was also brought into version alignment.
