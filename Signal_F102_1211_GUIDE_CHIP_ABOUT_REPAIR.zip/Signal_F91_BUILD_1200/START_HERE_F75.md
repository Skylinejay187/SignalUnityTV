# F75 / build 1184

Fixes the supplied build-log failure in the pause-screen SDK validation fixture: the current production mapping uses liveQuickGuideVisible, but the fixture omitted that property. The fixture now supplies it and checks standalone Boolean gate dependencies. Three regression tests run in normal preparation, including the original omission as a negative control. All 159 Swift files are unchanged from F74; the removal of the pause-card SIGNAL label is retained.

Local checks passed; see F75_VALIDATION.json. Full Xcode/tvOS build must run on the macOS build runner and was not available locally.
