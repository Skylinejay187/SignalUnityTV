# Signal F46 — build 1155

Based on F45 / build 1154. Use the existing universal source-ZIP tvOS build workflow.

## Live TV grid

The production and full-screen customization preview use the fixed 4-column, 3-row grid: 12 cards per page. Removed the Rows control and fourth-row draft option. Legacy saved four-row values cannot change the page size and normalize to three on grid entry. The old settings key remains readable for backup compatibility; there is no four-row UI/runtime mode.

Focused cards now rise 2 points and grow by 1.8%, using a 0.14-second ease-out. This works in Original and Aligned layouts, preserving the selected card shape/perspective and the underlying focus lattice. Pop Out preview's larger scale is bounded at 3%. Reduce Motion disables this focus displacement/scale animation. No looping task, timer, new blur, shadow filter, or additional decoder was added for the popup.

## Guide text and schedule

The screenshot shows multiple listing labels drawn on top of each other. Provider EPG responses can contain repeated identities or overlapping schedule revisions; the previous ZStack painted every interval independently. The display now deduplicates program IDs, chooses a consistent longest entry for same-start revisions, and trims an earlier displayed interval at the next program's start. Every resulting rectangle is unique and non-overlapping. The provider's underlying EPG data and Quick Guide metadata are retained.

Focus highlighting follows the visible normalized interval at the current-time marker. Disabled the native row focus magnification and removed layout animation during rail expansion/collapse, keeping text at fixed sizes while the timeline changes width.

## Guide appearance

Removed the left-side YOUR CHANNELS heading. Every category has a quiet gray rounded background by default; the selected category has a stronger gray background, and the focused category retains a clear bright highlight.

The Guide uses the exact shared Quick Guide black surface at 78% opacity. Crucially, the layer underneath is now a neutral gray gradient, independently of Pure Black dashboard mode, with one optional 640-pixel prepared program-art backdrop. The earlier translucent surface was rendered over black and therefore still looked solid black. The backdrop uses the existing cancellable utility-queue bitmap path, never a display-size live blur or another video player. Covered Guide artwork work stops through the existing visibility gate. The current program hero/live preview remains.

## Guide focus handoff

Category-to-timeline selection no longer uses the accidental native destination row ordinal. Right keeps the selected channel if it belongs to that category, otherwise enters the first channel. Empty categories retain category focus.

A narrow, full-height focus landing zone sits at the rail's right edge, spanning the vertical position of every visible category, including a scrolled bottom row. The mode/header controls and timeline rows cannot steal focus while category navigation owns the rail. One cancellable request commits the category, materializes/scrolls the destination row, then requests channel focus after layout. Header focus is held off until that handoff completes. Left restores the category rail through the same cancellable owner. Guide exit and playback teardown cancel the request.

## Preservation and validation

The entire VODPlayerScreen, Up Next/autoplay behavior, Aether bridge/host, settings-backup implementation, and other 125 prior Swift files remain byte-identical to F45. F45's explicit-self compiler repair and semantic compiler gate remain present.

Local source/regression checks F31–F46, build identity, remote-thumbnail gate, Swift grammar, YAML, shell, and Python checks passed. Exact historical fixtures remain intact through reviewed source projections. Native tests for category destination selection, duplicate/reordered EPG entries, clipping, and non-overlap are included in the macOS preflight.

Not run locally: native Swift executable tests, Xcode/tvOS compilation, Apple TV visual/remote-focus tests, or CPU/GPU profiling. No Apple SDK or Swift compiler is installed here. Device verification should cover Right from top/middle/bottom/scrolled categories, empty categories, Left/Back, long fast channel scrolling, repeated guide entry/exit, Original/Aligned focus popup, Pure Black and dynamic dashboard backgrounds, and rows with overlapping provider EPG revisions.
