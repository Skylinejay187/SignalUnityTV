# Signal vBRDC398R17F20F1 — build failure repair + performance recorder

## Confirmed cause from user-provided GitHub Actions log
The F19 build failed at `V1041 Production configuration validation` because app `1.0.1124` and Top Shelf `1.0.1122` were inconsistent. This was a version mismatch, not an Aether or Swift compile error.

## Corrections
- Patch forward from F20 (includes the in-app performance recorder, Settings controls and report).
- Align `Sources/Info.plist`, `TopShelfExtension/Info.plist`, and both XcodeGen target version settings to **1.0.1126 (1126)**.
- Add `verify_release_versions.py` for preflight checks before uploading or compiling. Run `python3 verify_release_versions.py` from extracted source root.
- Keep original Xcode validation in place; no playback/navigation/UI changes.

## Validation limits
Portable version preflight, Swift parser, plist parsing and ZIP integrity checked. This environment cannot run Xcode/tvOS build. Run GitHub Actions and report any subsequent compiler errors.

## Recording
Settings → Stable Protection → Start Performance Recording → navigate repeatedly → Stop Performance Recording → View Performance Recording. Screenshot the resulting report.
