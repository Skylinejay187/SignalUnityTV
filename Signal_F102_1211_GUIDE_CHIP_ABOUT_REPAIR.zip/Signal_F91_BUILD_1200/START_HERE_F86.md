# Signal F86 — Build 1195

Based on the complete F85/build1194 source. This is a source ZIP for the existing build workflow, not an installed IPA.

## Build failure and build time

The supplied logs have one compiler error: SportsHub reads CatalogStore.fullScreenPlaybackResourceSuspended while its getter is private. F86 makes the getter internally readable and keeps the setter private. It does not change playback suspension behavior. A new native compiler check uses the actual production declaration and actual Sports access expression in separate files; a negative control restores the old private declaration and must reproduce the failure. This check runs before the older checks in both entry points.

The supplied run spent about 16m33s in source checks, 2m49s in project/dependency preparation, then 7m23s compiling before failure. Historical source verification repeatedly decoded large JSON manifests and invoked the same F73 history chain five times per F72 call. F86 caches parsed manifests per process using file identity/mtime/ctime/size, revalidates on edits, and invokes that history pass once. It caches no source-validation decisions and removes no regression assertions. One local source check fell from 90.537s to 11.077s; this is not a full GitHub-build timing prediction.

## Shared Search improvements (dashboard and in-player VOD Search)

TMDB and Cinemeta were already wired in F85. F85 started the providers concurrently but withheld their results until the slowest provider finished, including NAS endpoint discovery/fallbacks. F86 publishes each of the four bounded provider batches as it completes. Local cards remain first; already published IDs and order remain stable, and later matches enrich missing fields or append. Cancellation, query generations, detail ownership, scene state and in-player eligibility guard publication. A complete result set is remembered only after the search finishes.

TMDB and Cinemeta search JSON now use the existing bounded, deduplicating metadata memory/disk cache, respecting its existing on/off setting. Existing catalog and configured-addon compatibility remains. TMDB still requires the configured API key; Cinemeta remains available without that key. URLComponents encodes TMDB query fields; Cinemeta path queries escape reserved characters.

Search cards request the TMDB w780 CDN rendition when the original URL is a plain HTTPS image.tmdb.org/t/p/original URL. Their existing 768px decode budget, landscape proportions, sideways focus animation and layout are unchanged. Full-resolution URLs remain in MediaItem for detail/hero views. NAS content-hashed WebP, signed URLs, other hosts, SVG and Kingfisher code are untouched. The first download still depends on network availability; cached artwork should reuse the existing Kingfisher pipeline.

## Research

NuvioTV's SearchViewModel (public dev source inspected during this change) collects provider results independently, renders the first result without waiting for all catalog responses, and batches subsequent UI updates. Signal adopts the independent-publication principle, not Nuvio's code or UI. Nuvio's TMDB service and website document TMDB/addon metadata. Stremio exposes Cinemeta and addon search, cache hints and compact poster metadata. Couch Streamer's developer TestFlight description documents metadata caching for scrolling/file previews; it does not disclose its search internals. No claim is made that another app or a cold network request is universally instantaneous.

References:
- https://github.com/NuvioMedia/NuvioTV/blob/dev/app/src/main/java/com/nuvio/tv/ui/screens/search/SearchViewModel.kt
- https://github.com/NuvioMedia/NuvioTV/blob/dev/app/src/main/java/com/nuvio/tv/core/tmdb/TmdbService.kt
- https://nuvio.tv/
- https://github.com/Stremio/stremio-addon-sdk/blob/master/docs/api/responses/meta.md
- https://github.com/Stremio/stremio-addon-sdk/blob/master/docs/README.md
- https://developer.themoviedb.org/docs/image-basics
- https://testflight.apple.com/join/46eGdwqE

## Validation and next device checks

29 historical/current regression command groups passed, with further Search/artwork/settings/Sports scope checks, 24 Python unit tests, bridge parity, FastZap wiring, geometry audits, source membership, identity, Python compilation and shell syntax. See F86_VALIDATION.json and F86_REGRESSION_RESULTS.json. The new native checks are included but NOT run locally: this environment has no Xcode/Swift compiler or device runtime. Full tvOS compilation is not yet verified. Existing native SDK checks remain enabled.

After building, search from both the main dashboard and VOD overlay. Try a new title, return to a prior query, type rapidly, navigate before slower providers finish, change scope, open/close Media Information, and repeat with slow/offline internet. Confirm cached posters, stable focus and uninterrupted audio/video. The current source preserves F85 Sports and its free iSportsurge test; StreamEast Premium authentication is still not implemented.
