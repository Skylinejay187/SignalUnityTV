# Signal F49 — build 1158

Narrow build-log correction forward from F48/build 1157. Use this source ZIP for the next build. AetherEngine remains pinned to 7.44.0; the MediaFlow safety lock, aligned-card pop/full-card customization preview, Search/TV overlay, guide, Up Next and playback implementation are preserved.

## Supplied failure and correction

Both supplied archives refer to F48/build 1157. The full Xcode log has one fatal Swift diagnostic:

`ConnectedServicesHealthClient.swift:200:17: error is not handled because the enclosing function is not declared 'throws'`

The F48 Real-Debrid health-request guard was accidentally inserted into the unrelated nonthrowing Offcloud verifier before its do/catch. Move that guard into the existing `getJSON(... ) async throws` request helper, immediately before transport. The Real-Debrid verifier already catches errors from this helper and returns a failed health result. A blocked Real-Debrid health check now makes no request. Valid routing sends the authenticated request through MediaFlow. Offcloud keeps its original independent request and error handling.

This is the only existing production Swift file changed from F48. The other 133 existing Swift source/test files are byte-identical; two new validation files add full-client coverage. Build identity and workflow/preflight wiring advance to F49/build 1158. No engine or player source changed.

## Validation and evidence

The supplied macOS Actions log confirms F48's actual-router/proxy-fixture and card-policy native tests passed. It also confirms the F47 browsing/native-control tests, F46 guide tests and F45 compiler check passed before the full application compilation failed. These are test results, not a successful F48 app build or an Apple TV runtime test.

Local F49 checks passed: narrow production-source delta/hash guards, exact negative-fixture reconstruction, changed/new Swift grammar, current F48/F47/F46/F45/F43 source guards, remote-thumbnail gate, build-identity tests, Python, shell and YAML checks. See F49_VALIDATION.json.

The macOS preflight now compiles the entire actual `ConnectedServicesHealthClient.swift`, with the actual router and isolated credential/registration/redaction interfaces, and runs mocked transport tests covering blocked RD requests, valid proxy wrapping and authorization headers, unverified IP, invalid configuration, HTTP failure, explicit safety-lock opt-out and independent Offcloud results. No real account/server is contacted. A negative compiler control moves the same guard back to its F48 position and must reproduce the supplied unhandled-throw diagnostic. Parsing alone did not detect this Swift semantic error; the full-client compiler check is mandatory in the next macOS preflight.

Not run here: the new native executable/negative compiler check, full Xcode/tvOS build or Apple TV playback/visual testing. This environment has no Swift compiler or Apple SDK. Native F48 test results above are grounded in the supplied user logs; F49 needs its next macOS build to establish compilation success.
