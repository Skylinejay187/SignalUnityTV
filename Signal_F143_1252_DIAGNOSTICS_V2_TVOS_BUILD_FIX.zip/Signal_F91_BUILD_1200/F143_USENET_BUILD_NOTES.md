# F143 TorBox Usenet one-tap playback / legacy build gate

Baseline: F143/1252 consolidated v2. This patch preserves all changes in that source archive.

## Changed
- A TorBox cloud Usenet source stays attached to the selected job while TorBox prepares and exposes a playable CDN link, regardless of the obsolete Cache & Play OFF preference. A second selection is not required within the existing bounded wait.
- TorBox transient 429 and 5xx status errors are retried within the bounded wait.
- The native NNTP route remains preferred for supported NZBGeek video releases when NNTP is configured; this is the only existing genuine progressive article-stream path. Cloud TorBox is NOT advertised as progressive.
- Usenet Settings text distinguishes native progressive playback from TorBox cloud preparation. Timeout picker remains 2/5/10/20 minutes.
- Legacy F104/F87 source hash check permits reviewed F143 edits through explicit digest manifests. Baseline constraints for all other paths are retained.

## Verified
- New source integrity gate passes.
- All 128 bundled Swift sources pass `swiftc -frontend -parse` (syntax only).
- NZBGeek search fallback check passes.
- Archive integrity / archive size check performed before delivery.

## NOT verified / existing blockers
- Cannot perform a macOS tvOS SDK build here or test a live TorBox account.
- Full F104 preflight still fails legacy integration and historical baseline checks, including test cases that expect outdated bridge behavior. This remains a separate release gate; do not claim a successful Xcode build.
- TorBox cloud API does not establish that incomplete Usenet files are HTTP-streamable. No client patch can guarantee progressive TorBox cloud playback absent a supported server endpoint.
